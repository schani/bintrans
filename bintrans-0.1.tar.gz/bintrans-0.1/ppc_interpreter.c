void interpret_ppc_insn (interpreter_t *intp) {
word_32 insn = mem_get_32(intp, intp->pc);
word_32 pc = intp->pc, next_pc = pc + 4;
switch (((insn >> 26) & 0x3F)) {
case 27:
/* XORIS */
if ((insn & 0xFC000000) != 0x6C000000) bt_assert(0);
({ word_32 tmp_0 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) ^ (((insn >> 0) & 0xFFFF) << 16)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_0); });
break;
case 26:
/* XORI */
if ((insn & 0xFC000000) != 0x68000000) bt_assert(0);
({ word_32 tmp_1 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) ^ ((insn >> 0) & 0xFFFF)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1); });
break;
case 31:
switch (((insn >> 0) & 0x7FF)) {
case 633:
/* XOR. */
if ((insn & 0xFC0007FF) != 0x7C000279) bt_assert(0);
({ word_32 tmp_2 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) ^ (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_2); });
({ word_1 tmp_3 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_3 << (1 * 31))); });
({ word_1 tmp_4 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_4 << (1 * 30))); });
({ word_1 tmp_5 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_5 << (1 * 29))); });
({ word_1 tmp_6 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_6 << (1 * 28))); });
break;
case 632:
/* XOR */
if ((insn & 0xFC0007FF) != 0x7C000278) bt_assert(0);
({ word_32 tmp_7 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) ^ (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_7); });
break;
case 1196:
/* SYNC */
if ((insn & 0xFFFFFFFF) != 0x7C0004AC) bt_assert(0);
0 /* nop */;
break;
case 1425:
/* SUBFZEO. */
if ((insn & 0xFC00FFFF) != 0x7C000591) bt_assert(0);
({
word_32 tmp_8 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_9 = (((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_9); });
({ word_1 tmp_10 = addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_10 << 29)); });
})
;
({ bt_assert(0); 0; }) /* not implemented */;
({ word_1 tmp_11 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_11 << (1 * 31))); });
({ word_1 tmp_12 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_12 << (1 * 30))); });
({ word_1 tmp_13 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_13 << (1 * 29))); });
({ word_1 tmp_14 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_14 << (1 * 28))); });
break;
case 1424:
/* SUBFZEO */
if ((insn & 0xFC00FFFF) != 0x7C000590) bt_assert(0);
({
word_32 tmp_15 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_16 = (((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_16); });
({ word_1 tmp_17 = addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_17 << 29)); });
})
;
({ bt_assert(0); 0; }) /* not implemented */;
break;
case 401:
/* SUBFZE. */
if ((insn & 0xFC00FFFF) != 0x7C000191) bt_assert(0);
({
word_32 tmp_18 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_19 = (((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_19); });
({ word_1 tmp_20 = addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_20 << 29)); });
})
;
({ word_1 tmp_21 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_21 << (1 * 31))); });
({ word_1 tmp_22 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_22 << (1 * 30))); });
({ word_1 tmp_23 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_23 << (1 * 29))); });
({ word_1 tmp_24 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_24 << (1 * 28))); });
break;
case 400:
/* SUBFZE */
if ((insn & 0xFC00FFFF) != 0x7C000190) bt_assert(0);
({
word_32 tmp_25 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_26 = (((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_26); });
({ word_1 tmp_27 = addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_27 << 29)); });
})
;
break;
case 1489:
/* SUBFMEO. */
if ((insn & 0xFC00FFFF) != 0x7C0005D1) bt_assert(0);
({
word_32 tmp_28 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_29 = ((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)) - 1); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_29); });
({ word_1 tmp_30 = ((addcarry_32(((word_32)~tmp_28), ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((((word_32)~tmp_28) + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_30 << 29)); });
})
;
({ bt_assert(0); 0; }) /* not implemented */;
({ word_1 tmp_31 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_31 << (1 * 31))); });
({ word_1 tmp_32 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_32 << (1 * 30))); });
({ word_1 tmp_33 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_33 << (1 * 29))); });
({ word_1 tmp_34 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_34 << (1 * 28))); });
break;
case 1488:
/* SUBFMEO */
if ((insn & 0xFC00FFFF) != 0x7C0005D0) bt_assert(0);
({
word_32 tmp_35 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_36 = ((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)) - 1); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_36); });
({ word_1 tmp_37 = ((addcarry_32(((word_32)~tmp_35), ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((((word_32)~tmp_35) + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_37 << 29)); });
})
;
({ bt_assert(0); 0; }) /* not implemented */;
break;
case 465:
/* SUBFME. */
if ((insn & 0xFC00FFFF) != 0x7C0001D1) bt_assert(0);
({
word_32 tmp_38 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_39 = ((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)) - 1); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_39); });
({ word_1 tmp_40 = ((addcarry_32(((word_32)~tmp_38), ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((((word_32)~tmp_38) + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_40 << 29)); });
})
;
({ word_1 tmp_41 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_41 << (1 * 31))); });
({ word_1 tmp_42 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_42 << (1 * 30))); });
({ word_1 tmp_43 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_43 << (1 * 29))); });
({ word_1 tmp_44 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_44 << (1 * 28))); });
break;
case 464:
/* SUBFME */
if ((insn & 0xFC00FFFF) != 0x7C0001D0) bt_assert(0);
({
word_32 tmp_45 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_46 = ((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)) - 1); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_46); });
({ word_1 tmp_47 = ((addcarry_32(((word_32)~tmp_45), ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((((word_32)~tmp_45) + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_47 << 29)); });
})
;
break;
case 1297:
/* SUBFEO. */
if ((insn & 0xFC0007FF) != 0x7C000511) bt_assert(0);
({
word_32 tmp_48 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
word_32 tmp_49 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_50 = (tmp_48 - (tmp_49 + (((intp->regs_SPR[2] >> 29) & 0x1) ^ 1))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_50); });
({ word_1 tmp_51 = ((addcarry_32(((word_32)~tmp_49), tmp_48) | addcarry_32((((word_32)~tmp_49) + tmp_48), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_51 << 29)); });
})
;
({ bt_assert(0); 0; }) /* not implemented */;
({ word_1 tmp_52 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_52 << (1 * 31))); });
({ word_1 tmp_53 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_53 << (1 * 30))); });
({ word_1 tmp_54 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_54 << (1 * 29))); });
({ word_1 tmp_55 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_55 << (1 * 28))); });
break;
case 1296:
/* SUBFEO */
if ((insn & 0xFC0007FF) != 0x7C000510) bt_assert(0);
({
word_32 tmp_56 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
word_32 tmp_57 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_58 = (tmp_56 - (tmp_57 + (((intp->regs_SPR[2] >> 29) & 0x1) ^ 1))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_58); });
({ word_1 tmp_59 = ((addcarry_32(((word_32)~tmp_57), tmp_56) | addcarry_32((((word_32)~tmp_57) + tmp_56), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_59 << 29)); });
})
;
({ bt_assert(0); 0; }) /* not implemented */;
break;
case 273:
/* SUBFE. */
if ((insn & 0xFC0007FF) != 0x7C000111) bt_assert(0);
({
word_32 tmp_60 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
word_32 tmp_61 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_62 = (tmp_60 - (tmp_61 + (((intp->regs_SPR[2] >> 29) & 0x1) ^ 1))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_62); });
({ word_1 tmp_63 = ((addcarry_32(((word_32)~tmp_61), tmp_60) | addcarry_32((((word_32)~tmp_61) + tmp_60), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_63 << 29)); });
})
;
({ word_1 tmp_64 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_64 << (1 * 31))); });
({ word_1 tmp_65 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_65 << (1 * 30))); });
({ word_1 tmp_66 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_66 << (1 * 29))); });
({ word_1 tmp_67 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_67 << (1 * 28))); });
break;
case 272:
/* SUBFE */
if ((insn & 0xFC0007FF) != 0x7C000110) bt_assert(0);
({
word_32 tmp_68 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
word_32 tmp_69 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_70 = (tmp_68 - (tmp_69 + (((intp->regs_SPR[2] >> 29) & 0x1) ^ 1))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_70); });
({ word_1 tmp_71 = ((addcarry_32(((word_32)~tmp_69), tmp_68) | addcarry_32((((word_32)~tmp_69) + tmp_68), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_71 << 29)); });
})
;
break;
case 1041:
/* SUBFCO. */
if ((insn & 0xFC0007FF) != 0x7C000411) bt_assert(0);
({ word_1 tmp_72 = ((addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), (intp->regs_GPR[((insn >> 11) & 0x1F)])) | addcarry_32((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), 1)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_72 << 29)); });
({ word_32 tmp_73 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_73); });
({ bt_assert(0); 0; }) /* not implemented */;
({ word_1 tmp_74 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_74 << (1 * 31))); });
({ word_1 tmp_75 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_75 << (1 * 30))); });
({ word_1 tmp_76 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_76 << (1 * 29))); });
({ word_1 tmp_77 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_77 << (1 * 28))); });
break;
case 1040:
/* SUBFCO */
if ((insn & 0xFC0007FF) != 0x7C000410) bt_assert(0);
({ word_1 tmp_78 = ((addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), (intp->regs_GPR[((insn >> 11) & 0x1F)])) | addcarry_32((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), 1)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_78 << 29)); });
({ word_32 tmp_79 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_79); });
({ bt_assert(0); 0; }) /* not implemented */;
break;
case 17:
/* SUBFC. */
if ((insn & 0xFC0007FF) != 0x7C000011) bt_assert(0);
({ word_1 tmp_80 = ((addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), (intp->regs_GPR[((insn >> 11) & 0x1F)])) | addcarry_32((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), 1)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_80 << 29)); });
({ word_32 tmp_81 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_81); });
({ word_1 tmp_82 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_82 << (1 * 31))); });
({ word_1 tmp_83 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_83 << (1 * 30))); });
({ word_1 tmp_84 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_84 << (1 * 29))); });
({ word_1 tmp_85 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_85 << (1 * 28))); });
break;
case 16:
/* SUBFC */
if ((insn & 0xFC0007FF) != 0x7C000010) bt_assert(0);
({ word_1 tmp_86 = ((addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), (intp->regs_GPR[((insn >> 11) & 0x1F)])) | addcarry_32((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), 1)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_86 << 29)); });
({ word_32 tmp_87 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_87); });
break;
case 1105:
/* SUBFO. */
if ((insn & 0xFC0007FF) != 0x7C000451) bt_assert(0);
({ word_32 tmp_88 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_88); });
({ bt_assert(0); 0; }) /* not implemented */;
({ word_1 tmp_89 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_89 << (1 * 31))); });
({ word_1 tmp_90 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_90 << (1 * 30))); });
({ word_1 tmp_91 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_91 << (1 * 29))); });
({ word_1 tmp_92 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_92 << (1 * 28))); });
break;
case 1104:
/* SUBFO */
if ((insn & 0xFC0007FF) != 0x7C000450) bt_assert(0);
({ word_32 tmp_93 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_93); });
({ bt_assert(0); 0; }) /* not implemented */;
break;
case 81:
/* SUBF. */
if ((insn & 0xFC0007FF) != 0x7C000051) bt_assert(0);
({ word_32 tmp_94 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_94); });
({ word_1 tmp_95 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_95 << (1 * 31))); });
({ word_1 tmp_96 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_96 << (1 * 30))); });
({ word_1 tmp_97 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_97 << (1 * 29))); });
({ word_1 tmp_98 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_98 << (1 * 28))); });
break;
case 80:
/* SUBF */
if ((insn & 0xFC0007FF) != 0x7C000050) bt_assert(0);
({ word_32 tmp_99 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_99); });
break;
case 302:
/* STWX */
if ((insn & 0xFC0007FF) != 0x7C00012E) bt_assert(0);
({ word_32 tmp_100 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); mem_set_32(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_100); });
break;
case 366:
/* STWUX */
if ((insn & 0xFC0007FF) != 0x7C00016E) bt_assert(0);
({ word_32 tmp_101 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); mem_set_32(intp, ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_101); });
({ word_32 tmp_102 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_102); });
break;
case 1324:
/* STWBRX */
if ((insn & 0xFC0007FF) != 0x7C00052C) bt_assert(0);
({ word_32 tmp_103 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); mem_set_32(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_103); });
break;
case 814:
/* STHX */
if ((insn & 0xFC0007FF) != 0x7C00032E) bt_assert(0);
({ word_16 tmp_104 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF); mem_set_16(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_104); });
break;
case 1836:
/* STHBRX */
if ((insn & 0xFC0007FF) != 0x7C00072C) bt_assert(0);
({ word_16 tmp_105 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF); mem_set_16(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_105); });
break;
case 1326:
/* STFSX */
if ((insn & 0xFC0007FF) != 0x7C00052E) bt_assert(0);
({ word_32 tmp_106 = ({ float tmp = ((float)(intp->regs_FPR[((insn >> 21) & 0x1F)])); *(word_32*)&tmp; }); mem_set_32(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_106); });
break;
case 1454:
/* STFDX */
if ((insn & 0xFC0007FF) != 0x7C0005AE) bt_assert(0);
({ word_64 tmp_107 = ({ double tmp = (intp->regs_FPR[((insn >> 21) & 0x1F)]); *(word_64*)&tmp; }); mem_set_64(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_107); });
break;
case 430:
/* STBX */
if ((insn & 0xFC0007FF) != 0x7C0001AE) bt_assert(0);
({ word_8 tmp_108 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFF); mem_set_8(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_108); });
break;
case 1073:
/* SRW. */
if ((insn & 0xFC0007FF) != 0x7C000431) bt_assert(0);
({ word_32 tmp_109 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_109); });
({ word_1 tmp_110 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_110 << (1 * 31))); });
({ word_1 tmp_111 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_111 << (1 * 30))); });
({ word_1 tmp_112 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_112 << (1 * 29))); });
({ word_1 tmp_113 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_113 << (1 * 28))); });
break;
case 1072:
/* SRW */
if ((insn & 0xFC0007FF) != 0x7C000430) bt_assert(0);
({ word_32 tmp_114 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_114); });
break;
case 1649:
/* SRAWI. */
if ((insn & 0xFC0007FF) != 0x7C000671) bt_assert(0);
({ word_1 tmp_115 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? (((((1 << ((insn >> 11) & 0x1F)) - 1) & (intp->regs_GPR[((insn >> 21) & 0x1F)])) == 0) ? 0 : 1) : 0); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_115 << 29)); });
({ word_32 tmp_116 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> ((insn >> 11) & 0x1F)) | (((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (1 << 31)) ? ~((1 << (32 - ((insn >> 11) & 0x1F))) - 1) : 0)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_116); });
({ word_1 tmp_117 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_117 << (1 * 31))); });
({ word_1 tmp_118 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_118 << (1 * 30))); });
({ word_1 tmp_119 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_119 << (1 * 29))); });
({ word_1 tmp_120 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_120 << (1 * 28))); });
break;
case 1648:
/* SRAWI */
if ((insn & 0xFC0007FF) != 0x7C000670) bt_assert(0);
({ word_1 tmp_121 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? (((((1 << ((insn >> 11) & 0x1F)) - 1) & (intp->regs_GPR[((insn >> 21) & 0x1F)])) == 0) ? 0 : 1) : 0); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_121 << 29)); });
({ word_32 tmp_122 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> ((insn >> 11) & 0x1F)) | (((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (1 << 31)) ? ~((1 << (32 - ((insn >> 11) & 0x1F))) - 1) : 0)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_122); });
break;
case 1585:
/* SRAW. */
if ((insn & 0xFC0007FF) != 0x7C000631) bt_assert(0);
({ word_1 tmp_123 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? (((((1 << ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)) - 1) & (intp->regs_GPR[((insn >> 21) & 0x1F)])) == 0) ? 0 : 1) : 0); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_123 << 29)); });
({ word_32 tmp_124 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)) | (((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (1 << 31)) ? ~((1 << (32 - ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31))) - 1) : 0)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_124); });
({ word_1 tmp_125 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_125 << (1 * 31))); });
({ word_1 tmp_126 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_126 << (1 * 30))); });
({ word_1 tmp_127 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_127 << (1 * 29))); });
({ word_1 tmp_128 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_128 << (1 * 28))); });
break;
case 1584:
/* SRAW */
if ((insn & 0xFC0007FF) != 0x7C000630) bt_assert(0);
({ word_1 tmp_129 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? (((((1 << ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)) - 1) & (intp->regs_GPR[((insn >> 21) & 0x1F)])) == 0) ? 0 : 1) : 0); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_129 << 29)); });
({ word_32 tmp_130 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)) | (((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (1 << 31)) ? ~((1 << (32 - ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31))) - 1) : 0)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_130); });
break;
case 49:
/* SLW. */
if ((insn & 0xFC0007FF) != 0x7C000031) bt_assert(0);
({ word_32 tmp_131 = (((intp->regs_GPR[((insn >> 11) & 0x1F)]) & (1 << 5)) ? 0 : ((intp->regs_GPR[((insn >> 21) & 0x1F)]) << (((intp->regs_GPR[((insn >> 11) & 0x1F)]) >> 0) & 0x1F))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_131); });
({ word_1 tmp_132 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_132 << (1 * 31))); });
({ word_1 tmp_133 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_133 << (1 * 30))); });
({ word_1 tmp_134 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_134 << (1 * 29))); });
({ word_1 tmp_135 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_135 << (1 * 28))); });
break;
case 48:
/* SLW */
if ((insn & 0xFC0007FF) != 0x7C000030) bt_assert(0);
({ word_32 tmp_136 = (((intp->regs_GPR[((insn >> 11) & 0x1F)]) & (1 << 5)) ? 0 : ((intp->regs_GPR[((insn >> 21) & 0x1F)]) << (((intp->regs_GPR[((insn >> 11) & 0x1F)]) >> 0) & 0x1F))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_136); });
break;
case 825:
/* ORC. */
if ((insn & 0xFC0007FF) != 0x7C000339) bt_assert(0);
({ word_32 tmp_137 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) | ((word_32)~(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_137); });
({ word_1 tmp_138 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_138 << (1 * 31))); });
({ word_1 tmp_139 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_139 << (1 * 30))); });
({ word_1 tmp_140 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_140 << (1 * 29))); });
({ word_1 tmp_141 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_141 << (1 * 28))); });
break;
case 824:
/* ORC */
if ((insn & 0xFC0007FF) != 0x7C000338) bt_assert(0);
({ word_32 tmp_142 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) | ((word_32)~(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_142); });
break;
case 889:
/* OR. */
if ((insn & 0xFC0007FF) != 0x7C000379) bt_assert(0);
({ word_32 tmp_143 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) | (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_143); });
({ word_1 tmp_144 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_144 << (1 * 31))); });
({ word_1 tmp_145 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_145 << (1 * 30))); });
({ word_1 tmp_146 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_146 << (1 * 29))); });
({ word_1 tmp_147 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_147 << (1 * 28))); });
break;
case 888:
/* OR */
if ((insn & 0xFC0007FF) != 0x7C000378) bt_assert(0);
({ word_32 tmp_148 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) | (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_148); });
break;
case 249:
/* NOR. */
if ((insn & 0xFC0007FF) != 0x7C0000F9) bt_assert(0);
({ word_32 tmp_149 = ((word_32)~((intp->regs_GPR[((insn >> 21) & 0x1F)]) | (intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_149); });
({ word_1 tmp_150 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_150 << (1 * 31))); });
({ word_1 tmp_151 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_151 << (1 * 30))); });
({ word_1 tmp_152 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_152 << (1 * 29))); });
({ word_1 tmp_153 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_153 << (1 * 28))); });
break;
case 248:
/* NOR */
if ((insn & 0xFC0007FF) != 0x7C0000F8) bt_assert(0);
({ word_32 tmp_154 = ((word_32)~((intp->regs_GPR[((insn >> 21) & 0x1F)]) | (intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_154); });
break;
case 1233:
/* NEGO. */
if ((insn & 0xFC00FFFF) != 0x7C0004D1) bt_assert(0);
({ word_32 tmp_155 = ((word_32)-(intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_155); });
({ bt_assert(0); 0; }) /* not implemented */;
({ word_1 tmp_156 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_156 << (1 * 31))); });
({ word_1 tmp_157 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_157 << (1 * 30))); });
({ word_1 tmp_158 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_158 << (1 * 29))); });
({ word_1 tmp_159 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_159 << (1 * 28))); });
break;
case 1232:
/* NEGO */
if ((insn & 0xFC00FFFF) != 0x7C0004D0) bt_assert(0);
({ word_32 tmp_160 = ((word_32)-(intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_160); });
({ bt_assert(0); 0; }) /* not implemented */;
break;
case 209:
/* NEG. */
if ((insn & 0xFC00FFFF) != 0x7C0000D1) bt_assert(0);
({ word_32 tmp_161 = ((word_32)-(intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_161); });
({ word_1 tmp_162 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_162 << (1 * 31))); });
({ word_1 tmp_163 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_163 << (1 * 30))); });
({ word_1 tmp_164 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_164 << (1 * 29))); });
({ word_1 tmp_165 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_165 << (1 * 28))); });
break;
case 208:
/* NEG */
if ((insn & 0xFC00FFFF) != 0x7C0000D0) bt_assert(0);
({ word_32 tmp_166 = ((word_32)-(intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_166); });
break;
case 953:
/* NAND. */
if ((insn & 0xFC0007FF) != 0x7C0003B9) bt_assert(0);
({ word_32 tmp_167 = ((word_32)~((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_167); });
({ word_1 tmp_168 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_168 << (1 * 31))); });
({ word_1 tmp_169 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_169 << (1 * 30))); });
({ word_1 tmp_170 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_170 << (1 * 29))); });
({ word_1 tmp_171 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_171 << (1 * 28))); });
break;
case 952:
/* NAND */
if ((insn & 0xFC0007FF) != 0x7C0003B8) bt_assert(0);
({ word_32 tmp_172 = ((word_32)~((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_172); });
break;
case 1495:
/* MULLWO. */
if ((insn & 0xFC0007FF) != 0x7C0005D7) bt_assert(0);
({ word_32 tmp_173 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) * (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_173); });
({ bt_assert(0); 0; }) /* not implemented */;
({ word_1 tmp_174 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_174 << (1 * 31))); });
({ word_1 tmp_175 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_175 << (1 * 30))); });
({ word_1 tmp_176 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_176 << (1 * 29))); });
({ word_1 tmp_177 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_177 << (1 * 28))); });
break;
case 1494:
/* MULLWO */
if ((insn & 0xFC0007FF) != 0x7C0005D6) bt_assert(0);
({ word_32 tmp_178 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) * (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_178); });
({ bt_assert(0); 0; }) /* not implemented */;
break;
case 471:
/* MULLW. */
if ((insn & 0xFC0007FF) != 0x7C0001D7) bt_assert(0);
({ word_32 tmp_179 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) * (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_179); });
({ word_1 tmp_180 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_180 << (1 * 31))); });
({ word_1 tmp_181 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_181 << (1 * 30))); });
({ word_1 tmp_182 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_182 << (1 * 29))); });
({ word_1 tmp_183 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_183 << (1 * 28))); });
break;
case 470:
/* MULLW */
if ((insn & 0xFC0007FF) != 0x7C0001D6) bt_assert(0);
({ word_32 tmp_184 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) * (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_184); });
break;
case 22:
/* MULHWU */
if ((insn & 0xFC0007FF) != 0x7C000016) bt_assert(0);
({ word_32 tmp_185 = ((word_32)((((word_64)(intp->regs_GPR[((insn >> 16) & 0x1F)])) * ((word_64)(intp->regs_GPR[((insn >> 11) & 0x1F)]))) >> 32)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_185); });
break;
case 150:
/* MULHW */
if ((insn & 0xFC0007FF) != 0x7C000096) bt_assert(0);
({ word_32 tmp_186 = ((word_32)(((((intp->regs_GPR[((insn >> 16) & 0x1F)]) & 0x80000000) ? ((word_64)(intp->regs_GPR[((insn >> 16) & 0x1F)]) | 0xFFFFFFFF00000000) : (word_64)(intp->regs_GPR[((insn >> 16) & 0x1F)])) * (((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 0x80000000) ? ((word_64)(intp->regs_GPR[((insn >> 11) & 0x1F)]) | 0xFFFFFFFF00000000) : (word_64)(intp->regs_GPR[((insn >> 11) & 0x1F)]))) >> 32)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_186); });
break;
case 934:
switch (((insn >> 11) & 0x3FF)) {
case 32:
/* MTXER */
if ((insn & 0xFC1FFFFF) != 0x7C0103A6) bt_assert(0);
({ word_32 tmp_187 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); ((intp->regs_SPR[2]) = tmp_187); });
break;
case 256:
/* MTLR */
if ((insn & 0xFC1FFFFF) != 0x7C0803A6) bt_assert(0);
({ word_32 tmp_188 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); ((intp->regs_SPR[0]) = tmp_188); });
break;
case 288:
/* MTCTR */
if ((insn & 0xFC1FFFFF) != 0x7C0903A6) bt_assert(0);
({ word_32 tmp_189 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); ((intp->regs_SPR[3]) = tmp_189); });
break;
default:
bt_assert(0);
}
break;
case 288:
/* MTCRF */
if ((insn & 0xFC100FFF) != 0x7C000120) bt_assert(0);
({ word_32 tmp_190 = (((intp->regs_SPR[1]) & ((word_32)~maskmask(4, 8, ((insn >> 12) & 0xFF)))) | ((intp->regs_GPR[((insn >> 21) & 0x1F)]) & maskmask(4, 8, ((insn >> 12) & 0xFF)))); ((intp->regs_SPR[1]) = tmp_190); });
break;
case 678:
switch (((insn >> 11) & 0x3FF)) {
case 32:
/* MFXER */
if ((insn & 0xFC1FFFFF) != 0x7C0102A6) bt_assert(0);
({ word_32 tmp_191 = (intp->regs_SPR[2]); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_191); });
break;
case 256:
/* MFLR */
if ((insn & 0xFC1FFFFF) != 0x7C0802A6) bt_assert(0);
({ word_32 tmp_192 = (intp->regs_SPR[0]); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_192); });
break;
case 288:
/* MFCTR */
if ((insn & 0xFC1FFFFF) != 0x7C0902A6) bt_assert(0);
({ word_32 tmp_193 = (intp->regs_SPR[3]); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_193); });
break;
default:
bt_assert(0);
}
break;
case 38:
/* MFCR */
if ((insn & 0xFC1FFFFF) != 0x7C000026) bt_assert(0);
({ word_32 tmp_194 = (intp->regs_SPR[1]); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_194); });
break;
case 1024:
/* MCRXR */
if ((insn & 0xFC7FFFFF) != 0x7C000400) bt_assert(0);
({ word_4 tmp_195 = (((intp->regs_SPR[2]) >> (4 * 7)) & ((1 << 4) - 1)); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(4 * ((7 - ((insn >> 23) & 0x7)) & 0x7), 4 * ((7 - ((insn >> 23) & 0x7)) & 0x7) + 4 - 1)) | (tmp_195 << (4 * ((7 - ((insn >> 23) & 0x7)) & 0x7)))); });
break;
case 46:
/* LWZX */
if ((insn & 0xFC0007FF) != 0x7C00002E) bt_assert(0);
({ word_32 tmp_196 = mem_get_32(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_196); });
break;
case 110:
/* LWZUX */
if ((insn & 0xFC0007FF) != 0x7C00006E) bt_assert(0);
({
word_32 tmp_197 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)]));
({ word_32 tmp_198 = mem_get_32(intp, tmp_197); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_198); });
({ word_32 tmp_199 = tmp_197; ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_199); });
})
;
break;
case 1068:
/* LWBRX */
if ((insn & 0xFC0007FF) != 0x7C00042C) bt_assert(0);
({ word_32 tmp_200 = mem_get_32(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_200); });
break;
case 558:
/* LHZX */
if ((insn & 0xFC0007FF) != 0x7C00022E) bt_assert(0);
({ word_32 tmp_201 = mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_201); });
break;
case 1580:
/* LHBRX */
if ((insn & 0xFC0007FF) != 0x7C00062C) bt_assert(0);
({ word_32 tmp_202 = mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_202); });
break;
case 686:
/* LHAX */
if ((insn & 0xFC0007FF) != 0x7C0002AE) bt_assert(0);
({ word_32 tmp_203 = ((mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))) & 0x8000) ? ((word_32)mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))) | 0xFFFF0000) : (word_32)mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)]))))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_203); });
break;
case 1070:
/* LFSX */
if ((insn & 0xFC0007FF) != 0x7C00042E) bt_assert(0);
({ double tmp_204 = ((double)({ word_32 tmp = mem_get_32(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))); *(float*)&tmp; })); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_204); });
break;
case 1198:
/* LFDX */
if ((insn & 0xFC0007FF) != 0x7C0004AE) bt_assert(0);
({ double tmp_205 = ({ word_64 tmp = mem_get_64(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))); *(double*)&tmp; }); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_205); });
break;
case 174:
/* LBZX */
if ((insn & 0xFC0007FF) != 0x7C0000AE) bt_assert(0);
({ word_32 tmp_206 = mem_get_8(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_206); });
break;
case 238:
/* LBZUX */
if ((insn & 0xFC0007FF) != 0x7C0000EE) bt_assert(0);
({
word_32 tmp_207 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)]));
({ word_32 tmp_208 = mem_get_8(intp, tmp_207); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_208); });
({ word_32 tmp_209 = tmp_207; ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_209); });
})
;
break;
case 1964:
/* ICBI */
if ((insn & 0xFFE007FF) != 0x7C0007AC) bt_assert(0);
0 /* ignore */;
break;
case 1845:
/* EXTSH. */
if ((insn & 0xFC00FFFF) != 0x7C000735) bt_assert(0);
({ word_32 tmp_210 = (((((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF) & 0x8000) ? ((word_32)(((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)(((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_210); });
({ word_1 tmp_211 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_211 << (1 * 31))); });
({ word_1 tmp_212 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_212 << (1 * 30))); });
({ word_1 tmp_213 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_213 << (1 * 29))); });
({ word_1 tmp_214 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_214 << (1 * 28))); });
break;
case 1844:
/* EXTSH */
if ((insn & 0xFC00FFFF) != 0x7C000734) bt_assert(0);
({ word_32 tmp_215 = (((((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF) & 0x8000) ? ((word_32)(((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)(((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_215); });
break;
case 1908:
/* EXTSB */
if ((insn & 0xFC00FFFF) != 0x7C000774) bt_assert(0);
({ word_32 tmp_216 = (((((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFF) & 0x80) ? ((word_32)(((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFF) | 0xFFFFFF00) : (word_32)(((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFF)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_216); });
break;
case 569:
/* EQV. */
if ((insn & 0xFC0007FF) != 0x7C000239) bt_assert(0);
({ word_32 tmp_217 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) ^ ((word_32)~(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_217); });
({ word_1 tmp_218 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_218 << (1 * 31))); });
({ word_1 tmp_219 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_219 << (1 * 30))); });
({ word_1 tmp_220 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_220 << (1 * 29))); });
({ word_1 tmp_221 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_221 << (1 * 28))); });
break;
case 568:
/* EQV */
if ((insn & 0xFC0007FF) != 0x7C000238) bt_assert(0);
({ word_32 tmp_222 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) ^ ((word_32)~(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_222); });
break;
case 1943:
/* DIVWUO. */
if ((insn & 0xFC0007FF) != 0x7C000797) bt_assert(0);
({ word_32 tmp_223 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) / (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_223); });
({ bt_assert(0); 0; }) /* not implemented */;
({ word_1 tmp_224 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_224 << (1 * 31))); });
({ word_1 tmp_225 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_225 << (1 * 30))); });
({ word_1 tmp_226 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_226 << (1 * 29))); });
({ word_1 tmp_227 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_227 << (1 * 28))); });
break;
case 1942:
/* DIVWUO */
if ((insn & 0xFC0007FF) != 0x7C000796) bt_assert(0);
({ word_32 tmp_228 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) / (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_228); });
({ bt_assert(0); 0; }) /* not implemented */;
break;
case 919:
/* DIVWU. */
if ((insn & 0xFC0007FF) != 0x7C000397) bt_assert(0);
({ word_32 tmp_229 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) / (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_229); });
({ word_1 tmp_230 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_230 << (1 * 31))); });
({ word_1 tmp_231 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_231 << (1 * 30))); });
({ word_1 tmp_232 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_232 << (1 * 29))); });
({ word_1 tmp_233 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_233 << (1 * 28))); });
break;
case 918:
/* DIVWU */
if ((insn & 0xFC0007FF) != 0x7C000396) bt_assert(0);
({ word_32 tmp_234 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) / (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_234); });
break;
case 2007:
/* DIVWO. */
if ((insn & 0xFC0007FF) != 0x7C0007D7) bt_assert(0);
({ word_32 tmp_235 = ((word_32)((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) / (sword_32)(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_235); });
({ bt_assert(0); 0; }) /* not implemented */;
({ word_1 tmp_236 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_236 << (1 * 31))); });
({ word_1 tmp_237 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_237 << (1 * 30))); });
({ word_1 tmp_238 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_238 << (1 * 29))); });
({ word_1 tmp_239 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_239 << (1 * 28))); });
break;
case 2006:
/* DIVWO */
if ((insn & 0xFC0007FF) != 0x7C0007D6) bt_assert(0);
({ word_32 tmp_240 = ((word_32)((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) / (sword_32)(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_240); });
({ bt_assert(0); 0; }) /* not implemented */;
break;
case 983:
/* DIVW. */
if ((insn & 0xFC0007FF) != 0x7C0003D7) bt_assert(0);
({ word_32 tmp_241 = ((word_32)((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) / (sword_32)(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_241); });
({ word_1 tmp_242 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_242 << (1 * 31))); });
({ word_1 tmp_243 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_243 << (1 * 30))); });
({ word_1 tmp_244 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_244 << (1 * 29))); });
({ word_1 tmp_245 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_245 << (1 * 28))); });
break;
case 982:
/* DIVW */
if ((insn & 0xFC0007FF) != 0x7C0003D6) bt_assert(0);
({ word_32 tmp_246 = ((word_32)((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) / (sword_32)(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_246); });
break;
case 2028:
/* DCBZ */
if ((insn & 0xFFE007FF) != 0x7C0007EC) bt_assert(0);
({
word_32 tmp_247 = ((((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])) & 4294967264);
({ word_32 tmp_248 = 0; mem_set_32(intp, tmp_247, tmp_248); });
({ word_32 tmp_249 = 0; mem_set_32(intp, (tmp_247 + 4), tmp_249); });
({ word_32 tmp_250 = 0; mem_set_32(intp, (tmp_247 + 8), tmp_250); });
({ word_32 tmp_251 = 0; mem_set_32(intp, (tmp_247 + 12), tmp_251); });
({ word_32 tmp_252 = 0; mem_set_32(intp, (tmp_247 + 16), tmp_252); });
({ word_32 tmp_253 = 0; mem_set_32(intp, (tmp_247 + 20), tmp_253); });
({ word_32 tmp_254 = 0; mem_set_32(intp, (tmp_247 + 24), tmp_254); });
({ word_32 tmp_255 = 0; mem_set_32(intp, (tmp_247 + 28), tmp_255); });
})
;
break;
case 108:
/* DCBST */
if ((insn & 0xFFE007FF) != 0x7C00006C) bt_assert(0);
0 /* ignore */;
break;
case 52:
/* CNTLZW */
if ((insn & 0xFC00FFFF) != 0x7C000034) bt_assert(0);
({ word_32 tmp_256 = leading_zeros((intp->regs_GPR[((insn >> 21) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_256); });
break;
case 0:
/* CMPW */
if ((insn & 0xFC6007FF) != 0x7C000000) bt_assert(0);
({ word_1 tmp_257 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)(intp->regs_GPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F) + 1 - 1)) | (tmp_257 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F)))); });
({ word_1 tmp_258 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)(intp->regs_GPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F) + 1 - 1)) | (tmp_258 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F)))); });
({ word_1 tmp_259 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == (intp->regs_GPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F) + 1 - 1)) | (tmp_259 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F)))); });
({ word_1 tmp_260 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F), 1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1 - 1)) | (tmp_260 << (1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F)))); });
break;
case 64:
/* CMPLW */
if ((insn & 0xFC6007FF) != 0x7C000040) bt_assert(0);
({ word_1 tmp_261 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) < (intp->regs_GPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F) + 1 - 1)) | (tmp_261 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F)))); });
({ word_1 tmp_262 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) > (intp->regs_GPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F) + 1 - 1)) | (tmp_262 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F)))); });
({ word_1 tmp_263 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == (intp->regs_GPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F) + 1 - 1)) | (tmp_263 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F)))); });
({ word_1 tmp_264 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F), 1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1 - 1)) | (tmp_264 << (1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F)))); });
break;
case 121:
/* ANDC. */
if ((insn & 0xFC0007FF) != 0x7C000079) bt_assert(0);
({ word_32 tmp_265 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) & ((word_32)~(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_265); });
({ word_1 tmp_266 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_266 << (1 * 31))); });
({ word_1 tmp_267 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_267 << (1 * 30))); });
({ word_1 tmp_268 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_268 << (1 * 29))); });
({ word_1 tmp_269 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_269 << (1 * 28))); });
break;
case 120:
/* ANDC */
if ((insn & 0xFC0007FF) != 0x7C000078) bt_assert(0);
({ word_32 tmp_270 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) & ((word_32)~(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_270); });
break;
case 57:
/* AND. */
if ((insn & 0xFC0007FF) != 0x7C000039) bt_assert(0);
({ word_32 tmp_271 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_271); });
({ word_1 tmp_272 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_272 << (1 * 31))); });
({ word_1 tmp_273 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_273 << (1 * 30))); });
({ word_1 tmp_274 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_274 << (1 * 29))); });
({ word_1 tmp_275 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_275 << (1 * 28))); });
break;
case 56:
/* AND */
if ((insn & 0xFC0007FF) != 0x7C000038) bt_assert(0);
({ word_32 tmp_276 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_276); });
break;
case 1429:
/* ADDZEO. */
if ((insn & 0xFC00FFFF) != 0x7C000595) bt_assert(0);
({
word_32 tmp_277 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_278 = (tmp_277 + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_278); });
({ word_1 tmp_279 = addcarry_32(tmp_277, ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_279 << 29)); });
})
;
({ bt_assert(0); 0; }) /* not implemented */;
({ word_1 tmp_280 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_280 << (1 * 31))); });
({ word_1 tmp_281 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_281 << (1 * 30))); });
({ word_1 tmp_282 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_282 << (1 * 29))); });
({ word_1 tmp_283 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_283 << (1 * 28))); });
break;
case 1428:
/* ADDZEO */
if ((insn & 0xFC00FFFF) != 0x7C000594) bt_assert(0);
({
word_32 tmp_284 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_285 = (tmp_284 + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_285); });
({ word_1 tmp_286 = addcarry_32(tmp_284, ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_286 << 29)); });
})
;
({ bt_assert(0); 0; }) /* not implemented */;
break;
case 405:
/* ADDZE. */
if ((insn & 0xFC00FFFF) != 0x7C000195) bt_assert(0);
({
word_32 tmp_287 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_288 = (tmp_287 + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_288); });
({ word_1 tmp_289 = addcarry_32(tmp_287, ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_289 << 29)); });
})
;
({ word_1 tmp_290 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_290 << (1 * 31))); });
({ word_1 tmp_291 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_291 << (1 * 30))); });
({ word_1 tmp_292 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_292 << (1 * 29))); });
({ word_1 tmp_293 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_293 << (1 * 28))); });
break;
case 404:
/* ADDZE */
if ((insn & 0xFC00FFFF) != 0x7C000194) bt_assert(0);
({
word_32 tmp_294 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_295 = (tmp_294 + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_295); });
({ word_1 tmp_296 = addcarry_32(tmp_294, ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_296 << 29)); });
})
;
break;
case 1493:
/* ADDMEO. */
if ((insn & 0xFC00FFFF) != 0x7C0005D5) bt_assert(0);
({
word_32 tmp_297 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_298 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((intp->regs_SPR[2] >> 29) & 0x1)) + 4294967295); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_298); });
({ word_1 tmp_299 = ((addcarry_32(tmp_297, ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((tmp_297 + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_299 << 29)); });
})
;
({ bt_assert(0); 0; }) /* not implemented */;
({ word_1 tmp_300 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_300 << (1 * 31))); });
({ word_1 tmp_301 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_301 << (1 * 30))); });
({ word_1 tmp_302 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_302 << (1 * 29))); });
({ word_1 tmp_303 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_303 << (1 * 28))); });
break;
case 1492:
/* ADDMEO */
if ((insn & 0xFC00FFFF) != 0x7C0005D4) bt_assert(0);
({
word_32 tmp_304 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_305 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((intp->regs_SPR[2] >> 29) & 0x1)) + 4294967295); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_305); });
({ word_1 tmp_306 = ((addcarry_32(tmp_304, ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((tmp_304 + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_306 << 29)); });
})
;
({ bt_assert(0); 0; }) /* not implemented */;
break;
case 469:
/* ADDME. */
if ((insn & 0xFC00FFFF) != 0x7C0001D5) bt_assert(0);
({
word_32 tmp_307 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_308 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((intp->regs_SPR[2] >> 29) & 0x1)) + 4294967295); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_308); });
({ word_1 tmp_309 = ((addcarry_32(tmp_307, ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((tmp_307 + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_309 << 29)); });
})
;
({ word_1 tmp_310 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_310 << (1 * 31))); });
({ word_1 tmp_311 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_311 << (1 * 30))); });
({ word_1 tmp_312 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_312 << (1 * 29))); });
({ word_1 tmp_313 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_313 << (1 * 28))); });
break;
case 468:
/* ADDME */
if ((insn & 0xFC00FFFF) != 0x7C0001D4) bt_assert(0);
({
word_32 tmp_314 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_315 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((intp->regs_SPR[2] >> 29) & 0x1)) + 4294967295); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_315); });
({ word_1 tmp_316 = ((addcarry_32(tmp_314, ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((tmp_314 + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_316 << 29)); });
})
;
break;
case 1301:
/* ADDEO. */
if ((insn & 0xFC0007FF) != 0x7C000515) bt_assert(0);
({
word_32 tmp_317 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
word_32 tmp_318 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
({ word_32 tmp_319 = ((tmp_317 + tmp_318) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_319); });
({ word_1 tmp_320 = ((addcarry_32(tmp_317, tmp_318) | addcarry_32((tmp_317 + tmp_318), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_320 << 29)); });
})
;
({ bt_assert(0); 0; }) /* not implemented */;
({ word_1 tmp_321 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_321 << (1 * 31))); });
({ word_1 tmp_322 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_322 << (1 * 30))); });
({ word_1 tmp_323 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_323 << (1 * 29))); });
({ word_1 tmp_324 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_324 << (1 * 28))); });
break;
case 1300:
/* ADDEO */
if ((insn & 0xFC0007FF) != 0x7C000514) bt_assert(0);
({
word_32 tmp_325 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
word_32 tmp_326 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
({ word_32 tmp_327 = ((tmp_325 + tmp_326) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_327); });
({ word_1 tmp_328 = ((addcarry_32(tmp_325, tmp_326) | addcarry_32((tmp_325 + tmp_326), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_328 << 29)); });
})
;
({ bt_assert(0); 0; }) /* not implemented */;
break;
case 277:
/* ADDE. */
if ((insn & 0xFC0007FF) != 0x7C000115) bt_assert(0);
({
word_32 tmp_329 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
word_32 tmp_330 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
({ word_32 tmp_331 = ((tmp_329 + tmp_330) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_331); });
({ word_1 tmp_332 = ((addcarry_32(tmp_329, tmp_330) | addcarry_32((tmp_329 + tmp_330), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_332 << 29)); });
})
;
({ word_1 tmp_333 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_333 << (1 * 31))); });
({ word_1 tmp_334 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_334 << (1 * 30))); });
({ word_1 tmp_335 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_335 << (1 * 29))); });
({ word_1 tmp_336 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_336 << (1 * 28))); });
break;
case 276:
/* ADDE */
if ((insn & 0xFC0007FF) != 0x7C000114) bt_assert(0);
({
word_32 tmp_337 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
word_32 tmp_338 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
({ word_32 tmp_339 = ((tmp_337 + tmp_338) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_339); });
({ word_1 tmp_340 = ((addcarry_32(tmp_337, tmp_338) | addcarry_32((tmp_337 + tmp_338), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_340 << 29)); });
})
;
break;
case 1045:
/* ADDCO. */
if ((insn & 0xFC0007FF) != 0x7C000415) bt_assert(0);
({ word_1 tmp_341 = addcarry_32((intp->regs_GPR[((insn >> 16) & 0x1F)]), (intp->regs_GPR[((insn >> 11) & 0x1F)])); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_341 << 29)); });
({ word_32 tmp_342 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_342); });
({ bt_assert(0); 0; }) /* not implemented */;
({ word_1 tmp_343 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_343 << (1 * 31))); });
({ word_1 tmp_344 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_344 << (1 * 30))); });
({ word_1 tmp_345 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_345 << (1 * 29))); });
({ word_1 tmp_346 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_346 << (1 * 28))); });
break;
case 1044:
/* ADDCO */
if ((insn & 0xFC0007FF) != 0x7C000414) bt_assert(0);
({ word_1 tmp_347 = addcarry_32((intp->regs_GPR[((insn >> 16) & 0x1F)]), (intp->regs_GPR[((insn >> 11) & 0x1F)])); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_347 << 29)); });
({ word_32 tmp_348 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_348); });
({ bt_assert(0); 0; }) /* not implemented */;
break;
case 21:
/* ADDC. */
if ((insn & 0xFC0007FF) != 0x7C000015) bt_assert(0);
({ word_1 tmp_349 = addcarry_32((intp->regs_GPR[((insn >> 16) & 0x1F)]), (intp->regs_GPR[((insn >> 11) & 0x1F)])); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_349 << 29)); });
({ word_32 tmp_350 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_350); });
({ word_1 tmp_351 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_351 << (1 * 31))); });
({ word_1 tmp_352 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_352 << (1 * 30))); });
({ word_1 tmp_353 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_353 << (1 * 29))); });
({ word_1 tmp_354 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_354 << (1 * 28))); });
break;
case 20:
/* ADDC */
if ((insn & 0xFC0007FF) != 0x7C000014) bt_assert(0);
({ word_1 tmp_355 = addcarry_32((intp->regs_GPR[((insn >> 16) & 0x1F)]), (intp->regs_GPR[((insn >> 11) & 0x1F)])); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_355 << 29)); });
({ word_32 tmp_356 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_356); });
break;
case 1557:
/* ADDO. */
if ((insn & 0xFC0007FF) != 0x7C000615) bt_assert(0);
({ word_32 tmp_357 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_357); });
({ bt_assert(0); 0; }) /* not implemented */;
({ word_1 tmp_358 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_358 << (1 * 31))); });
({ word_1 tmp_359 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_359 << (1 * 30))); });
({ word_1 tmp_360 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_360 << (1 * 29))); });
({ word_1 tmp_361 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_361 << (1 * 28))); });
break;
case 1556:
/* ADDO */
if ((insn & 0xFC0007FF) != 0x7C000614) bt_assert(0);
({ word_32 tmp_362 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_362); });
({ bt_assert(0); 0; }) /* not implemented */;
break;
case 533:
/* ADD. */
if ((insn & 0xFC0007FF) != 0x7C000215) bt_assert(0);
({ word_32 tmp_363 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_363); });
({ word_1 tmp_364 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_364 << (1 * 31))); });
({ word_1 tmp_365 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_365 << (1 * 30))); });
({ word_1 tmp_366 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_366 << (1 * 29))); });
({ word_1 tmp_367 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_367 << (1 * 28))); });
break;
case 532:
/* ADD */
if ((insn & 0xFC0007FF) != 0x7C000214) bt_assert(0);
({ word_32 tmp_368 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_368); });
break;
default:
bt_assert(0);
}
break;
case 8:
/* SUBFIC */
if ((insn & 0xFC000000) != 0x20000000) bt_assert(0);
({ word_1 tmp_369 = ((addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))) | addcarry_32((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), 1)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_369 << 29)); });
({ word_32 tmp_370 = (((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_370); });
break;
case 37:
/* STWU */
if ((insn & 0xFC000000) != 0x94000000) bt_assert(0);
({ word_32 tmp_371 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); mem_set_32(intp, ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), tmp_371); });
({ word_32 tmp_372 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_372); });
break;
case 36:
/* STW */
if ((insn & 0xFC000000) != 0x90000000) bt_assert(0);
({ word_32 tmp_373 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); mem_set_32(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), tmp_373); });
break;
case 45:
/* STHU */
if ((insn & 0xFC000000) != 0xB4000000) bt_assert(0);
({ word_16 tmp_374 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF); mem_set_16(intp, ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), tmp_374); });
({ word_32 tmp_375 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_375); });
break;
case 44:
/* STH */
if ((insn & 0xFC000000) != 0xB0000000) bt_assert(0);
({ word_16 tmp_376 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF); mem_set_16(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)))), tmp_376); });
break;
case 52:
/* STFS */
if ((insn & 0xFC000000) != 0xD0000000) bt_assert(0);
({ word_32 tmp_377 = ({ float tmp = ((float)(intp->regs_FPR[((insn >> 21) & 0x1F)])); *(word_32*)&tmp; }); mem_set_32(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), tmp_377); });
break;
case 55:
/* STFDU */
if ((insn & 0xFC000000) != 0xDC000000) bt_assert(0);
({ word_64 tmp_378 = ({ double tmp = (intp->regs_FPR[((insn >> 21) & 0x1F)]); *(word_64*)&tmp; }); mem_set_64(intp, ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), tmp_378); });
({ word_32 tmp_379 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_379); });
break;
case 54:
/* STFD */
if ((insn & 0xFC000000) != 0xD8000000) bt_assert(0);
({ word_64 tmp_380 = ({ double tmp = (intp->regs_FPR[((insn >> 21) & 0x1F)]); *(word_64*)&tmp; }); mem_set_64(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), tmp_380); });
break;
case 39:
/* STBU */
if ((insn & 0xFC000000) != 0x9C000000) bt_assert(0);
({ word_8 tmp_381 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFF); mem_set_8(intp, ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), tmp_381); });
({ word_32 tmp_382 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_382); });
break;
case 38:
/* STB */
if ((insn & 0xFC000000) != 0x98000000) bt_assert(0);
({ word_8 tmp_383 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFF); mem_set_8(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)))), tmp_383); });
break;
case 17:
/* SC */
if ((insn & 0xFFFFFFFF) != 0x44000002) bt_assert(0);
handle_system_call(intp);
break;
case 23:
switch (((insn >> 0) & 0x1)) {
case 1:
/* RLWNM. */
if ((insn & 0xFC000001) != 0x5C000001) bt_assert(0);
({ word_32 tmp_384 = (rotl_32((intp->regs_GPR[((insn >> 21) & 0x1F)]), ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)) & mask_32((31 - ((insn >> 1) & 0x1F)), (31 - ((insn >> 6) & 0x1F)))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_384); });
({ word_1 tmp_385 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_385 << (1 * 31))); });
({ word_1 tmp_386 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_386 << (1 * 30))); });
({ word_1 tmp_387 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_387 << (1 * 29))); });
({ word_1 tmp_388 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_388 << (1 * 28))); });
break;
case 0:
/* RLWNM */
if ((insn & 0xFC000001) != 0x5C000000) bt_assert(0);
({ word_32 tmp_389 = (rotl_32((intp->regs_GPR[((insn >> 21) & 0x1F)]), ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)) & mask_32((31 - ((insn >> 1) & 0x1F)), (31 - ((insn >> 6) & 0x1F)))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_389); });
break;
default:
bt_assert(0);
}
break;
case 21:
switch (((insn >> 0) & 0x1)) {
case 1:
/* RLWINM. */
if ((insn & 0xFC000001) != 0x54000001) bt_assert(0);
({ word_32 tmp_390 = (rotl_32((intp->regs_GPR[((insn >> 21) & 0x1F)]), ((insn >> 11) & 0x1F)) & mask_32((31 - ((insn >> 1) & 0x1F)), (31 - ((insn >> 6) & 0x1F)))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_390); });
({ word_1 tmp_391 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_391 << (1 * 31))); });
({ word_1 tmp_392 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_392 << (1 * 30))); });
({ word_1 tmp_393 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_393 << (1 * 29))); });
({ word_1 tmp_394 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_394 << (1 * 28))); });
break;
case 0:
/* RLWINM */
if ((insn & 0xFC000001) != 0x54000000) bt_assert(0);
({ word_32 tmp_395 = (rotl_32((intp->regs_GPR[((insn >> 21) & 0x1F)]), ((insn >> 11) & 0x1F)) & mask_32((31 - ((insn >> 1) & 0x1F)), (31 - ((insn >> 6) & 0x1F)))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_395); });
break;
default:
bt_assert(0);
}
break;
case 20:
/* RLWIMI */
if ((insn & 0xFC000001) != 0x50000000) bt_assert(0);
({ word_32 tmp_396 = ((rotl_32((intp->regs_GPR[((insn >> 21) & 0x1F)]), ((insn >> 11) & 0x1F)) & mask_32((31 - ((insn >> 1) & 0x1F)), (31 - ((insn >> 6) & 0x1F)))) | ((intp->regs_GPR[((insn >> 16) & 0x1F)]) & ((word_32)~mask_32((31 - ((insn >> 1) & 0x1F)), (31 - ((insn >> 6) & 0x1F)))))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_396); });
break;
case 25:
/* ORIS */
if ((insn & 0xFC000000) != 0x64000000) bt_assert(0);
({ word_32 tmp_397 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) | (((insn >> 0) & 0xFFFF) << 16)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_397); });
break;
case 24:
/* ORI */
if ((insn & 0xFC000000) != 0x60000000) bt_assert(0);
({ word_32 tmp_398 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) | ((insn >> 0) & 0xFFFF)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_398); });
break;
case 7:
/* MULLI */
if ((insn & 0xFC000000) != 0x1C000000) bt_assert(0);
({ word_32 tmp_399 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) * ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_399); });
break;
case 63:
switch (((insn >> 0) & 0x3F)) {
case 12:
switch (((insn >> 6) & 0x3F)) {
case 4:
/* MTFSFI */
if ((insn & 0xFC7F0FFF) != 0xFC00010C) bt_assert(0);
({ word_4 tmp_400 = ((insn >> 12) & 0xF); ((intp->regs_SPR[4]) = ((intp->regs_SPR[4]) & ~mask_32(4 * ((7 - ((insn >> 23) & 0x7)) & 0x7), 4 * ((7 - ((insn >> 23) & 0x7)) & 0x7) + 4 - 1)) | (tmp_400 << (4 * ((7 - ((insn >> 23) & 0x7)) & 0x7)))); });
break;
case 2:
/* MTFSB0 */
if ((insn & 0xFC1FFFFF) != 0xFC00008C) bt_assert(0);
({ word_1 tmp_401 = 0; ((intp->regs_SPR[4]) = ((intp->regs_SPR[4]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_401 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
default:
bt_assert(0);
}
break;
case 14:
switch (((insn >> 6) & 0x1F)) {
case 22:
/* MTFSF */
if ((insn & 0xFFFF07FF) != 0xFDFE058E) bt_assert(0);
({ word_32 tmp_402 = ((word_32)(({ double tmp = (intp->regs_FPR[((insn >> 11) & 0x1F)]); *(word_64*)&tmp; }) & 4294967295)); ((intp->regs_SPR[4]) = tmp_402); });
break;
case 18:
/* MFFS */
if ((insn & 0xFC1FFFFF) != 0xFC00048E) bt_assert(0);
({ double tmp_403 = ({ word_64 tmp = ((word_64)(intp->regs_SPR[4])); *(double*)&tmp; }); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_403); });
break;
default:
bt_assert(0);
}
break;
case 40:
/* FSUB */
if ((insn & 0xFC0007FF) != 0xFC000028) bt_assert(0);
({ double tmp_404 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) - (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_404); });
break;
case 24:
/* FRSP */
if ((insn & 0xFC1F07FF) != 0xFC000018) bt_assert(0);
({ double tmp_405 = (intp->regs_FPR[((insn >> 11) & 0x1F)]); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_405); });
break;
case 60:
/* FNMSUB */
if ((insn & 0xFC00003F) != 0xFC00003C) bt_assert(0);
({ double tmp_406 = (-(((intp->regs_FPR[((insn >> 16) & 0x1F)]) * (intp->regs_FPR[((insn >> 6) & 0x1F)])) - (intp->regs_FPR[((insn >> 11) & 0x1F)]))); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_406); });
break;
case 16:
switch (((insn >> 6) & 0x1F)) {
case 1:
/* FNEG */
if ((insn & 0xFC1F07FF) != 0xFC000050) bt_assert(0);
({ double tmp_407 = (-(intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_407); });
break;
case 2:
/* FMR */
if ((insn & 0xFC1F07FF) != 0xFC000090) bt_assert(0);
({ double tmp_408 = (intp->regs_FPR[((insn >> 11) & 0x1F)]); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_408); });
break;
case 8:
/* FABS */
if ((insn & 0xFC1F07FF) != 0xFC000210) bt_assert(0);
({ double tmp_409 = ({ word_64 tmp = (({ double tmp = (intp->regs_FPR[((insn >> 11) & 0x1F)]); *(word_64*)&tmp; }) & 9223372036854775807); *(double*)&tmp; }); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_409); });
break;
default:
bt_assert(0);
}
break;
case 50:
/* FMUL */
if ((insn & 0xFC00F83F) != 0xFC000032) bt_assert(0);
({ double tmp_410 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) * (intp->regs_FPR[((insn >> 6) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_410); });
break;
case 56:
/* FMSUB */
if ((insn & 0xFC00003F) != 0xFC000038) bt_assert(0);
({ double tmp_411 = (((intp->regs_FPR[((insn >> 16) & 0x1F)]) * (intp->regs_FPR[((insn >> 6) & 0x1F)])) - (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_411); });
break;
case 58:
/* FMADD */
if ((insn & 0xFC00003F) != 0xFC00003A) bt_assert(0);
({ double tmp_412 = (((intp->regs_FPR[((insn >> 16) & 0x1F)]) * (intp->regs_FPR[((insn >> 6) & 0x1F)])) + (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_412); });
break;
case 36:
/* FDIV */
if ((insn & 0xFC0007FF) != 0xFC000024) bt_assert(0);
({ double tmp_413 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) / (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_413); });
break;
case 30:
/* FCTIWZ */
if ((insn & 0xFC1F07FF) != 0xFC00001E) bt_assert(0);
({ double tmp_414 = ({ word_64 tmp = ((word_64)((word_32)(sword_32)(intp->regs_FPR[((insn >> 11) & 0x1F)]))); *(double*)&tmp; }); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_414); });
break;
case 0:
/* FCMPU */
if ((insn & 0xFC6007FF) != 0xFC000000) bt_assert(0);
({ word_1 tmp_415 = (((intp->regs_FPR[((insn >> 16) & 0x1F)]) < (intp->regs_FPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F) + 1 - 1)) | (tmp_415 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F)))); });
({ word_1 tmp_416 = (((intp->regs_FPR[((insn >> 16) & 0x1F)]) > (intp->regs_FPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F) + 1 - 1)) | (tmp_416 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F)))); });
({ word_1 tmp_417 = (((intp->regs_FPR[((insn >> 16) & 0x1F)]) == (intp->regs_FPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F) + 1 - 1)) | (tmp_417 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F)))); });
({ word_1 tmp_418 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F), 1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1 - 1)) | (tmp_418 << (1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F)))); });
break;
case 42:
/* FADD */
if ((insn & 0xFC0007FF) != 0xFC00002A) bt_assert(0);
({ double tmp_419 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) + (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_419); });
break;
default:
bt_assert(0);
}
break;
case 19:
switch (((insn >> 0) & 0x7FF)) {
case 0:
/* MCRF */
if ((insn & 0xFC63FFFF) != 0x4C000000) bt_assert(0);
({ word_4 tmp_420 = (((intp->regs_SPR[1]) >> (4 * ((7 - ((insn >> 18) & 0x7)) & 0x7))) & ((1 << 4) - 1)); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(4 * ((7 - ((insn >> 23) & 0x7)) & 0x7), 4 * ((7 - ((insn >> 23) & 0x7)) & 0x7) + 4 - 1)) | (tmp_420 << (4 * ((7 - ((insn >> 23) & 0x7)) & 0x7)))); });
break;
case 300:
/* ISYNC */
if ((insn & 0xFFFFFFFF) != 0x4C00012C) bt_assert(0);
0 /* nop */;
break;
case 386:
/* CRXOR */
if ((insn & 0xFC0007FF) != 0x4C000182) bt_assert(0);
({ word_1 tmp_421 = (((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) ^ (((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1))) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_421 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 834:
/* CRORC */
if ((insn & 0xFC0007FF) != 0x4C000342) bt_assert(0);
({ word_1 tmp_422 = (((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) | (((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) ^ 1) & 0x1)) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_422 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 898:
/* CROR */
if ((insn & 0xFC0007FF) != 0x4C000382) bt_assert(0);
({ word_1 tmp_423 = (((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) | (((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1))) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_423 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 66:
/* CRNOR */
if ((insn & 0xFC0007FF) != 0x4C000042) bt_assert(0);
({ word_1 tmp_424 = (((((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) | (((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1))) & 0x1) ^ 1) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_424 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 450:
/* CRNAND */
if ((insn & 0xFC0007FF) != 0x4C0001C2) bt_assert(0);
({ word_1 tmp_425 = (((((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) & (((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1))) & 0x1) ^ 1) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_425 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 578:
/* CREQV */
if ((insn & 0xFC0007FF) != 0x4C000242) bt_assert(0);
({ word_1 tmp_426 = (((((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) ^ (((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1))) & 0x1) ^ 1) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_426 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 258:
/* CRANDC */
if ((insn & 0xFC0007FF) != 0x4C000102) bt_assert(0);
({ word_1 tmp_427 = (((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) & (((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) ^ 1) & 0x1)) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_427 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 514:
/* CRAND */
if ((insn & 0xFC0007FF) != 0x4C000202) bt_assert(0);
({ word_1 tmp_428 = (((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) & (((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1))) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_428 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 32:
switch (((insn >> 11) & 0x1F)) {
case 0:
switch (((insn >> 21) & 0x1F)) {
case 5:
/* BNELR+ */
if ((insn & 0xFFE0FFFF) != 0x4CA00020) bt_assert(0);
intp->have_jumped = 1;
(((intp->regs_SPR[1]) & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) ? 0 /* nop */ : (next_pc = ((intp->regs_SPR[0]) & 4294967292)));
break;
case 4:
/* BNELR */
if ((insn & 0xFFE0FFFF) != 0x4C800020) bt_assert(0);
intp->have_jumped = 1;
(((intp->regs_SPR[1]) & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) ? 0 /* nop */ : (next_pc = ((intp->regs_SPR[0]) & 4294967292)));
break;
case 20:
/* BLR */
if ((insn & 0xFFE0FFFF) != 0x4E800020) bt_assert(0);
intp->have_jumped = 1;
(next_pc = ((intp->regs_SPR[0]) & 4294967292));
break;
case 12:
/* BEQLR */
if ((insn & 0xFFE0FFFF) != 0x4D800020) bt_assert(0);
intp->have_jumped = 1;
(((intp->regs_SPR[1]) & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) ? (next_pc = ((intp->regs_SPR[0]) & 4294967292)) : 0 /* nop */);
break;
default:
bt_assert(0);
}
break;
default:
bt_assert(0);
}
break;
case 33:
/* BLRL */
if ((insn & 0xFFE0FFFF) != 0x4E800021) bt_assert(0);
intp->have_jumped = 1;
({
word_32 tmp_429 = (intp->regs_SPR[0]);
({ word_32 tmp_430 = (pc + 4); ((intp->regs_SPR[0]) = tmp_430); });
(next_pc = (tmp_429 & 4294967292));
})
;
break;
case 1056:
/* BCTR */
if ((insn & 0xFFE0FFFF) != 0x4E800420) bt_assert(0);
intp->have_jumped = 1;
(next_pc = ((intp->regs_SPR[3]) & 4294967292));
break;
default:
bt_assert(0);
}
break;
case 33:
/* LWZU */
if ((insn & 0xFC000000) != 0x84000000) bt_assert(0);
({
word_32 tmp_431 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)));
({ word_32 tmp_432 = mem_get_32(intp, tmp_431); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_432); });
({ word_32 tmp_433 = tmp_431; ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_433); });
})
;
break;
case 32:
/* LWZ */
if ((insn & 0xFC000000) != 0x80000000) bt_assert(0);
({ word_32 tmp_434 = ((((insn >> 16) & 0x1F) == 0) ? mem_get_32(intp, ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))) : mem_get_32(intp, ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_434); });
break;
case 41:
/* LHZU */
if ((insn & 0xFC000000) != 0xA4000000) bt_assert(0);
({
word_32 tmp_435 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)));
({ word_32 tmp_436 = mem_get_16(intp, tmp_435); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_436); });
({ word_32 tmp_437 = tmp_435; ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_437); });
})
;
break;
case 40:
/* LHZ */
if ((insn & 0xFC000000) != 0xA0000000) bt_assert(0);
({ word_32 tmp_438 = mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_438); });
break;
case 43:
/* LHAU */
if ((insn & 0xFC000000) != 0xAC000000) bt_assert(0);
({
word_32 tmp_439 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)));
({ word_32 tmp_440 = ((mem_get_16(intp, tmp_439) & 0x8000) ? ((word_32)mem_get_16(intp, tmp_439) | 0xFFFF0000) : (word_32)mem_get_16(intp, tmp_439)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_440); });
({ word_32 tmp_441 = tmp_439; ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_441); });
})
;
break;
case 42:
/* LHA */
if ((insn & 0xFC000000) != 0xA8000000) bt_assert(0);
({ word_32 tmp_442 = ((mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))))) & 0x8000) ? ((word_32)mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))))) | 0xFFFF0000) : (word_32)mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)))))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_442); });
break;
case 48:
/* LFS */
if ((insn & 0xFC000000) != 0xC0000000) bt_assert(0);
({ double tmp_443 = ((double)({ word_32 tmp = mem_get_32(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))))); *(float*)&tmp; })); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_443); });
break;
case 50:
/* LFD */
if ((insn & 0xFC000000) != 0xC8000000) bt_assert(0);
({ double tmp_444 = ({ word_64 tmp = mem_get_64(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))))); *(double*)&tmp; }); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_444); });
break;
case 35:
/* LBZU */
if ((insn & 0xFC000000) != 0x8C000000) bt_assert(0);
({
word_32 tmp_445 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)));
({ word_32 tmp_446 = mem_get_8(intp, tmp_445); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_446); });
({ word_32 tmp_447 = tmp_445; ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_447); });
})
;
break;
case 34:
/* LBZ */
if ((insn & 0xFC000000) != 0x88000000) bt_assert(0);
({ word_32 tmp_448 = mem_get_8(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_448); });
break;
case 59:
switch (((insn >> 0) & 0x3F)) {
case 40:
/* FSUBS */
if ((insn & 0xFC0007FF) != 0xEC000028) bt_assert(0);
({ double tmp_449 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) - (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_449); });
break;
case 50:
/* FMULS */
if ((insn & 0xFC00F83F) != 0xEC000032) bt_assert(0);
({ double tmp_450 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) * (intp->regs_FPR[((insn >> 6) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_450); });
break;
case 56:
/* FMSUBS */
if ((insn & 0xFC00003F) != 0xEC000038) bt_assert(0);
({ double tmp_451 = (((intp->regs_FPR[((insn >> 16) & 0x1F)]) * (intp->regs_FPR[((insn >> 6) & 0x1F)])) - (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_451); });
break;
case 58:
/* FMADDS */
if ((insn & 0xFC00003F) != 0xEC00003A) bt_assert(0);
({ double tmp_452 = (((intp->regs_FPR[((insn >> 16) & 0x1F)]) * (intp->regs_FPR[((insn >> 6) & 0x1F)])) + (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_452); });
break;
case 36:
/* FDIVS */
if ((insn & 0xFC0007FF) != 0xEC000024) bt_assert(0);
({ double tmp_453 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) / (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_453); });
break;
case 42:
/* FADDS */
if ((insn & 0xFC0007FF) != 0xEC00002A) bt_assert(0);
({ double tmp_454 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) + (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_454); });
break;
default:
bt_assert(0);
}
break;
case 11:
/* CMPWI */
if ((insn & 0xFC600000) != 0x2C000000) bt_assert(0);
({ word_1 tmp_455 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F) + 1 - 1)) | (tmp_455 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F)))); });
({ word_1 tmp_456 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F) + 1 - 1)) | (tmp_456 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F)))); });
({ word_1 tmp_457 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F) + 1 - 1)) | (tmp_457 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F)))); });
({ word_1 tmp_458 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F), 1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1 - 1)) | (tmp_458 << (1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F)))); });
break;
case 10:
/* CMPLWI */
if ((insn & 0xFC600000) != 0x28000000) bt_assert(0);
({ word_1 tmp_459 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) < ((insn >> 0) & 0xFFFF)) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F) + 1 - 1)) | (tmp_459 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F)))); });
({ word_1 tmp_460 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) > ((insn >> 0) & 0xFFFF)) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F) + 1 - 1)) | (tmp_460 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F)))); });
({ word_1 tmp_461 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == ((insn >> 0) & 0xFFFF)) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F) + 1 - 1)) | (tmp_461 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F)))); });
({ word_1 tmp_462 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F), 1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1 - 1)) | (tmp_462 << (1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F)))); });
break;
case 16:
switch (((insn >> 21) & 0x1F)) {
case 5:
/* BNE- */
if ((insn & 0xFFE00003) != 0x40A00000) bt_assert(0);
intp->have_jumped = 1;
(((intp->regs_SPR[1]) & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) ? 0 /* nop */ : (next_pc = (pc + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2))));
break;
case 4:
/* BNE */
if ((insn & 0xFFE00003) != 0x40800000) bt_assert(0);
intp->have_jumped = 1;
(((intp->regs_SPR[1]) & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) ? 0 /* nop */ : (next_pc = (pc + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2))));
break;
case 13:
/* BEQ+ */
if ((insn & 0xFFE00003) != 0x41A00000) bt_assert(0);
intp->have_jumped = 1;
(((intp->regs_SPR[1]) & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) ? (next_pc = (pc + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2))) : 0 /* nop */);
break;
case 12:
/* BEQ */
if ((insn & 0xFFE00003) != 0x41800000) bt_assert(0);
intp->have_jumped = 1;
(((intp->regs_SPR[1]) & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) ? (next_pc = (pc + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2))) : 0 /* nop */);
break;
case 18:
/* BDZ */
if ((insn & 0xFFE00003) != 0x42400000) bt_assert(0);
intp->have_jumped = 1;
({ word_32 tmp_463 = ((intp->regs_SPR[3]) - 1); ((intp->regs_SPR[3]) = tmp_463); });
(((intp->regs_SPR[3]) == 0) ? (next_pc = (pc + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2))) : 0 /* nop */);
break;
case 16:
/* BDNZ */
if ((insn & 0xFFE00003) != 0x42000000) bt_assert(0);
intp->have_jumped = 1;
({ word_32 tmp_464 = ((intp->regs_SPR[3]) - 1); ((intp->regs_SPR[3]) = tmp_464); });
(((intp->regs_SPR[3]) == 0) ? 0 /* nop */ : (next_pc = (pc + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2))));
break;
default:
bt_assert(0);
}
break;
case 18:
switch (((insn >> 0) & 0x3)) {
case 1:
/* BL */
if ((insn & 0xFC000003) != 0x48000001) bt_assert(0);
intp->have_jumped = 1;
({ word_32 tmp_465 = (pc + 4); ((intp->regs_SPR[0]) = tmp_465); });
(next_pc = (pc + (((((insn >> 2) & 0xFFFFFF) & 0x800000) ? ((word_32)((insn >> 2) & 0xFFFFFF) | 0xFF000000) : (word_32)((insn >> 2) & 0xFFFFFF)) << 2)));
break;
case 0:
/* B */
if ((insn & 0xFC000003) != 0x48000000) bt_assert(0);
intp->have_jumped = 1;
(next_pc = (pc + (((((insn >> 2) & 0xFFFFFF) & 0x800000) ? ((word_32)((insn >> 2) & 0xFFFFFF) | 0xFF000000) : (word_32)((insn >> 2) & 0xFFFFFF)) << 2)));
break;
default:
bt_assert(0);
}
break;
case 29:
/* ANDIS. */
if ((insn & 0xFC000000) != 0x74000000) bt_assert(0);
({ word_32 tmp_466 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (((insn >> 0) & 0xFFFF) << 16)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_466); });
({ word_1 tmp_467 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_467 << (1 * 31))); });
({ word_1 tmp_468 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_468 << (1 * 30))); });
({ word_1 tmp_469 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_469 << (1 * 29))); });
({ word_1 tmp_470 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_470 << (1 * 28))); });
break;
case 28:
/* ANDI. */
if ((insn & 0xFC000000) != 0x70000000) bt_assert(0);
({ word_32 tmp_471 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) & ((insn >> 0) & 0xFFFF)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_471); });
({ word_1 tmp_472 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_472 << (1 * 31))); });
({ word_1 tmp_473 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_473 << (1 * 30))); });
({ word_1 tmp_474 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_474 << (1 * 29))); });
({ word_1 tmp_475 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_475 << (1 * 28))); });
break;
case 15:
/* ADDIS */
if ((insn & 0xFC000000) != 0x3C000000) bt_assert(0);
({ word_32 tmp_476 = ((((insn >> 16) & 0x1F) == 0) ? (((insn >> 0) & 0xFFFF) << 16) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (((insn >> 0) & 0xFFFF) << 16))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_476); });
break;
case 13:
/* ADDIC. */
if ((insn & 0xFC000000) != 0x34000000) bt_assert(0);
({ word_1 tmp_477 = addcarry_32((intp->regs_GPR[((insn >> 16) & 0x1F)]), ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_477 << 29)); });
({ word_32 tmp_478 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_478); });
({ word_1 tmp_479 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_479 << (1 * 31))); });
({ word_1 tmp_480 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_480 << (1 * 30))); });
({ word_1 tmp_481 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_481 << (1 * 29))); });
({ word_1 tmp_482 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_482 << (1 * 28))); });
break;
case 12:
/* ADDIC */
if ((insn & 0xFC000000) != 0x30000000) bt_assert(0);
({ word_1 tmp_483 = addcarry_32((intp->regs_GPR[((insn >> 16) & 0x1F)]), ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_483 << 29)); });
({ word_32 tmp_484 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_484); });
break;
case 14:
/* ADDI */
if ((insn & 0xFC000000) != 0x38000000) bt_assert(0);
({ word_32 tmp_485 = ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_485); });
break;
default:
bt_assert(0);
}
intp->pc = next_pc;
++intp->insn_count;
}
void dump_ppc_registers (interpreter_t *intp) {
printf("LR: 0x%x\n", intp->regs_SPR[0]);
printf("CR: 0x%x\n", intp->regs_SPR[1]);
printf("XER: 0x%x\n", intp->regs_SPR[2]);
printf("CTR: 0x%x\n", intp->regs_SPR[3]);
printf("FPSCR: 0x%x\n", intp->regs_SPR[4]);
printf("GPR0: 0x%x\n", intp->regs_GPR[0]);
printf("GPR1: 0x%x\n", intp->regs_GPR[1]);
printf("GPR2: 0x%x\n", intp->regs_GPR[2]);
printf("GPR3: 0x%x\n", intp->regs_GPR[3]);
printf("GPR4: 0x%x\n", intp->regs_GPR[4]);
printf("GPR5: 0x%x\n", intp->regs_GPR[5]);
printf("GPR6: 0x%x\n", intp->regs_GPR[6]);
printf("GPR7: 0x%x\n", intp->regs_GPR[7]);
printf("GPR8: 0x%x\n", intp->regs_GPR[8]);
printf("GPR9: 0x%x\n", intp->regs_GPR[9]);
printf("GPR10: 0x%x\n", intp->regs_GPR[10]);
printf("GPR11: 0x%x\n", intp->regs_GPR[11]);
printf("GPR12: 0x%x\n", intp->regs_GPR[12]);
printf("GPR13: 0x%x\n", intp->regs_GPR[13]);
printf("GPR14: 0x%x\n", intp->regs_GPR[14]);
printf("GPR15: 0x%x\n", intp->regs_GPR[15]);
printf("GPR16: 0x%x\n", intp->regs_GPR[16]);
printf("GPR17: 0x%x\n", intp->regs_GPR[17]);
printf("GPR18: 0x%x\n", intp->regs_GPR[18]);
printf("GPR19: 0x%x\n", intp->regs_GPR[19]);
printf("GPR20: 0x%x\n", intp->regs_GPR[20]);
printf("GPR21: 0x%x\n", intp->regs_GPR[21]);
printf("GPR22: 0x%x\n", intp->regs_GPR[22]);
printf("GPR23: 0x%x\n", intp->regs_GPR[23]);
printf("GPR24: 0x%x\n", intp->regs_GPR[24]);
printf("GPR25: 0x%x\n", intp->regs_GPR[25]);
printf("GPR26: 0x%x\n", intp->regs_GPR[26]);
printf("GPR27: 0x%x\n", intp->regs_GPR[27]);
printf("GPR28: 0x%x\n", intp->regs_GPR[28]);
printf("GPR29: 0x%x\n", intp->regs_GPR[29]);
printf("GPR30: 0x%x\n", intp->regs_GPR[30]);
printf("GPR31: 0x%x\n", intp->regs_GPR[31]);
printf("FPR0: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[0], intp->regs_FPR[0]);
printf("FPR1: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[1], intp->regs_FPR[1]);
printf("FPR2: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[2], intp->regs_FPR[2]);
printf("FPR3: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[3], intp->regs_FPR[3]);
printf("FPR4: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[4], intp->regs_FPR[4]);
printf("FPR5: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[5], intp->regs_FPR[5]);
printf("FPR6: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[6], intp->regs_FPR[6]);
printf("FPR7: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[7], intp->regs_FPR[7]);
printf("FPR8: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[8], intp->regs_FPR[8]);
printf("FPR9: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[9], intp->regs_FPR[9]);
printf("FPR10: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[10], intp->regs_FPR[10]);
printf("FPR11: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[11], intp->regs_FPR[11]);
printf("FPR12: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[12], intp->regs_FPR[12]);
printf("FPR13: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[13], intp->regs_FPR[13]);
printf("FPR14: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[14], intp->regs_FPR[14]);
printf("FPR15: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[15], intp->regs_FPR[15]);
printf("FPR16: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[16], intp->regs_FPR[16]);
printf("FPR17: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[17], intp->regs_FPR[17]);
printf("FPR18: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[18], intp->regs_FPR[18]);
printf("FPR19: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[19], intp->regs_FPR[19]);
printf("FPR20: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[20], intp->regs_FPR[20]);
printf("FPR21: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[21], intp->regs_FPR[21]);
printf("FPR22: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[22], intp->regs_FPR[22]);
printf("FPR23: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[23], intp->regs_FPR[23]);
printf("FPR24: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[24], intp->regs_FPR[24]);
printf("FPR25: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[25], intp->regs_FPR[25]);
printf("FPR26: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[26], intp->regs_FPR[26]);
printf("FPR27: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[27], intp->regs_FPR[27]);
printf("FPR28: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[28], intp->regs_FPR[28]);
printf("FPR29: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[29], intp->regs_FPR[29]);
printf("FPR30: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[30], intp->regs_FPR[30]);
printf("FPR31: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[31], intp->regs_FPR[31]);
printf("PC: 0x%x\n", intp->pc);
}
