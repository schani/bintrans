void SKELETON_FUNC_NAME (interpreter_t *intp SKELETON_FUNC_ARGS) {
word_8 opcode, opcode2;
word_32 next_pc;
SKELETON_PRE_DECODE
i386_decode_opcode(intp, &prefix_flags, &opcode, &opcode2);
switch (opcode) {
case 51 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_R16_RM16; op_width = 16;
handle_xor_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM32; op_width = 32;
handle_xor_insn();
}
break;
case 50 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_R8_RM8; op_width = 8;
handle_xor_insn();
}
break;
case 49 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_R16; op_width = 16;
handle_xor_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_R32; op_width = 32;
handle_xor_insn();
}
break;
case 48 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_R8; op_width = 8;
handle_xor_insn();
}
break;
case 53 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_AX_IMM16; op_width = 16;
handle_xor_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_EAX_IMM32; op_width = 32;
handle_xor_insn();
}
break;
case 52 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_AL_IMM8; op_width = 8;
handle_xor_insn();
}
break;
case 135 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_R16; op_width = 16;
handle_xchg_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_R32; op_width = 32;
handle_xchg_insn();
}
break;
case 134 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_R8; op_width = 8;
handle_xchg_insn();
}
break;
case 144 :
case 145 :
case 146 :
case 147 :
case 148 :
case 149 :
case 150 :
case 151 :
opcode_reg = opcode - 144;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_PR16_AX; op_width = 16;
handle_xchg_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_PR32_EAX; op_width = 32;
handle_xchg_insn();
}
break;
case 133 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_R16; op_width = 16;
handle_test_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_R32; op_width = 32;
handle_test_insn();
}
break;
case 132 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_R8; op_width = 8;
handle_test_insn();
}
break;
case 169 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_AX_IMM16; op_width = 16;
handle_test_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_EAX_IMM32; op_width = 32;
handle_test_insn();
}
break;
case 168 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_AL_IMM8; op_width = 8;
handle_test_insn();
}
break;
case 43 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_R16_RM16; op_width = 16;
handle_sub_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM32; op_width = 32;
handle_sub_insn();
}
break;
case 42 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_R8_RM8; op_width = 8;
handle_sub_insn();
}
break;
case 41 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_R16; op_width = 16;
handle_sub_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_R32; op_width = 32;
handle_sub_insn();
}
break;
case 40 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_R8; op_width = 8;
handle_sub_insn();
}
break;
case 45 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_AX_IMM16; op_width = 16;
handle_sub_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_EAX_IMM32; op_width = 32;
handle_sub_insn();
}
break;
case 44 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_AL_IMM8; op_width = 8;
handle_sub_insn();
}
break;
case 171 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_AX; op_width = 16;
handle_stosw_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_EAX; op_width = 32;
handle_stosd_insn();
}
break;
case 170 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_AL; op_width = 8;
handle_stosb_insn();
}
break;
case 27 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_R16_RM16; op_width = 16;
handle_sbb_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM32; op_width = 32;
handle_sbb_insn();
}
break;
case 26 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_R8_RM8; op_width = 8;
handle_sbb_insn();
}
break;
case 25 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_R16; op_width = 16;
handle_sbb_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_R32; op_width = 32;
handle_sbb_insn();
}
break;
case 24 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_R8; op_width = 8;
handle_sbb_insn();
}
break;
case 29 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_AX_IMM16; op_width = 16;
handle_sbb_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_EAX_IMM32; op_width = 32;
handle_sbb_insn();
}
break;
case 28 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_AL_IMM8; op_width = 8;
handle_sbb_insn();
}
break;
case 209 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_1; op_width = 16;
handle_shr_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_1; op_width = 32;
handle_shr_insn();
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_1; op_width = 16;
handle_shl_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_1; op_width = 32;
handle_shl_insn();
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_1; op_width = 16;
handle_sar_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_1; op_width = 32;
handle_sar_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 192 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM8_IMM8; op_width = 8;
handle_shr_insn();
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM8_IMM8; op_width = 8;
handle_shl_insn();
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM8_IMM8; op_width = 8;
handle_sar_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 210 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_CL; op_width = 8;
handle_shr_insn();
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_CL; op_width = 8;
handle_shl_insn();
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_CL; op_width = 8;
handle_sar_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 208 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_1; op_width = 8;
handle_shr_insn();
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_1; op_width = 8;
handle_shl_insn();
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_1; op_width = 8;
handle_sar_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 193 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_IMM8; op_width = 16;
handle_shr_insn();
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_IMM8; op_width = 32;
handle_shr_insn();
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_IMM8; op_width = 16;
handle_shl_insn();
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_IMM8; op_width = 32;
handle_shl_insn();
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_IMM8; op_width = 16;
handle_sar_insn();
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_IMM8; op_width = 32;
handle_sar_insn();
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_IMM8; op_width = 16;
handle_ror_insn();
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_IMM8; op_width = 32;
handle_ror_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 211 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_CL; op_width = 16;
handle_shr_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_CL; op_width = 32;
handle_shr_insn();
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_CL; op_width = 16;
handle_shl_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_CL; op_width = 32;
handle_shl_insn();
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_CL; op_width = 16;
handle_sar_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_CL; op_width = 32;
handle_sar_insn();
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_CL; op_width = 16;
handle_rol_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_CL; op_width = 32;
handle_rol_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 194 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM16; op_width = 16;
handle_ret_insn();
}
break;
case 195 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_ret_insn();
}
break;
case 242 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 174 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_repne_scasb_insn();
}
break;
default :
switch (reg) {
default :
bt_assert(0);
}
}
break;
case 243 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 171 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_rep_stosd_insn();
}
break;
case 170 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_rep_stosb_insn();
}
break;
case 165 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_rep_movsd_insn();
}
break;
case 164 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_rep_movsb_insn();
}
break;
case 166 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_repe_cmpsb_insn();
}
break;
default :
switch (reg) {
default :
bt_assert(0);
}
}
break;
case 104 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_push_insn();
}
break;
case 106 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_push_insn();
}
break;
case 80 :
case 81 :
case 82 :
case 83 :
case 84 :
case 85 :
case 86 :
case 87 :
opcode_reg = opcode - 80;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PR32; op_width = 32;
handle_push_insn();
}
break;
case 88 :
case 89 :
case 90 :
case 91 :
case 92 :
case 93 :
case 94 :
case 95 :
opcode_reg = opcode - 88;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PR32; op_width = 32;
handle_pop_insn();
}
break;
case 143 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M32; op_width = 32;
handle_pop_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 11 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_R16_RM16; op_width = 16;
handle_or_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM32; op_width = 32;
handle_or_insn();
}
break;
case 10 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_R8_RM8; op_width = 8;
handle_or_insn();
}
break;
case 9 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_R16; op_width = 16;
handle_or_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_R32; op_width = 32;
handle_or_insn();
}
break;
case 8 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_R8; op_width = 8;
handle_or_insn();
}
break;
case 13 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_AX_IMM16; op_width = 16;
handle_or_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_EAX_IMM32; op_width = 32;
handle_or_insn();
}
break;
case 12 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_AL_IMM8; op_width = 8;
handle_or_insn();
}
break;
case 199 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_IMM16; op_width = 16;
handle_mov_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_IMM32; op_width = 32;
handle_mov_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 198 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM8_IMM8; op_width = 8;
handle_mov_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 184 :
case 185 :
case 186 :
case 187 :
case 188 :
case 189 :
case 190 :
case 191 :
opcode_reg = opcode - 184;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_PR16_IMM16; op_width = 16;
handle_mov_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_PR32_IMM32; op_width = 32;
handle_mov_insn();
}
break;
case 176 :
case 177 :
case 178 :
case 179 :
case 180 :
case 181 :
case 182 :
case 183 :
opcode_reg = opcode - 176;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_PR8_IMM8; op_width = 8;
handle_mov_insn();
}
break;
case 163 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_MOFFS32_AX; op_width = 16;
handle_mov_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_MOFFS32_EAX; op_width = 32;
handle_mov_insn();
}
break;
case 161 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_AX_MOFFS32; op_width = 16;
handle_mov_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_EAX_MOFFS32; op_width = 32;
handle_mov_insn();
}
break;
case 139 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_R16_RM16; op_width = 16;
handle_mov_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM32; op_width = 32;
handle_mov_insn();
}
break;
case 138 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_R8_RM8; op_width = 8;
handle_mov_insn();
}
break;
case 137 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_R16; op_width = 16;
handle_mov_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_R32; op_width = 32;
handle_mov_insn();
}
break;
case 136 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_R8; op_width = 8;
handle_mov_insn();
}
break;
case 141 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM32; op_width = 32;
handle_lea_insn();
}
break;
case 120 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_js_insn();
}
break;
case 122 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_jp_insn();
}
break;
case 121 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_jns_insn();
}
break;
case 123 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_jnp_insn();
}
break;
case 117 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_jne_insn();
}
break;
case 233 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_jmp_insn();
}
break;
case 235 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_jmp_insn();
}
break;
case 126 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_jle_insn();
}
break;
case 124 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_jl_insn();
}
break;
case 125 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_jge_insn();
}
break;
case 127 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_jg_insn();
}
break;
case 116 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_je_insn();
}
break;
case 118 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_jbe_insn();
}
break;
case 114 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_jb_insn();
}
break;
case 115 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_jae_insn();
}
break;
case 119 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_SIMM8; op_width = 32;
handle_ja_insn();
}
break;
case 205 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM8; op_width = 8;
handle_int_insn();
}
break;
case 64 :
case 65 :
case 66 :
case 67 :
case 68 :
case 69 :
case 70 :
case 71 :
opcode_reg = opcode - 64;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_PR16; op_width = 16;
handle_inc_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_PR32; op_width = 32;
handle_inc_insn();
}
break;
case 105 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_IMM16; op_width = 16;
handle_imul_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_IMM32; op_width = 32;
handle_imul_insn();
}
break;
case 221 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 232 :
case 233 :
case 234 :
case 235 :
case 236 :
case 237 :
case 238 :
case 239 :
opcode_reg = opcode2 - 232;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fucomp_insn();
}
break;
case 224 :
case 225 :
case 226 :
case 227 :
case 228 :
case 229 :
case 230 :
case 231 :
opcode_reg = opcode2 - 224;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fucom_insn();
}
break;
case 216 :
case 217 :
case 218 :
case 219 :
case 220 :
case 221 :
case 222 :
case 223 :
opcode_reg = opcode2 - 216;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fstp_insn();
}
break;
case 208 :
case 209 :
case 210 :
case 211 :
case 212 :
case 213 :
case 214 :
case 215 :
opcode_reg = opcode2 - 208;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fst_insn();
}
break;
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M64; op_width = 64;
handle_fstp_insn();
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M64; op_width = 64;
handle_fst_insn();
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M64; op_width = 64;
handle_fld_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 219 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M64; op_width = 64;
handle_fstp_insn();
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M64; op_width = 64;
handle_fld_insn();
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M32; op_width = 32;
handle_fistp_insn();
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M32; op_width = 32;
handle_fist_insn();
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M32; op_width = 32;
handle_fild_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 223 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 224 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_fnstsw_insn();
}
break;
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M64; op_width = 64;
handle_fistp_insn();
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M64; op_width = 64;
handle_fild_insn();
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M16_NOPREFIX; op_width = 16;
handle_fild_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 218 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 233 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_fucompp_insn();
}
break;
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M32; op_width = 32;
handle_fisubr_insn();
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M32; op_width = 32;
handle_fimul_insn();
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M32; op_width = 32;
handle_fidivr_insn();
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M32; op_width = 32;
handle_fidiv_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 222 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 224 :
case 225 :
case 226 :
case 227 :
case 228 :
case 229 :
case 230 :
case 231 :
opcode_reg = opcode2 - 224;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fsubrp_insn();
}
break;
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fmulp_insn();
}
break;
case 240 :
case 241 :
case 242 :
case 243 :
case 244 :
case 245 :
case 246 :
case 247 :
opcode_reg = opcode2 - 240;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fdivrp_insn();
}
break;
case 248 :
case 249 :
case 250 :
case 251 :
case 252 :
case 253 :
case 254 :
case 255 :
opcode_reg = opcode2 - 248;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fdivp_insn();
}
break;
case 217 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_fcompp_insn();
}
break;
case 192 :
case 193 :
case 194 :
case 195 :
case 196 :
case 197 :
case 198 :
case 199 :
opcode_reg = opcode2 - 192;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_faddp_insn();
}
break;
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
default :
bt_assert(0);
}
}
break;
case 220 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fmul_insn();
}
break;
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M64; op_width = 64;
handle_fsub_insn();
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M64; op_width = 64;
handle_fmul_insn();
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M64; op_width = 64;
handle_fdivr_insn();
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M64; op_width = 64;
handle_fdiv_insn();
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M64; op_width = 64;
handle_fcomp_insn();
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M64; op_width = 64;
handle_fcom_insn();
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M64; op_width = 64;
handle_fadd_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 216 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 224 :
case 225 :
case 226 :
case 227 :
case 228 :
case 229 :
case 230 :
case 231 :
opcode_reg = opcode2 - 224;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fsub_insn();
}
break;
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fmul_insn();
}
break;
case 240 :
case 241 :
case 242 :
case 243 :
case 244 :
case 245 :
case 246 :
case 247 :
opcode_reg = opcode2 - 240;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fdiv_insn();
}
break;
case 216 :
case 217 :
case 218 :
case 219 :
case 220 :
case 221 :
case 222 :
case 223 :
opcode_reg = opcode2 - 216;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fcomp_insn();
}
break;
case 208 :
case 209 :
case 210 :
case 211 :
case 212 :
case 213 :
case 214 :
case 215 :
opcode_reg = opcode2 - 208;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fcom_insn();
}
break;
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M32; op_width = 32;
handle_fsub_insn();
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M32; op_width = 32;
handle_fdiv_insn();
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M32; op_width = 32;
handle_fadd_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 217 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 241 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_fyl2x_insn();
}
break;
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fxch_insn();
}
break;
case 253 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_fscale_insn();
}
break;
case 252 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_frndint_insn();
}
break;
case 238 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_fldz_insn();
}
break;
case 232 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_fld1_insn();
}
break;
case 192 :
case 193 :
case 194 :
case 195 :
case 196 :
case 197 :
case 198 :
case 199 :
opcode_reg = opcode2 - 192;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_PST; op_width = 3;
handle_fld_insn();
}
break;
case 224 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_fchs_insn();
}
break;
case 240 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_f2xm1_insn();
}
break;
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M32; op_width = 32;
handle_fstp_insn();
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M32; op_width = 32;
handle_fst_insn();
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M16_NOPREFIX; op_width = 16;
handle_fstcw_insn();
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M16_NOPREFIX; op_width = 16;
handle_fldcw_insn();
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_M32; op_width = 32;
handle_fld_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 247 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_IMM16; op_width = 16;
handle_test_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_IMM32; op_width = 32;
handle_test_insn();
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16; op_width = 16;
handle_not_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32; op_width = 32;
handle_not_insn();
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16; op_width = 16;
handle_neg_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32; op_width = 32;
handle_neg_insn();
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32; op_width = 32;
handle_mul_insn();
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16; op_width = 16;
handle_imul_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32; op_width = 32;
handle_imul_insn();
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32; op_width = 32;
handle_idiv_insn();
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32; op_width = 32;
handle_div_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 246 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM8_IMM8; op_width = 8;
handle_test_insn();
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_not_insn();
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_neg_insn();
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_mul_insn();
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_imul_insn();
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_idiv_insn();
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_div_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 72 :
case 73 :
case 74 :
case 75 :
case 76 :
case 77 :
case 78 :
case 79 :
opcode_reg = opcode - 72;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_PR16; op_width = 16;
handle_dec_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_PR32; op_width = 32;
handle_dec_insn();
}
break;
case 254 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_inc_insn();
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_dec_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 59 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_R16_RM16; op_width = 16;
handle_cmp_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM32; op_width = 32;
handle_cmp_insn();
}
break;
case 58 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_R8_RM8; op_width = 8;
handle_cmp_insn();
}
break;
case 57 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_R16; op_width = 16;
handle_cmp_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_R32; op_width = 32;
handle_cmp_insn();
}
break;
case 56 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_R8; op_width = 8;
handle_cmp_insn();
}
break;
case 61 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_AX_IMM16; op_width = 16;
handle_cmp_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_EAX_IMM32; op_width = 32;
handle_cmp_insn();
}
break;
case 60 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_AL_IMM8; op_width = 8;
handle_cmp_insn();
}
break;
case 252 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_cld_insn();
}
break;
case 153 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_NIL;
handle_cdq_insn();
}
break;
case 152 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_AX_AL; op_width = 16;
handle_cbw_cwde_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_EAX_AX; op_width = 32;
handle_cbw_cwde_insn();
}
break;
case 255 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32; op_width = 32;
handle_push_insn();
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32; op_width = 32;
handle_jmp_insn();
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16; op_width = 16;
handle_inc_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32; op_width = 32;
handle_inc_insn();
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16; op_width = 16;
handle_dec_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32; op_width = 32;
handle_dec_insn();
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32; op_width = 32;
handle_call_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 232 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_call_insn();
}
break;
case 15 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 172 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_R32_IMM8; op_width = 32;
handle_shrd_insn();
}
break;
case 173 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_R32; op_width = 32;
handle_shrd_insn();
}
break;
case 164 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_R32_IMM8; op_width = 32;
handle_shld_insn();
}
break;
case 165 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_R32; op_width = 32;
handle_shld_insn();
}
break;
case 149 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_setne_insn();
}
break;
case 151 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_setnbe_insn();
}
break;
case 146 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_setnae_insn();
}
break;
case 158 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_setle_insn();
}
break;
case 156 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_setl_insn();
}
break;
case 159 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_setg_insn();
}
break;
case 148 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_sete_insn();
}
break;
case 150 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8; op_width = 8;
handle_setbe_insn();
}
break;
case 183 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM16; op_width = 32;
handle_movzx_insn();
}
break;
case 182 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_R16_RM8; op_width = 16;
handle_movzx_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM8; op_width = 32;
handle_movzx_insn();
}
break;
case 191 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM16; op_width = 32;
handle_movsx_insn();
}
break;
case 190 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_R16_RM8; op_width = 16;
handle_movsx_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM8; op_width = 32;
handle_movsx_insn();
}
break;
case 136 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_js_insn();
}
break;
case 138 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_jp_insn();
}
break;
case 137 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_jns_insn();
}
break;
case 139 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_jnp_insn();
}
break;
case 133 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_jne_insn();
}
break;
case 142 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_jle_insn();
}
break;
case 140 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_jl_insn();
}
break;
case 141 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_jge_insn();
}
break;
case 143 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_jg_insn();
}
break;
case 132 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_je_insn();
}
break;
case 134 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_jbe_insn();
}
break;
case 130 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_jb_insn();
}
break;
case 131 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_jae_insn();
}
break;
case 135 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_IMM32; op_width = 32;
handle_ja_insn();
}
break;
case 175 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_R16_RM16; op_width = 16;
handle_imul_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM32; op_width = 32;
handle_imul_insn();
}
break;
case 171 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_R32; op_width = 32;
handle_bts_insn();
}
break;
case 163 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_R32; op_width = 32;
handle_bt_insn();
}
break;
case 189 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_R16_RM16; op_width = 16;
handle_bsr_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM32; op_width = 32;
handle_bsr_insn();
}
break;
default :
switch (reg) {
default :
bt_assert(0);
}
}
break;
case 35 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_R16_RM16; op_width = 16;
handle_and_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM32; op_width = 32;
handle_and_insn();
}
break;
case 34 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_R8_RM8; op_width = 8;
handle_and_insn();
}
break;
case 33 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_R16; op_width = 16;
handle_and_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_R32; op_width = 32;
handle_and_insn();
}
break;
case 32 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_R8; op_width = 8;
handle_and_insn();
}
break;
case 37 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_AX_IMM16; op_width = 16;
handle_and_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_EAX_IMM32; op_width = 32;
handle_and_insn();
}
break;
case 36 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_AL_IMM8; op_width = 8;
handle_and_insn();
}
break;
case 3 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_R16_RM16; op_width = 16;
handle_add_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM32; op_width = 32;
handle_add_insn();
}
break;
case 2 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_R8_RM8; op_width = 8;
handle_add_insn();
}
break;
case 1 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_R16; op_width = 16;
handle_add_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_R32; op_width = 32;
handle_add_insn();
}
break;
case 0 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_R8; op_width = 8;
handle_add_insn();
}
break;
case 5 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_AX_IMM16; op_width = 16;
handle_add_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_EAX_IMM32; op_width = 32;
handle_add_insn();
}
break;
case 4 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_AL_IMM8; op_width = 8;
handle_add_insn();
}
break;
case 19 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_R16_RM16; op_width = 16;
handle_adc_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_R32_RM32; op_width = 32;
handle_adc_insn();
}
break;
case 18 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_R8_RM8; op_width = 8;
handle_adc_insn();
}
break;
case 17 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
mode = MODE_RM16_R16; op_width = 16;
handle_adc_insn();
} else {
next_pc = pc = intp->pc;
mode = MODE_RM32_R32; op_width = 32;
handle_adc_insn();
}
break;
case 16 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
mode = MODE_RM8_R8; op_width = 8;
handle_adc_insn();
}
break;
case 131 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_SIMM8; op_width = 16;
handle_xor_insn();
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_SIMM8; op_width = 32;
handle_xor_insn();
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_SIMM8; op_width = 16;
handle_sub_insn();
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_SIMM8; op_width = 32;
handle_sub_insn();
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_SIMM8; op_width = 16;
handle_sbb_insn();
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_SIMM8; op_width = 32;
handle_sbb_insn();
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_SIMM8; op_width = 16;
handle_or_insn();
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_SIMM8; op_width = 32;
handle_or_insn();
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_SIMM8; op_width = 16;
handle_cmp_insn();
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_SIMM8; op_width = 32;
handle_cmp_insn();
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_SIMM8; op_width = 16;
handle_and_insn();
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_SIMM8; op_width = 32;
handle_and_insn();
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_SIMM8; op_width = 16;
handle_add_insn();
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_SIMM8; op_width = 32;
handle_add_insn();
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_SIMM8; op_width = 16;
handle_adc_insn();
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_SIMM8; op_width = 32;
handle_adc_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 129 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_IMM16; op_width = 16;
handle_xor_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_IMM32; op_width = 32;
handle_xor_insn();
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_IMM16; op_width = 16;
handle_sub_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_IMM32; op_width = 32;
handle_sub_insn();
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_IMM16; op_width = 16;
handle_sbb_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_IMM32; op_width = 32;
handle_sbb_insn();
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_IMM16; op_width = 16;
handle_or_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_IMM32; op_width = 32;
handle_or_insn();
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_IMM16; op_width = 16;
handle_cmp_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_IMM32; op_width = 32;
handle_cmp_insn();
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_IMM16; op_width = 16;
handle_and_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_IMM32; op_width = 32;
handle_and_insn();
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_IMM16; op_width = 16;
handle_add_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_IMM32; op_width = 32;
handle_add_insn();
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_RM16_IMM16; op_width = 16;
handle_adc_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_RM32_IMM32; op_width = 32;
handle_adc_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 128 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM8_IMM8; op_width = 8;
handle_xor_insn();
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM8_IMM8; op_width = 8;
handle_sub_insn();
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM8_IMM8; op_width = 8;
handle_sbb_insn();
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM8_IMM8; op_width = 8;
handle_or_insn();
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM8_IMM8; op_width = 8;
handle_cmp_insn();
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM8_IMM8; op_width = 8;
handle_and_insn();
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM8_IMM8; op_width = 8;
handle_add_insn();
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_RM8_IMM8; op_width = 8;
handle_adc_insn();
}
break;
default :
bt_assert(0);
}
}
break;
case 21 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
mode = MODE_AX_IMM16; op_width = 16;
handle_adc_insn();
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
mode = MODE_EAX_IMM32; op_width = 32;
handle_adc_insn();
}
break;
case 20 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
mode = MODE_AL_IMM8; op_width = 8;
handle_adc_insn();
}
break;
default:
bt_assert(0);
}
intp->pc = next_pc;
}
