typedef word_32 ppc_word;
#define NUM_EMU_REGISTERS 69
#define NUM_INSNS 205
#define EMU_REGISTER_SET double regs_FPR[32]; word_32 regs_GPR[32]; word_32 regs_SPR[5];
#define CLASS_FIRST_INDEX_FPR 37
#define CLASS_FIRST_INDEX_GPR 5
#define CLASS_FIRST_INDEX_SPR 0
#define REG_INDEX_FPR31 68
#define REG_INDEX_FPR30 67
#define REG_INDEX_FPR29 66
#define REG_INDEX_FPR28 65
#define REG_INDEX_FPR27 64
#define REG_INDEX_FPR26 63
#define REG_INDEX_FPR25 62
#define REG_INDEX_FPR24 61
#define REG_INDEX_FPR23 60
#define REG_INDEX_FPR22 59
#define REG_INDEX_FPR21 58
#define REG_INDEX_FPR20 57
#define REG_INDEX_FPR19 56
#define REG_INDEX_FPR18 55
#define REG_INDEX_FPR17 54
#define REG_INDEX_FPR16 53
#define REG_INDEX_FPR15 52
#define REG_INDEX_FPR14 51
#define REG_INDEX_FPR13 50
#define REG_INDEX_FPR12 49
#define REG_INDEX_FPR11 48
#define REG_INDEX_FPR10 47
#define REG_INDEX_FPR9 46
#define REG_INDEX_FPR8 45
#define REG_INDEX_FPR7 44
#define REG_INDEX_FPR6 43
#define REG_INDEX_FPR5 42
#define REG_INDEX_FPR4 41
#define REG_INDEX_FPR3 40
#define REG_INDEX_FPR2 39
#define REG_INDEX_FPR1 38
#define REG_INDEX_FPR0 37
#define REG_INDEX_GPR31 36
#define REG_INDEX_GPR30 35
#define REG_INDEX_GPR29 34
#define REG_INDEX_GPR28 33
#define REG_INDEX_GPR27 32
#define REG_INDEX_GPR26 31
#define REG_INDEX_GPR25 30
#define REG_INDEX_GPR24 29
#define REG_INDEX_GPR23 28
#define REG_INDEX_GPR22 27
#define REG_INDEX_GPR21 26
#define REG_INDEX_GPR20 25
#define REG_INDEX_GPR19 24
#define REG_INDEX_GPR18 23
#define REG_INDEX_GPR17 22
#define REG_INDEX_GPR16 21
#define REG_INDEX_GPR15 20
#define REG_INDEX_GPR14 19
#define REG_INDEX_GPR13 18
#define REG_INDEX_GPR12 17
#define REG_INDEX_GPR11 16
#define REG_INDEX_GPR10 15
#define REG_INDEX_GPR9 14
#define REG_INDEX_GPR8 13
#define REG_INDEX_GPR7 12
#define REG_INDEX_GPR6 11
#define REG_INDEX_GPR5 10
#define REG_INDEX_GPR4 9
#define REG_INDEX_GPR3 8
#define REG_INDEX_GPR2 7
#define REG_INDEX_GPR1 6
#define REG_INDEX_GPR0 5
#define REG_INDEX_FPSCR 4
#define REG_INDEX_CTR 3
#define REG_INDEX_XER 2
#define REG_INDEX_CR 1
#define REG_INDEX_LR 0
#define PPC_FIELD_MBE    ((insn >> 5) & 0x1)
#define PPC_FIELD_CRZ2    ((insn >> 20) & 0x1)
#define PPC_FIELD_CRZ1    ((insn >> 11) & 0x1)
#define PPC_FIELD_CRM    ((insn >> 12) & 0xFF)
#define PPC_FIELD_FMZ2    ((insn >> 25) & 0x1)
#define PPC_FIELD_FMZ1    ((insn >> 16) & 0x1)
#define PPC_FIELD_FM    ((insn >> 17) & 0xFF)
#define PPC_FIELD_TBRL    ((insn >> 16) & 0x1F)
#define PPC_FIELD_TBRH    ((insn >> 11) & 0x1F)
#define PPC_FIELD_SPR    ((insn >> 11) & 0x3FF)
#define PPC_FIELD_IMMZ    ((insn >> 11) & 0x1)
#define PPC_FIELD_IMM    ((insn >> 12) & 0xF)
#define PPC_FIELD_RC    ((insn >> 0) & 0x1)
#define PPC_FIELD_SRZ    ((insn >> 20) & 0x1)
#define PPC_FIELD_SR    ((insn >> 16) & 0xF)
#define PPC_FIELD_OE    ((insn >> 10) & 0x1)
#define PPC_FIELD_XO9    ((insn >> 1) & 0x1FF)
#define PPC_FIELD_XO5    ((insn >> 1) & 0x1F)
#define PPC_FIELD_XO4    ((insn >> 2) & 0x7)
#define PPC_FIELD_XO2    ((insn >> 2) & 0x1FF)
#define PPC_FIELD_XO1    ((insn >> 1) & 0x3FF)
#define PPC_FIELD_XO0    ((insn >> 0) & 0x3)
#define PPC_FIELD_DS    ((insn >> 2) & 0x3FFF)
#define PPC_FIELD_UIMM    ((insn >> 0) & 0xFFFF)
#define PPC_FIELD_SIMM    ((insn >> 0) & 0xFFFF)
#define PPC_FIELD_D    ((insn >> 0) & 0xFFFF)
#define PPC_FIELD_ME    ((insn >> 1) & 0x1F)
#define PPC_FIELD_MB    ((insn >> 6) & 0x1F)
#define PPC_FIELD_FRC    ((insn >> 6) & 0x1F)
#define PPC_FIELD_C    ((insn >> 6) & 0x1F)
#define PPC_FIELD_SH    ((insn >> 11) & 0x1F)
#define PPC_FIELD_NB    ((insn >> 11) & 0x1F)
#define PPC_FIELD_CRBB    ((insn >> 11) & 0x1F)
#define PPC_FIELD_FRB    ((insn >> 11) & 0x1F)
#define PPC_FIELD_RB    ((insn >> 11) & 0x1F)
#define PPC_FIELD_CRSZ    ((insn >> 16) & 0x3)
#define PPC_FIELD_CRFS    ((insn >> 18) & 0x7)
#define PPC_FIELD_CRBA    ((insn >> 16) & 0x1F)
#define PPC_FIELD_FRA    ((insn >> 16) & 0x1F)
#define PPC_FIELD_RA    ((insn >> 16) & 0x1F)
#define PPC_FIELD_BICC    ((insn >> 16) & 0x3)
#define PPC_FIELD_BICR    ((insn >> 18) & 0x7)
#define PPC_FIELD_BI    ((insn >> 16) & 0x1F)
#define PPC_FIELD_TO    ((insn >> 21) & 0x1F)
#define PPC_FIELD_LZ    ((insn >> 22) & 0x1)
#define PPC_FIELD_L    ((insn >> 21) & 0x1)
#define PPC_FIELD_CRDZ    ((insn >> 21) & 0x3)
#define PPC_FIELD_CRFD    ((insn >> 23) & 0x7)
#define PPC_FIELD_CRBD    ((insn >> 21) & 0x1F)
#define PPC_FIELD_FRD    ((insn >> 21) & 0x1F)
#define PPC_FIELD_RD    ((insn >> 21) & 0x1F)
#define PPC_FIELD_FRS    ((insn >> 21) & 0x1F)
#define PPC_FIELD_RS    ((insn >> 21) & 0x1F)
#define PPC_FIELD_SRS    ((insn >> 21) & 0x1F)
#define PPC_FIELD_BO    ((insn >> 21) & 0x1F)
#define PPC_FIELD_BD    ((insn >> 2) & 0x3FFF)
#define PPC_FIELD_LK    ((insn >> 0) & 0x1)
#define PPC_FIELD_AA    ((insn >> 1) & 0x1)
#define PPC_FIELD_LI    ((insn >> 2) & 0xFFFFFF)
#define PPC_FIELD_OPCD    ((insn >> 26) & 0x3F)
