static word_8 mod, reg, rm, sib_scale, sib_index, sib_base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 disp32, imm32;
word_32 tmp_1302 (interpreter_t *intp) {
return (({ word_32 tmp_1334; switch (sib_base) {  case 0: case 1: case 2: case 3: case 4: case 6: case 7: tmp_1334 = (intp->regs_GPR[sib_base]); break;  case 5: tmp_1334 = ({ word_32 tmp_1335; switch (mod) {  case 0: tmp_1335 = disp32; break;  case 1: case 2: case 3: tmp_1335 = (intp->regs_GPR[5]); break; } tmp_1335; }); break; } tmp_1334; }) + ({ word_32 tmp_1336; switch (sib_index) {  case 0: case 1: case 2: case 3: case 5: case 6: case 7: tmp_1336 = ((intp->regs_GPR[sib_index]) << sib_scale); break;  case 4: tmp_1336 = 0; break; } tmp_1336; }));
}
word_32 tmp_528 (interpreter_t *intp) {
return ({ word_32 tmp_1337; switch (mod) {  case 0: tmp_1337 = ({ word_32 tmp_1338; switch (rm) {  case 0: case 1: case 2: case 3: case 6: case 7: tmp_1338 = (intp->regs_GPR[rm]); break;  case 4: tmp_1338 = tmp_1302(intp); break;  case 5: tmp_1338 = disp32; break; } tmp_1338; }); break;  case 1: tmp_1337 = ({ word_32 tmp_1339; switch (rm) {  case 0: case 1: case 2: case 3: case 5: case 6: case 7: tmp_1339 = ((intp->regs_GPR[rm]) + ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8)); break;  case 4: tmp_1339 = (((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8) + tmp_1302(intp)); break; } tmp_1339; }); break;  case 2: tmp_1337 = ({ word_32 tmp_1340; switch (rm) {  case 0: case 1: case 2: case 3: case 5: case 6: case 7: tmp_1340 = ((intp->regs_GPR[rm]) + disp32); break;  case 4: tmp_1340 = (disp32 + tmp_1302(intp)); break; } tmp_1340; }); break; } tmp_1337; });
}
void tmp_516 (interpreter_t *intp, word_8 tmp_1341) {
({ switch (opcode_reg) {  case 0: case 1: case 2: case 3: ((intp->regs_GPR[opcode_reg]) = ((intp->regs_GPR[opcode_reg]) & 0xFFFFFF00) | (tmp_1341 << 0)); break;  case 4: case 5: case 6: case 7: ((intp->regs_GPR[((opcode_reg - 4) & 0x7)]) = ((intp->regs_GPR[((opcode_reg - 4) & 0x7)]) & 0xFFFF00FF) | (tmp_1341 << 8)); break; }});
}
void tmp_38 (interpreter_t *intp, word_8 tmp_1342) {
({ switch (mod) {  case 0: case 1: case 2: mem_set_8(intp, tmp_528(intp), tmp_1342); break;  case 3: ({ switch (rm) {  case 0: case 1: case 2: case 3: ((intp->regs_GPR[rm]) = ((intp->regs_GPR[rm]) & 0xFFFFFF00) | (tmp_1342 << 0)); break;  case 4: case 5: case 6: case 7: ((intp->regs_GPR[((rm - 4) & 0x7)]) = ((intp->regs_GPR[((rm - 4) & 0x7)]) & 0xFFFF00FF) | (tmp_1342 << 8)); break; }}); break; }});
}
void tmp_31 (interpreter_t *intp, word_32 tmp_1343) {
({ switch (mod) {  case 0: case 1: case 2: mem_set_32(intp, tmp_528(intp), tmp_1343); break;  case 3: ((intp->regs_GPR[rm]) = tmp_1343); break; }});
}
void tmp_24 (interpreter_t *intp, word_16 tmp_1344) {
({ switch (mod) {  case 0: case 1: case 2: mem_set_16(intp, tmp_528(intp), tmp_1344); break;  case 3: ((intp->regs_GPR[rm]) = ((intp->regs_GPR[rm]) & 0xFFFF0000) | (tmp_1344 << 0)); break; }});
}
void tmp_17 (interpreter_t *intp, word_8 tmp_1345) {
({ switch (reg) {  case 0: case 1: case 2: case 3: ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFFFF00) | (tmp_1345 << 0)); break;  case 4: case 5: case 6: case 7: ((intp->regs_GPR[((reg - 4) & 0x7)]) = ((intp->regs_GPR[((reg - 4) & 0x7)]) & 0xFFFF00FF) | (tmp_1345 << 8)); break; }});
}
word_8 tmp_16 (interpreter_t *intp) {
return ({ word_8 tmp_1346; switch (mod) {  case 0: case 1: case 2: tmp_1346 = mem_get_8(intp, tmp_528(intp)); break;  case 3: tmp_1346 = ({ word_8 tmp_1347; switch (rm) {  case 0: case 1: case 2: case 3: tmp_1347 = (((intp->regs_GPR[rm]) >> 0) & 0xFF); break;  case 4: case 5: case 6: case 7: tmp_1347 = (((intp->regs_GPR[((rm - 4) & 0x7)]) >> 8) & 0xFF); break; } tmp_1347; }); break; } tmp_1346; });
}
word_8 tmp_15 (interpreter_t *intp) {
return ({ word_8 tmp_1348; switch (reg) {  case 0: case 1: case 2: case 3: tmp_1348 = (((intp->regs_GPR[reg]) >> 0) & 0xFF); break;  case 4: case 5: case 6: case 7: tmp_1348 = (((intp->regs_GPR[((reg - 4) & 0x7)]) >> 8) & 0xFF); break; } tmp_1348; });
}
word_32 tmp_8 (interpreter_t *intp) {
return ({ word_32 tmp_1349; switch (mod) {  case 0: case 1: case 2: tmp_1349 = mem_get_32(intp, tmp_528(intp)); break;  case 3: tmp_1349 = (intp->regs_GPR[rm]); break; } tmp_1349; });
}
word_16 tmp_1 (interpreter_t *intp) {
return ({ word_16 tmp_1350; switch (mod) {  case 0: case 1: case 2: tmp_1350 = mem_get_16(intp, tmp_528(intp)); break;  case 3: tmp_1350 = (((intp->regs_GPR[rm]) >> 0) & 0xFFFF); break; } tmp_1350; });
}
void interpret_i386_insn (interpreter_t *intp) {
word_8 opcode, opcode2;
word_32 pc, next_pc;
int prefix_flags;
i386_decode_opcode(intp, &prefix_flags, &opcode, &opcode2);
switch (opcode) {
case 51 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_0 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) ^ tmp_1(intp)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_0 << 0)); });
({ word_1 tmp_2 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_2 << 0)); });
({ word_1 tmp_3 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_3 << 11)); });
({ word_1 tmp_4 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_4 << 7)); });
({ word_1 tmp_5 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_5 << 6)); });
({ word_1 tmp_6 = parity_even(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_6 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_7 = ((intp->regs_GPR[reg]) ^ tmp_8(intp)); ((intp->regs_GPR[reg]) = tmp_7); });
({ word_1 tmp_9 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9 << 0)); });
({ word_1 tmp_10 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10 << 11)); });
({ word_1 tmp_11 = (((intp->regs_GPR[reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_11 << 7)); });
({ word_1 tmp_12 = (((intp->regs_GPR[reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_12 << 6)); });
({ word_1 tmp_13 = parity_even(((intp->regs_GPR[reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_13 << 2)); });
}
break;
case 50 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_14 = (tmp_15(intp) ^ tmp_16(intp)); tmp_17(intp, tmp_14); });
({ word_1 tmp_18 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_18 << 0)); });
({ word_1 tmp_19 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_19 << 11)); });
({ word_1 tmp_20 = ((tmp_15(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_20 << 7)); });
({ word_1 tmp_21 = ((tmp_15(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_21 << 6)); });
({ word_1 tmp_22 = parity_even((tmp_15(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_22 << 2)); });
}
break;
case 49 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_23 = (tmp_1(intp) ^ (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); tmp_24(intp, tmp_23); });
({ word_1 tmp_25 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_25 << 0)); });
({ word_1 tmp_26 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_26 << 11)); });
({ word_1 tmp_27 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_27 << 7)); });
({ word_1 tmp_28 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_28 << 6)); });
({ word_1 tmp_29 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_29 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_30 = (tmp_8(intp) ^ (intp->regs_GPR[reg])); tmp_31(intp, tmp_30); });
({ word_1 tmp_32 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_32 << 0)); });
({ word_1 tmp_33 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_33 << 11)); });
({ word_1 tmp_34 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_34 << 7)); });
({ word_1 tmp_35 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_35 << 6)); });
({ word_1 tmp_36 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_36 << 2)); });
}
break;
case 48 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_37 = (tmp_16(intp) ^ tmp_15(intp)); tmp_38(intp, tmp_37); });
({ word_1 tmp_39 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_39 << 0)); });
({ word_1 tmp_40 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_40 << 11)); });
({ word_1 tmp_41 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_41 << 7)); });
({ word_1 tmp_42 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_42 << 6)); });
({ word_1 tmp_43 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_43 << 2)); });
}
break;
case 53 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_44 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) ^ imm16); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_44 << 0)); });
({ word_1 tmp_45 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_45 << 0)); });
({ word_1 tmp_46 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_46 << 11)); });
({ word_1 tmp_47 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_47 << 7)); });
({ word_1 tmp_48 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_48 << 6)); });
({ word_1 tmp_49 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_49 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_50 = ((intp->regs_GPR[0]) ^ imm32); ((intp->regs_GPR[0]) = tmp_50); });
({ word_1 tmp_51 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_51 << 0)); });
({ word_1 tmp_52 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_52 << 11)); });
({ word_1 tmp_53 = (((intp->regs_GPR[0]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_53 << 7)); });
({ word_1 tmp_54 = (((intp->regs_GPR[0]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_54 << 6)); });
({ word_1 tmp_55 = parity_even(((intp->regs_GPR[0]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_55 << 2)); });
}
break;
case 52 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_56 = (((intp->regs_GPR[0] >> 0) & 0xFF) ^ imm8); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_56 << 0)); });
({ word_1 tmp_57 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_57 << 0)); });
({ word_1 tmp_58 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_58 << 11)); });
({ word_1 tmp_59 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_59 << 7)); });
({ word_1 tmp_60 = ((((intp->regs_GPR[0] >> 0) & 0xFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_60 << 6)); });
({ word_1 tmp_61 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_61 << 2)); });
}
break;
case 135 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_62 = (((intp->regs_GPR[reg]) >> 0) & 0xFFFF);
({ word_16 tmp_63 = tmp_1(intp); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_63 << 0)); });
({ word_16 tmp_64 = tmp_62; tmp_24(intp, tmp_64); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_65 = (intp->regs_GPR[reg]);
({ word_32 tmp_66 = tmp_8(intp); ((intp->regs_GPR[reg]) = tmp_66); });
({ word_32 tmp_67 = tmp_65; tmp_31(intp, tmp_67); });
})
;
}
break;
case 134 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_8 tmp_68 = tmp_15(intp);
({ word_8 tmp_69 = tmp_16(intp); tmp_17(intp, tmp_69); });
({ word_8 tmp_70 = tmp_68; tmp_38(intp, tmp_70); });
})
;
}
break;
case 144 :
case 145 :
case 146 :
case 147 :
case 148 :
case 149 :
case 150 :
case 151 :
opcode_reg = opcode - 144;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_71 = ((intp->regs_GPR[0] >> 0) & 0xFFFF);
({ word_16 tmp_72 = (((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_72 << 0)); });
({ word_16 tmp_73 = tmp_71; ((intp->regs_GPR[opcode_reg]) = ((intp->regs_GPR[opcode_reg]) & 0xFFFF0000) | (tmp_73 << 0)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_74 = (intp->regs_GPR[0]);
({ word_32 tmp_75 = (intp->regs_GPR[opcode_reg]); ((intp->regs_GPR[0]) = tmp_75); });
({ word_32 tmp_76 = tmp_74; ((intp->regs_GPR[opcode_reg]) = tmp_76); });
})
;
}
break;
case 133 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_77 = (tmp_1(intp) & (((intp->regs_GPR[reg]) >> 0) & 0xFFFF));
({ word_1 tmp_78 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_78 << 0)); });
({ word_1 tmp_79 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_79 << 11)); });
({ word_1 tmp_80 = ((tmp_77 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_80 << 7)); });
({ word_1 tmp_81 = ((tmp_77 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_81 << 6)); });
({ word_1 tmp_82 = parity_even((tmp_77 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_82 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_83 = (tmp_8(intp) & (intp->regs_GPR[reg]));
({ word_1 tmp_84 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_84 << 0)); });
({ word_1 tmp_85 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_85 << 11)); });
({ word_1 tmp_86 = ((tmp_83 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_86 << 7)); });
({ word_1 tmp_87 = ((tmp_83 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_87 << 6)); });
({ word_1 tmp_88 = parity_even((tmp_83 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_88 << 2)); });
})
;
}
break;
case 132 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_8 tmp_89 = (tmp_16(intp) & tmp_15(intp));
({ word_1 tmp_90 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_90 << 0)); });
({ word_1 tmp_91 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_91 << 11)); });
({ word_1 tmp_92 = ((tmp_89 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_92 << 7)); });
({ word_1 tmp_93 = ((tmp_89 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_93 << 6)); });
({ word_1 tmp_94 = parity_even((tmp_89 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_94 << 2)); });
})
;
}
break;
case 169 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_95 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) & imm16);
({ word_1 tmp_96 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_96 << 0)); });
({ word_1 tmp_97 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_97 << 11)); });
({ word_1 tmp_98 = ((tmp_95 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_98 << 7)); });
({ word_1 tmp_99 = ((tmp_95 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_99 << 6)); });
({ word_1 tmp_100 = parity_even((tmp_95 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_100 << 2)); });
})
;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_101 = ((intp->regs_GPR[0]) & imm32);
({ word_1 tmp_102 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_102 << 0)); });
({ word_1 tmp_103 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_103 << 11)); });
({ word_1 tmp_104 = ((tmp_101 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_104 << 7)); });
({ word_1 tmp_105 = ((tmp_101 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_105 << 6)); });
({ word_1 tmp_106 = parity_even((tmp_101 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_106 << 2)); });
})
;
}
break;
case 168 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_8 tmp_107 = (((intp->regs_GPR[0] >> 0) & 0xFF) & imm8);
({ word_1 tmp_108 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_108 << 0)); });
({ word_1 tmp_109 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_109 << 11)); });
({ word_1 tmp_110 = ((tmp_107 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_110 << 7)); });
({ word_1 tmp_111 = ((tmp_107 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_111 << 6)); });
({ word_1 tmp_112 = parity_even((tmp_107 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_112 << 2)); });
})
;
}
break;
case 43 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_113 = subcarry_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), tmp_1(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_113 << 0)); });
({ word_1 tmp_114 = addoverflow_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), (((word_16)~tmp_1(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_114 << 11)); });
({ word_16 tmp_115 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) - tmp_1(intp)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_115 << 0)); });
({ word_1 tmp_116 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_116 << 7)); });
({ word_1 tmp_117 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_117 << 6)); });
({ word_1 tmp_118 = parity_even(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_118 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_119 = subcarry_32((intp->regs_GPR[reg]), tmp_8(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_119 << 0)); });
({ word_1 tmp_120 = addoverflow_32((intp->regs_GPR[reg]), (((word_32)~tmp_8(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_120 << 11)); });
({ word_32 tmp_121 = ((intp->regs_GPR[reg]) - tmp_8(intp)); ((intp->regs_GPR[reg]) = tmp_121); });
({ word_1 tmp_122 = (((intp->regs_GPR[reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_122 << 7)); });
({ word_1 tmp_123 = (((intp->regs_GPR[reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_123 << 6)); });
({ word_1 tmp_124 = parity_even(((intp->regs_GPR[reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_124 << 2)); });
}
break;
case 42 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_125 = subcarry_8(tmp_15(intp), tmp_16(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_125 << 0)); });
({ word_1 tmp_126 = addoverflow_8(tmp_15(intp), (((word_8)~tmp_16(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_126 << 11)); });
({ word_8 tmp_127 = (tmp_15(intp) - tmp_16(intp)); tmp_17(intp, tmp_127); });
({ word_1 tmp_128 = ((tmp_15(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_128 << 7)); });
({ word_1 tmp_129 = ((tmp_15(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_129 << 6)); });
({ word_1 tmp_130 = parity_even((tmp_15(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_130 << 2)); });
}
break;
case 41 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_131 = subcarry_16(tmp_1(intp), (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_131 << 0)); });
({ word_1 tmp_132 = addoverflow_16(tmp_1(intp), (((word_16)~(((intp->regs_GPR[reg]) >> 0) & 0xFFFF)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_132 << 11)); });
({ word_16 tmp_133 = (tmp_1(intp) - (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); tmp_24(intp, tmp_133); });
({ word_1 tmp_134 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_134 << 7)); });
({ word_1 tmp_135 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_135 << 6)); });
({ word_1 tmp_136 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_136 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_137 = subcarry_32(tmp_8(intp), (intp->regs_GPR[reg])); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_137 << 0)); });
({ word_1 tmp_138 = addoverflow_32(tmp_8(intp), (((word_32)~(intp->regs_GPR[reg])) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_138 << 11)); });
({ word_32 tmp_139 = (tmp_8(intp) - (intp->regs_GPR[reg])); tmp_31(intp, tmp_139); });
({ word_1 tmp_140 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_140 << 7)); });
({ word_1 tmp_141 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_141 << 6)); });
({ word_1 tmp_142 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_142 << 2)); });
}
break;
case 40 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_143 = subcarry_8(tmp_16(intp), tmp_15(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_143 << 0)); });
({ word_1 tmp_144 = addoverflow_8(tmp_16(intp), (((word_8)~tmp_15(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_144 << 11)); });
({ word_8 tmp_145 = (tmp_16(intp) - tmp_15(intp)); tmp_38(intp, tmp_145); });
({ word_1 tmp_146 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_146 << 7)); });
({ word_1 tmp_147 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_147 << 6)); });
({ word_1 tmp_148 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_148 << 2)); });
}
break;
case 45 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_149 = subcarry_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_149 << 0)); });
({ word_1 tmp_150 = addoverflow_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), (((word_16)~imm16) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_150 << 11)); });
({ word_16 tmp_151 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) - imm16); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_151 << 0)); });
({ word_1 tmp_152 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_152 << 7)); });
({ word_1 tmp_153 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_153 << 6)); });
({ word_1 tmp_154 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_154 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_155 = subcarry_32((intp->regs_GPR[0]), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_155 << 0)); });
({ word_1 tmp_156 = addoverflow_32((intp->regs_GPR[0]), (((word_32)~imm32) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_156 << 11)); });
({ word_32 tmp_157 = ((intp->regs_GPR[0]) - imm32); ((intp->regs_GPR[0]) = tmp_157); });
({ word_1 tmp_158 = (((intp->regs_GPR[0]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_158 << 7)); });
({ word_1 tmp_159 = (((intp->regs_GPR[0]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_159 << 6)); });
({ word_1 tmp_160 = parity_even(((intp->regs_GPR[0]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_160 << 2)); });
}
break;
case 44 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_161 = subcarry_8(((intp->regs_GPR[0] >> 0) & 0xFF), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_161 << 0)); });
({ word_1 tmp_162 = addoverflow_8(((intp->regs_GPR[0] >> 0) & 0xFF), (((word_8)~imm8) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_162 << 11)); });
({ word_8 tmp_163 = (((intp->regs_GPR[0] >> 0) & 0xFF) - imm8); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_163 << 0)); });
({ word_1 tmp_164 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_164 << 7)); });
({ word_1 tmp_165 = ((((intp->regs_GPR[0] >> 0) & 0xFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_165 << 6)); });
({ word_1 tmp_166 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_166 << 2)); });
}
break;
case 171 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_167 = ((intp->regs_GPR[0] >> 0) & 0xFFFF); mem_set_16(intp, (intp->regs_GPR[7]), tmp_167); });
({ word_32 tmp_168 = ((intp->regs_GPR[7]) + 2); ((intp->regs_GPR[7]) = tmp_168); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_169 = (intp->regs_GPR[0]); mem_set_32(intp, (intp->regs_GPR[7]), tmp_169); });
({ word_32 tmp_170 = ((intp->regs_GPR[7]) + 4); ((intp->regs_GPR[7]) = tmp_170); });
}
break;
case 170 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_171 = ((intp->regs_GPR[0] >> 0) & 0xFF); mem_set_8(intp, (intp->regs_GPR[7]), tmp_171); });
({ word_32 tmp_172 = ((intp->regs_GPR[7]) + 1); ((intp->regs_GPR[7]) = tmp_172); });
}
break;
case 27 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_173 = (tmp_1(intp) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_174 = subcarry_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), tmp_173); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_174 << 0)); });
({ word_1 tmp_175 = addoverflow_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), (((word_16)~tmp_173) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_175 << 11)); });
({ word_16 tmp_176 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) - tmp_173); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_176 << 0)); });
({ word_1 tmp_177 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_177 << 7)); });
({ word_1 tmp_178 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_178 << 6)); });
({ word_1 tmp_179 = parity_even(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_179 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_180 = (tmp_8(intp) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_181 = subcarry_32((intp->regs_GPR[reg]), tmp_180); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_181 << 0)); });
({ word_1 tmp_182 = addoverflow_32((intp->regs_GPR[reg]), (((word_32)~tmp_180) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_182 << 11)); });
({ word_32 tmp_183 = ((intp->regs_GPR[reg]) - tmp_180); ((intp->regs_GPR[reg]) = tmp_183); });
({ word_1 tmp_184 = (((intp->regs_GPR[reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_184 << 7)); });
({ word_1 tmp_185 = (((intp->regs_GPR[reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_185 << 6)); });
({ word_1 tmp_186 = parity_even(((intp->regs_GPR[reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_186 << 2)); });
})
;
}
break;
case 26 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_8 tmp_187 = (tmp_16(intp) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_188 = subcarry_8(tmp_15(intp), tmp_187); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_188 << 0)); });
({ word_1 tmp_189 = addoverflow_8(tmp_15(intp), (((word_8)~tmp_187) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_189 << 11)); });
({ word_8 tmp_190 = (tmp_15(intp) - tmp_187); tmp_17(intp, tmp_190); });
({ word_1 tmp_191 = ((tmp_15(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_191 << 7)); });
({ word_1 tmp_192 = ((tmp_15(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_192 << 6)); });
({ word_1 tmp_193 = parity_even((tmp_15(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_193 << 2)); });
})
;
}
break;
case 25 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_194 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_195 = subcarry_16(tmp_1(intp), tmp_194); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_195 << 0)); });
({ word_1 tmp_196 = addoverflow_16(tmp_1(intp), (((word_16)~tmp_194) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_196 << 11)); });
({ word_16 tmp_197 = (tmp_1(intp) - tmp_194); tmp_24(intp, tmp_197); });
({ word_1 tmp_198 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_198 << 7)); });
({ word_1 tmp_199 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_199 << 6)); });
({ word_1 tmp_200 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_200 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_201 = ((intp->regs_GPR[reg]) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_202 = subcarry_32(tmp_8(intp), tmp_201); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_202 << 0)); });
({ word_1 tmp_203 = addoverflow_32(tmp_8(intp), (((word_32)~tmp_201) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_203 << 11)); });
({ word_32 tmp_204 = (tmp_8(intp) - tmp_201); tmp_31(intp, tmp_204); });
({ word_1 tmp_205 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_205 << 7)); });
({ word_1 tmp_206 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_206 << 6)); });
({ word_1 tmp_207 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_207 << 2)); });
})
;
}
break;
case 24 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_8 tmp_208 = (tmp_15(intp) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_209 = subcarry_8(tmp_16(intp), tmp_208); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_209 << 0)); });
({ word_1 tmp_210 = addoverflow_8(tmp_16(intp), (((word_8)~tmp_208) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_210 << 11)); });
({ word_8 tmp_211 = (tmp_16(intp) - tmp_208); tmp_38(intp, tmp_211); });
({ word_1 tmp_212 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_212 << 7)); });
({ word_1 tmp_213 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_213 << 6)); });
({ word_1 tmp_214 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_214 << 2)); });
})
;
}
break;
case 29 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_215 = (imm16 + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_216 = subcarry_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), tmp_215); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_216 << 0)); });
({ word_1 tmp_217 = addoverflow_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), (((word_16)~tmp_215) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_217 << 11)); });
({ word_16 tmp_218 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) - tmp_215); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_218 << 0)); });
({ word_1 tmp_219 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_219 << 7)); });
({ word_1 tmp_220 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_220 << 6)); });
({ word_1 tmp_221 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_221 << 2)); });
})
;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_222 = (imm32 + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_223 = subcarry_32((intp->regs_GPR[0]), tmp_222); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_223 << 0)); });
({ word_1 tmp_224 = addoverflow_32((intp->regs_GPR[0]), (((word_32)~tmp_222) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_224 << 11)); });
({ word_32 tmp_225 = ((intp->regs_GPR[0]) - tmp_222); ((intp->regs_GPR[0]) = tmp_225); });
({ word_1 tmp_226 = (((intp->regs_GPR[0]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_226 << 7)); });
({ word_1 tmp_227 = (((intp->regs_GPR[0]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_227 << 6)); });
({ word_1 tmp_228 = parity_even(((intp->regs_GPR[0]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_228 << 2)); });
})
;
}
break;
case 28 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_8 tmp_229 = (imm8 + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_230 = subcarry_8(((intp->regs_GPR[0] >> 0) & 0xFF), tmp_229); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_230 << 0)); });
({ word_1 tmp_231 = addoverflow_8(((intp->regs_GPR[0] >> 0) & 0xFF), (((word_8)~tmp_229) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_231 << 11)); });
({ word_8 tmp_232 = (((intp->regs_GPR[0] >> 0) & 0xFF) - tmp_229); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_232 << 0)); });
({ word_1 tmp_233 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_233 << 7)); });
({ word_1 tmp_234 = ((((intp->regs_GPR[0] >> 0) & 0xFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_234 << 6)); });
({ word_1 tmp_235 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_235 << 2)); });
})
;
}
break;
case 209 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_32 tmp_236 = (1 & 31);
({ word_1 tmp_237 = ((tmp_1(intp) & (1 << tmp_236)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_237 << 0)); });
({ word_16 tmp_238 = (tmp_1(intp) >> tmp_236); tmp_24(intp, tmp_238); });
({ word_1 tmp_239 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_1(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_239 << 11)); });
({ word_1 tmp_240 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_240 << 7)); });
({ word_1 tmp_241 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_241 << 6)); });
({ word_1 tmp_242 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_242 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_243 = (1 & 31);
({ word_1 tmp_244 = ((tmp_8(intp) & (1 << tmp_243)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_244 << 0)); });
({ word_32 tmp_245 = (tmp_8(intp) >> tmp_243); tmp_31(intp, tmp_245); });
({ word_1 tmp_246 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_8(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_246 << 11)); });
({ word_1 tmp_247 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_247 << 7)); });
({ word_1 tmp_248 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_248 << 6)); });
({ word_1 tmp_249 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_249 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_32 tmp_250 = (1 & 31);
({ word_1 tmp_251 = ((tmp_1(intp) & (1 << (16 - tmp_250))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_251 << 0)); });
({ word_16 tmp_252 = (tmp_1(intp) << tmp_250); tmp_24(intp, tmp_252); });
({ word_1 tmp_253 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_253 << 11)); });
({ word_1 tmp_254 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_254 << 7)); });
({ word_1 tmp_255 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_255 << 6)); });
({ word_1 tmp_256 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_256 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_257 = (1 & 31);
({ word_1 tmp_258 = ((tmp_8(intp) & (1 << (32 - tmp_257))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_258 << 0)); });
({ word_32 tmp_259 = (tmp_8(intp) << tmp_257); tmp_31(intp, tmp_259); });
({ word_1 tmp_260 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_260 << 11)); });
({ word_1 tmp_261 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_261 << 7)); });
({ word_1 tmp_262 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_262 << 6)); });
({ word_1 tmp_263 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_263 << 2)); });
})
;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_264 = ((tmp_1(intp) >> (1 & 31)) | ((tmp_1(intp) & (1 << 15)) ? ~((1 << (16 - (1 & 31))) - 1) : 0)); tmp_24(intp, tmp_264); });
({ word_1 tmp_265 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_265 << 7)); });
({ word_1 tmp_266 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_266 << 6)); });
({ word_1 tmp_267 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_267 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_268 = ((tmp_8(intp) >> (1 & 31)) | ((tmp_8(intp) & (1 << 31)) ? ~((1 << (32 - (1 & 31))) - 1) : 0)); tmp_31(intp, tmp_268); });
({ word_1 tmp_269 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_269 << 7)); });
({ word_1 tmp_270 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_270 << 6)); });
({ word_1 tmp_271 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_271 << 2)); });
}
break;
default :
bt_assert(0);
}
}
break;
case 192 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_272 = (imm8 & 31);
({ word_1 tmp_273 = ((tmp_16(intp) & (1 << tmp_272)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_273 << 0)); });
({ word_8 tmp_274 = (tmp_16(intp) >> tmp_272); tmp_38(intp, tmp_274); });
({ word_1 tmp_275 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_16(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_275 << 11)); });
({ word_1 tmp_276 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_276 << 7)); });
({ word_1 tmp_277 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_277 << 6)); });
({ word_1 tmp_278 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_278 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_279 = (imm8 & 31);
({ word_1 tmp_280 = ((tmp_16(intp) & (1 << (8 - tmp_279))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_280 << 0)); });
({ word_8 tmp_281 = (tmp_16(intp) << tmp_279); tmp_38(intp, tmp_281); });
({ word_1 tmp_282 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_282 << 11)); });
({ word_1 tmp_283 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_283 << 7)); });
({ word_1 tmp_284 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_284 << 6)); });
({ word_1 tmp_285 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_285 << 2)); });
})
;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_286 = ((tmp_16(intp) >> (imm8 & 31)) | ((tmp_16(intp) & (1 << 7)) ? ~((1 << (8 - (imm8 & 31))) - 1) : 0)); tmp_38(intp, tmp_286); });
({ word_1 tmp_287 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_287 << 7)); });
({ word_1 tmp_288 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_288 << 6)); });
({ word_1 tmp_289 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_289 << 2)); });
}
break;
default :
bt_assert(0);
}
}
break;
case 210 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_290 = (((intp->regs_GPR[1] >> 0) & 0xFF) & 31);
({ word_1 tmp_291 = ((tmp_16(intp) & (1 << tmp_290)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_291 << 0)); });
({ word_8 tmp_292 = (tmp_16(intp) >> tmp_290); tmp_38(intp, tmp_292); });
({ word_1 tmp_293 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_16(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_293 << 11)); });
({ word_1 tmp_294 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_294 << 7)); });
({ word_1 tmp_295 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_295 << 6)); });
({ word_1 tmp_296 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_296 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_297 = (((intp->regs_GPR[1] >> 0) & 0xFF) & 31);
({ word_1 tmp_298 = ((tmp_16(intp) & (1 << (8 - tmp_297))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_298 << 0)); });
({ word_8 tmp_299 = (tmp_16(intp) << tmp_297); tmp_38(intp, tmp_299); });
({ word_1 tmp_300 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_300 << 11)); });
({ word_1 tmp_301 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_301 << 7)); });
({ word_1 tmp_302 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_302 << 6)); });
({ word_1 tmp_303 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_303 << 2)); });
})
;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_304 = ((tmp_16(intp) >> (((intp->regs_GPR[1] >> 0) & 0xFF) & 31)) | ((tmp_16(intp) & (1 << 7)) ? ~((1 << (8 - (((intp->regs_GPR[1] >> 0) & 0xFF) & 31))) - 1) : 0)); tmp_38(intp, tmp_304); });
({ word_1 tmp_305 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_305 << 7)); });
({ word_1 tmp_306 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_306 << 6)); });
({ word_1 tmp_307 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_307 << 2)); });
}
break;
default :
bt_assert(0);
}
}
break;
case 208 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_308 = (1 & 31);
({ word_1 tmp_309 = ((tmp_16(intp) & (1 << tmp_308)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_309 << 0)); });
({ word_8 tmp_310 = (tmp_16(intp) >> tmp_308); tmp_38(intp, tmp_310); });
({ word_1 tmp_311 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_16(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_311 << 11)); });
({ word_1 tmp_312 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_312 << 7)); });
({ word_1 tmp_313 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_313 << 6)); });
({ word_1 tmp_314 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_314 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_315 = (1 & 31);
({ word_1 tmp_316 = ((tmp_16(intp) & (1 << (8 - tmp_315))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_316 << 0)); });
({ word_8 tmp_317 = (tmp_16(intp) << tmp_315); tmp_38(intp, tmp_317); });
({ word_1 tmp_318 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_318 << 11)); });
({ word_1 tmp_319 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_319 << 7)); });
({ word_1 tmp_320 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_320 << 6)); });
({ word_1 tmp_321 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_321 << 2)); });
})
;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_322 = ((tmp_16(intp) >> (1 & 31)) | ((tmp_16(intp) & (1 << 7)) ? ~((1 << (8 - (1 & 31))) - 1) : 0)); tmp_38(intp, tmp_322); });
({ word_1 tmp_323 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_323 << 7)); });
({ word_1 tmp_324 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_324 << 6)); });
({ word_1 tmp_325 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_325 << 2)); });
}
break;
default :
bt_assert(0);
}
}
break;
case 193 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_326 = (imm8 & 31);
({ word_1 tmp_327 = ((tmp_1(intp) & (1 << tmp_326)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_327 << 0)); });
({ word_16 tmp_328 = (tmp_1(intp) >> tmp_326); tmp_24(intp, tmp_328); });
({ word_1 tmp_329 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_1(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_329 << 11)); });
({ word_1 tmp_330 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_330 << 7)); });
({ word_1 tmp_331 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_331 << 6)); });
({ word_1 tmp_332 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_332 << 2)); });
})
;
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_333 = (imm8 & 31);
({ word_1 tmp_334 = ((tmp_8(intp) & (1 << tmp_333)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_334 << 0)); });
({ word_32 tmp_335 = (tmp_8(intp) >> tmp_333); tmp_31(intp, tmp_335); });
({ word_1 tmp_336 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_8(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_336 << 11)); });
({ word_1 tmp_337 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_337 << 7)); });
({ word_1 tmp_338 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_338 << 6)); });
({ word_1 tmp_339 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_339 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_340 = (imm8 & 31);
({ word_1 tmp_341 = ((tmp_1(intp) & (1 << (16 - tmp_340))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_341 << 0)); });
({ word_16 tmp_342 = (tmp_1(intp) << tmp_340); tmp_24(intp, tmp_342); });
({ word_1 tmp_343 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_343 << 11)); });
({ word_1 tmp_344 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_344 << 7)); });
({ word_1 tmp_345 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_345 << 6)); });
({ word_1 tmp_346 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_346 << 2)); });
})
;
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_347 = (imm8 & 31);
({ word_1 tmp_348 = ((tmp_8(intp) & (1 << (32 - tmp_347))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_348 << 0)); });
({ word_32 tmp_349 = (tmp_8(intp) << tmp_347); tmp_31(intp, tmp_349); });
({ word_1 tmp_350 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_350 << 11)); });
({ word_1 tmp_351 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_351 << 7)); });
({ word_1 tmp_352 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_352 << 6)); });
({ word_1 tmp_353 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_353 << 2)); });
})
;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_354 = ((tmp_1(intp) >> (imm8 & 31)) | ((tmp_1(intp) & (1 << 15)) ? ~((1 << (16 - (imm8 & 31))) - 1) : 0)); tmp_24(intp, tmp_354); });
({ word_1 tmp_355 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_355 << 7)); });
({ word_1 tmp_356 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_356 << 6)); });
({ word_1 tmp_357 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_357 << 2)); });
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_358 = ((tmp_8(intp) >> (imm8 & 31)) | ((tmp_8(intp) & (1 << 31)) ? ~((1 << (32 - (imm8 & 31))) - 1) : 0)); tmp_31(intp, tmp_358); });
({ word_1 tmp_359 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_359 << 7)); });
({ word_1 tmp_360 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_360 << 6)); });
({ word_1 tmp_361 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_361 << 2)); });
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_362 = (imm8 & (16 - 1));
({ word_16 tmp_363 = rotl_16(tmp_1(intp), (16 - tmp_362)); tmp_24(intp, tmp_363); });
({ word_1 tmp_364 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_364 << 0)); });
((tmp_362 == 1) ? ({ word_1 tmp_365 = ((((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0) ^ ((tmp_1(intp) & (1 << (16 - 2))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_365 << 11)); }) : 0 /* nop */);
})
;
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_366 = (imm8 & (32 - 1));
({ word_32 tmp_367 = rotl_32(tmp_8(intp), (32 - tmp_366)); tmp_31(intp, tmp_367); });
({ word_1 tmp_368 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_368 << 0)); });
((tmp_366 == 1) ? ({ word_1 tmp_369 = ((((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0) ^ ((tmp_8(intp) & (1 << (32 - 2))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_369 << 11)); }) : 0 /* nop */);
})
;
}
break;
default :
bt_assert(0);
}
}
break;
case 211 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_32 tmp_370 = (((intp->regs_GPR[1] >> 0) & 0xFF) & 31);
({ word_1 tmp_371 = ((tmp_1(intp) & (1 << tmp_370)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_371 << 0)); });
({ word_16 tmp_372 = (tmp_1(intp) >> tmp_370); tmp_24(intp, tmp_372); });
({ word_1 tmp_373 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_1(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_373 << 11)); });
({ word_1 tmp_374 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_374 << 7)); });
({ word_1 tmp_375 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_375 << 6)); });
({ word_1 tmp_376 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_376 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_377 = (((intp->regs_GPR[1] >> 0) & 0xFF) & 31);
({ word_1 tmp_378 = ((tmp_8(intp) & (1 << tmp_377)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_378 << 0)); });
({ word_32 tmp_379 = (tmp_8(intp) >> tmp_377); tmp_31(intp, tmp_379); });
({ word_1 tmp_380 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_8(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_380 << 11)); });
({ word_1 tmp_381 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_381 << 7)); });
({ word_1 tmp_382 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_382 << 6)); });
({ word_1 tmp_383 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_383 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_32 tmp_384 = (((intp->regs_GPR[1] >> 0) & 0xFF) & 31);
({ word_1 tmp_385 = ((tmp_1(intp) & (1 << (16 - tmp_384))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_385 << 0)); });
({ word_16 tmp_386 = (tmp_1(intp) << tmp_384); tmp_24(intp, tmp_386); });
({ word_1 tmp_387 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_387 << 11)); });
({ word_1 tmp_388 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_388 << 7)); });
({ word_1 tmp_389 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_389 << 6)); });
({ word_1 tmp_390 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_390 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_391 = (((intp->regs_GPR[1] >> 0) & 0xFF) & 31);
({ word_1 tmp_392 = ((tmp_8(intp) & (1 << (32 - tmp_391))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_392 << 0)); });
({ word_32 tmp_393 = (tmp_8(intp) << tmp_391); tmp_31(intp, tmp_393); });
({ word_1 tmp_394 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_394 << 11)); });
({ word_1 tmp_395 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_395 << 7)); });
({ word_1 tmp_396 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_396 << 6)); });
({ word_1 tmp_397 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_397 << 2)); });
})
;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_398 = ((tmp_1(intp) >> (((intp->regs_GPR[1] >> 0) & 0xFF) & 31)) | ((tmp_1(intp) & (1 << 15)) ? ~((1 << (16 - (((intp->regs_GPR[1] >> 0) & 0xFF) & 31))) - 1) : 0)); tmp_24(intp, tmp_398); });
({ word_1 tmp_399 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_399 << 7)); });
({ word_1 tmp_400 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_400 << 6)); });
({ word_1 tmp_401 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_401 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_402 = ((tmp_8(intp) >> (((intp->regs_GPR[1] >> 0) & 0xFF) & 31)) | ((tmp_8(intp) & (1 << 31)) ? ~((1 << (32 - (((intp->regs_GPR[1] >> 0) & 0xFF) & 31))) - 1) : 0)); tmp_31(intp, tmp_402); });
({ word_1 tmp_403 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_403 << 7)); });
({ word_1 tmp_404 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_404 << 6)); });
({ word_1 tmp_405 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_405 << 2)); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_32 tmp_406 = (((intp->regs_GPR[1] >> 0) & 0xFF) & (16 - 1));
({ word_16 tmp_407 = rotl_16(tmp_1(intp), tmp_406); tmp_24(intp, tmp_407); });
({ word_1 tmp_408 = ((tmp_1(intp) & (1 << 0)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_408 << 0)); });
((tmp_406 == 1) ? ({ word_1 tmp_409 = ((((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0) ^ ((intp->regs_SPR[0] >> 0) & 0x1)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_409 << 11)); }) : 0 /* nop */);
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_410 = (((intp->regs_GPR[1] >> 0) & 0xFF) & (32 - 1));
({ word_32 tmp_411 = rotl_32(tmp_8(intp), tmp_410); tmp_31(intp, tmp_411); });
({ word_1 tmp_412 = ((tmp_8(intp) & (1 << 0)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_412 << 0)); });
((tmp_410 == 1) ? ({ word_1 tmp_413 = ((((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0) ^ ((intp->regs_SPR[0] >> 0) & 0x1)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_413 << 11)); }) : 0 /* nop */);
})
;
}
break;
default :
bt_assert(0);
}
}
break;
case 194 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
({ word_32 tmp_414 = (((intp->regs_GPR[4]) + imm16) + 4); ((intp->regs_GPR[4]) = tmp_414); });
(next_pc = mem_get_32(intp, (((intp->regs_GPR[4]) - imm16) - 4)));
}
break;
case 195 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
intp->have_jumped = 1;
({ word_32 tmp_415 = ((intp->regs_GPR[4]) + 4); ((intp->regs_GPR[4]) = tmp_415); });
(next_pc = mem_get_32(intp, ((intp->regs_GPR[4]) - 4)));
}
break;
case 242 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 174 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
(((intp->regs_GPR[1]) == 0) ? 0 /* nop */ : 
({ do {
({
word_8 tmp_416 = (((intp->regs_GPR[0] >> 0) & 0xFF) - mem_get_8(intp, (intp->regs_GPR[7])));
({ word_1 tmp_417 = subcarry_8(((intp->regs_GPR[0] >> 0) & 0xFF), mem_get_8(intp, (intp->regs_GPR[7]))); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_417 << 0)); });
({ word_1 tmp_418 = ((tmp_416 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_418 << 6)); });
({ word_1 tmp_419 = ((tmp_416 & (1 << 7)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_419 << 7)); });
})
;
({ word_32 tmp_420 = ((intp->regs_GPR[7]) + 1); ((intp->regs_GPR[7]) = tmp_420); });
({ word_32 tmp_421 = ((intp->regs_GPR[1]) - 1); ((intp->regs_GPR[1]) = tmp_421); });
} while (((((intp->regs_SPR[0] >> 6) & 0x1) == 0) && (!((intp->regs_GPR[1]) == 0)))); })
);
}
break;
default :
switch (reg) {
default :
bt_assert(0);
}
}
break;
case 243 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 171 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
(((intp->regs_GPR[1]) == 0) ? 0 /* nop */ : 
({ do {
({ word_32 tmp_422 = (intp->regs_GPR[0]); mem_set_32(intp, (intp->regs_GPR[7]), tmp_422); });
({ word_32 tmp_423 = ((intp->regs_GPR[7]) + 4); ((intp->regs_GPR[7]) = tmp_423); });
({ word_32 tmp_424 = ((intp->regs_GPR[1]) - 1); ((intp->regs_GPR[1]) = tmp_424); });
} while ((!((intp->regs_GPR[1]) == 0))); })
);
}
break;
case 170 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
(((intp->regs_GPR[1]) == 0) ? 0 /* nop */ : 
({ do {
({ word_8 tmp_425 = ((intp->regs_GPR[0] >> 0) & 0xFF); mem_set_8(intp, (intp->regs_GPR[7]), tmp_425); });
({ word_32 tmp_426 = ((intp->regs_GPR[7]) + 1); ((intp->regs_GPR[7]) = tmp_426); });
({ word_32 tmp_427 = ((intp->regs_GPR[1]) - 1); ((intp->regs_GPR[1]) = tmp_427); });
} while ((!((intp->regs_GPR[1]) == 0))); })
);
}
break;
case 165 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
(((intp->regs_GPR[1]) == 0) ? 0 /* nop */ : 
({ do {
({ word_32 tmp_428 = mem_get_32(intp, (intp->regs_GPR[6])); mem_set_32(intp, (intp->regs_GPR[7]), tmp_428); });
({ word_32 tmp_429 = ((intp->regs_GPR[6]) + 4); ((intp->regs_GPR[6]) = tmp_429); });
({ word_32 tmp_430 = ((intp->regs_GPR[7]) + 4); ((intp->regs_GPR[7]) = tmp_430); });
({ word_32 tmp_431 = ((intp->regs_GPR[1]) - 1); ((intp->regs_GPR[1]) = tmp_431); });
} while ((!((intp->regs_GPR[1]) == 0))); })
);
}
break;
case 164 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
(((intp->regs_GPR[1]) == 0) ? 0 /* nop */ : 
({ do {
({ word_8 tmp_432 = mem_get_8(intp, (intp->regs_GPR[6])); mem_set_8(intp, (intp->regs_GPR[7]), tmp_432); });
({ word_32 tmp_433 = ((intp->regs_GPR[6]) + 1); ((intp->regs_GPR[6]) = tmp_433); });
({ word_32 tmp_434 = ((intp->regs_GPR[7]) + 1); ((intp->regs_GPR[7]) = tmp_434); });
({ word_32 tmp_435 = ((intp->regs_GPR[1]) - 1); ((intp->regs_GPR[1]) = tmp_435); });
} while ((!((intp->regs_GPR[1]) == 0))); })
);
}
break;
case 166 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
(((intp->regs_GPR[1]) == 0) ? 0 /* nop */ : 
({ do {
({
word_8 tmp_436 = mem_get_8(intp, (intp->regs_GPR[6]));
word_8 tmp_437 = mem_get_8(intp, (intp->regs_GPR[7]));
({
word_8 tmp_438 = (tmp_436 - tmp_437);
({ word_1 tmp_439 = subcarry_8(tmp_436, tmp_437); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_439 << 0)); });
({ word_1 tmp_440 = ((tmp_438 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_440 << 6)); });
({ word_1 tmp_441 = ((tmp_438 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_441 << 7)); });
({ word_1 tmp_442 = addoverflow_8(tmp_436, (((word_8)~tmp_437) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_442 << 11)); });
})
;
})
;
({ word_32 tmp_443 = ((intp->regs_GPR[6]) + 1); ((intp->regs_GPR[6]) = tmp_443); });
({ word_32 tmp_444 = ((intp->regs_GPR[7]) + 1); ((intp->regs_GPR[7]) = tmp_444); });
({ word_32 tmp_445 = ((intp->regs_GPR[1]) - 1); ((intp->regs_GPR[1]) = tmp_445); });
} while (((((intp->regs_SPR[0] >> 6) & 0x1) == 1) && (!((intp->regs_GPR[1]) == 0)))); })
);
}
break;
default :
switch (reg) {
default :
bt_assert(0);
}
}
break;
case 104 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_446 = imm32; mem_set_32(intp, ((intp->regs_GPR[4]) - 4), tmp_446); });
({ word_32 tmp_447 = ((intp->regs_GPR[4]) - 4); ((intp->regs_GPR[4]) = tmp_447); });
}
break;
case 106 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_448 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8); mem_set_32(intp, ((intp->regs_GPR[4]) - 4), tmp_448); });
({ word_32 tmp_449 = ((intp->regs_GPR[4]) - 4); ((intp->regs_GPR[4]) = tmp_449); });
}
break;
case 80 :
case 81 :
case 82 :
case 83 :
case 84 :
case 85 :
case 86 :
case 87 :
opcode_reg = opcode - 80;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_450 = (intp->regs_GPR[opcode_reg]); mem_set_32(intp, ((intp->regs_GPR[4]) - 4), tmp_450); });
({ word_32 tmp_451 = ((intp->regs_GPR[4]) - 4); ((intp->regs_GPR[4]) = tmp_451); });
}
break;
case 88 :
case 89 :
case 90 :
case 91 :
case 92 :
case 93 :
case 94 :
case 95 :
opcode_reg = opcode - 88;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_452 = ((intp->regs_GPR[4]) + 4); ((intp->regs_GPR[4]) = tmp_452); });
({ word_32 tmp_453 = mem_get_32(intp, ((intp->regs_GPR[4]) - 4)); ((intp->regs_GPR[opcode_reg]) = tmp_453); });
}
break;
case 143 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_454 = ((intp->regs_GPR[4]) + 4); ((intp->regs_GPR[4]) = tmp_454); });
({ word_32 tmp_455 = mem_get_32(intp, ((intp->regs_GPR[4]) - 4)); tmp_31(intp, tmp_455); });
}
break;
default :
bt_assert(0);
}
}
break;
case 11 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_456 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) | tmp_1(intp)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_456 << 0)); });
({ word_1 tmp_457 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_457 << 0)); });
({ word_1 tmp_458 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_458 << 11)); });
({ word_1 tmp_459 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_459 << 7)); });
({ word_1 tmp_460 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_460 << 6)); });
({ word_1 tmp_461 = parity_even(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_461 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_462 = ((intp->regs_GPR[reg]) | tmp_8(intp)); ((intp->regs_GPR[reg]) = tmp_462); });
({ word_1 tmp_463 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_463 << 0)); });
({ word_1 tmp_464 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_464 << 11)); });
({ word_1 tmp_465 = (((intp->regs_GPR[reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_465 << 7)); });
({ word_1 tmp_466 = (((intp->regs_GPR[reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_466 << 6)); });
({ word_1 tmp_467 = parity_even(((intp->regs_GPR[reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_467 << 2)); });
}
break;
case 10 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_468 = (tmp_15(intp) | tmp_16(intp)); tmp_17(intp, tmp_468); });
({ word_1 tmp_469 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_469 << 0)); });
({ word_1 tmp_470 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_470 << 11)); });
({ word_1 tmp_471 = ((tmp_15(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_471 << 7)); });
({ word_1 tmp_472 = ((tmp_15(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_472 << 6)); });
({ word_1 tmp_473 = parity_even((tmp_15(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_473 << 2)); });
}
break;
case 9 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_474 = (tmp_1(intp) | (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); tmp_24(intp, tmp_474); });
({ word_1 tmp_475 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_475 << 0)); });
({ word_1 tmp_476 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_476 << 11)); });
({ word_1 tmp_477 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_477 << 7)); });
({ word_1 tmp_478 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_478 << 6)); });
({ word_1 tmp_479 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_479 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_480 = (tmp_8(intp) | (intp->regs_GPR[reg])); tmp_31(intp, tmp_480); });
({ word_1 tmp_481 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_481 << 0)); });
({ word_1 tmp_482 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_482 << 11)); });
({ word_1 tmp_483 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_483 << 7)); });
({ word_1 tmp_484 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_484 << 6)); });
({ word_1 tmp_485 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_485 << 2)); });
}
break;
case 8 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_486 = (tmp_16(intp) | tmp_15(intp)); tmp_38(intp, tmp_486); });
({ word_1 tmp_487 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_487 << 0)); });
({ word_1 tmp_488 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_488 << 11)); });
({ word_1 tmp_489 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_489 << 7)); });
({ word_1 tmp_490 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_490 << 6)); });
({ word_1 tmp_491 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_491 << 2)); });
}
break;
case 13 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_492 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) | imm16); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_492 << 0)); });
({ word_1 tmp_493 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_493 << 0)); });
({ word_1 tmp_494 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_494 << 11)); });
({ word_1 tmp_495 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_495 << 7)); });
({ word_1 tmp_496 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_496 << 6)); });
({ word_1 tmp_497 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_497 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_498 = ((intp->regs_GPR[0]) | imm32); ((intp->regs_GPR[0]) = tmp_498); });
({ word_1 tmp_499 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_499 << 0)); });
({ word_1 tmp_500 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_500 << 11)); });
({ word_1 tmp_501 = (((intp->regs_GPR[0]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_501 << 7)); });
({ word_1 tmp_502 = (((intp->regs_GPR[0]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_502 << 6)); });
({ word_1 tmp_503 = parity_even(((intp->regs_GPR[0]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_503 << 2)); });
}
break;
case 12 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_504 = (((intp->regs_GPR[0] >> 0) & 0xFF) | imm8); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_504 << 0)); });
({ word_1 tmp_505 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_505 << 0)); });
({ word_1 tmp_506 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_506 << 11)); });
({ word_1 tmp_507 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_507 << 7)); });
({ word_1 tmp_508 = ((((intp->regs_GPR[0] >> 0) & 0xFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_508 << 6)); });
({ word_1 tmp_509 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_509 << 2)); });
}
break;
case 199 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_510 = imm16; tmp_24(intp, tmp_510); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_511 = imm32; tmp_31(intp, tmp_511); });
}
break;
default :
bt_assert(0);
}
}
break;
case 198 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_512 = imm8; tmp_38(intp, tmp_512); });
}
break;
default :
bt_assert(0);
}
}
break;
case 184 :
case 185 :
case 186 :
case 187 :
case 188 :
case 189 :
case 190 :
case 191 :
opcode_reg = opcode - 184;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_513 = imm16; ((intp->regs_GPR[opcode_reg]) = ((intp->regs_GPR[opcode_reg]) & 0xFFFF0000) | (tmp_513 << 0)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_514 = imm32; ((intp->regs_GPR[opcode_reg]) = tmp_514); });
}
break;
case 176 :
case 177 :
case 178 :
case 179 :
case 180 :
case 181 :
case 182 :
case 183 :
opcode_reg = opcode - 176;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_515 = imm8; tmp_516(intp, tmp_515); });
}
break;
case 163 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_517 = ((intp->regs_GPR[0] >> 0) & 0xFFFF); mem_set_16(intp, imm32, tmp_517); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_518 = (intp->regs_GPR[0]); mem_set_32(intp, imm32, tmp_518); });
}
break;
case 161 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_519 = mem_get_16(intp, imm32); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_519 << 0)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_520 = mem_get_32(intp, imm32); ((intp->regs_GPR[0]) = tmp_520); });
}
break;
case 139 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_521 = tmp_1(intp); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_521 << 0)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_522 = tmp_8(intp); ((intp->regs_GPR[reg]) = tmp_522); });
}
break;
case 138 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_523 = tmp_16(intp); tmp_17(intp, tmp_523); });
}
break;
case 137 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_524 = (((intp->regs_GPR[reg]) >> 0) & 0xFFFF); tmp_24(intp, tmp_524); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_525 = (intp->regs_GPR[reg]); tmp_31(intp, tmp_525); });
}
break;
case 136 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_526 = tmp_15(intp); tmp_38(intp, tmp_526); });
}
break;
case 141 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_527 = tmp_528(intp); ((intp->regs_GPR[reg]) = tmp_527); });
}
break;
case 120 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == 1) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 122 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 2) & 0x1) == 1) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 121 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == 0) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 123 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 2) & 0x1) == 0) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 117 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 6) & 0x1) == 0) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 233 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(next_pc = (pc + imm32));
}
break;
case 235 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)));
}
break;
case 126 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 6) & 0x1) == 1) || (!(((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)))) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 124 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)) ? 0 /* nop */ : (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))));
}
break;
case 125 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 127 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 6) & 0x1) == 0) && (((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1))) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 116 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 6) & 0x1) == 1) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 118 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 0) & 0x1) == 1) || (((intp->regs_SPR[0] >> 6) & 0x1) == 1)) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 114 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 0) & 0x1) == 1) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 115 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 0) & 0x1) == 0) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 119 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 0) & 0x1) == 0) && (((intp->regs_SPR[0] >> 6) & 0x1) == 0)) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 205 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
handle_system_call(intp);
}
break;
case 64 :
case 65 :
case 66 :
case 67 :
case 68 :
case 69 :
case 70 :
case 71 :
opcode_reg = opcode - 64;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_529 = addoverflow_16((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_529 << 11)); });
({ word_16 tmp_530 = ((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) + 1); ((intp->regs_GPR[opcode_reg]) = ((intp->regs_GPR[opcode_reg]) & 0xFFFF0000) | (tmp_530 << 0)); });
({ word_1 tmp_531 = (((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_531 << 7)); });
({ word_1 tmp_532 = (((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_532 << 6)); });
({ word_1 tmp_533 = parity_even(((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_533 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_534 = addoverflow_32((intp->regs_GPR[opcode_reg]), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_534 << 11)); });
({ word_32 tmp_535 = ((intp->regs_GPR[opcode_reg]) + 1); ((intp->regs_GPR[opcode_reg]) = tmp_535); });
({ word_1 tmp_536 = (((intp->regs_GPR[opcode_reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_536 << 7)); });
({ word_1 tmp_537 = (((intp->regs_GPR[opcode_reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_537 << 6)); });
({ word_1 tmp_538 = parity_even(((intp->regs_GPR[opcode_reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_538 << 2)); });
}
break;
case 105 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_539 = ((word_16)((((imm16 & 0x8000) ? ((word_32)imm16 | 0xFFFF0000) : (word_32)imm16) * ((tmp_1(intp) & 0x8000) ? ((word_32)tmp_1(intp) | 0xFFFF0000) : (word_32)tmp_1(intp))) >> 16));
({ word_1 tmp_540 = (((tmp_539 == 0) || (tmp_539 == ((word_16)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_540 << 0)); });
({ word_1 tmp_541 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_541 << 11)); });
})
;
({ word_16 tmp_542 = (imm16 * tmp_1(intp)); tmp_24(intp, tmp_542); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_543 = ((word_32)((((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32) * ((tmp_8(intp) & 0x80000000) ? ((word_64)tmp_8(intp) | 0xFFFFFFFF00000000) : (word_64)tmp_8(intp))) >> 32));
({ word_1 tmp_544 = (((tmp_543 == 0) || (tmp_543 == ((word_32)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_544 << 0)); });
({ word_1 tmp_545 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_545 << 11)); });
})
;
({ word_32 tmp_546 = (imm32 * tmp_8(intp)); tmp_31(intp, tmp_546); });
}
break;
case 221 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 232 :
case 233 :
case 234 :
case 235 :
case 236 :
case 237 :
case 238 :
case 239 :
opcode_reg = opcode2 - 232;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_547 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_547 << 8)); });
({ word_1 tmp_548 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_548 << 10)); });
({ word_1 tmp_549 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_549 << 14)); });
({ word_3 tmp_550 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_550 << 11)); });
}
break;
case 224 :
case 225 :
case 226 :
case 227 :
case 228 :
case 229 :
case 230 :
case 231 :
opcode_reg = opcode2 - 224;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_551 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_551 << 8)); });
({ word_1 tmp_552 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_552 << 10)); });
({ word_1 tmp_553 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_553 << 14)); });
}
break;
case 216 :
case 217 :
case 218 :
case 219 :
case 220 :
case 221 :
case 222 :
case 223 :
opcode_reg = opcode2 - 216;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_554 = (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_554); });
({ word_3 tmp_555 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_555 << 11)); });
}
break;
case 208 :
case 209 :
case 210 :
case 211 :
case 212 :
case 213 :
case 214 :
case 215 :
opcode_reg = opcode2 - 208;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_556 = (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_556); });
}
break;
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_64 tmp_557 = ({ double tmp = (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]); *(word_64*)&tmp; }); mem_set_64(intp, tmp_528(intp), tmp_557); });
({ word_3 tmp_558 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_558 << 11)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_64 tmp_559 = ({ double tmp = (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]); *(word_64*)&tmp; }); mem_set_64(intp, tmp_528(intp), tmp_559); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_560 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_560 << 11)); });
({ double tmp_561 = ({ word_64 tmp = mem_get_64(intp, tmp_528(intp)); *(double*)&tmp; }); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_561); });
}
break;
default :
bt_assert(0);
}
}
break;
case 219 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_64 tmp_562 = ({ double tmp = (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]); *(word_64*)&tmp; }); mem_set_64(intp, tmp_528(intp), tmp_562); });
({ word_3 tmp_563 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_563 << 11)); });
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_564 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_564 << 11)); });
({ double tmp_565 = ({ word_64 tmp = mem_get_64(intp, tmp_528(intp)); *(double*)&tmp; }); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_565); });
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_566 = ((word_32)(sword_32)(intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); tmp_31(intp, tmp_566); });
({ word_3 tmp_567 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_567 << 11)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_568 = ((word_32)(sword_32)(intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); tmp_31(intp, tmp_568); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_569 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_569 << 11)); });
({ double tmp_570 = ((double)(sword_32)tmp_8(intp)); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_570); });
}
break;
default :
bt_assert(0);
}
}
break;
case 223 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 224 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_16 tmp_571 = (intp->regs_FSPR[0]); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_571 << 0)); });
}
break;
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_64 tmp_572 = ((word_64)(sword_64)(intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); mem_set_64(intp, tmp_528(intp), tmp_572); });
({ word_3 tmp_573 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_573 << 11)); });
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_574 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_574 << 11)); });
({ double tmp_575 = ((double)(sword_64)mem_get_64(intp, tmp_528(intp))); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_575); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_576 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_576 << 11)); });
({ double tmp_577 = ((double)(sword_16)tmp_1(intp)); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_577); });
}
break;
default :
bt_assert(0);
}
}
break;
case 218 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 233 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_578 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_578 << 8)); });
({ word_1 tmp_579 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_579 << 10)); });
({ word_1 tmp_580 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_580 << 14)); });
({ word_3 tmp_581 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 2) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_581 << 11)); });
}
break;
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_582 = (((double)(sword_32)tmp_8(intp)) - (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_582); });
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_583 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) * ((double)(sword_32)tmp_8(intp))); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_583); });
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_584 = (((double)(sword_32)tmp_8(intp)) / (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_584); });
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_585 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) / ((double)(sword_32)tmp_8(intp))); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_585); });
}
break;
default :
bt_assert(0);
}
}
break;
case 222 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 224 :
case 225 :
case 226 :
case 227 :
case 228 :
case 229 :
case 230 :
case 231 :
opcode_reg = opcode2 - 224;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_586 = ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) - (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_586); });
({ word_3 tmp_587 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_587 << 11)); });
}
break;
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_588 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) * (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_588); });
({ word_3 tmp_589 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_589 << 11)); });
}
break;
case 240 :
case 241 :
case 242 :
case 243 :
case 244 :
case 245 :
case 246 :
case 247 :
opcode_reg = opcode2 - 240;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_590 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) / (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_590); });
({ word_3 tmp_591 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_591 << 11)); });
}
break;
case 248 :
case 249 :
case 250 :
case 251 :
case 252 :
case 253 :
case 254 :
case 255 :
opcode_reg = opcode2 - 248;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_592 = ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) / (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_592); });
({ word_3 tmp_593 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_593 << 11)); });
}
break;
case 217 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_594 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_594 << 8)); });
({ word_1 tmp_595 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_595 << 10)); });
({ word_1 tmp_596 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_596 << 14)); });
({ word_3 tmp_597 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 2) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_597 << 11)); });
}
break;
case 192 :
case 193 :
case 194 :
case 195 :
case 196 :
case 197 :
case 198 :
case 199 :
opcode_reg = opcode2 - 192;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_598 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) + (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_598); });
({ word_3 tmp_599 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_599 << 11)); });
}
break;
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
default :
bt_assert(0);
}
}
break;
case 220 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_600 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) * (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_600); });
}
break;
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_601 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) - ({ word_64 tmp = mem_get_64(intp, tmp_528(intp)); *(double*)&tmp; })); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_601); });
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_602 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) * ({ word_64 tmp = mem_get_64(intp, tmp_528(intp)); *(double*)&tmp; })); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_602); });
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_603 = (({ word_64 tmp = mem_get_64(intp, tmp_528(intp)); *(double*)&tmp; }) / (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_603); });
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_604 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) / ({ word_64 tmp = mem_get_64(intp, tmp_528(intp)); *(double*)&tmp; })); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_604); });
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_605 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < ({ word_64 tmp = mem_get_64(intp, tmp_528(intp)); *(double*)&tmp; })) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_605 << 8)); });
({ word_1 tmp_606 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_606 << 10)); });
({ word_1 tmp_607 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == ({ word_64 tmp = mem_get_64(intp, tmp_528(intp)); *(double*)&tmp; })) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_607 << 14)); });
({ word_3 tmp_608 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_608 << 11)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_609 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < ({ word_64 tmp = mem_get_64(intp, tmp_528(intp)); *(double*)&tmp; })) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_609 << 8)); });
({ word_1 tmp_610 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_610 << 10)); });
({ word_1 tmp_611 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == ({ word_64 tmp = mem_get_64(intp, tmp_528(intp)); *(double*)&tmp; })) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_611 << 14)); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_612 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) + ({ word_64 tmp = mem_get_64(intp, tmp_528(intp)); *(double*)&tmp; })); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_612); });
}
break;
default :
bt_assert(0);
}
}
break;
case 216 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 224 :
case 225 :
case 226 :
case 227 :
case 228 :
case 229 :
case 230 :
case 231 :
opcode_reg = opcode2 - 224;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_613 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) - (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_613); });
}
break;
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_614 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) * (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_614); });
}
break;
case 240 :
case 241 :
case 242 :
case 243 :
case 244 :
case 245 :
case 246 :
case 247 :
opcode_reg = opcode2 - 240;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_615 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) / (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_615); });
}
break;
case 216 :
case 217 :
case 218 :
case 219 :
case 220 :
case 221 :
case 222 :
case 223 :
opcode_reg = opcode2 - 216;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_616 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_616 << 8)); });
({ word_1 tmp_617 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_617 << 10)); });
({ word_1 tmp_618 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_618 << 14)); });
({ word_3 tmp_619 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_619 << 11)); });
}
break;
case 208 :
case 209 :
case 210 :
case 211 :
case 212 :
case 213 :
case 214 :
case 215 :
opcode_reg = opcode2 - 208;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_620 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_620 << 8)); });
({ word_1 tmp_621 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_621 << 10)); });
({ word_1 tmp_622 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_622 << 14)); });
}
break;
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_623 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) - ((double)({ word_32 tmp = tmp_8(intp); *(float*)&tmp; }))); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_623); });
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_624 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) / ((double)({ word_32 tmp = tmp_8(intp); *(float*)&tmp; }))); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_624); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_625 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) + ((double)({ word_32 tmp = tmp_8(intp); *(float*)&tmp; }))); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_625); });
}
break;
default :
bt_assert(0);
}
}
break;
case 217 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 241 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ bt_assert(0); 0; }) /* not implemented */;
}
break;
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
double tmp_626 = (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]);
({ double tmp_627 = (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_627); });
({ double tmp_628 = tmp_626; ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_628); });
})
;
}
break;
case 253 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ bt_assert(0); 0; }) /* not implemented */;
}
break;
case 252 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ bt_assert(0); 0; }) /* not implemented */;
}
break;
case 238 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_629 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_629 << 11)); });
({ double tmp_630 = ((double)0.0); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_630); });
}
break;
case 232 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_631 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_631 << 11)); });
({ double tmp_632 = ((double)1.0); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_632); });
}
break;
case 192 :
case 193 :
case 194 :
case 195 :
case 196 :
case 197 :
case 198 :
case 199 :
opcode_reg = opcode2 - 192;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_633 = (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7)]) = tmp_633); });
({ word_3 tmp_634 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_634 << 11)); });
}
break;
case 224 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_635 = (-(intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_635); });
}
break;
case 240 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ bt_assert(0); 0; }) /* not implemented */;
}
break;
default :
bt_assert(opcode2 <= 0xbf);
switch (reg) {
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_636 = ({ float tmp = ((float)(intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); *(word_32*)&tmp; }); tmp_31(intp, tmp_636); });
({ word_3 tmp_637 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_637 << 11)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_638 = ({ float tmp = ((float)(intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); *(word_32*)&tmp; }); tmp_31(intp, tmp_638); });
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_16 tmp_639 = (intp->regs_FSPR[1]); tmp_24(intp, tmp_639); });
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_16 tmp_640 = tmp_1(intp); ((intp->regs_FSPR[1]) = tmp_640); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_641 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_641 << 11)); });
({ double tmp_642 = ((double)({ word_32 tmp = tmp_8(intp); *(float*)&tmp; })); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_642); });
}
break;
default :
bt_assert(0);
}
}
break;
case 247 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_643 = (tmp_1(intp) & imm16);
({ word_1 tmp_644 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_644 << 0)); });
({ word_1 tmp_645 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_645 << 11)); });
({ word_1 tmp_646 = ((tmp_643 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_646 << 7)); });
({ word_1 tmp_647 = ((tmp_643 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_647 << 6)); });
({ word_1 tmp_648 = parity_even((tmp_643 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_648 << 2)); });
})
;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_649 = (tmp_8(intp) & imm32);
({ word_1 tmp_650 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_650 << 0)); });
({ word_1 tmp_651 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_651 << 11)); });
({ word_1 tmp_652 = ((tmp_649 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_652 << 7)); });
({ word_1 tmp_653 = ((tmp_649 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_653 << 6)); });
({ word_1 tmp_654 = parity_even((tmp_649 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_654 << 2)); });
})
;
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_655 = ((word_16)~tmp_1(intp)); tmp_24(intp, tmp_655); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_656 = ((word_32)~tmp_8(intp)); tmp_31(intp, tmp_656); });
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_657 = ((tmp_1(intp) == 0) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_657 << 0)); });
({ word_1 tmp_658 = addoverflow_16(((word_16)~tmp_1(intp)), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_658 << 11)); });
({ word_16 tmp_659 = ((word_16)-tmp_1(intp)); tmp_24(intp, tmp_659); });
({ word_1 tmp_660 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_660 << 7)); });
({ word_1 tmp_661 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_661 << 6)); });
({ word_1 tmp_662 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_662 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_663 = ((tmp_8(intp) == 0) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_663 << 0)); });
({ word_1 tmp_664 = addoverflow_32(((word_32)~tmp_8(intp)), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_664 << 11)); });
({ word_32 tmp_665 = ((word_32)-tmp_8(intp)); tmp_31(intp, tmp_665); });
({ word_1 tmp_666 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_666 << 7)); });
({ word_1 tmp_667 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_667 << 6)); });
({ word_1 tmp_668 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_668 << 2)); });
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_669 = (intp->regs_GPR[0]);
word_32 tmp_670 = tmp_8(intp);
({ word_32 tmp_671 = (tmp_669 * tmp_670); ((intp->regs_GPR[0]) = tmp_671); });
({ word_32 tmp_672 = ((word_32)((((word_64)tmp_669) * ((word_64)tmp_670)) >> 32)); ((intp->regs_GPR[2]) = tmp_672); });
({ word_1 tmp_673 = (((intp->regs_GPR[2]) == 0) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_673 << 0)); });
({ word_1 tmp_674 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_674 << 11)); });
})
;
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
((16 == 32) ? 
({
word_32 tmp_675 = (intp->regs_GPR[0]);
word_32 tmp_676 = ((word_32)tmp_1(intp));
({ word_32 tmp_677 = (tmp_675 * tmp_676); ((intp->regs_GPR[0]) = tmp_677); });
({ word_32 tmp_678 = ((word_32)((((tmp_675 & 0x80000000) ? ((word_64)tmp_675 | 0xFFFFFFFF00000000) : (word_64)tmp_675) * ((tmp_676 & 0x80000000) ? ((word_64)tmp_676 | 0xFFFFFFFF00000000) : (word_64)tmp_676)) >> 32)); ((intp->regs_GPR[2]) = tmp_678); });
({ word_1 tmp_679 = ((((intp->regs_GPR[2]) == 0) || ((intp->regs_GPR[2]) == ((word_32)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_679 << 0)); });
({ word_1 tmp_680 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_680 << 11)); });
})
 : 
({
word_16 tmp_681 = ((intp->regs_GPR[0] >> 0) & 0xFFFF);
word_16 tmp_682 = ((word_16)tmp_1(intp));
({ word_16 tmp_683 = (tmp_681 * tmp_682); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_683 << 0)); });
({ word_16 tmp_684 = ((word_16)((((tmp_681 & 0x8000) ? ((word_32)tmp_681 | 0xFFFF0000) : (word_32)tmp_681) * ((tmp_682 & 0x8000) ? ((word_32)tmp_682 | 0xFFFF0000) : (word_32)tmp_682)) >> 16)); (intp->regs_GPR[2] = (intp->regs_GPR[2] & 0xFFFF0000) | (tmp_684 << 0)); });
({ word_1 tmp_685 = (((((intp->regs_GPR[2] >> 0) & 0xFFFF) == 0) || (((intp->regs_GPR[2] >> 0) & 0xFFFF) == ((word_16)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_685 << 0)); });
({ word_1 tmp_686 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_686 << 11)); });
})
);
} else {
next_pc = pc = intp->pc;
((32 == 32) ? 
({
word_32 tmp_687 = (intp->regs_GPR[0]);
word_32 tmp_688 = ((word_32)tmp_8(intp));
({ word_32 tmp_689 = (tmp_687 * tmp_688); ((intp->regs_GPR[0]) = tmp_689); });
({ word_32 tmp_690 = ((word_32)((((tmp_687 & 0x80000000) ? ((word_64)tmp_687 | 0xFFFFFFFF00000000) : (word_64)tmp_687) * ((tmp_688 & 0x80000000) ? ((word_64)tmp_688 | 0xFFFFFFFF00000000) : (word_64)tmp_688)) >> 32)); ((intp->regs_GPR[2]) = tmp_690); });
({ word_1 tmp_691 = ((((intp->regs_GPR[2]) == 0) || ((intp->regs_GPR[2]) == ((word_32)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_691 << 0)); });
({ word_1 tmp_692 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_692 << 11)); });
})
 : 
({
word_16 tmp_693 = ((intp->regs_GPR[0] >> 0) & 0xFFFF);
word_16 tmp_694 = ((word_16)tmp_8(intp));
({ word_16 tmp_695 = (tmp_693 * tmp_694); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_695 << 0)); });
({ word_16 tmp_696 = ((word_16)((((tmp_693 & 0x8000) ? ((word_32)tmp_693 | 0xFFFF0000) : (word_32)tmp_693) * ((tmp_694 & 0x8000) ? ((word_32)tmp_694 | 0xFFFF0000) : (word_32)tmp_694)) >> 16)); (intp->regs_GPR[2] = (intp->regs_GPR[2] & 0xFFFF0000) | (tmp_696 << 0)); });
({ word_1 tmp_697 = (((((intp->regs_GPR[2] >> 0) & 0xFFFF) == 0) || (((intp->regs_GPR[2] >> 0) & 0xFFFF) == ((word_16)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_697 << 0)); });
({ word_1 tmp_698 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_698 << 11)); });
})
);
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_699 = (intp->regs_GPR[0]);
word_32 tmp_700 = tmp_8(intp);
({ word_32 tmp_701 = ((word_32)((sword_32)tmp_699 / (sword_32)tmp_700)); ((intp->regs_GPR[0]) = tmp_701); });
({ word_32 tmp_702 = ((word_32)((sword_32)tmp_699 % (sword_32)tmp_700)); ((intp->regs_GPR[2]) = tmp_702); });
})
;
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_64 tmp_703 = ((((word_64)(intp->regs_GPR[2])) << 32) | ((word_64)(intp->regs_GPR[0])));
word_64 tmp_704 = ((word_64)tmp_8(intp));
({ word_32 tmp_705 = ((word_32)((tmp_703 / tmp_704) & mask_64(0, 31))); ((intp->regs_GPR[0]) = tmp_705); });
({ word_32 tmp_706 = ((word_32)(tmp_703 % tmp_704)); ((intp->regs_GPR[2]) = tmp_706); });
})
;
}
break;
default :
bt_assert(0);
}
}
break;
case 246 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_8 tmp_707 = (tmp_16(intp) & imm8);
({ word_1 tmp_708 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_708 << 0)); });
({ word_1 tmp_709 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_709 << 11)); });
({ word_1 tmp_710 = ((tmp_707 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_710 << 7)); });
({ word_1 tmp_711 = ((tmp_707 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_711 << 6)); });
({ word_1 tmp_712 = parity_even((tmp_707 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_712 << 2)); });
})
;
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_713 = ((word_8)~tmp_16(intp)); tmp_38(intp, tmp_713); });
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_714 = ((tmp_16(intp) == 0) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_714 << 0)); });
({ word_1 tmp_715 = addoverflow_8(((word_8)~tmp_16(intp)), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_715 << 11)); });
({ word_8 tmp_716 = ((word_8)-tmp_16(intp)); tmp_38(intp, tmp_716); });
({ word_1 tmp_717 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_717 << 7)); });
({ word_1 tmp_718 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_718 << 6)); });
({ word_1 tmp_719 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_719 << 2)); });
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_16 tmp_720 = (tmp_16(intp) * ((intp->regs_GPR[0] >> 0) & 0xFF)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_720 << 0)); });
({ word_1 tmp_721 = ((((intp->regs_GPR[0] >> 8) & 0xFF) == 0) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_721 << 0)); });
({ word_1 tmp_722 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_722 << 11)); });
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_16 tmp_723 = (((tmp_16(intp) & 0x80) ? ((word_32)tmp_16(intp) | 0xFF00) : (word_32)tmp_16(intp)) * ((((intp->regs_GPR[0] >> 0) & 0xFF) & 0x80) ? ((word_32)((intp->regs_GPR[0] >> 0) & 0xFF) | 0xFF00) : (word_32)((intp->regs_GPR[0] >> 0) & 0xFF))); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_723 << 0)); });
({ word_1 tmp_724 = (((((intp->regs_GPR[0] >> 8) & 0xFF) == 0) || (((intp->regs_GPR[0] >> 8) & 0xFF) == 255)) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_724 << 0)); });
({ word_1 tmp_725 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_725 << 11)); });
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_8 tmp_726 = ((intp->regs_GPR[0] >> 0) & 0xFF);
word_8 tmp_727 = tmp_16(intp);
({ word_8 tmp_728 = ((word_8)((sword_8)tmp_726 / (sword_8)tmp_727)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_728 << 0)); });
({ word_8 tmp_729 = ((word_8)((sword_8)tmp_726 % (sword_8)tmp_727)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF00FF) | (tmp_729 << 8)); });
})
;
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_16 tmp_730 = ((intp->regs_GPR[0] >> 0) & 0xFFFF);
word_16 tmp_731 = tmp_16(intp);
({ word_8 tmp_732 = ((word_8)((tmp_730 / tmp_731) & 255)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_732 << 0)); });
({ word_8 tmp_733 = ((word_8)(tmp_730 % tmp_731)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF00FF) | (tmp_733 << 8)); });
})
;
}
break;
default :
bt_assert(0);
}
}
break;
case 72 :
case 73 :
case 74 :
case 75 :
case 76 :
case 77 :
case 78 :
case 79 :
opcode_reg = opcode - 72;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_734 = addoverflow_16((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF), ((word_16)~0)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_734 << 11)); });
({ word_16 tmp_735 = ((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) - 1); ((intp->regs_GPR[opcode_reg]) = ((intp->regs_GPR[opcode_reg]) & 0xFFFF0000) | (tmp_735 << 0)); });
({ word_1 tmp_736 = (((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_736 << 7)); });
({ word_1 tmp_737 = (((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_737 << 6)); });
({ word_1 tmp_738 = parity_even(((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_738 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_739 = addoverflow_32((intp->regs_GPR[opcode_reg]), ((word_32)~0)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_739 << 11)); });
({ word_32 tmp_740 = ((intp->regs_GPR[opcode_reg]) - 1); ((intp->regs_GPR[opcode_reg]) = tmp_740); });
({ word_1 tmp_741 = (((intp->regs_GPR[opcode_reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_741 << 7)); });
({ word_1 tmp_742 = (((intp->regs_GPR[opcode_reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_742 << 6)); });
({ word_1 tmp_743 = parity_even(((intp->regs_GPR[opcode_reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_743 << 2)); });
}
break;
case 254 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_744 = addoverflow_8(tmp_16(intp), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_744 << 11)); });
({ word_8 tmp_745 = (tmp_16(intp) + 1); tmp_38(intp, tmp_745); });
({ word_1 tmp_746 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_746 << 7)); });
({ word_1 tmp_747 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_747 << 6)); });
({ word_1 tmp_748 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_748 << 2)); });
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_749 = addoverflow_8(tmp_16(intp), ((word_8)~0)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_749 << 11)); });
({ word_8 tmp_750 = (tmp_16(intp) - 1); tmp_38(intp, tmp_750); });
({ word_1 tmp_751 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_751 << 7)); });
({ word_1 tmp_752 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_752 << 6)); });
({ word_1 tmp_753 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_753 << 2)); });
}
break;
default :
bt_assert(0);
}
}
break;
case 59 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_754 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) - tmp_1(intp));
({ word_1 tmp_755 = subcarry_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), tmp_1(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_755 << 0)); });
({ word_1 tmp_756 = ((tmp_754 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_756 << 6)); });
({ word_1 tmp_757 = ((tmp_754 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_757 << 7)); });
({ word_1 tmp_758 = addoverflow_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), (((word_16)~tmp_1(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_758 << 11)); });
({ word_1 tmp_759 = parity_even((tmp_754 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_759 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_760 = ((intp->regs_GPR[reg]) - tmp_8(intp));
({ word_1 tmp_761 = subcarry_32((intp->regs_GPR[reg]), tmp_8(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_761 << 0)); });
({ word_1 tmp_762 = ((tmp_760 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_762 << 6)); });
({ word_1 tmp_763 = ((tmp_760 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_763 << 7)); });
({ word_1 tmp_764 = addoverflow_32((intp->regs_GPR[reg]), (((word_32)~tmp_8(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_764 << 11)); });
({ word_1 tmp_765 = parity_even((tmp_760 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_765 << 2)); });
})
;
}
break;
case 58 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_8 tmp_766 = (tmp_15(intp) - tmp_16(intp));
({ word_1 tmp_767 = subcarry_8(tmp_15(intp), tmp_16(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_767 << 0)); });
({ word_1 tmp_768 = ((tmp_766 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_768 << 6)); });
({ word_1 tmp_769 = ((tmp_766 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_769 << 7)); });
({ word_1 tmp_770 = addoverflow_8(tmp_15(intp), (((word_8)~tmp_16(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_770 << 11)); });
({ word_1 tmp_771 = parity_even((tmp_766 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_771 << 2)); });
})
;
}
break;
case 57 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_772 = (tmp_1(intp) - (((intp->regs_GPR[reg]) >> 0) & 0xFFFF));
({ word_1 tmp_773 = subcarry_16(tmp_1(intp), (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_773 << 0)); });
({ word_1 tmp_774 = ((tmp_772 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_774 << 6)); });
({ word_1 tmp_775 = ((tmp_772 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_775 << 7)); });
({ word_1 tmp_776 = addoverflow_16(tmp_1(intp), (((word_16)~(((intp->regs_GPR[reg]) >> 0) & 0xFFFF)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_776 << 11)); });
({ word_1 tmp_777 = parity_even((tmp_772 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_777 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_778 = (tmp_8(intp) - (intp->regs_GPR[reg]));
({ word_1 tmp_779 = subcarry_32(tmp_8(intp), (intp->regs_GPR[reg])); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_779 << 0)); });
({ word_1 tmp_780 = ((tmp_778 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_780 << 6)); });
({ word_1 tmp_781 = ((tmp_778 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_781 << 7)); });
({ word_1 tmp_782 = addoverflow_32(tmp_8(intp), (((word_32)~(intp->regs_GPR[reg])) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_782 << 11)); });
({ word_1 tmp_783 = parity_even((tmp_778 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_783 << 2)); });
})
;
}
break;
case 56 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_8 tmp_784 = (tmp_16(intp) - tmp_15(intp));
({ word_1 tmp_785 = subcarry_8(tmp_16(intp), tmp_15(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_785 << 0)); });
({ word_1 tmp_786 = ((tmp_784 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_786 << 6)); });
({ word_1 tmp_787 = ((tmp_784 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_787 << 7)); });
({ word_1 tmp_788 = addoverflow_8(tmp_16(intp), (((word_8)~tmp_15(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_788 << 11)); });
({ word_1 tmp_789 = parity_even((tmp_784 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_789 << 2)); });
})
;
}
break;
case 61 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_790 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) - imm16);
({ word_1 tmp_791 = subcarry_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_791 << 0)); });
({ word_1 tmp_792 = ((tmp_790 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_792 << 6)); });
({ word_1 tmp_793 = ((tmp_790 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_793 << 7)); });
({ word_1 tmp_794 = addoverflow_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), (((word_16)~imm16) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_794 << 11)); });
({ word_1 tmp_795 = parity_even((tmp_790 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_795 << 2)); });
})
;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_796 = ((intp->regs_GPR[0]) - imm32);
({ word_1 tmp_797 = subcarry_32((intp->regs_GPR[0]), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_797 << 0)); });
({ word_1 tmp_798 = ((tmp_796 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_798 << 6)); });
({ word_1 tmp_799 = ((tmp_796 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_799 << 7)); });
({ word_1 tmp_800 = addoverflow_32((intp->regs_GPR[0]), (((word_32)~imm32) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_800 << 11)); });
({ word_1 tmp_801 = parity_even((tmp_796 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_801 << 2)); });
})
;
}
break;
case 60 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_8 tmp_802 = (((intp->regs_GPR[0] >> 0) & 0xFF) - imm8);
({ word_1 tmp_803 = subcarry_8(((intp->regs_GPR[0] >> 0) & 0xFF), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_803 << 0)); });
({ word_1 tmp_804 = ((tmp_802 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_804 << 6)); });
({ word_1 tmp_805 = ((tmp_802 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_805 << 7)); });
({ word_1 tmp_806 = addoverflow_8(((intp->regs_GPR[0] >> 0) & 0xFF), (((word_8)~imm8) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_806 << 11)); });
({ word_1 tmp_807 = parity_even((tmp_802 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_807 << 2)); });
})
;
}
break;
case 252 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_808 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFBFF) | (tmp_808 << 10)); });
}
break;
case 153 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
(((intp->regs_GPR[0]) & (1 << 31)) ? ({ word_32 tmp_809 = mask_32(0, 31); ((intp->regs_GPR[2]) = tmp_809); }) : ({ word_32 tmp_810 = 0; ((intp->regs_GPR[2]) = tmp_810); }));
}
break;
case 152 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_811 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & 0x80) ? ((word_32)((intp->regs_GPR[0] >> 0) & 0xFF) | 0xFF00) : (word_32)((intp->regs_GPR[0] >> 0) & 0xFF)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_811 << 0)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_812 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((intp->regs_GPR[0] >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((intp->regs_GPR[0] >> 0) & 0xFFFF)); ((intp->regs_GPR[0]) = tmp_812); });
}
break;
case 255 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_813 = tmp_8(intp); mem_set_32(intp, ((intp->regs_GPR[4]) - 4), tmp_813); });
({ word_32 tmp_814 = ((intp->regs_GPR[4]) - 4); ((intp->regs_GPR[4]) = tmp_814); });
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(next_pc = tmp_8(intp));
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_815 = addoverflow_16(tmp_1(intp), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_815 << 11)); });
({ word_16 tmp_816 = (tmp_1(intp) + 1); tmp_24(intp, tmp_816); });
({ word_1 tmp_817 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_817 << 7)); });
({ word_1 tmp_818 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_818 << 6)); });
({ word_1 tmp_819 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_819 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_820 = addoverflow_32(tmp_8(intp), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_820 << 11)); });
({ word_32 tmp_821 = (tmp_8(intp) + 1); tmp_31(intp, tmp_821); });
({ word_1 tmp_822 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_822 << 7)); });
({ word_1 tmp_823 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_823 << 6)); });
({ word_1 tmp_824 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_824 << 2)); });
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_825 = addoverflow_16(tmp_1(intp), ((word_16)~0)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_825 << 11)); });
({ word_16 tmp_826 = (tmp_1(intp) - 1); tmp_24(intp, tmp_826); });
({ word_1 tmp_827 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_827 << 7)); });
({ word_1 tmp_828 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_828 << 6)); });
({ word_1 tmp_829 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_829 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_830 = addoverflow_32(tmp_8(intp), ((word_32)~0)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_830 << 11)); });
({ word_32 tmp_831 = (tmp_8(intp) - 1); tmp_31(intp, tmp_831); });
({ word_1 tmp_832 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_832 << 7)); });
({ word_1 tmp_833 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_833 << 6)); });
({ word_1 tmp_834 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_834 << 2)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
intp->have_jumped = 1;
({ word_32 tmp_835 = ((intp->regs_GPR[4]) - 4); ((intp->regs_GPR[4]) = tmp_835); });
({ word_32 tmp_836 = pc; mem_set_32(intp, (intp->regs_GPR[4]), tmp_836); });
(next_pc = tmp_8(intp));
}
break;
default :
bt_assert(0);
}
}
break;
case 232 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
({ word_32 tmp_837 = ((intp->regs_GPR[4]) - 4); ((intp->regs_GPR[4]) = tmp_837); });
({ word_32 tmp_838 = pc; mem_set_32(intp, (intp->regs_GPR[4]), tmp_838); });
(next_pc = (pc + imm32));
}
break;
case 15 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 172 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
(((imm8 & 31) == 0) ? 0 /* nop */ : 
({
word_32 tmp_839 = (imm8 & 31);
({ word_1 tmp_840 = ((tmp_8(intp) & (1 << (tmp_839 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_840 << 0)); });
({ word_32 tmp_841 = ((tmp_8(intp) >> tmp_839) | ((intp->regs_GPR[reg]) << (32 - tmp_839))); tmp_31(intp, tmp_841); });
({ word_1 tmp_842 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_842 << 7)); });
({ word_1 tmp_843 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_843 << 6)); });
({ word_1 tmp_844 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_844 << 2)); });
})
);
}
break;
case 173 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
((((intp->regs_GPR[1]) & 31) == 0) ? 0 /* nop */ : 
({
word_32 tmp_845 = ((intp->regs_GPR[1]) & 31);
({ word_1 tmp_846 = ((tmp_8(intp) & (1 << (tmp_845 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_846 << 0)); });
({ word_32 tmp_847 = ((tmp_8(intp) >> tmp_845) | ((intp->regs_GPR[reg]) << (32 - tmp_845))); tmp_31(intp, tmp_847); });
({ word_1 tmp_848 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_848 << 7)); });
({ word_1 tmp_849 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_849 << 6)); });
({ word_1 tmp_850 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_850 << 2)); });
})
);
}
break;
case 164 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
(((imm8 & 31) == 0) ? 0 /* nop */ : 
({
word_32 tmp_851 = (imm8 & 31);
({ word_1 tmp_852 = ((tmp_8(intp) & (1 << (32 - tmp_851))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_852 << 0)); });
({ word_32 tmp_853 = ((tmp_8(intp) << tmp_851) | ((intp->regs_GPR[reg]) >> (32 - tmp_851))); tmp_31(intp, tmp_853); });
({ word_1 tmp_854 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_854 << 7)); });
({ word_1 tmp_855 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_855 << 6)); });
({ word_1 tmp_856 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_856 << 2)); });
})
);
}
break;
case 165 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
((((intp->regs_GPR[1]) & 31) == 0) ? 0 /* nop */ : 
({
word_32 tmp_857 = ((intp->regs_GPR[1]) & 31);
({ word_1 tmp_858 = ((tmp_8(intp) & (1 << (32 - tmp_857))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_858 << 0)); });
({ word_32 tmp_859 = ((tmp_8(intp) << tmp_857) | ((intp->regs_GPR[reg]) >> (32 - tmp_857))); tmp_31(intp, tmp_859); });
({ word_1 tmp_860 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_860 << 7)); });
({ word_1 tmp_861 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_861 << 6)); });
({ word_1 tmp_862 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_862 << 2)); });
})
);
}
break;
case 149 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_863 = (((intp->regs_SPR[0] >> 6) & 0x1) ^ 1); tmp_38(intp, tmp_863); });
}
break;
case 151 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_864 = (((((intp->regs_SPR[0] >> 0) & 0x1) == 0) && (((intp->regs_SPR[0] >> 6) & 0x1) == 0)) ? 1 : 0); tmp_38(intp, tmp_864); });
}
break;
case 146 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_865 = ((intp->regs_SPR[0] >> 0) & 0x1); tmp_38(intp, tmp_865); });
}
break;
case 158 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_866 = (((((intp->regs_SPR[0] >> 6) & 0x1) == 1) || (!(((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)))) ? 1 : 0); tmp_38(intp, tmp_866); });
}
break;
case 156 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_867 = ((((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)) ? 0 : 1); tmp_38(intp, tmp_867); });
}
break;
case 159 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_868 = (((((intp->regs_SPR[0] >> 6) & 0x1) == 0) && (((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1))) ? 1 : 0); tmp_38(intp, tmp_868); });
}
break;
case 148 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_869 = ((intp->regs_SPR[0] >> 6) & 0x1); tmp_38(intp, tmp_869); });
}
break;
case 150 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_870 = (((((intp->regs_SPR[0] >> 0) & 0x1) == 1) || (((intp->regs_SPR[0] >> 6) & 0x1) == 1)) ? 1 : 0); tmp_38(intp, tmp_870); });
}
break;
case 183 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_871 = tmp_1(intp); ((intp->regs_GPR[reg]) = tmp_871); });
}
break;
case 182 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_872 = tmp_16(intp); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_872 << 0)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_873 = tmp_16(intp); ((intp->regs_GPR[reg]) = tmp_873); });
}
break;
case 191 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_874 = ((tmp_1(intp) & 0x8000) ? ((word_32)tmp_1(intp) | 0xFFFF0000) : (word_32)tmp_1(intp)); ((intp->regs_GPR[reg]) = tmp_874); });
}
break;
case 190 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_875 = ((tmp_16(intp) & 0x80) ? ((word_32)tmp_16(intp) | 0xFF00) : (word_32)tmp_16(intp)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_875 << 0)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_876 = ((tmp_16(intp) & 0x80) ? ((word_32)tmp_16(intp) | 0xFFFFFF00) : (word_32)tmp_16(intp)); ((intp->regs_GPR[reg]) = tmp_876); });
}
break;
case 136 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == 1) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 138 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 2) & 0x1) == 1) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 137 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == 0) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 139 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 2) & 0x1) == 0) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 133 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 6) & 0x1) == 0) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 142 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 6) & 0x1) == 1) || (!(((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)))) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 140 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)) ? 0 /* nop */ : (next_pc = (pc + imm32)));
}
break;
case 141 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 143 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 6) & 0x1) == 0) && (((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1))) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 132 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 6) & 0x1) == 1) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 134 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 0) & 0x1) == 1) || (((intp->regs_SPR[0] >> 6) & 0x1) == 1)) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 130 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 0) & 0x1) == 1) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 131 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 0) & 0x1) == 0) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 135 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 0) & 0x1) == 0) && (((intp->regs_SPR[0] >> 6) & 0x1) == 0)) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 175 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_877 = ((word_16)((((tmp_1(intp) & 0x8000) ? ((word_32)tmp_1(intp) | 0xFFFF0000) : (word_32)tmp_1(intp)) * (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 0x8000) ? ((word_32)(((intp->regs_GPR[reg]) >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)(((intp->regs_GPR[reg]) >> 0) & 0xFFFF))) >> 16));
({ word_1 tmp_878 = (((tmp_877 == 0) || (tmp_877 == ((word_16)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_878 << 0)); });
({ word_1 tmp_879 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_879 << 11)); });
})
;
({ word_16 tmp_880 = (tmp_1(intp) * (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_880 << 0)); });
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_881 = ((word_32)((((tmp_8(intp) & 0x80000000) ? ((word_64)tmp_8(intp) | 0xFFFFFFFF00000000) : (word_64)tmp_8(intp)) * (((intp->regs_GPR[reg]) & 0x80000000) ? ((word_64)(intp->regs_GPR[reg]) | 0xFFFFFFFF00000000) : (word_64)(intp->regs_GPR[reg]))) >> 32));
({ word_1 tmp_882 = (((tmp_881 == 0) || (tmp_881 == ((word_32)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_882 << 0)); });
({ word_1 tmp_883 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_883 << 11)); });
})
;
({ word_32 tmp_884 = (tmp_8(intp) * (intp->regs_GPR[reg])); ((intp->regs_GPR[reg]) = tmp_884); });
}
break;
case 171 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_885 = ((intp->regs_GPR[reg]) & 31);
({ word_1 tmp_886 = ((((mod == 3) ? (intp->regs_GPR[rm]) : mem_get_32(intp, (tmp_528(intp) + ((((intp->regs_GPR[reg]) >> 5) | (((intp->regs_GPR[reg]) & (1 << 31)) ? ~((1 << (32 - 5)) - 1) : 0)) << 2)))) & (1 << tmp_885)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_886 << 0)); });
({ word_32 tmp_887 = (((mod == 3) ? (intp->regs_GPR[rm]) : mem_get_32(intp, (tmp_528(intp) + ((((intp->regs_GPR[reg]) >> 5) | (((intp->regs_GPR[reg]) & (1 << 31)) ? ~((1 << (32 - 5)) - 1) : 0)) << 2)))) | (1 << tmp_885)); ((mod == 3) ? ((intp->regs_GPR[rm]) = tmp_887) : mem_set_32(intp, (tmp_528(intp) + ((((intp->regs_GPR[reg]) >> 5) | (((intp->regs_GPR[reg]) & (1 << 31)) ? ~((1 << (32 - 5)) - 1) : 0)) << 2)), tmp_887)); });
})
;
}
break;
case 163 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_888 = ((((mod == 3) ? (intp->regs_GPR[rm]) : mem_get_32(intp, (tmp_528(intp) + ((((intp->regs_GPR[reg]) >> 5) | (((intp->regs_GPR[reg]) & (1 << 31)) ? ~((1 << (32 - 5)) - 1) : 0)) << 2)))) & (1 << ((intp->regs_GPR[reg]) & 31))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_888 << 0)); });
}
break;
case 189 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_889 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_889 << 6)); });
({ word_16 tmp_890 = (31 - leading_zeros(tmp_1(intp))); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_890 << 0)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_891 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_891 << 6)); });
({ word_32 tmp_892 = (31 - leading_zeros(tmp_8(intp))); ((intp->regs_GPR[reg]) = tmp_892); });
}
break;
default :
switch (reg) {
default :
bt_assert(0);
}
}
break;
case 35 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_893 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & tmp_1(intp)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_893 << 0)); });
({ word_1 tmp_894 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_894 << 11)); });
({ word_1 tmp_895 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_895 << 0)); });
({ word_1 tmp_896 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_896 << 7)); });
({ word_1 tmp_897 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_897 << 6)); });
({ word_1 tmp_898 = parity_even(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_898 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_899 = ((intp->regs_GPR[reg]) & tmp_8(intp)); ((intp->regs_GPR[reg]) = tmp_899); });
({ word_1 tmp_900 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_900 << 11)); });
({ word_1 tmp_901 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_901 << 0)); });
({ word_1 tmp_902 = (((intp->regs_GPR[reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_902 << 7)); });
({ word_1 tmp_903 = (((intp->regs_GPR[reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_903 << 6)); });
({ word_1 tmp_904 = parity_even(((intp->regs_GPR[reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_904 << 2)); });
}
break;
case 34 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_905 = (tmp_15(intp) & tmp_16(intp)); tmp_17(intp, tmp_905); });
({ word_1 tmp_906 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_906 << 11)); });
({ word_1 tmp_907 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_907 << 0)); });
({ word_1 tmp_908 = ((tmp_15(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_908 << 7)); });
({ word_1 tmp_909 = ((tmp_15(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_909 << 6)); });
({ word_1 tmp_910 = parity_even((tmp_15(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_910 << 2)); });
}
break;
case 33 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_911 = (tmp_1(intp) & (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); tmp_24(intp, tmp_911); });
({ word_1 tmp_912 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_912 << 11)); });
({ word_1 tmp_913 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_913 << 0)); });
({ word_1 tmp_914 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_914 << 7)); });
({ word_1 tmp_915 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_915 << 6)); });
({ word_1 tmp_916 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_916 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_917 = (tmp_8(intp) & (intp->regs_GPR[reg])); tmp_31(intp, tmp_917); });
({ word_1 tmp_918 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_918 << 11)); });
({ word_1 tmp_919 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_919 << 0)); });
({ word_1 tmp_920 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_920 << 7)); });
({ word_1 tmp_921 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_921 << 6)); });
({ word_1 tmp_922 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_922 << 2)); });
}
break;
case 32 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_923 = (tmp_16(intp) & tmp_15(intp)); tmp_38(intp, tmp_923); });
({ word_1 tmp_924 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_924 << 11)); });
({ word_1 tmp_925 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_925 << 0)); });
({ word_1 tmp_926 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_926 << 7)); });
({ word_1 tmp_927 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_927 << 6)); });
({ word_1 tmp_928 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_928 << 2)); });
}
break;
case 37 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_929 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) & imm16); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_929 << 0)); });
({ word_1 tmp_930 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_930 << 11)); });
({ word_1 tmp_931 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_931 << 0)); });
({ word_1 tmp_932 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_932 << 7)); });
({ word_1 tmp_933 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_933 << 6)); });
({ word_1 tmp_934 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_934 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_935 = ((intp->regs_GPR[0]) & imm32); ((intp->regs_GPR[0]) = tmp_935); });
({ word_1 tmp_936 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_936 << 11)); });
({ word_1 tmp_937 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_937 << 0)); });
({ word_1 tmp_938 = (((intp->regs_GPR[0]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_938 << 7)); });
({ word_1 tmp_939 = (((intp->regs_GPR[0]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_939 << 6)); });
({ word_1 tmp_940 = parity_even(((intp->regs_GPR[0]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_940 << 2)); });
}
break;
case 36 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_941 = (((intp->regs_GPR[0] >> 0) & 0xFF) & imm8); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_941 << 0)); });
({ word_1 tmp_942 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_942 << 11)); });
({ word_1 tmp_943 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_943 << 0)); });
({ word_1 tmp_944 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_944 << 7)); });
({ word_1 tmp_945 = ((((intp->regs_GPR[0] >> 0) & 0xFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_945 << 6)); });
({ word_1 tmp_946 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_946 << 2)); });
}
break;
case 3 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_947 = addoverflow_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), tmp_1(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_947 << 11)); });
({ word_1 tmp_948 = addcarry_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), tmp_1(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_948 << 0)); });
({ word_16 tmp_949 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) + tmp_1(intp)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_949 << 0)); });
({ word_1 tmp_950 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_950 << 7)); });
({ word_1 tmp_951 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_951 << 6)); });
({ word_1 tmp_952 = parity_even(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_952 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_953 = addoverflow_32((intp->regs_GPR[reg]), tmp_8(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_953 << 11)); });
({ word_1 tmp_954 = addcarry_32((intp->regs_GPR[reg]), tmp_8(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_954 << 0)); });
({ word_32 tmp_955 = ((intp->regs_GPR[reg]) + tmp_8(intp)); ((intp->regs_GPR[reg]) = tmp_955); });
({ word_1 tmp_956 = (((intp->regs_GPR[reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_956 << 7)); });
({ word_1 tmp_957 = (((intp->regs_GPR[reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_957 << 6)); });
({ word_1 tmp_958 = parity_even(((intp->regs_GPR[reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_958 << 2)); });
}
break;
case 2 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_959 = addoverflow_8(tmp_15(intp), tmp_16(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_959 << 11)); });
({ word_1 tmp_960 = addcarry_8(tmp_15(intp), tmp_16(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_960 << 0)); });
({ word_8 tmp_961 = (tmp_15(intp) + tmp_16(intp)); tmp_17(intp, tmp_961); });
({ word_1 tmp_962 = ((tmp_15(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_962 << 7)); });
({ word_1 tmp_963 = ((tmp_15(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_963 << 6)); });
({ word_1 tmp_964 = parity_even((tmp_15(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_964 << 2)); });
}
break;
case 1 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_965 = addoverflow_16(tmp_1(intp), (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_965 << 11)); });
({ word_1 tmp_966 = addcarry_16(tmp_1(intp), (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_966 << 0)); });
({ word_16 tmp_967 = (tmp_1(intp) + (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); tmp_24(intp, tmp_967); });
({ word_1 tmp_968 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_968 << 7)); });
({ word_1 tmp_969 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_969 << 6)); });
({ word_1 tmp_970 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_970 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_971 = addoverflow_32(tmp_8(intp), (intp->regs_GPR[reg])); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_971 << 11)); });
({ word_1 tmp_972 = addcarry_32(tmp_8(intp), (intp->regs_GPR[reg])); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_972 << 0)); });
({ word_32 tmp_973 = (tmp_8(intp) + (intp->regs_GPR[reg])); tmp_31(intp, tmp_973); });
({ word_1 tmp_974 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_974 << 7)); });
({ word_1 tmp_975 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_975 << 6)); });
({ word_1 tmp_976 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_976 << 2)); });
}
break;
case 0 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_977 = addoverflow_8(tmp_16(intp), tmp_15(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_977 << 11)); });
({ word_1 tmp_978 = addcarry_8(tmp_16(intp), tmp_15(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_978 << 0)); });
({ word_8 tmp_979 = (tmp_16(intp) + tmp_15(intp)); tmp_38(intp, tmp_979); });
({ word_1 tmp_980 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_980 << 7)); });
({ word_1 tmp_981 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_981 << 6)); });
({ word_1 tmp_982 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_982 << 2)); });
}
break;
case 5 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_983 = addoverflow_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_983 << 11)); });
({ word_1 tmp_984 = addcarry_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_984 << 0)); });
({ word_16 tmp_985 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) + imm16); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_985 << 0)); });
({ word_1 tmp_986 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_986 << 7)); });
({ word_1 tmp_987 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_987 << 6)); });
({ word_1 tmp_988 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_988 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_989 = addoverflow_32((intp->regs_GPR[0]), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_989 << 11)); });
({ word_1 tmp_990 = addcarry_32((intp->regs_GPR[0]), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_990 << 0)); });
({ word_32 tmp_991 = ((intp->regs_GPR[0]) + imm32); ((intp->regs_GPR[0]) = tmp_991); });
({ word_1 tmp_992 = (((intp->regs_GPR[0]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_992 << 7)); });
({ word_1 tmp_993 = (((intp->regs_GPR[0]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_993 << 6)); });
({ word_1 tmp_994 = parity_even(((intp->regs_GPR[0]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_994 << 2)); });
}
break;
case 4 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_995 = addoverflow_8(((intp->regs_GPR[0] >> 0) & 0xFF), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_995 << 11)); });
({ word_1 tmp_996 = addcarry_8(((intp->regs_GPR[0] >> 0) & 0xFF), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_996 << 0)); });
({ word_8 tmp_997 = (((intp->regs_GPR[0] >> 0) & 0xFF) + imm8); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_997 << 0)); });
({ word_1 tmp_998 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_998 << 7)); });
({ word_1 tmp_999 = ((((intp->regs_GPR[0] >> 0) & 0xFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_999 << 6)); });
({ word_1 tmp_1000 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1000 << 2)); });
}
break;
case 19 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_1001 = ((addoverflow_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), tmp_1(intp)) | addoverflow_16(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) + tmp_1(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1001 << 11)); });
({ word_1 tmp_1002 = ((addcarry_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), tmp_1(intp)) | addcarry_16(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) + tmp_1(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1002 << 0)); });
({ word_16 tmp_1003 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) + tmp_1(intp)) + ((intp->regs_SPR[0] >> 0) & 0x1)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_1003 << 0)); });
({ word_1 tmp_1004 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1004 << 7)); });
({ word_1 tmp_1005 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1005 << 6)); });
({ word_1 tmp_1006 = parity_even(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1006 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_1007 = ((addoverflow_32((intp->regs_GPR[reg]), tmp_8(intp)) | addoverflow_32(((intp->regs_GPR[reg]) + tmp_8(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1007 << 11)); });
({ word_1 tmp_1008 = ((addcarry_32((intp->regs_GPR[reg]), tmp_8(intp)) | addcarry_32(((intp->regs_GPR[reg]) + tmp_8(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1008 << 0)); });
({ word_32 tmp_1009 = (((intp->regs_GPR[reg]) + tmp_8(intp)) + ((intp->regs_SPR[0] >> 0) & 0x1)); ((intp->regs_GPR[reg]) = tmp_1009); });
({ word_1 tmp_1010 = (((intp->regs_GPR[reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1010 << 7)); });
({ word_1 tmp_1011 = (((intp->regs_GPR[reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1011 << 6)); });
({ word_1 tmp_1012 = parity_even(((intp->regs_GPR[reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1012 << 2)); });
}
break;
case 18 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_1013 = ((addoverflow_8(tmp_15(intp), tmp_16(intp)) | addoverflow_8((tmp_15(intp) + tmp_16(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1013 << 11)); });
({ word_1 tmp_1014 = ((addcarry_8(tmp_15(intp), tmp_16(intp)) | addcarry_8((tmp_15(intp) + tmp_16(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1014 << 0)); });
({ word_8 tmp_1015 = ((tmp_15(intp) + tmp_16(intp)) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_17(intp, tmp_1015); });
({ word_1 tmp_1016 = ((tmp_15(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1016 << 7)); });
({ word_1 tmp_1017 = ((tmp_15(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1017 << 6)); });
({ word_1 tmp_1018 = parity_even((tmp_15(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1018 << 2)); });
}
break;
case 17 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_1019 = ((addoverflow_16(tmp_1(intp), (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)) | addoverflow_16((tmp_1(intp) + (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1019 << 11)); });
({ word_1 tmp_1020 = ((addcarry_16(tmp_1(intp), (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)) | addcarry_16((tmp_1(intp) + (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1020 << 0)); });
({ word_16 tmp_1021 = ((tmp_1(intp) + (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_24(intp, tmp_1021); });
({ word_1 tmp_1022 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1022 << 7)); });
({ word_1 tmp_1023 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1023 << 6)); });
({ word_1 tmp_1024 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1024 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_1025 = ((addoverflow_32(tmp_8(intp), (intp->regs_GPR[reg])) | addoverflow_32((tmp_8(intp) + (intp->regs_GPR[reg])), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1025 << 11)); });
({ word_1 tmp_1026 = ((addcarry_32(tmp_8(intp), (intp->regs_GPR[reg])) | addcarry_32((tmp_8(intp) + (intp->regs_GPR[reg])), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1026 << 0)); });
({ word_32 tmp_1027 = ((tmp_8(intp) + (intp->regs_GPR[reg])) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_31(intp, tmp_1027); });
({ word_1 tmp_1028 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1028 << 7)); });
({ word_1 tmp_1029 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1029 << 6)); });
({ word_1 tmp_1030 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1030 << 2)); });
}
break;
case 16 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_1031 = ((addoverflow_8(tmp_16(intp), tmp_15(intp)) | addoverflow_8((tmp_16(intp) + tmp_15(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1031 << 11)); });
({ word_1 tmp_1032 = ((addcarry_8(tmp_16(intp), tmp_15(intp)) | addcarry_8((tmp_16(intp) + tmp_15(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1032 << 0)); });
({ word_8 tmp_1033 = ((tmp_16(intp) + tmp_15(intp)) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_38(intp, tmp_1033); });
({ word_1 tmp_1034 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1034 << 7)); });
({ word_1 tmp_1035 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1035 << 6)); });
({ word_1 tmp_1036 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1036 << 2)); });
}
break;
case 131 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_1037 = (tmp_1(intp) ^ ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); tmp_24(intp, tmp_1037); });
({ word_1 tmp_1038 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1038 << 0)); });
({ word_1 tmp_1039 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1039 << 11)); });
({ word_1 tmp_1040 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1040 << 7)); });
({ word_1 tmp_1041 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1041 << 6)); });
({ word_1 tmp_1042 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1042 << 2)); });
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_1043 = (tmp_8(intp) ^ ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); tmp_31(intp, tmp_1043); });
({ word_1 tmp_1044 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1044 << 0)); });
({ word_1 tmp_1045 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1045 << 11)); });
({ word_1 tmp_1046 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1046 << 7)); });
({ word_1 tmp_1047 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1047 << 6)); });
({ word_1 tmp_1048 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1048 << 2)); });
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1049 = subcarry_16(tmp_1(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1049 << 0)); });
({ word_1 tmp_1050 = addoverflow_16(tmp_1(intp), (((word_16)~((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1050 << 11)); });
({ word_16 tmp_1051 = (tmp_1(intp) - ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); tmp_24(intp, tmp_1051); });
({ word_1 tmp_1052 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1052 << 7)); });
({ word_1 tmp_1053 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1053 << 6)); });
({ word_1 tmp_1054 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1054 << 2)); });
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1055 = subcarry_32(tmp_8(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1055 << 0)); });
({ word_1 tmp_1056 = addoverflow_32(tmp_8(intp), (((word_32)~((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1056 << 11)); });
({ word_32 tmp_1057 = (tmp_8(intp) - ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); tmp_31(intp, tmp_1057); });
({ word_1 tmp_1058 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1058 << 7)); });
({ word_1 tmp_1059 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1059 << 6)); });
({ word_1 tmp_1060 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1060 << 2)); });
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_1061 = (((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_1062 = subcarry_16(tmp_1(intp), tmp_1061); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1062 << 0)); });
({ word_1 tmp_1063 = addoverflow_16(tmp_1(intp), (((word_16)~tmp_1061) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1063 << 11)); });
({ word_16 tmp_1064 = (tmp_1(intp) - tmp_1061); tmp_24(intp, tmp_1064); });
({ word_1 tmp_1065 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1065 << 7)); });
({ word_1 tmp_1066 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1066 << 6)); });
({ word_1 tmp_1067 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1067 << 2)); });
})
;
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_1068 = (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_1069 = subcarry_32(tmp_8(intp), tmp_1068); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1069 << 0)); });
({ word_1 tmp_1070 = addoverflow_32(tmp_8(intp), (((word_32)~tmp_1068) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1070 << 11)); });
({ word_32 tmp_1071 = (tmp_8(intp) - tmp_1068); tmp_31(intp, tmp_1071); });
({ word_1 tmp_1072 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1072 << 7)); });
({ word_1 tmp_1073 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1073 << 6)); });
({ word_1 tmp_1074 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1074 << 2)); });
})
;
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_1075 = (tmp_1(intp) | ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); tmp_24(intp, tmp_1075); });
({ word_1 tmp_1076 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1076 << 0)); });
({ word_1 tmp_1077 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1077 << 11)); });
({ word_1 tmp_1078 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1078 << 7)); });
({ word_1 tmp_1079 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1079 << 6)); });
({ word_1 tmp_1080 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1080 << 2)); });
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_1081 = (tmp_8(intp) | ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); tmp_31(intp, tmp_1081); });
({ word_1 tmp_1082 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1082 << 0)); });
({ word_1 tmp_1083 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1083 << 11)); });
({ word_1 tmp_1084 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1084 << 7)); });
({ word_1 tmp_1085 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1085 << 6)); });
({ word_1 tmp_1086 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1086 << 2)); });
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_1087 = (tmp_1(intp) - ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8));
({ word_1 tmp_1088 = subcarry_16(tmp_1(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1088 << 0)); });
({ word_1 tmp_1089 = ((tmp_1087 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1089 << 6)); });
({ word_1 tmp_1090 = ((tmp_1087 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1090 << 7)); });
({ word_1 tmp_1091 = addoverflow_16(tmp_1(intp), (((word_16)~((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1091 << 11)); });
({ word_1 tmp_1092 = parity_even((tmp_1087 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1092 << 2)); });
})
;
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_1093 = (tmp_8(intp) - ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
({ word_1 tmp_1094 = subcarry_32(tmp_8(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1094 << 0)); });
({ word_1 tmp_1095 = ((tmp_1093 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1095 << 6)); });
({ word_1 tmp_1096 = ((tmp_1093 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1096 << 7)); });
({ word_1 tmp_1097 = addoverflow_32(tmp_8(intp), (((word_32)~((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1097 << 11)); });
({ word_1 tmp_1098 = parity_even((tmp_1093 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1098 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_1099 = (tmp_1(intp) & ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); tmp_24(intp, tmp_1099); });
({ word_1 tmp_1100 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1100 << 11)); });
({ word_1 tmp_1101 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1101 << 0)); });
({ word_1 tmp_1102 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1102 << 7)); });
({ word_1 tmp_1103 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1103 << 6)); });
({ word_1 tmp_1104 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1104 << 2)); });
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_1105 = (tmp_8(intp) & ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); tmp_31(intp, tmp_1105); });
({ word_1 tmp_1106 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1106 << 11)); });
({ word_1 tmp_1107 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1107 << 0)); });
({ word_1 tmp_1108 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1108 << 7)); });
({ word_1 tmp_1109 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1109 << 6)); });
({ word_1 tmp_1110 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1110 << 2)); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1111 = addoverflow_16(tmp_1(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1111 << 11)); });
({ word_1 tmp_1112 = addcarry_16(tmp_1(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1112 << 0)); });
({ word_16 tmp_1113 = (tmp_1(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); tmp_24(intp, tmp_1113); });
({ word_1 tmp_1114 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1114 << 7)); });
({ word_1 tmp_1115 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1115 << 6)); });
({ word_1 tmp_1116 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1116 << 2)); });
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1117 = addoverflow_32(tmp_8(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1117 << 11)); });
({ word_1 tmp_1118 = addcarry_32(tmp_8(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1118 << 0)); });
({ word_32 tmp_1119 = (tmp_8(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); tmp_31(intp, tmp_1119); });
({ word_1 tmp_1120 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1120 << 7)); });
({ word_1 tmp_1121 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1121 << 6)); });
({ word_1 tmp_1122 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1122 << 2)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1123 = ((addoverflow_16(tmp_1(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)) | addoverflow_16((tmp_1(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1123 << 11)); });
({ word_1 tmp_1124 = ((addcarry_16(tmp_1(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)) | addcarry_16((tmp_1(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1124 << 0)); });
({ word_16 tmp_1125 = ((tmp_1(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_24(intp, tmp_1125); });
({ word_1 tmp_1126 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1126 << 7)); });
({ word_1 tmp_1127 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1127 << 6)); });
({ word_1 tmp_1128 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1128 << 2)); });
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1129 = ((addoverflow_32(tmp_8(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)) | addoverflow_32((tmp_8(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1129 << 11)); });
({ word_1 tmp_1130 = ((addcarry_32(tmp_8(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)) | addcarry_32((tmp_8(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1130 << 0)); });
({ word_32 tmp_1131 = ((tmp_8(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_31(intp, tmp_1131); });
({ word_1 tmp_1132 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1132 << 7)); });
({ word_1 tmp_1133 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1133 << 6)); });
({ word_1 tmp_1134 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1134 << 2)); });
}
break;
default :
bt_assert(0);
}
}
break;
case 129 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_1135 = (tmp_1(intp) ^ imm16); tmp_24(intp, tmp_1135); });
({ word_1 tmp_1136 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1136 << 0)); });
({ word_1 tmp_1137 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1137 << 11)); });
({ word_1 tmp_1138 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1138 << 7)); });
({ word_1 tmp_1139 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1139 << 6)); });
({ word_1 tmp_1140 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1140 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_1141 = (tmp_8(intp) ^ imm32); tmp_31(intp, tmp_1141); });
({ word_1 tmp_1142 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1142 << 0)); });
({ word_1 tmp_1143 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1143 << 11)); });
({ word_1 tmp_1144 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1144 << 7)); });
({ word_1 tmp_1145 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1145 << 6)); });
({ word_1 tmp_1146 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1146 << 2)); });
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1147 = subcarry_16(tmp_1(intp), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1147 << 0)); });
({ word_1 tmp_1148 = addoverflow_16(tmp_1(intp), (((word_16)~imm16) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1148 << 11)); });
({ word_16 tmp_1149 = (tmp_1(intp) - imm16); tmp_24(intp, tmp_1149); });
({ word_1 tmp_1150 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1150 << 7)); });
({ word_1 tmp_1151 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1151 << 6)); });
({ word_1 tmp_1152 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1152 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1153 = subcarry_32(tmp_8(intp), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1153 << 0)); });
({ word_1 tmp_1154 = addoverflow_32(tmp_8(intp), (((word_32)~imm32) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1154 << 11)); });
({ word_32 tmp_1155 = (tmp_8(intp) - imm32); tmp_31(intp, tmp_1155); });
({ word_1 tmp_1156 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1156 << 7)); });
({ word_1 tmp_1157 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1157 << 6)); });
({ word_1 tmp_1158 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1158 << 2)); });
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_1159 = (imm16 + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_1160 = subcarry_16(tmp_1(intp), tmp_1159); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1160 << 0)); });
({ word_1 tmp_1161 = addoverflow_16(tmp_1(intp), (((word_16)~tmp_1159) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1161 << 11)); });
({ word_16 tmp_1162 = (tmp_1(intp) - tmp_1159); tmp_24(intp, tmp_1162); });
({ word_1 tmp_1163 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1163 << 7)); });
({ word_1 tmp_1164 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1164 << 6)); });
({ word_1 tmp_1165 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1165 << 2)); });
})
;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_1166 = (imm32 + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_1167 = subcarry_32(tmp_8(intp), tmp_1166); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1167 << 0)); });
({ word_1 tmp_1168 = addoverflow_32(tmp_8(intp), (((word_32)~tmp_1166) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1168 << 11)); });
({ word_32 tmp_1169 = (tmp_8(intp) - tmp_1166); tmp_31(intp, tmp_1169); });
({ word_1 tmp_1170 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1170 << 7)); });
({ word_1 tmp_1171 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1171 << 6)); });
({ word_1 tmp_1172 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1172 << 2)); });
})
;
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_1173 = (tmp_1(intp) | imm16); tmp_24(intp, tmp_1173); });
({ word_1 tmp_1174 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1174 << 0)); });
({ word_1 tmp_1175 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1175 << 11)); });
({ word_1 tmp_1176 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1176 << 7)); });
({ word_1 tmp_1177 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1177 << 6)); });
({ word_1 tmp_1178 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1178 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_1179 = (tmp_8(intp) | imm32); tmp_31(intp, tmp_1179); });
({ word_1 tmp_1180 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1180 << 0)); });
({ word_1 tmp_1181 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1181 << 11)); });
({ word_1 tmp_1182 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1182 << 7)); });
({ word_1 tmp_1183 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1183 << 6)); });
({ word_1 tmp_1184 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1184 << 2)); });
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_1185 = (tmp_1(intp) - imm16);
({ word_1 tmp_1186 = subcarry_16(tmp_1(intp), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1186 << 0)); });
({ word_1 tmp_1187 = ((tmp_1185 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1187 << 6)); });
({ word_1 tmp_1188 = ((tmp_1185 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1188 << 7)); });
({ word_1 tmp_1189 = addoverflow_16(tmp_1(intp), (((word_16)~imm16) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1189 << 11)); });
({ word_1 tmp_1190 = parity_even((tmp_1185 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1190 << 2)); });
})
;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_1191 = (tmp_8(intp) - imm32);
({ word_1 tmp_1192 = subcarry_32(tmp_8(intp), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1192 << 0)); });
({ word_1 tmp_1193 = ((tmp_1191 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1193 << 6)); });
({ word_1 tmp_1194 = ((tmp_1191 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1194 << 7)); });
({ word_1 tmp_1195 = addoverflow_32(tmp_8(intp), (((word_32)~imm32) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1195 << 11)); });
({ word_1 tmp_1196 = parity_even((tmp_1191 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1196 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_1197 = (tmp_1(intp) & imm16); tmp_24(intp, tmp_1197); });
({ word_1 tmp_1198 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1198 << 11)); });
({ word_1 tmp_1199 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1199 << 0)); });
({ word_1 tmp_1200 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1200 << 7)); });
({ word_1 tmp_1201 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1201 << 6)); });
({ word_1 tmp_1202 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1202 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_1203 = (tmp_8(intp) & imm32); tmp_31(intp, tmp_1203); });
({ word_1 tmp_1204 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1204 << 11)); });
({ word_1 tmp_1205 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1205 << 0)); });
({ word_1 tmp_1206 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1206 << 7)); });
({ word_1 tmp_1207 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1207 << 6)); });
({ word_1 tmp_1208 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1208 << 2)); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1209 = addoverflow_16(tmp_1(intp), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1209 << 11)); });
({ word_1 tmp_1210 = addcarry_16(tmp_1(intp), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1210 << 0)); });
({ word_16 tmp_1211 = (tmp_1(intp) + imm16); tmp_24(intp, tmp_1211); });
({ word_1 tmp_1212 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1212 << 7)); });
({ word_1 tmp_1213 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1213 << 6)); });
({ word_1 tmp_1214 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1214 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1215 = addoverflow_32(tmp_8(intp), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1215 << 11)); });
({ word_1 tmp_1216 = addcarry_32(tmp_8(intp), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1216 << 0)); });
({ word_32 tmp_1217 = (tmp_8(intp) + imm32); tmp_31(intp, tmp_1217); });
({ word_1 tmp_1218 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1218 << 7)); });
({ word_1 tmp_1219 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1219 << 6)); });
({ word_1 tmp_1220 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1220 << 2)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1221 = ((addoverflow_16(tmp_1(intp), imm16) | addoverflow_16((tmp_1(intp) + imm16), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1221 << 11)); });
({ word_1 tmp_1222 = ((addcarry_16(tmp_1(intp), imm16) | addcarry_16((tmp_1(intp) + imm16), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1222 << 0)); });
({ word_16 tmp_1223 = ((tmp_1(intp) + imm16) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_24(intp, tmp_1223); });
({ word_1 tmp_1224 = ((tmp_1(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1224 << 7)); });
({ word_1 tmp_1225 = ((tmp_1(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1225 << 6)); });
({ word_1 tmp_1226 = parity_even((tmp_1(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1226 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1227 = ((addoverflow_32(tmp_8(intp), imm32) | addoverflow_32((tmp_8(intp) + imm32), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1227 << 11)); });
({ word_1 tmp_1228 = ((addcarry_32(tmp_8(intp), imm32) | addcarry_32((tmp_8(intp) + imm32), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1228 << 0)); });
({ word_32 tmp_1229 = ((tmp_8(intp) + imm32) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_31(intp, tmp_1229); });
({ word_1 tmp_1230 = ((tmp_8(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1230 << 7)); });
({ word_1 tmp_1231 = ((tmp_8(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1231 << 6)); });
({ word_1 tmp_1232 = parity_even((tmp_8(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1232 << 2)); });
}
break;
default :
bt_assert(0);
}
}
break;
case 128 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_1233 = (tmp_16(intp) ^ imm8); tmp_38(intp, tmp_1233); });
({ word_1 tmp_1234 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1234 << 0)); });
({ word_1 tmp_1235 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1235 << 11)); });
({ word_1 tmp_1236 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1236 << 7)); });
({ word_1 tmp_1237 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1237 << 6)); });
({ word_1 tmp_1238 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1238 << 2)); });
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1239 = subcarry_8(tmp_16(intp), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1239 << 0)); });
({ word_1 tmp_1240 = addoverflow_8(tmp_16(intp), (((word_8)~imm8) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1240 << 11)); });
({ word_8 tmp_1241 = (tmp_16(intp) - imm8); tmp_38(intp, tmp_1241); });
({ word_1 tmp_1242 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1242 << 7)); });
({ word_1 tmp_1243 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1243 << 6)); });
({ word_1 tmp_1244 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1244 << 2)); });
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_8 tmp_1245 = (imm8 + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_1246 = subcarry_8(tmp_16(intp), tmp_1245); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1246 << 0)); });
({ word_1 tmp_1247 = addoverflow_8(tmp_16(intp), (((word_8)~tmp_1245) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1247 << 11)); });
({ word_8 tmp_1248 = (tmp_16(intp) - tmp_1245); tmp_38(intp, tmp_1248); });
({ word_1 tmp_1249 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1249 << 7)); });
({ word_1 tmp_1250 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1250 << 6)); });
({ word_1 tmp_1251 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1251 << 2)); });
})
;
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_1252 = (tmp_16(intp) | imm8); tmp_38(intp, tmp_1252); });
({ word_1 tmp_1253 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1253 << 0)); });
({ word_1 tmp_1254 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1254 << 11)); });
({ word_1 tmp_1255 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1255 << 7)); });
({ word_1 tmp_1256 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1256 << 6)); });
({ word_1 tmp_1257 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1257 << 2)); });
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_8 tmp_1258 = (tmp_16(intp) - imm8);
({ word_1 tmp_1259 = subcarry_8(tmp_16(intp), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1259 << 0)); });
({ word_1 tmp_1260 = ((tmp_1258 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1260 << 6)); });
({ word_1 tmp_1261 = ((tmp_1258 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1261 << 7)); });
({ word_1 tmp_1262 = addoverflow_8(tmp_16(intp), (((word_8)~imm8) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1262 << 11)); });
({ word_1 tmp_1263 = parity_even((tmp_1258 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1263 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_1264 = (tmp_16(intp) & imm8); tmp_38(intp, tmp_1264); });
({ word_1 tmp_1265 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1265 << 11)); });
({ word_1 tmp_1266 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1266 << 0)); });
({ word_1 tmp_1267 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1267 << 7)); });
({ word_1 tmp_1268 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1268 << 6)); });
({ word_1 tmp_1269 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1269 << 2)); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1270 = addoverflow_8(tmp_16(intp), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1270 << 11)); });
({ word_1 tmp_1271 = addcarry_8(tmp_16(intp), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1271 << 0)); });
({ word_8 tmp_1272 = (tmp_16(intp) + imm8); tmp_38(intp, tmp_1272); });
({ word_1 tmp_1273 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1273 << 7)); });
({ word_1 tmp_1274 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1274 << 6)); });
({ word_1 tmp_1275 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1275 << 2)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1276 = ((addoverflow_8(tmp_16(intp), imm8) | addoverflow_8((tmp_16(intp) + imm8), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1276 << 11)); });
({ word_1 tmp_1277 = ((addcarry_8(tmp_16(intp), imm8) | addcarry_8((tmp_16(intp) + imm8), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1277 << 0)); });
({ word_8 tmp_1278 = ((tmp_16(intp) + imm8) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_38(intp, tmp_1278); });
({ word_1 tmp_1279 = ((tmp_16(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1279 << 7)); });
({ word_1 tmp_1280 = ((tmp_16(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1280 << 6)); });
({ word_1 tmp_1281 = parity_even((tmp_16(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1281 << 2)); });
}
break;
default :
bt_assert(0);
}
}
break;
case 21 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1282 = ((addoverflow_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), imm16) | addoverflow_16((((intp->regs_GPR[0] >> 0) & 0xFFFF) + imm16), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1282 << 11)); });
({ word_1 tmp_1283 = ((addcarry_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), imm16) | addcarry_16((((intp->regs_GPR[0] >> 0) & 0xFFFF) + imm16), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1283 << 0)); });
({ word_16 tmp_1284 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) + imm16) + ((intp->regs_SPR[0] >> 0) & 0x1)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_1284 << 0)); });
({ word_1 tmp_1285 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1285 << 7)); });
({ word_1 tmp_1286 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1286 << 6)); });
({ word_1 tmp_1287 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1287 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1288 = ((addoverflow_32((intp->regs_GPR[0]), imm32) | addoverflow_32(((intp->regs_GPR[0]) + imm32), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1288 << 11)); });
({ word_1 tmp_1289 = ((addcarry_32((intp->regs_GPR[0]), imm32) | addcarry_32(((intp->regs_GPR[0]) + imm32), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1289 << 0)); });
({ word_32 tmp_1290 = (((intp->regs_GPR[0]) + imm32) + ((intp->regs_SPR[0] >> 0) & 0x1)); ((intp->regs_GPR[0]) = tmp_1290); });
({ word_1 tmp_1291 = (((intp->regs_GPR[0]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1291 << 7)); });
({ word_1 tmp_1292 = (((intp->regs_GPR[0]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1292 << 6)); });
({ word_1 tmp_1293 = parity_even(((intp->regs_GPR[0]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1293 << 2)); });
}
break;
case 20 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
bt_assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_1294 = ((addoverflow_8(((intp->regs_GPR[0] >> 0) & 0xFF), imm8) | addoverflow_8((((intp->regs_GPR[0] >> 0) & 0xFF) + imm8), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_1294 << 11)); });
({ word_1 tmp_1295 = ((addcarry_8(((intp->regs_GPR[0] >> 0) & 0xFF), imm8) | addcarry_8((((intp->regs_GPR[0] >> 0) & 0xFF) + imm8), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_1295 << 0)); });
({ word_8 tmp_1296 = ((((intp->regs_GPR[0] >> 0) & 0xFF) + imm8) + ((intp->regs_SPR[0] >> 0) & 0x1)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_1296 << 0)); });
({ word_1 tmp_1297 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_1297 << 7)); });
({ word_1 tmp_1298 = ((((intp->regs_GPR[0] >> 0) & 0xFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_1298 << 6)); });
({ word_1 tmp_1299 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_1299 << 2)); });
}
break;
default:
bt_assert(0);
}
intp->pc = next_pc;
}
void dump_i386_registers (interpreter_t *intp) {
printf("EAX: 0x%x\n", intp->regs_GPR[0]);
printf("ECX: 0x%x\n", intp->regs_GPR[1]);
printf("EDX: 0x%x\n", intp->regs_GPR[2]);
printf("EBX: 0x%x\n", intp->regs_GPR[3]);
printf("ESP: 0x%x\n", intp->regs_GPR[4]);
printf("EBP: 0x%x\n", intp->regs_GPR[5]);
printf("ESI: 0x%x\n", intp->regs_GPR[6]);
printf("EDI: 0x%x\n", intp->regs_GPR[7]);
printf("EFLAGS: 0x%x\n", intp->regs_SPR[0]);
printf("FPSW: 0x%x\n", intp->regs_FSPR[0]);
printf("FPCW: 0x%x\n", intp->regs_FSPR[1]);
printf("FPST0: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[0], intp->regs_FPST[0]);
printf("FPST1: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[1], intp->regs_FPST[1]);
printf("FPST2: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[2], intp->regs_FPST[2]);
printf("FPST3: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[3], intp->regs_FPST[3]);
printf("FPST4: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[4], intp->regs_FPST[4]);
printf("FPST5: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[5], intp->regs_FPST[5]);
printf("FPST6: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[6], intp->regs_FPST[6]);
printf("FPST7: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[7], intp->regs_FPST[7]);
printf("PC: 0x%x\n", intp->pc);
}
