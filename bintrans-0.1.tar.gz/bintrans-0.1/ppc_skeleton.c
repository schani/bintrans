void SKELETON_FUNC_NAME (word_32 insn, word_32 pc SKELETON_FUNC_ARGS) {
SKELETON_PRE_DECODE
switch (((insn >> 26) & 0x3F)) {
case 27:
/* XORIS */
if ((insn & 0xFC000000) != 0x6C000000) bt_assert(0);
handle_xoris_insn(insn, pc);
break;
case 26:
/* XORI */
if ((insn & 0xFC000000) != 0x68000000) bt_assert(0);
handle_xori_insn(insn, pc);
break;
case 31:
switch (((insn >> 0) & 0x7FF)) {
case 633:
/* XOR. */
if ((insn & 0xFC0007FF) != 0x7C000279) bt_assert(0);
handle_xord_insn(insn, pc);
break;
case 632:
/* XOR */
if ((insn & 0xFC0007FF) != 0x7C000278) bt_assert(0);
handle_xor_insn(insn, pc);
break;
case 1196:
/* SYNC */
if ((insn & 0xFFFFFFFF) != 0x7C0004AC) bt_assert(0);
handle_sync_insn(insn, pc);
break;
case 1425:
/* SUBFZEO. */
if ((insn & 0xFC00FFFF) != 0x7C000591) bt_assert(0);
handle_subfzeod_insn(insn, pc);
break;
case 1424:
/* SUBFZEO */
if ((insn & 0xFC00FFFF) != 0x7C000590) bt_assert(0);
handle_subfzeo_insn(insn, pc);
break;
case 401:
/* SUBFZE. */
if ((insn & 0xFC00FFFF) != 0x7C000191) bt_assert(0);
handle_subfzed_insn(insn, pc);
break;
case 400:
/* SUBFZE */
if ((insn & 0xFC00FFFF) != 0x7C000190) bt_assert(0);
handle_subfze_insn(insn, pc);
break;
case 1489:
/* SUBFMEO. */
if ((insn & 0xFC00FFFF) != 0x7C0005D1) bt_assert(0);
handle_subfmeod_insn(insn, pc);
break;
case 1488:
/* SUBFMEO */
if ((insn & 0xFC00FFFF) != 0x7C0005D0) bt_assert(0);
handle_subfmeo_insn(insn, pc);
break;
case 465:
/* SUBFME. */
if ((insn & 0xFC00FFFF) != 0x7C0001D1) bt_assert(0);
handle_subfmed_insn(insn, pc);
break;
case 464:
/* SUBFME */
if ((insn & 0xFC00FFFF) != 0x7C0001D0) bt_assert(0);
handle_subfme_insn(insn, pc);
break;
case 1297:
/* SUBFEO. */
if ((insn & 0xFC0007FF) != 0x7C000511) bt_assert(0);
handle_subfeod_insn(insn, pc);
break;
case 1296:
/* SUBFEO */
if ((insn & 0xFC0007FF) != 0x7C000510) bt_assert(0);
handle_subfeo_insn(insn, pc);
break;
case 273:
/* SUBFE. */
if ((insn & 0xFC0007FF) != 0x7C000111) bt_assert(0);
handle_subfed_insn(insn, pc);
break;
case 272:
/* SUBFE */
if ((insn & 0xFC0007FF) != 0x7C000110) bt_assert(0);
handle_subfe_insn(insn, pc);
break;
case 1041:
/* SUBFCO. */
if ((insn & 0xFC0007FF) != 0x7C000411) bt_assert(0);
handle_subfcod_insn(insn, pc);
break;
case 1040:
/* SUBFCO */
if ((insn & 0xFC0007FF) != 0x7C000410) bt_assert(0);
handle_subfco_insn(insn, pc);
break;
case 17:
/* SUBFC. */
if ((insn & 0xFC0007FF) != 0x7C000011) bt_assert(0);
handle_subfcd_insn(insn, pc);
break;
case 16:
/* SUBFC */
if ((insn & 0xFC0007FF) != 0x7C000010) bt_assert(0);
handle_subfc_insn(insn, pc);
break;
case 1105:
/* SUBFO. */
if ((insn & 0xFC0007FF) != 0x7C000451) bt_assert(0);
handle_subfod_insn(insn, pc);
break;
case 1104:
/* SUBFO */
if ((insn & 0xFC0007FF) != 0x7C000450) bt_assert(0);
handle_subfo_insn(insn, pc);
break;
case 81:
/* SUBF. */
if ((insn & 0xFC0007FF) != 0x7C000051) bt_assert(0);
handle_subfd_insn(insn, pc);
break;
case 80:
/* SUBF */
if ((insn & 0xFC0007FF) != 0x7C000050) bt_assert(0);
handle_subf_insn(insn, pc);
break;
case 302:
/* STWX */
if ((insn & 0xFC0007FF) != 0x7C00012E) bt_assert(0);
handle_stwx_insn(insn, pc);
break;
case 366:
/* STWUX */
if ((insn & 0xFC0007FF) != 0x7C00016E) bt_assert(0);
handle_stwux_insn(insn, pc);
break;
case 1324:
/* STWBRX */
if ((insn & 0xFC0007FF) != 0x7C00052C) bt_assert(0);
handle_stwbrx_insn(insn, pc);
break;
case 814:
/* STHX */
if ((insn & 0xFC0007FF) != 0x7C00032E) bt_assert(0);
handle_sthx_insn(insn, pc);
break;
case 1836:
/* STHBRX */
if ((insn & 0xFC0007FF) != 0x7C00072C) bt_assert(0);
handle_sthbrx_insn(insn, pc);
break;
case 1326:
/* STFSX */
if ((insn & 0xFC0007FF) != 0x7C00052E) bt_assert(0);
handle_stfsx_insn(insn, pc);
break;
case 1454:
/* STFDX */
if ((insn & 0xFC0007FF) != 0x7C0005AE) bt_assert(0);
handle_stfdx_insn(insn, pc);
break;
case 430:
/* STBX */
if ((insn & 0xFC0007FF) != 0x7C0001AE) bt_assert(0);
handle_stbx_insn(insn, pc);
break;
case 1073:
/* SRW. */
if ((insn & 0xFC0007FF) != 0x7C000431) bt_assert(0);
handle_srwd_insn(insn, pc);
break;
case 1072:
/* SRW */
if ((insn & 0xFC0007FF) != 0x7C000430) bt_assert(0);
handle_srw_insn(insn, pc);
break;
case 1649:
/* SRAWI. */
if ((insn & 0xFC0007FF) != 0x7C000671) bt_assert(0);
handle_srawid_insn(insn, pc);
break;
case 1648:
/* SRAWI */
if ((insn & 0xFC0007FF) != 0x7C000670) bt_assert(0);
handle_srawi_insn(insn, pc);
break;
case 1585:
/* SRAW. */
if ((insn & 0xFC0007FF) != 0x7C000631) bt_assert(0);
handle_srawd_insn(insn, pc);
break;
case 1584:
/* SRAW */
if ((insn & 0xFC0007FF) != 0x7C000630) bt_assert(0);
handle_sraw_insn(insn, pc);
break;
case 49:
/* SLW. */
if ((insn & 0xFC0007FF) != 0x7C000031) bt_assert(0);
handle_slwd_insn(insn, pc);
break;
case 48:
/* SLW */
if ((insn & 0xFC0007FF) != 0x7C000030) bt_assert(0);
handle_slw_insn(insn, pc);
break;
case 825:
/* ORC. */
if ((insn & 0xFC0007FF) != 0x7C000339) bt_assert(0);
handle_orcd_insn(insn, pc);
break;
case 824:
/* ORC */
if ((insn & 0xFC0007FF) != 0x7C000338) bt_assert(0);
handle_orc_insn(insn, pc);
break;
case 889:
/* OR. */
if ((insn & 0xFC0007FF) != 0x7C000379) bt_assert(0);
handle_ord_insn(insn, pc);
break;
case 888:
/* OR */
if ((insn & 0xFC0007FF) != 0x7C000378) bt_assert(0);
handle_or_insn(insn, pc);
break;
case 249:
/* NOR. */
if ((insn & 0xFC0007FF) != 0x7C0000F9) bt_assert(0);
handle_nord_insn(insn, pc);
break;
case 248:
/* NOR */
if ((insn & 0xFC0007FF) != 0x7C0000F8) bt_assert(0);
handle_nor_insn(insn, pc);
break;
case 1233:
/* NEGO. */
if ((insn & 0xFC00FFFF) != 0x7C0004D1) bt_assert(0);
handle_negod_insn(insn, pc);
break;
case 1232:
/* NEGO */
if ((insn & 0xFC00FFFF) != 0x7C0004D0) bt_assert(0);
handle_nego_insn(insn, pc);
break;
case 209:
/* NEG. */
if ((insn & 0xFC00FFFF) != 0x7C0000D1) bt_assert(0);
handle_negd_insn(insn, pc);
break;
case 208:
/* NEG */
if ((insn & 0xFC00FFFF) != 0x7C0000D0) bt_assert(0);
handle_neg_insn(insn, pc);
break;
case 953:
/* NAND. */
if ((insn & 0xFC0007FF) != 0x7C0003B9) bt_assert(0);
handle_nandd_insn(insn, pc);
break;
case 952:
/* NAND */
if ((insn & 0xFC0007FF) != 0x7C0003B8) bt_assert(0);
handle_nand_insn(insn, pc);
break;
case 1495:
/* MULLWO. */
if ((insn & 0xFC0007FF) != 0x7C0005D7) bt_assert(0);
handle_mullwod_insn(insn, pc);
break;
case 1494:
/* MULLWO */
if ((insn & 0xFC0007FF) != 0x7C0005D6) bt_assert(0);
handle_mullwo_insn(insn, pc);
break;
case 471:
/* MULLW. */
if ((insn & 0xFC0007FF) != 0x7C0001D7) bt_assert(0);
handle_mullwd_insn(insn, pc);
break;
case 470:
/* MULLW */
if ((insn & 0xFC0007FF) != 0x7C0001D6) bt_assert(0);
handle_mullw_insn(insn, pc);
break;
case 22:
/* MULHWU */
if ((insn & 0xFC0007FF) != 0x7C000016) bt_assert(0);
handle_mulhwu_insn(insn, pc);
break;
case 150:
/* MULHW */
if ((insn & 0xFC0007FF) != 0x7C000096) bt_assert(0);
handle_mulhw_insn(insn, pc);
break;
case 934:
switch (((insn >> 11) & 0x3FF)) {
case 32:
/* MTXER */
if ((insn & 0xFC1FFFFF) != 0x7C0103A6) bt_assert(0);
handle_mtxer_insn(insn, pc);
break;
case 256:
/* MTLR */
if ((insn & 0xFC1FFFFF) != 0x7C0803A6) bt_assert(0);
handle_mtlr_insn(insn, pc);
break;
case 288:
/* MTCTR */
if ((insn & 0xFC1FFFFF) != 0x7C0903A6) bt_assert(0);
handle_mtctr_insn(insn, pc);
break;
default:
bt_assert(0);
}
break;
case 288:
/* MTCRF */
if ((insn & 0xFC100FFF) != 0x7C000120) bt_assert(0);
handle_mtcrf_insn(insn, pc);
break;
case 678:
switch (((insn >> 11) & 0x3FF)) {
case 32:
/* MFXER */
if ((insn & 0xFC1FFFFF) != 0x7C0102A6) bt_assert(0);
handle_mfxer_insn(insn, pc);
break;
case 256:
/* MFLR */
if ((insn & 0xFC1FFFFF) != 0x7C0802A6) bt_assert(0);
handle_mflr_insn(insn, pc);
break;
case 288:
/* MFCTR */
if ((insn & 0xFC1FFFFF) != 0x7C0902A6) bt_assert(0);
handle_mfctr_insn(insn, pc);
break;
default:
bt_assert(0);
}
break;
case 38:
/* MFCR */
if ((insn & 0xFC1FFFFF) != 0x7C000026) bt_assert(0);
handle_mfcr_insn(insn, pc);
break;
case 1024:
/* MCRXR */
if ((insn & 0xFC7FFFFF) != 0x7C000400) bt_assert(0);
handle_mcrxr_insn(insn, pc);
break;
case 46:
/* LWZX */
if ((insn & 0xFC0007FF) != 0x7C00002E) bt_assert(0);
handle_lwzx_insn(insn, pc);
break;
case 110:
/* LWZUX */
if ((insn & 0xFC0007FF) != 0x7C00006E) bt_assert(0);
handle_lwzux_insn(insn, pc);
break;
case 1068:
/* LWBRX */
if ((insn & 0xFC0007FF) != 0x7C00042C) bt_assert(0);
handle_lwbrx_insn(insn, pc);
break;
case 558:
/* LHZX */
if ((insn & 0xFC0007FF) != 0x7C00022E) bt_assert(0);
handle_lhzx_insn(insn, pc);
break;
case 1580:
/* LHBRX */
if ((insn & 0xFC0007FF) != 0x7C00062C) bt_assert(0);
handle_lhbrx_insn(insn, pc);
break;
case 686:
/* LHAX */
if ((insn & 0xFC0007FF) != 0x7C0002AE) bt_assert(0);
handle_lhax_insn(insn, pc);
break;
case 1070:
/* LFSX */
if ((insn & 0xFC0007FF) != 0x7C00042E) bt_assert(0);
handle_lfsx_insn(insn, pc);
break;
case 1198:
/* LFDX */
if ((insn & 0xFC0007FF) != 0x7C0004AE) bt_assert(0);
handle_lfdx_insn(insn, pc);
break;
case 174:
/* LBZX */
if ((insn & 0xFC0007FF) != 0x7C0000AE) bt_assert(0);
handle_lbzx_insn(insn, pc);
break;
case 238:
/* LBZUX */
if ((insn & 0xFC0007FF) != 0x7C0000EE) bt_assert(0);
handle_lbzux_insn(insn, pc);
break;
case 1964:
/* ICBI */
if ((insn & 0xFFE007FF) != 0x7C0007AC) bt_assert(0);
handle_icbi_insn(insn, pc);
break;
case 1845:
/* EXTSH. */
if ((insn & 0xFC00FFFF) != 0x7C000735) bt_assert(0);
handle_extshd_insn(insn, pc);
break;
case 1844:
/* EXTSH */
if ((insn & 0xFC00FFFF) != 0x7C000734) bt_assert(0);
handle_extsh_insn(insn, pc);
break;
case 1908:
/* EXTSB */
if ((insn & 0xFC00FFFF) != 0x7C000774) bt_assert(0);
handle_extsb_insn(insn, pc);
break;
case 569:
/* EQV. */
if ((insn & 0xFC0007FF) != 0x7C000239) bt_assert(0);
handle_eqvd_insn(insn, pc);
break;
case 568:
/* EQV */
if ((insn & 0xFC0007FF) != 0x7C000238) bt_assert(0);
handle_eqv_insn(insn, pc);
break;
case 1943:
/* DIVWUO. */
if ((insn & 0xFC0007FF) != 0x7C000797) bt_assert(0);
handle_divwuod_insn(insn, pc);
break;
case 1942:
/* DIVWUO */
if ((insn & 0xFC0007FF) != 0x7C000796) bt_assert(0);
handle_divwuo_insn(insn, pc);
break;
case 919:
/* DIVWU. */
if ((insn & 0xFC0007FF) != 0x7C000397) bt_assert(0);
handle_divwud_insn(insn, pc);
break;
case 918:
/* DIVWU */
if ((insn & 0xFC0007FF) != 0x7C000396) bt_assert(0);
handle_divwu_insn(insn, pc);
break;
case 2007:
/* DIVWO. */
if ((insn & 0xFC0007FF) != 0x7C0007D7) bt_assert(0);
handle_divwod_insn(insn, pc);
break;
case 2006:
/* DIVWO */
if ((insn & 0xFC0007FF) != 0x7C0007D6) bt_assert(0);
handle_divwo_insn(insn, pc);
break;
case 983:
/* DIVW. */
if ((insn & 0xFC0007FF) != 0x7C0003D7) bt_assert(0);
handle_divwd_insn(insn, pc);
break;
case 982:
/* DIVW */
if ((insn & 0xFC0007FF) != 0x7C0003D6) bt_assert(0);
handle_divw_insn(insn, pc);
break;
case 2028:
/* DCBZ */
if ((insn & 0xFFE007FF) != 0x7C0007EC) bt_assert(0);
handle_dcbz_insn(insn, pc);
break;
case 108:
/* DCBST */
if ((insn & 0xFFE007FF) != 0x7C00006C) bt_assert(0);
handle_dcbst_insn(insn, pc);
break;
case 52:
/* CNTLZW */
if ((insn & 0xFC00FFFF) != 0x7C000034) bt_assert(0);
handle_cntlzw_insn(insn, pc);
break;
case 0:
/* CMPW */
if ((insn & 0xFC6007FF) != 0x7C000000) bt_assert(0);
handle_cmpw_insn(insn, pc);
break;
case 64:
/* CMPLW */
if ((insn & 0xFC6007FF) != 0x7C000040) bt_assert(0);
handle_cmplw_insn(insn, pc);
break;
case 121:
/* ANDC. */
if ((insn & 0xFC0007FF) != 0x7C000079) bt_assert(0);
handle_andcd_insn(insn, pc);
break;
case 120:
/* ANDC */
if ((insn & 0xFC0007FF) != 0x7C000078) bt_assert(0);
handle_andc_insn(insn, pc);
break;
case 57:
/* AND. */
if ((insn & 0xFC0007FF) != 0x7C000039) bt_assert(0);
handle_andd_insn(insn, pc);
break;
case 56:
/* AND */
if ((insn & 0xFC0007FF) != 0x7C000038) bt_assert(0);
handle_and_insn(insn, pc);
break;
case 1429:
/* ADDZEO. */
if ((insn & 0xFC00FFFF) != 0x7C000595) bt_assert(0);
handle_addzeod_insn(insn, pc);
break;
case 1428:
/* ADDZEO */
if ((insn & 0xFC00FFFF) != 0x7C000594) bt_assert(0);
handle_addzeo_insn(insn, pc);
break;
case 405:
/* ADDZE. */
if ((insn & 0xFC00FFFF) != 0x7C000195) bt_assert(0);
handle_addzed_insn(insn, pc);
break;
case 404:
/* ADDZE */
if ((insn & 0xFC00FFFF) != 0x7C000194) bt_assert(0);
handle_addze_insn(insn, pc);
break;
case 1493:
/* ADDMEO. */
if ((insn & 0xFC00FFFF) != 0x7C0005D5) bt_assert(0);
handle_addmeod_insn(insn, pc);
break;
case 1492:
/* ADDMEO */
if ((insn & 0xFC00FFFF) != 0x7C0005D4) bt_assert(0);
handle_addmeo_insn(insn, pc);
break;
case 469:
/* ADDME. */
if ((insn & 0xFC00FFFF) != 0x7C0001D5) bt_assert(0);
handle_addmed_insn(insn, pc);
break;
case 468:
/* ADDME */
if ((insn & 0xFC00FFFF) != 0x7C0001D4) bt_assert(0);
handle_addme_insn(insn, pc);
break;
case 1301:
/* ADDEO. */
if ((insn & 0xFC0007FF) != 0x7C000515) bt_assert(0);
handle_addeod_insn(insn, pc);
break;
case 1300:
/* ADDEO */
if ((insn & 0xFC0007FF) != 0x7C000514) bt_assert(0);
handle_addeo_insn(insn, pc);
break;
case 277:
/* ADDE. */
if ((insn & 0xFC0007FF) != 0x7C000115) bt_assert(0);
handle_added_insn(insn, pc);
break;
case 276:
/* ADDE */
if ((insn & 0xFC0007FF) != 0x7C000114) bt_assert(0);
handle_adde_insn(insn, pc);
break;
case 1045:
/* ADDCO. */
if ((insn & 0xFC0007FF) != 0x7C000415) bt_assert(0);
handle_addcod_insn(insn, pc);
break;
case 1044:
/* ADDCO */
if ((insn & 0xFC0007FF) != 0x7C000414) bt_assert(0);
handle_addco_insn(insn, pc);
break;
case 21:
/* ADDC. */
if ((insn & 0xFC0007FF) != 0x7C000015) bt_assert(0);
handle_addcd_insn(insn, pc);
break;
case 20:
/* ADDC */
if ((insn & 0xFC0007FF) != 0x7C000014) bt_assert(0);
handle_addc_insn(insn, pc);
break;
case 1557:
/* ADDO. */
if ((insn & 0xFC0007FF) != 0x7C000615) bt_assert(0);
handle_addod_insn(insn, pc);
break;
case 1556:
/* ADDO */
if ((insn & 0xFC0007FF) != 0x7C000614) bt_assert(0);
handle_addo_insn(insn, pc);
break;
case 533:
/* ADD. */
if ((insn & 0xFC0007FF) != 0x7C000215) bt_assert(0);
handle_addd_insn(insn, pc);
break;
case 532:
/* ADD */
if ((insn & 0xFC0007FF) != 0x7C000214) bt_assert(0);
handle_add_insn(insn, pc);
break;
default:
bt_assert(0);
}
break;
case 8:
/* SUBFIC */
if ((insn & 0xFC000000) != 0x20000000) bt_assert(0);
handle_subfic_insn(insn, pc);
break;
case 37:
/* STWU */
if ((insn & 0xFC000000) != 0x94000000) bt_assert(0);
handle_stwu_insn(insn, pc);
break;
case 36:
/* STW */
if ((insn & 0xFC000000) != 0x90000000) bt_assert(0);
handle_stw_insn(insn, pc);
break;
case 45:
/* STHU */
if ((insn & 0xFC000000) != 0xB4000000) bt_assert(0);
handle_sthu_insn(insn, pc);
break;
case 44:
/* STH */
if ((insn & 0xFC000000) != 0xB0000000) bt_assert(0);
handle_sth_insn(insn, pc);
break;
case 52:
/* STFS */
if ((insn & 0xFC000000) != 0xD0000000) bt_assert(0);
handle_stfs_insn(insn, pc);
break;
case 55:
/* STFDU */
if ((insn & 0xFC000000) != 0xDC000000) bt_assert(0);
handle_stfdu_insn(insn, pc);
break;
case 54:
/* STFD */
if ((insn & 0xFC000000) != 0xD8000000) bt_assert(0);
handle_stfd_insn(insn, pc);
break;
case 39:
/* STBU */
if ((insn & 0xFC000000) != 0x9C000000) bt_assert(0);
handle_stbu_insn(insn, pc);
break;
case 38:
/* STB */
if ((insn & 0xFC000000) != 0x98000000) bt_assert(0);
handle_stb_insn(insn, pc);
break;
case 17:
/* SC */
if ((insn & 0xFFFFFFFF) != 0x44000002) bt_assert(0);
handle_sc_insn(insn, pc);
break;
case 23:
switch (((insn >> 0) & 0x1)) {
case 1:
/* RLWNM. */
if ((insn & 0xFC000001) != 0x5C000001) bt_assert(0);
handle_rlwnmd_insn(insn, pc);
break;
case 0:
/* RLWNM */
if ((insn & 0xFC000001) != 0x5C000000) bt_assert(0);
handle_rlwnm_insn(insn, pc);
break;
default:
bt_assert(0);
}
break;
case 21:
switch (((insn >> 0) & 0x1)) {
case 1:
/* RLWINM. */
if ((insn & 0xFC000001) != 0x54000001) bt_assert(0);
handle_rlwinmd_insn(insn, pc);
break;
case 0:
/* RLWINM */
if ((insn & 0xFC000001) != 0x54000000) bt_assert(0);
handle_rlwinm_insn(insn, pc);
break;
default:
bt_assert(0);
}
break;
case 20:
/* RLWIMI */
if ((insn & 0xFC000001) != 0x50000000) bt_assert(0);
handle_rlwimi_insn(insn, pc);
break;
case 25:
/* ORIS */
if ((insn & 0xFC000000) != 0x64000000) bt_assert(0);
handle_oris_insn(insn, pc);
break;
case 24:
/* ORI */
if ((insn & 0xFC000000) != 0x60000000) bt_assert(0);
handle_ori_insn(insn, pc);
break;
case 7:
/* MULLI */
if ((insn & 0xFC000000) != 0x1C000000) bt_assert(0);
handle_mulli_insn(insn, pc);
break;
case 63:
switch (((insn >> 0) & 0x3F)) {
case 12:
switch (((insn >> 6) & 0x3F)) {
case 4:
/* MTFSFI */
if ((insn & 0xFC7F0FFF) != 0xFC00010C) bt_assert(0);
handle_mtfsfi_insn(insn, pc);
break;
case 2:
/* MTFSB0 */
if ((insn & 0xFC1FFFFF) != 0xFC00008C) bt_assert(0);
handle_mtfsb0_insn(insn, pc);
break;
default:
bt_assert(0);
}
break;
case 14:
switch (((insn >> 6) & 0x1F)) {
case 22:
/* MTFSF */
if ((insn & 0xFFFF07FF) != 0xFDFE058E) bt_assert(0);
handle_mtfsf_insn(insn, pc);
break;
case 18:
/* MFFS */
if ((insn & 0xFC1FFFFF) != 0xFC00048E) bt_assert(0);
handle_mffs_insn(insn, pc);
break;
default:
bt_assert(0);
}
break;
case 40:
/* FSUB */
if ((insn & 0xFC0007FF) != 0xFC000028) bt_assert(0);
handle_fsub_insn(insn, pc);
break;
case 24:
/* FRSP */
if ((insn & 0xFC1F07FF) != 0xFC000018) bt_assert(0);
handle_frsp_insn(insn, pc);
break;
case 60:
/* FNMSUB */
if ((insn & 0xFC00003F) != 0xFC00003C) bt_assert(0);
handle_fnmsub_insn(insn, pc);
break;
case 16:
switch (((insn >> 6) & 0x1F)) {
case 1:
/* FNEG */
if ((insn & 0xFC1F07FF) != 0xFC000050) bt_assert(0);
handle_fneg_insn(insn, pc);
break;
case 2:
/* FMR */
if ((insn & 0xFC1F07FF) != 0xFC000090) bt_assert(0);
handle_fmr_insn(insn, pc);
break;
case 8:
/* FABS */
if ((insn & 0xFC1F07FF) != 0xFC000210) bt_assert(0);
handle_fabs_insn(insn, pc);
break;
default:
bt_assert(0);
}
break;
case 50:
/* FMUL */
if ((insn & 0xFC00F83F) != 0xFC000032) bt_assert(0);
handle_fmul_insn(insn, pc);
break;
case 56:
/* FMSUB */
if ((insn & 0xFC00003F) != 0xFC000038) bt_assert(0);
handle_fmsub_insn(insn, pc);
break;
case 58:
/* FMADD */
if ((insn & 0xFC00003F) != 0xFC00003A) bt_assert(0);
handle_fmadd_insn(insn, pc);
break;
case 36:
/* FDIV */
if ((insn & 0xFC0007FF) != 0xFC000024) bt_assert(0);
handle_fdiv_insn(insn, pc);
break;
case 30:
/* FCTIWZ */
if ((insn & 0xFC1F07FF) != 0xFC00001E) bt_assert(0);
handle_fctiwz_insn(insn, pc);
break;
case 0:
/* FCMPU */
if ((insn & 0xFC6007FF) != 0xFC000000) bt_assert(0);
handle_fcmpu_insn(insn, pc);
break;
case 42:
/* FADD */
if ((insn & 0xFC0007FF) != 0xFC00002A) bt_assert(0);
handle_fadd_insn(insn, pc);
break;
default:
bt_assert(0);
}
break;
case 19:
switch (((insn >> 0) & 0x7FF)) {
case 0:
/* MCRF */
if ((insn & 0xFC63FFFF) != 0x4C000000) bt_assert(0);
handle_mcrf_insn(insn, pc);
break;
case 300:
/* ISYNC */
if ((insn & 0xFFFFFFFF) != 0x4C00012C) bt_assert(0);
handle_isync_insn(insn, pc);
break;
case 386:
/* CRXOR */
if ((insn & 0xFC0007FF) != 0x4C000182) bt_assert(0);
handle_crxor_insn(insn, pc);
break;
case 834:
/* CRORC */
if ((insn & 0xFC0007FF) != 0x4C000342) bt_assert(0);
handle_crorc_insn(insn, pc);
break;
case 898:
/* CROR */
if ((insn & 0xFC0007FF) != 0x4C000382) bt_assert(0);
handle_cror_insn(insn, pc);
break;
case 66:
/* CRNOR */
if ((insn & 0xFC0007FF) != 0x4C000042) bt_assert(0);
handle_crnor_insn(insn, pc);
break;
case 450:
/* CRNAND */
if ((insn & 0xFC0007FF) != 0x4C0001C2) bt_assert(0);
handle_crnand_insn(insn, pc);
break;
case 578:
/* CREQV */
if ((insn & 0xFC0007FF) != 0x4C000242) bt_assert(0);
handle_creqv_insn(insn, pc);
break;
case 258:
/* CRANDC */
if ((insn & 0xFC0007FF) != 0x4C000102) bt_assert(0);
handle_crandc_insn(insn, pc);
break;
case 514:
/* CRAND */
if ((insn & 0xFC0007FF) != 0x4C000202) bt_assert(0);
handle_crand_insn(insn, pc);
break;
case 32:
switch (((insn >> 11) & 0x1F)) {
case 0:
switch (((insn >> 21) & 0x1F)) {
case 5:
/* BNELR+ */
if ((insn & 0xFFE0FFFF) != 0x4CA00020) bt_assert(0);
handle_bnelrp_insn(insn, pc);
break;
case 4:
/* BNELR */
if ((insn & 0xFFE0FFFF) != 0x4C800020) bt_assert(0);
handle_bnelr_insn(insn, pc);
break;
case 20:
/* BLR */
if ((insn & 0xFFE0FFFF) != 0x4E800020) bt_assert(0);
handle_blr_insn(insn, pc);
break;
case 12:
/* BEQLR */
if ((insn & 0xFFE0FFFF) != 0x4D800020) bt_assert(0);
handle_beqlr_insn(insn, pc);
break;
default:
bt_assert(0);
}
break;
default:
bt_assert(0);
}
break;
case 33:
/* BLRL */
if ((insn & 0xFFE0FFFF) != 0x4E800021) bt_assert(0);
handle_blrl_insn(insn, pc);
break;
case 1056:
/* BCTR */
if ((insn & 0xFFE0FFFF) != 0x4E800420) bt_assert(0);
handle_bctr_insn(insn, pc);
break;
default:
bt_assert(0);
}
break;
case 33:
/* LWZU */
if ((insn & 0xFC000000) != 0x84000000) bt_assert(0);
handle_lwzu_insn(insn, pc);
break;
case 32:
/* LWZ */
if ((insn & 0xFC000000) != 0x80000000) bt_assert(0);
handle_lwz_insn(insn, pc);
break;
case 41:
/* LHZU */
if ((insn & 0xFC000000) != 0xA4000000) bt_assert(0);
handle_lhzu_insn(insn, pc);
break;
case 40:
/* LHZ */
if ((insn & 0xFC000000) != 0xA0000000) bt_assert(0);
handle_lhz_insn(insn, pc);
break;
case 43:
/* LHAU */
if ((insn & 0xFC000000) != 0xAC000000) bt_assert(0);
handle_lhau_insn(insn, pc);
break;
case 42:
/* LHA */
if ((insn & 0xFC000000) != 0xA8000000) bt_assert(0);
handle_lha_insn(insn, pc);
break;
case 48:
/* LFS */
if ((insn & 0xFC000000) != 0xC0000000) bt_assert(0);
handle_lfs_insn(insn, pc);
break;
case 50:
/* LFD */
if ((insn & 0xFC000000) != 0xC8000000) bt_assert(0);
handle_lfd_insn(insn, pc);
break;
case 35:
/* LBZU */
if ((insn & 0xFC000000) != 0x8C000000) bt_assert(0);
handle_lbzu_insn(insn, pc);
break;
case 34:
/* LBZ */
if ((insn & 0xFC000000) != 0x88000000) bt_assert(0);
handle_lbz_insn(insn, pc);
break;
case 59:
switch (((insn >> 0) & 0x3F)) {
case 40:
/* FSUBS */
if ((insn & 0xFC0007FF) != 0xEC000028) bt_assert(0);
handle_fsubs_insn(insn, pc);
break;
case 50:
/* FMULS */
if ((insn & 0xFC00F83F) != 0xEC000032) bt_assert(0);
handle_fmuls_insn(insn, pc);
break;
case 56:
/* FMSUBS */
if ((insn & 0xFC00003F) != 0xEC000038) bt_assert(0);
handle_fmsubs_insn(insn, pc);
break;
case 58:
/* FMADDS */
if ((insn & 0xFC00003F) != 0xEC00003A) bt_assert(0);
handle_fmadds_insn(insn, pc);
break;
case 36:
/* FDIVS */
if ((insn & 0xFC0007FF) != 0xEC000024) bt_assert(0);
handle_fdivs_insn(insn, pc);
break;
case 42:
/* FADDS */
if ((insn & 0xFC0007FF) != 0xEC00002A) bt_assert(0);
handle_fadds_insn(insn, pc);
break;
default:
bt_assert(0);
}
break;
case 11:
/* CMPWI */
if ((insn & 0xFC600000) != 0x2C000000) bt_assert(0);
handle_cmpwi_insn(insn, pc);
break;
case 10:
/* CMPLWI */
if ((insn & 0xFC600000) != 0x28000000) bt_assert(0);
handle_cmplwi_insn(insn, pc);
break;
case 16:
switch (((insn >> 21) & 0x1F)) {
case 5:
/* BNE- */
if ((insn & 0xFFE00003) != 0x40A00000) bt_assert(0);
handle_bne__insn(insn, pc);
break;
case 4:
/* BNE */
if ((insn & 0xFFE00003) != 0x40800000) bt_assert(0);
handle_bne_insn(insn, pc);
break;
case 13:
/* BEQ+ */
if ((insn & 0xFFE00003) != 0x41A00000) bt_assert(0);
handle_beqp_insn(insn, pc);
break;
case 12:
/* BEQ */
if ((insn & 0xFFE00003) != 0x41800000) bt_assert(0);
handle_beq_insn(insn, pc);
break;
case 18:
/* BDZ */
if ((insn & 0xFFE00003) != 0x42400000) bt_assert(0);
handle_bdz_insn(insn, pc);
break;
case 16:
/* BDNZ */
if ((insn & 0xFFE00003) != 0x42000000) bt_assert(0);
handle_bdnz_insn(insn, pc);
break;
default:
bt_assert(0);
}
break;
case 18:
switch (((insn >> 0) & 0x3)) {
case 1:
/* BL */
if ((insn & 0xFC000003) != 0x48000001) bt_assert(0);
handle_bl_insn(insn, pc);
break;
case 0:
/* B */
if ((insn & 0xFC000003) != 0x48000000) bt_assert(0);
handle_b_insn(insn, pc);
break;
default:
bt_assert(0);
}
break;
case 29:
/* ANDIS. */
if ((insn & 0xFC000000) != 0x74000000) bt_assert(0);
handle_andisd_insn(insn, pc);
break;
case 28:
/* ANDI. */
if ((insn & 0xFC000000) != 0x70000000) bt_assert(0);
handle_andid_insn(insn, pc);
break;
case 15:
/* ADDIS */
if ((insn & 0xFC000000) != 0x3C000000) bt_assert(0);
handle_addis_insn(insn, pc);
break;
case 13:
/* ADDIC. */
if ((insn & 0xFC000000) != 0x34000000) bt_assert(0);
handle_addicd_insn(insn, pc);
break;
case 12:
/* ADDIC */
if ((insn & 0xFC000000) != 0x30000000) bt_assert(0);
handle_addic_insn(insn, pc);
break;
case 14:
/* ADDI */
if ((insn & 0xFC000000) != 0x38000000) bt_assert(0);
handle_addi_insn(insn, pc);
break;
default:
bt_assert(0);
}

}
