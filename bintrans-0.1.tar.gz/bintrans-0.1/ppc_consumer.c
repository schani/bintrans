void consume_ppc_insn (word_32 insn, word_32 pc, word_32 *_consumed_CR, word_32 *_consumed_XER, word_32 *_consumed_GPR) {
word_32 consumed_CR;
word_32 consumed_XER;

word_32 consumed_GPR;
switch (((insn >> 26) & 0x3F)) {
case 27:
/* XORIS */
if ((insn & 0xFC000000) != 0x6C000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 26:
/* XORI */
if ((insn & 0xFC000000) != 0x68000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 31:
switch (((insn >> 0) & 0x7FF)) {
case 633:
/* XOR. */
if ((insn & 0xFC0007FF) != 0x7C000279) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 632:
/* XOR */
if ((insn & 0xFC0007FF) != 0x7C000278) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 1196:
/* SYNC */
if ((insn & 0xFFFFFFFF) != 0x7C0004AC) goto unrecognized;
{
word_32 consumed = 0;
/* nop */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
/* nop */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
/* nop */
consumed_GPR = consumed;
}
break;
case 1425:
/* SUBFZEO. */
if ((insn & 0xFC00FFFF) != 0x7C000591) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
bt_assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1424:
/* SUBFZEO */
if ((insn & 0xFC00FFFF) != 0x7C000590) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
bt_assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
bt_assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 401:
/* SUBFZE. */
if ((insn & 0xFC00FFFF) != 0x7C000191) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 400:
/* SUBFZE */
if ((insn & 0xFC00FFFF) != 0x7C000190) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed_GPR = consumed;
}
break;
case 1489:
/* SUBFMEO. */
if ((insn & 0xFC00FFFF) != 0x7C0005D1) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| 0);
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1488:
/* SUBFMEO */
if ((insn & 0xFC00FFFF) != 0x7C0005D0) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
bt_assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| 0);
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 465:
/* SUBFME. */
if ((insn & 0xFC00FFFF) != 0x7C0001D1) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| 0);
consumed |= 0 | 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 464:
/* SUBFME */
if ((insn & 0xFC00FFFF) != 0x7C0001D0) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1297:
/* SUBFEO. */
if ((insn & 0xFC0007FF) != 0x7C000511) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | (0 | 0x20000000)| 0)));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1296:
/* SUBFEO */
if ((insn & 0xFC0007FF) != 0x7C000510) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | (0 | 0x20000000)| 0)));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
bt_assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 273:
/* SUBFE. */
if ((insn & 0xFC0007FF) != 0x7C000111) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | (0 | 0x20000000)| 0)));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 272:
/* SUBFE */
if ((insn & 0xFC0007FF) != 0x7C000110) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | (0 | 0x20000000)| 0)));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1041:
/* SUBFCO. */
if ((insn & 0xFC0007FF) != 0x7C000411) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| 0));
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
bt_assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1040:
/* SUBFCO */
if ((insn & 0xFC0007FF) != 0x7C000410) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| 0));
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
bt_assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 17:
/* SUBFC. */
if ((insn & 0xFC0007FF) != 0x7C000011) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| 0));
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 16:
/* SUBFC */
if ((insn & 0xFC0007FF) != 0x7C000010) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| 0));
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 1105:
/* SUBFO. */
if ((insn & 0xFC0007FF) != 0x7C000451) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
bt_assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1104:
/* SUBFO */
if ((insn & 0xFC0007FF) != 0x7C000450) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
bt_assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 81:
/* SUBF. */
if ((insn & 0xFC0007FF) != 0x7C000051) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 80:
/* SUBF */
if ((insn & 0xFC0007FF) != 0x7C000050) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 302:
/* STWX */
if ((insn & 0xFC0007FF) != 0x7C00012E) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 366:
/* STWUX */
if ((insn & 0xFC0007FF) != 0x7C00016E) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 1324:
/* STWBRX */
if ((insn & 0xFC0007FF) != 0x7C00052C) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 814:
/* STHX */
if ((insn & 0xFC0007FF) != 0x7C00032E) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 1836:
/* STHBRX */
if ((insn & 0xFC0007FF) != 0x7C00072C) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 1326:
/* STFSX */
if ((insn & 0xFC0007FF) != 0x7C00052E) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | 0;
consumed_GPR = consumed;
}
break;
case 1454:
/* STFDX */
if ((insn & 0xFC0007FF) != 0x7C0005AE) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | 0;
consumed_GPR = consumed;
}
break;
case 430:
/* STBX */
if ((insn & 0xFC0007FF) != 0x7C0001AE) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 1073:
/* SRW. */
if ((insn & 0xFC0007FF) != 0x7C000431) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1072:
/* SRW */
if ((insn & 0xFC0007FF) != 0x7C000430) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0));
consumed_GPR = consumed;
}
break;
case 1649:
/* SRAWI. */
if ((insn & 0xFC0007FF) != 0x7C000671) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | ((0 | (0 | 0| (1 << ((insn >> 21) & 0x1F)))| 0) | 0 | 0) | 0);
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1648:
/* SRAWI */
if ((insn & 0xFC0007FF) != 0x7C000670) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | ((0 | (0 | 0| (1 << ((insn >> 21) & 0x1F)))| 0) | 0 | 0) | 0);
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 1585:
/* SRAW. */
if ((insn & 0xFC0007FF) != 0x7C000631) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | ((0 | (0 | (0 | (0 | 0| (0 | (1 << ((insn >> 11) & 0x1F))| 0))| 0)| (1 << ((insn >> 21) & 0x1F)))| 0) | 0 | 0) | 0);
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1584:
/* SRAW */
if ((insn & 0xFC0007FF) != 0x7C000630) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | ((0 | (0 | (0 | (0 | 0| (0 | (1 << ((insn >> 11) & 0x1F))| 0))| 0)| (1 << ((insn >> 21) & 0x1F)))| 0) | 0 | 0) | 0);
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0));
consumed_GPR = consumed;
}
break;
case 49:
/* SLW. */
if ((insn & 0xFC0007FF) != 0x7C000031) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 11) & 0x1F))| 0) | 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F)))));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 48:
/* SLW */
if ((insn & 0xFC0007FF) != 0x7C000030) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 11) & 0x1F))| 0) | 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F)))));
consumed_GPR = consumed;
}
break;
case 825:
/* ORC. */
if ((insn & 0xFC0007FF) != 0x7C000339) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 824:
/* ORC */
if ((insn & 0xFC0007FF) != 0x7C000338) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
break;
case 889:
/* OR. */
if ((insn & 0xFC0007FF) != 0x7C000379) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 888:
/* OR */
if ((insn & 0xFC0007FF) != 0x7C000378) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 249:
/* NOR. */
if ((insn & 0xFC0007FF) != 0x7C0000F9) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F))));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 248:
/* NOR */
if ((insn & 0xFC0007FF) != 0x7C0000F8) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
break;
case 1233:
/* NEGO. */
if ((insn & 0xFC00FFFF) != 0x7C0004D1) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F)));
bt_assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1232:
/* NEGO */
if ((insn & 0xFC00FFFF) != 0x7C0004D0) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F)));
bt_assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 209:
/* NEG. */
if ((insn & 0xFC00FFFF) != 0x7C0000D1) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 208:
/* NEG */
if ((insn & 0xFC00FFFF) != 0x7C0000D0) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 953:
/* NAND. */
if ((insn & 0xFC0007FF) != 0x7C0003B9) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F))));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 952:
/* NAND */
if ((insn & 0xFC0007FF) != 0x7C0003B8) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
break;
case 1495:
/* MULLWO. */
if ((insn & 0xFC0007FF) != 0x7C0005D7) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
bt_assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1494:
/* MULLWO */
if ((insn & 0xFC0007FF) != 0x7C0005D6) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
bt_assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 471:
/* MULLW. */
if ((insn & 0xFC0007FF) != 0x7C0001D7) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 470:
/* MULLW */
if ((insn & 0xFC0007FF) != 0x7C0001D6) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 22:
/* MULHWU */
if ((insn & 0xFC0007FF) != 0x7C000016) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (0 | (1 << ((insn >> 11) & 0x1F))))| 0));
consumed_GPR = consumed;
}
break;
case 150:
/* MULHW */
if ((insn & 0xFC0007FF) != 0x7C000096) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (0 | (1 << ((insn >> 11) & 0x1F))))| 0));
consumed_GPR = consumed;
}
break;
case 934:
switch (((insn >> 11) & 0x3FF)) {
case 32:
/* MTXER */
if ((insn & 0xFC1FFFFF) != 0x7C0103A6) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 256:
/* MTLR */
if ((insn & 0xFC1FFFFF) != 0x7C0803A6) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 288:
/* MTCTR */
if ((insn & 0xFC1FFFFF) != 0x7C0903A6) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 288:
/* MTCRF */
if ((insn & 0xFC100FFF) != 0x7C000120) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0xFFFFFFFF| 0)| 0);
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | (1 << ((insn >> 21) & 0x1F))| 0));
consumed_GPR = consumed;
}
break;
case 678:
switch (((insn >> 11) & 0x3FF)) {
case 32:
/* MFXER */
if ((insn & 0xFC1FFFFF) != 0x7C0102A6) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0xFFFFFFFF;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 256:
/* MFLR */
if ((insn & 0xFC1FFFFF) != 0x7C0802A6) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 288:
/* MFCTR */
if ((insn & 0xFC1FFFFF) != 0x7C0902A6) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 38:
/* MFCR */
if ((insn & 0xFC1FFFFF) != 0x7C000026) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0xFFFFFFFF;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1024:
/* MCRXR */
if ((insn & 0xFC7FFFFF) != 0x7C000400) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (15 << (4 * 7));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 46:
/* LWZX */
if ((insn & 0xFC0007FF) != 0x7C00002E) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)))));
consumed_GPR = consumed;
}
break;
case 110:
/* LWZUX */
if ((insn & 0xFC0007FF) != 0x7C00006E) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1068:
/* LWBRX */
if ((insn & 0xFC0007FF) != 0x7C00042C) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)))));
consumed_GPR = consumed;
}
break;
case 558:
/* LHZX */
if ((insn & 0xFC0007FF) != 0x7C00022E) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))))));
consumed_GPR = consumed;
}
break;
case 1580:
/* LHBRX */
if ((insn & 0xFC0007FF) != 0x7C00062C) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))))));
consumed_GPR = consumed;
}
break;
case 686:
/* LHAX */
if ((insn & 0xFC0007FF) != 0x7C0002AE) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))))));
consumed_GPR = consumed;
}
break;
case 1070:
/* LFSX */
if ((insn & 0xFC0007FF) != 0x7C00042E) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)))))));
consumed_GPR = consumed;
}
break;
case 1198:
/* LFDX */
if ((insn & 0xFC0007FF) != 0x7C0004AE) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))))));
consumed_GPR = consumed;
}
break;
case 174:
/* LBZX */
if ((insn & 0xFC0007FF) != 0x7C0000AE) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))))));
consumed_GPR = consumed;
}
break;
case 238:
/* LBZUX */
if ((insn & 0xFC0007FF) != 0x7C0000EE) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1964:
/* ICBI */
if ((insn & 0xFFE007FF) != 0x7C0007AC) goto unrecognized;
{
word_32 consumed = 0;
/* ignore */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
/* ignore */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
/* ignore */
consumed_GPR = consumed;
}
break;
case 1845:
/* EXTSH. */
if ((insn & 0xFC00FFFF) != 0x7C000735) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1844:
/* EXTSH */
if ((insn & 0xFC00FFFF) != 0x7C000734) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 1908:
/* EXTSB */
if ((insn & 0xFC00FFFF) != 0x7C000774) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 569:
/* EQV. */
if ((insn & 0xFC0007FF) != 0x7C000239) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 568:
/* EQV */
if ((insn & 0xFC0007FF) != 0x7C000238) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
break;
case 1943:
/* DIVWUO. */
if ((insn & 0xFC0007FF) != 0x7C000797) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
bt_assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1942:
/* DIVWUO */
if ((insn & 0xFC0007FF) != 0x7C000796) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
bt_assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 919:
/* DIVWU. */
if ((insn & 0xFC0007FF) != 0x7C000397) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 918:
/* DIVWU */
if ((insn & 0xFC0007FF) != 0x7C000396) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 2007:
/* DIVWO. */
if ((insn & 0xFC0007FF) != 0x7C0007D7) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
bt_assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 2006:
/* DIVWO */
if ((insn & 0xFC0007FF) != 0x7C0007D6) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
bt_assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 983:
/* DIVW. */
if ((insn & 0xFC0007FF) != 0x7C0003D7) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 982:
/* DIVW */
if ((insn & 0xFC0007FF) != 0x7C0003D6) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 2028:
/* DCBZ */
if ((insn & 0xFFE007FF) != 0x7C0007EC) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| 0);
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 108:
/* DCBST */
if ((insn & 0xFFE007FF) != 0x7C00006C) goto unrecognized;
{
word_32 consumed = 0;
/* ignore */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
/* ignore */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
/* ignore */
consumed_GPR = consumed;
}
break;
case 52:
/* CNTLZW */
if ((insn & 0xFC00FFFF) != 0x7C000034) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 0:
/* CMPW */
if ((insn & 0xFC6007FF) != 0x7C000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 64:
/* CMPLW */
if ((insn & 0xFC6007FF) != 0x7C000040) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 121:
/* ANDC. */
if ((insn & 0xFC0007FF) != 0x7C000079) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 120:
/* ANDC */
if ((insn & 0xFC0007FF) != 0x7C000078) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
break;
case 57:
/* AND. */
if ((insn & 0xFC0007FF) != 0x7C000039) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 56:
/* AND */
if ((insn & 0xFC0007FF) != 0x7C000038) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 1429:
/* ADDZEO. */
if ((insn & 0xFC00FFFF) != 0x7C000595) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1428:
/* ADDZEO */
if ((insn & 0xFC00FFFF) != 0x7C000594) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
bt_assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 405:
/* ADDZE. */
if ((insn & 0xFC00FFFF) != 0x7C000195) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 404:
/* ADDZE */
if ((insn & 0xFC00FFFF) != 0x7C000194) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1493:
/* ADDMEO. */
if ((insn & 0xFC00FFFF) != 0x7C0005D5) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0)| 0);
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1492:
/* ADDMEO */
if ((insn & 0xFC00FFFF) != 0x7C0005D4) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
bt_assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0)| 0);
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 469:
/* ADDME. */
if ((insn & 0xFC00FFFF) != 0x7C0001D5) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0)| 0);
consumed |= 0 | 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 468:
/* ADDME */
if ((insn & 0xFC00FFFF) != 0x7C0001D4) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F));
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0)| 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1301:
/* ADDEO. */
if ((insn & 0xFC0007FF) != 0x7C000515) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F));
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1300:
/* ADDEO */
if ((insn & 0xFC0007FF) != 0x7C000514) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
bt_assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F));
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 277:
/* ADDE. */
if ((insn & 0xFC0007FF) != 0x7C000115) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 276:
/* ADDE */
if ((insn & 0xFC0007FF) != 0x7C000114) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0| 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1045:
/* ADDCO. */
if ((insn & 0xFC0007FF) != 0x7C000415) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
bt_assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1044:
/* ADDCO */
if ((insn & 0xFC0007FF) != 0x7C000414) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
bt_assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 21:
/* ADDC. */
if ((insn & 0xFC0007FF) != 0x7C000015) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 20:
/* ADDC */
if ((insn & 0xFC0007FF) != 0x7C000014) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 1557:
/* ADDO. */
if ((insn & 0xFC0007FF) != 0x7C000615) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
bt_assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1556:
/* ADDO */
if ((insn & 0xFC0007FF) != 0x7C000614) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
bt_assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
bt_assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 533:
/* ADD. */
if ((insn & 0xFC0007FF) != 0x7C000215) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 532:
/* ADD */
if ((insn & 0xFC0007FF) != 0x7C000214) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 8:
/* SUBFIC */
if ((insn & 0xFC000000) != 0x20000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| 0));
consumed |= 0 | (0 | 0| (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 37:
/* STWU */
if ((insn & 0xFC000000) != 0x94000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | (1 << ((insn >> 16) & 0x1F))| 0) | (1 << ((insn >> 21) & 0x1F));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 36:
/* STW */
if ((insn & 0xFC000000) != 0x90000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| 0) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 45:
/* STHU */
if ((insn & 0xFC000000) != 0xB4000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | (1 << ((insn >> 16) & 0x1F))| 0) | (1 << ((insn >> 21) & 0x1F));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 44:
/* STH */
if ((insn & 0xFC000000) != 0xB0000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0)) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 52:
/* STFS */
if ((insn & 0xFC000000) != 0xD0000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| 0) | 0;
consumed_GPR = consumed;
}
break;
case 55:
/* STFDU */
if ((insn & 0xFC000000) != 0xDC000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 54:
/* STFD */
if ((insn & 0xFC000000) != 0xD8000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| 0) | 0;
consumed_GPR = consumed;
}
break;
case 39:
/* STBU */
if ((insn & 0xFC000000) != 0x9C000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | (1 << ((insn >> 16) & 0x1F))| 0) | (1 << ((insn >> 21) & 0x1F));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 38:
/* STB */
if ((insn & 0xFC000000) != 0x98000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0)) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 17:
/* SC */
if ((insn & 0xFFFFFFFF) != 0x44000002) goto unrecognized;
{
word_32 consumed = 0;
consumed = 0xFFFFFFFF;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed = 0xFFFFFFFF;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed = 0xFFFFFFFF;
consumed_GPR = consumed;
}
break;
case 23:
switch (((insn >> 0) & 0x1)) {
case 1:
/* RLWNM. */
if ((insn & 0xFC000001) != 0x5C000001) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0))| 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 0:
/* RLWNM */
if ((insn & 0xFC000001) != 0x5C000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0))| 0);
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 21:
switch (((insn >> 0) & 0x1)) {
case 1:
/* RLWINM. */
if ((insn & 0xFC000001) != 0x54000001) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0)| 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 0:
/* RLWINM */
if ((insn & 0xFC000001) != 0x54000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0)| 0);
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 20:
/* RLWIMI */
if ((insn & 0xFC000001) != 0x50000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0)| 0)| (0 | (1 << ((insn >> 16) & 0x1F))| 0));
consumed_GPR = consumed;
}
break;
case 25:
/* ORIS */
if ((insn & 0xFC000000) != 0x64000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 24:
/* ORI */
if ((insn & 0xFC000000) != 0x60000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 7:
/* MULLI */
if ((insn & 0xFC000000) != 0x1C000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 63:
switch (((insn >> 0) & 0x3F)) {
case 12:
switch (((insn >> 6) & 0x3F)) {
case 4:
/* MTFSFI */
if ((insn & 0xFC7F0FFF) != 0xFC00010C) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 2:
/* MTFSB0 */
if ((insn & 0xFC1FFFFF) != 0xFC00008C) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 14:
switch (((insn >> 6) & 0x1F)) {
case 22:
/* MTFSF */
if ((insn & 0xFFFF07FF) != 0xFDFE058E) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 18:
/* MFFS */
if ((insn & 0xFC1FFFFF) != 0xFC00048E) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 40:
/* FSUB */
if ((insn & 0xFC0007FF) != 0xFC000028) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 24:
/* FRSP */
if ((insn & 0xFC1F07FF) != 0xFC000018) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 60:
/* FNMSUB */
if ((insn & 0xFC00003F) != 0xFC00003C) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 16:
switch (((insn >> 6) & 0x1F)) {
case 1:
/* FNEG */
if ((insn & 0xFC1F07FF) != 0xFC000050) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 2:
/* FMR */
if ((insn & 0xFC1F07FF) != 0xFC000090) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 8:
/* FABS */
if ((insn & 0xFC1F07FF) != 0xFC000210) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 50:
/* FMUL */
if ((insn & 0xFC00F83F) != 0xFC000032) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 56:
/* FMSUB */
if ((insn & 0xFC00003F) != 0xFC000038) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 58:
/* FMADD */
if ((insn & 0xFC00003F) != 0xFC00003A) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 36:
/* FDIV */
if ((insn & 0xFC0007FF) != 0xFC000024) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 30:
/* FCTIWZ */
if ((insn & 0xFC1F07FF) != 0xFC00001E) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 0:
/* FCMPU */
if ((insn & 0xFC6007FF) != 0xFC000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 42:
/* FADD */
if ((insn & 0xFC0007FF) != 0xFC00002A) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 19:
switch (((insn >> 0) & 0x7FF)) {
case 0:
/* MCRF */
if ((insn & 0xFC63FFFF) != 0x4C000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | (15 << (4 * ((7 - ((insn >> 18) & 0x7)) & 0x7)));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 300:
/* ISYNC */
if ((insn & 0xFFFFFFFF) != 0x4C00012C) goto unrecognized;
{
word_32 consumed = 0;
/* nop */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
/* nop */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
/* nop */
consumed_GPR = consumed;
}
break;
case 386:
/* CRXOR */
if ((insn & 0xFC0007FF) != 0x4C000182) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 834:
/* CRORC */
if ((insn & 0xFC0007FF) != 0x4C000342) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (0 | (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F)))| 0));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 898:
/* CROR */
if ((insn & 0xFC0007FF) != 0x4C000382) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 66:
/* CRNOR */
if ((insn & 0xFC0007FF) != 0x4C000042) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))))| 0);
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 450:
/* CRNAND */
if ((insn & 0xFC0007FF) != 0x4C0001C2) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))))| 0);
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 578:
/* CREQV */
if ((insn & 0xFC0007FF) != 0x4C000242) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))))| 0);
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 258:
/* CRANDC */
if ((insn & 0xFC0007FF) != 0x4C000102) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (0 | (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F)))| 0));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 514:
/* CRAND */
if ((insn & 0xFC0007FF) != 0x4C000202) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 32:
switch (((insn >> 11) & 0x1F)) {
case 0:
switch (((insn >> 21) & 0x1F)) {
case 5:
/* BNELR+ */
if ((insn & 0xFFE0FFFF) != 0x4CA00020) goto unrecognized;
{
word_32 consumed = 0;
consumed |= (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
/* nop */
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_GPR = consumed;
}
break;
case 4:
/* BNELR */
if ((insn & 0xFFE0FFFF) != 0x4C800020) goto unrecognized;
{
word_32 consumed = 0;
consumed |= (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
/* nop */
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_GPR = consumed;
}
break;
case 20:
/* BLR */
if ((insn & 0xFFE0FFFF) != 0x4E800020) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_GPR = consumed;
}
break;
case 12:
/* BEQLR */
if ((insn & 0xFFE0FFFF) != 0x4D800020) goto unrecognized;
{
word_32 consumed = 0;
consumed |= (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
consumed |= 0;
/* nop */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
default:
goto unrecognized;
}
break;
case 33:
/* BLRL */
if ((insn & 0xFFE0FFFF) != 0x4E800021) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0;
consumed_GPR = consumed;
}
break;
case 1056:
/* BCTR */
if ((insn & 0xFFE0FFFF) != 0x4E800420) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 33:
/* LWZU */
if ((insn & 0xFC000000) != 0x84000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 32:
/* LWZ */
if ((insn & 0xFC000000) != 0x80000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0)));
consumed_GPR = consumed;
}
break;
case 41:
/* LHZU */
if ((insn & 0xFC000000) != 0xA4000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 40:
/* LHZ */
if ((insn & 0xFC000000) != 0xA0000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0))));
consumed_GPR = consumed;
}
break;
case 43:
/* LHAU */
if ((insn & 0xFC000000) != 0xAC000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 42:
/* LHA */
if ((insn & 0xFC000000) != 0xA8000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0))));
consumed_GPR = consumed;
}
break;
case 48:
/* LFS */
if ((insn & 0xFC000000) != 0xC0000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0)))));
consumed_GPR = consumed;
}
break;
case 50:
/* LFD */
if ((insn & 0xFC000000) != 0xC8000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0))));
consumed_GPR = consumed;
}
break;
case 35:
/* LBZU */
if ((insn & 0xFC000000) != 0x8C000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 34:
/* LBZ */
if ((insn & 0xFC000000) != 0x88000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0))));
consumed_GPR = consumed;
}
break;
case 59:
switch (((insn >> 0) & 0x3F)) {
case 40:
/* FSUBS */
if ((insn & 0xFC0007FF) != 0xEC000028) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 50:
/* FMULS */
if ((insn & 0xFC00F83F) != 0xEC000032) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 56:
/* FMSUBS */
if ((insn & 0xFC00003F) != 0xEC000038) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 58:
/* FMADDS */
if ((insn & 0xFC00003F) != 0xEC00003A) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 36:
/* FDIVS */
if ((insn & 0xFC0007FF) != 0xEC000024) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 42:
/* FADDS */
if ((insn & 0xFC0007FF) != 0xEC00002A) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 11:
/* CMPWI */
if ((insn & 0xFC600000) != 0x2C000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 10:
/* CMPLWI */
if ((insn & 0xFC600000) != 0x28000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 16:
switch (((insn >> 21) & 0x1F)) {
case 5:
/* BNE- */
if ((insn & 0xFFE00003) != 0x40A00000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
/* nop */
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_GPR = consumed;
}
break;
case 4:
/* BNE */
if ((insn & 0xFFE00003) != 0x40800000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
/* nop */
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_GPR = consumed;
}
break;
case 13:
/* BEQ+ */
if ((insn & 0xFFE00003) != 0x41A00000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
consumed |= 0;
/* nop */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_GPR = consumed;
}
break;
case 12:
/* BEQ */
if ((insn & 0xFFE00003) != 0x41800000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
consumed |= 0;
/* nop */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_GPR = consumed;
}
break;
case 18:
/* BDZ */
if ((insn & 0xFFE00003) != 0x42400000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_GPR = consumed;
}
break;
case 16:
/* BDNZ */
if ((insn & 0xFFE00003) != 0x42000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 18:
switch (((insn >> 0) & 0x3)) {
case 1:
/* BL */
if ((insn & 0xFC000003) != 0x48000001) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
consumed_GPR = consumed;
}
break;
case 0:
/* B */
if ((insn & 0xFC000003) != 0x48000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 29:
/* ANDIS. */
if ((insn & 0xFC000000) != 0x74000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 28:
/* ANDI. */
if ((insn & 0xFC000000) != 0x70000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 15:
/* ADDIS */
if ((insn & 0xFC000000) != 0x3C000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0));
consumed_GPR = consumed;
}
break;
case 13:
/* ADDIC. */
if ((insn & 0xFC000000) != 0x34000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 12:
/* ADDIC */
if ((insn & 0xFC000000) != 0x30000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 14:
/* ADDI */
if ((insn & 0xFC000000) != 0x38000000) goto unrecognized;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0));
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
*_consumed_CR = consumed_CR;
*_consumed_XER = consumed_XER;
*_consumed_GPR = consumed_GPR;
return;
unrecognized:
*_consumed_CR = 0xffffffff;
*_consumed_XER = 0xffffffff;
*_consumed_GPR = 0xffffffff;
}
