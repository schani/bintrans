void disassemble_ppc_insn (word_32 insn, word_32 addr) {
switch (((insn >> 26) & 0x3F)) {
case 27:
/* XORIS */
if ((insn & 0xFC000000) != 0x6C000000) printf("unrecognized: %08x\n", insn);
printf("xoris r%u,r%u,%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 0) & 0xFFFF));
break;
case 26:
/* XORI */
if ((insn & 0xFC000000) != 0x68000000) printf("unrecognized: %08x\n", insn);
printf("xori r%u,r%u,%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 0) & 0xFFFF));
break;
case 31:
switch (((insn >> 0) & 0x7FF)) {
case 633:
/* XOR. */
if ((insn & 0xFC0007FF) != 0x7C000279) printf("unrecognized: %08x\n", insn);
printf("xor. r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 632:
/* XOR */
if ((insn & 0xFC0007FF) != 0x7C000278) printf("unrecognized: %08x\n", insn);
printf("xor r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1196:
/* SYNC */
if ((insn & 0xFFFFFFFF) != 0x7C0004AC) printf("unrecognized: %08x\n", insn);
printf("sync");
break;
case 1425:
/* SUBFZEO. */
if ((insn & 0xFC00FFFF) != 0x7C000591) printf("unrecognized: %08x\n", insn);
printf("subfzeo. r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 1424:
/* SUBFZEO */
if ((insn & 0xFC00FFFF) != 0x7C000590) printf("unrecognized: %08x\n", insn);
printf("subfzeo r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 401:
/* SUBFZE. */
if ((insn & 0xFC00FFFF) != 0x7C000191) printf("unrecognized: %08x\n", insn);
printf("subfze. r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 400:
/* SUBFZE */
if ((insn & 0xFC00FFFF) != 0x7C000190) printf("unrecognized: %08x\n", insn);
printf("subfze r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 1489:
/* SUBFMEO. */
if ((insn & 0xFC00FFFF) != 0x7C0005D1) printf("unrecognized: %08x\n", insn);
printf("subfmeo. r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 1488:
/* SUBFMEO */
if ((insn & 0xFC00FFFF) != 0x7C0005D0) printf("unrecognized: %08x\n", insn);
printf("subfmeo r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 465:
/* SUBFME. */
if ((insn & 0xFC00FFFF) != 0x7C0001D1) printf("unrecognized: %08x\n", insn);
printf("subfme. r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 464:
/* SUBFME */
if ((insn & 0xFC00FFFF) != 0x7C0001D0) printf("unrecognized: %08x\n", insn);
printf("subfme r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 1297:
/* SUBFEO. */
if ((insn & 0xFC0007FF) != 0x7C000511) printf("unrecognized: %08x\n", insn);
printf("subfeo. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1296:
/* SUBFEO */
if ((insn & 0xFC0007FF) != 0x7C000510) printf("unrecognized: %08x\n", insn);
printf("subfeo r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 273:
/* SUBFE. */
if ((insn & 0xFC0007FF) != 0x7C000111) printf("unrecognized: %08x\n", insn);
printf("subfe. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 272:
/* SUBFE */
if ((insn & 0xFC0007FF) != 0x7C000110) printf("unrecognized: %08x\n", insn);
printf("subfe r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1041:
/* SUBFCO. */
if ((insn & 0xFC0007FF) != 0x7C000411) printf("unrecognized: %08x\n", insn);
printf("subfco. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1040:
/* SUBFCO */
if ((insn & 0xFC0007FF) != 0x7C000410) printf("unrecognized: %08x\n", insn);
printf("subfco r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 17:
/* SUBFC. */
if ((insn & 0xFC0007FF) != 0x7C000011) printf("unrecognized: %08x\n", insn);
printf("subfc. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 16:
/* SUBFC */
if ((insn & 0xFC0007FF) != 0x7C000010) printf("unrecognized: %08x\n", insn);
printf("subfc r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1105:
/* SUBFO. */
if ((insn & 0xFC0007FF) != 0x7C000451) printf("unrecognized: %08x\n", insn);
printf("subfo. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1104:
/* SUBFO */
if ((insn & 0xFC0007FF) != 0x7C000450) printf("unrecognized: %08x\n", insn);
printf("subfo r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 81:
/* SUBF. */
if ((insn & 0xFC0007FF) != 0x7C000051) printf("unrecognized: %08x\n", insn);
printf("subf. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 80:
/* SUBF */
if ((insn & 0xFC0007FF) != 0x7C000050) printf("unrecognized: %08x\n", insn);
printf("subf r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 302:
/* STWX */
if ((insn & 0xFC0007FF) != 0x7C00012E) printf("unrecognized: %08x\n", insn);
printf("stwx r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 366:
/* STWUX */
if ((insn & 0xFC0007FF) != 0x7C00016E) printf("unrecognized: %08x\n", insn);
printf("stwux r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1324:
/* STWBRX */
if ((insn & 0xFC0007FF) != 0x7C00052C) printf("unrecognized: %08x\n", insn);
printf("stwbrx r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 814:
/* STHX */
if ((insn & 0xFC0007FF) != 0x7C00032E) printf("unrecognized: %08x\n", insn);
printf("sthx r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1836:
/* STHBRX */
if ((insn & 0xFC0007FF) != 0x7C00072C) printf("unrecognized: %08x\n", insn);
printf("sthbrx r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1326:
/* STFSX */
if ((insn & 0xFC0007FF) != 0x7C00052E) printf("unrecognized: %08x\n", insn);
printf("stfsx fr%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1454:
/* STFDX */
if ((insn & 0xFC0007FF) != 0x7C0005AE) printf("unrecognized: %08x\n", insn);
printf("stfdx fr%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 430:
/* STBX */
if ((insn & 0xFC0007FF) != 0x7C0001AE) printf("unrecognized: %08x\n", insn);
printf("stbx r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1073:
/* SRW. */
if ((insn & 0xFC0007FF) != 0x7C000431) printf("unrecognized: %08x\n", insn);
printf("srw. r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1072:
/* SRW */
if ((insn & 0xFC0007FF) != 0x7C000430) printf("unrecognized: %08x\n", insn);
printf("srw r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1649:
/* SRAWI. */
if ((insn & 0xFC0007FF) != 0x7C000671) printf("unrecognized: %08x\n", insn);
printf("srawi. r%u,r%u,%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1648:
/* SRAWI */
if ((insn & 0xFC0007FF) != 0x7C000670) printf("unrecognized: %08x\n", insn);
printf("srawi r%u,r%u,%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1585:
/* SRAW. */
if ((insn & 0xFC0007FF) != 0x7C000631) printf("unrecognized: %08x\n", insn);
printf("sraw. r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1584:
/* SRAW */
if ((insn & 0xFC0007FF) != 0x7C000630) printf("unrecognized: %08x\n", insn);
printf("sraw r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 49:
/* SLW. */
if ((insn & 0xFC0007FF) != 0x7C000031) printf("unrecognized: %08x\n", insn);
printf("slw. r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 48:
/* SLW */
if ((insn & 0xFC0007FF) != 0x7C000030) printf("unrecognized: %08x\n", insn);
printf("slw r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 825:
/* ORC. */
if ((insn & 0xFC0007FF) != 0x7C000339) printf("unrecognized: %08x\n", insn);
printf("orc. r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 824:
/* ORC */
if ((insn & 0xFC0007FF) != 0x7C000338) printf("unrecognized: %08x\n", insn);
printf("orc r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 889:
/* OR. */
if ((insn & 0xFC0007FF) != 0x7C000379) printf("unrecognized: %08x\n", insn);
printf("or. r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 888:
/* OR */
if ((insn & 0xFC0007FF) != 0x7C000378) printf("unrecognized: %08x\n", insn);
printf("or r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 249:
/* NOR. */
if ((insn & 0xFC0007FF) != 0x7C0000F9) printf("unrecognized: %08x\n", insn);
printf("nor. r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 248:
/* NOR */
if ((insn & 0xFC0007FF) != 0x7C0000F8) printf("unrecognized: %08x\n", insn);
printf("nor r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1233:
/* NEGO. */
if ((insn & 0xFC00FFFF) != 0x7C0004D1) printf("unrecognized: %08x\n", insn);
printf("nego. r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 1232:
/* NEGO */
if ((insn & 0xFC00FFFF) != 0x7C0004D0) printf("unrecognized: %08x\n", insn);
printf("nego r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 209:
/* NEG. */
if ((insn & 0xFC00FFFF) != 0x7C0000D1) printf("unrecognized: %08x\n", insn);
printf("neg. r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 208:
/* NEG */
if ((insn & 0xFC00FFFF) != 0x7C0000D0) printf("unrecognized: %08x\n", insn);
printf("neg r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 953:
/* NAND. */
if ((insn & 0xFC0007FF) != 0x7C0003B9) printf("unrecognized: %08x\n", insn);
printf("nand. r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 952:
/* NAND */
if ((insn & 0xFC0007FF) != 0x7C0003B8) printf("unrecognized: %08x\n", insn);
printf("nand r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1495:
/* MULLWO. */
if ((insn & 0xFC0007FF) != 0x7C0005D7) printf("unrecognized: %08x\n", insn);
printf("mullwo. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1494:
/* MULLWO */
if ((insn & 0xFC0007FF) != 0x7C0005D6) printf("unrecognized: %08x\n", insn);
printf("mullwo r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 471:
/* MULLW. */
if ((insn & 0xFC0007FF) != 0x7C0001D7) printf("unrecognized: %08x\n", insn);
printf("mullw. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 470:
/* MULLW */
if ((insn & 0xFC0007FF) != 0x7C0001D6) printf("unrecognized: %08x\n", insn);
printf("mullw r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 22:
/* MULHWU */
if ((insn & 0xFC0007FF) != 0x7C000016) printf("unrecognized: %08x\n", insn);
printf("mulhwu r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 150:
/* MULHW */
if ((insn & 0xFC0007FF) != 0x7C000096) printf("unrecognized: %08x\n", insn);
printf("mulhw r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 934:
switch (((insn >> 11) & 0x3FF)) {
case 32:
/* MTXER */
if ((insn & 0xFC1FFFFF) != 0x7C0103A6) printf("unrecognized: %08x\n", insn);
printf("mtxer r%u", (unsigned)((insn >> 21) & 0x1F));
break;
case 256:
/* MTLR */
if ((insn & 0xFC1FFFFF) != 0x7C0803A6) printf("unrecognized: %08x\n", insn);
printf("mtlr r%u", (unsigned)((insn >> 21) & 0x1F));
break;
case 288:
/* MTCTR */
if ((insn & 0xFC1FFFFF) != 0x7C0903A6) printf("unrecognized: %08x\n", insn);
printf("mtctr r%u", (unsigned)((insn >> 21) & 0x1F));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 288:
/* MTCRF */
if ((insn & 0xFC100FFF) != 0x7C000120) printf("unrecognized: %08x\n", insn);
printf("mtcrf %u,r%u", (unsigned)((insn >> 12) & 0xFF), (unsigned)((insn >> 21) & 0x1F));
break;
case 678:
switch (((insn >> 11) & 0x3FF)) {
case 32:
/* MFXER */
if ((insn & 0xFC1FFFFF) != 0x7C0102A6) printf("unrecognized: %08x\n", insn);
printf("mfxer r%u", (unsigned)((insn >> 21) & 0x1F));
break;
case 256:
/* MFLR */
if ((insn & 0xFC1FFFFF) != 0x7C0802A6) printf("unrecognized: %08x\n", insn);
printf("mflr r%u", (unsigned)((insn >> 21) & 0x1F));
break;
case 288:
/* MFCTR */
if ((insn & 0xFC1FFFFF) != 0x7C0902A6) printf("unrecognized: %08x\n", insn);
printf("mfctr r%u", (unsigned)((insn >> 21) & 0x1F));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 38:
/* MFCR */
if ((insn & 0xFC1FFFFF) != 0x7C000026) printf("unrecognized: %08x\n", insn);
printf("mfcr r%u", (unsigned)((insn >> 21) & 0x1F));
break;
case 1024:
/* MCRXR */
if ((insn & 0xFC7FFFFF) != 0x7C000400) printf("unrecognized: %08x\n", insn);
printf("mcrxr cr%u", (unsigned)((insn >> 23) & 0x7));
break;
case 46:
/* LWZX */
if ((insn & 0xFC0007FF) != 0x7C00002E) printf("unrecognized: %08x\n", insn);
printf("lwzx r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 110:
/* LWZUX */
if ((insn & 0xFC0007FF) != 0x7C00006E) printf("unrecognized: %08x\n", insn);
printf("lwzux r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1068:
/* LWBRX */
if ((insn & 0xFC0007FF) != 0x7C00042C) printf("unrecognized: %08x\n", insn);
printf("lwbrx r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 558:
/* LHZX */
if ((insn & 0xFC0007FF) != 0x7C00022E) printf("unrecognized: %08x\n", insn);
printf("lhzx r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1580:
/* LHBRX */
if ((insn & 0xFC0007FF) != 0x7C00062C) printf("unrecognized: %08x\n", insn);
printf("lhbrx r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 686:
/* LHAX */
if ((insn & 0xFC0007FF) != 0x7C0002AE) printf("unrecognized: %08x\n", insn);
printf("lhax r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1070:
/* LFSX */
if ((insn & 0xFC0007FF) != 0x7C00042E) printf("unrecognized: %08x\n", insn);
printf("lfsx fr%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1198:
/* LFDX */
if ((insn & 0xFC0007FF) != 0x7C0004AE) printf("unrecognized: %08x\n", insn);
printf("lfdx fr%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 174:
/* LBZX */
if ((insn & 0xFC0007FF) != 0x7C0000AE) printf("unrecognized: %08x\n", insn);
printf("lbzx r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 238:
/* LBZUX */
if ((insn & 0xFC0007FF) != 0x7C0000EE) printf("unrecognized: %08x\n", insn);
printf("lbzux r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1964:
/* ICBI */
if ((insn & 0xFFE007FF) != 0x7C0007AC) printf("unrecognized: %08x\n", insn);
printf("icbi r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1845:
/* EXTSH. */
if ((insn & 0xFC00FFFF) != 0x7C000735) printf("unrecognized: %08x\n", insn);
printf("extsh. r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F));
break;
case 1844:
/* EXTSH */
if ((insn & 0xFC00FFFF) != 0x7C000734) printf("unrecognized: %08x\n", insn);
printf("extsh r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F));
break;
case 1908:
/* EXTSB */
if ((insn & 0xFC00FFFF) != 0x7C000774) printf("unrecognized: %08x\n", insn);
printf("extsb r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F));
break;
case 569:
/* EQV. */
if ((insn & 0xFC0007FF) != 0x7C000239) printf("unrecognized: %08x\n", insn);
printf("eqv. r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 568:
/* EQV */
if ((insn & 0xFC0007FF) != 0x7C000238) printf("unrecognized: %08x\n", insn);
printf("eqv r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1943:
/* DIVWUO. */
if ((insn & 0xFC0007FF) != 0x7C000797) printf("unrecognized: %08x\n", insn);
printf("divwuo. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1942:
/* DIVWUO */
if ((insn & 0xFC0007FF) != 0x7C000796) printf("unrecognized: %08x\n", insn);
printf("divwuo r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 919:
/* DIVWU. */
if ((insn & 0xFC0007FF) != 0x7C000397) printf("unrecognized: %08x\n", insn);
printf("divwu. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 918:
/* DIVWU */
if ((insn & 0xFC0007FF) != 0x7C000396) printf("unrecognized: %08x\n", insn);
printf("divwu r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 2007:
/* DIVWO. */
if ((insn & 0xFC0007FF) != 0x7C0007D7) printf("unrecognized: %08x\n", insn);
printf("divwo. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 2006:
/* DIVWO */
if ((insn & 0xFC0007FF) != 0x7C0007D6) printf("unrecognized: %08x\n", insn);
printf("divwo r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 983:
/* DIVW. */
if ((insn & 0xFC0007FF) != 0x7C0003D7) printf("unrecognized: %08x\n", insn);
printf("divw. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 982:
/* DIVW */
if ((insn & 0xFC0007FF) != 0x7C0003D6) printf("unrecognized: %08x\n", insn);
printf("divw r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 2028:
/* DCBZ */
if ((insn & 0xFFE007FF) != 0x7C0007EC) printf("unrecognized: %08x\n", insn);
printf("dcbz r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 108:
/* DCBST */
if ((insn & 0xFFE007FF) != 0x7C00006C) printf("unrecognized: %08x\n", insn);
printf("dcbst r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 52:
/* CNTLZW */
if ((insn & 0xFC00FFFF) != 0x7C000034) printf("unrecognized: %08x\n", insn);
printf("cntlzw r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F));
break;
case 0:
/* CMPW */
if ((insn & 0xFC6007FF) != 0x7C000000) printf("unrecognized: %08x\n", insn);
printf("cmpw cr%u,r%u,r%u", (unsigned)((insn >> 23) & 0x7), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 64:
/* CMPLW */
if ((insn & 0xFC6007FF) != 0x7C000040) printf("unrecognized: %08x\n", insn);
printf("cmplw cr%u,r%u,r%u", (unsigned)((insn >> 23) & 0x7), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 121:
/* ANDC. */
if ((insn & 0xFC0007FF) != 0x7C000079) printf("unrecognized: %08x\n", insn);
printf("andc. r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 120:
/* ANDC */
if ((insn & 0xFC0007FF) != 0x7C000078) printf("unrecognized: %08x\n", insn);
printf("andc r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 57:
/* AND. */
if ((insn & 0xFC0007FF) != 0x7C000039) printf("unrecognized: %08x\n", insn);
printf("and. r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 56:
/* AND */
if ((insn & 0xFC0007FF) != 0x7C000038) printf("unrecognized: %08x\n", insn);
printf("and r%u,r%u,r%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1429:
/* ADDZEO. */
if ((insn & 0xFC00FFFF) != 0x7C000595) printf("unrecognized: %08x\n", insn);
printf("addzeo. r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 1428:
/* ADDZEO */
if ((insn & 0xFC00FFFF) != 0x7C000594) printf("unrecognized: %08x\n", insn);
printf("addzeo r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 405:
/* ADDZE. */
if ((insn & 0xFC00FFFF) != 0x7C000195) printf("unrecognized: %08x\n", insn);
printf("addze. r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 404:
/* ADDZE */
if ((insn & 0xFC00FFFF) != 0x7C000194) printf("unrecognized: %08x\n", insn);
printf("addze r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 1493:
/* ADDMEO. */
if ((insn & 0xFC00FFFF) != 0x7C0005D5) printf("unrecognized: %08x\n", insn);
printf("addmeo. r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 1492:
/* ADDMEO */
if ((insn & 0xFC00FFFF) != 0x7C0005D4) printf("unrecognized: %08x\n", insn);
printf("addmeo r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 469:
/* ADDME. */
if ((insn & 0xFC00FFFF) != 0x7C0001D5) printf("unrecognized: %08x\n", insn);
printf("addme. r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 468:
/* ADDME */
if ((insn & 0xFC00FFFF) != 0x7C0001D4) printf("unrecognized: %08x\n", insn);
printf("addme r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F));
break;
case 1301:
/* ADDEO. */
if ((insn & 0xFC0007FF) != 0x7C000515) printf("unrecognized: %08x\n", insn);
printf("addeo. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1300:
/* ADDEO */
if ((insn & 0xFC0007FF) != 0x7C000514) printf("unrecognized: %08x\n", insn);
printf("addeo r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 277:
/* ADDE. */
if ((insn & 0xFC0007FF) != 0x7C000115) printf("unrecognized: %08x\n", insn);
printf("adde. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 276:
/* ADDE */
if ((insn & 0xFC0007FF) != 0x7C000114) printf("unrecognized: %08x\n", insn);
printf("adde r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1045:
/* ADDCO. */
if ((insn & 0xFC0007FF) != 0x7C000415) printf("unrecognized: %08x\n", insn);
printf("addco. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1044:
/* ADDCO */
if ((insn & 0xFC0007FF) != 0x7C000414) printf("unrecognized: %08x\n", insn);
printf("addco r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 21:
/* ADDC. */
if ((insn & 0xFC0007FF) != 0x7C000015) printf("unrecognized: %08x\n", insn);
printf("addc. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 20:
/* ADDC */
if ((insn & 0xFC0007FF) != 0x7C000014) printf("unrecognized: %08x\n", insn);
printf("addc r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1557:
/* ADDO. */
if ((insn & 0xFC0007FF) != 0x7C000615) printf("unrecognized: %08x\n", insn);
printf("addo. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 1556:
/* ADDO */
if ((insn & 0xFC0007FF) != 0x7C000614) printf("unrecognized: %08x\n", insn);
printf("addo r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 533:
/* ADD. */
if ((insn & 0xFC0007FF) != 0x7C000215) printf("unrecognized: %08x\n", insn);
printf("add. r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 532:
/* ADD */
if ((insn & 0xFC0007FF) != 0x7C000214) printf("unrecognized: %08x\n", insn);
printf("add r%u,r%u,r%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 8:
/* SUBFIC */
if ((insn & 0xFC000000) != 0x20000000) printf("unrecognized: %08x\n", insn);
printf("subfic r%u,r%u,%d", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)));
break;
case 37:
/* STWU */
if ((insn & 0xFC000000) != 0x94000000) printf("unrecognized: %08x\n", insn);
printf("stwu r%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 36:
/* STW */
if ((insn & 0xFC000000) != 0x90000000) printf("unrecognized: %08x\n", insn);
printf("stw r%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 45:
/* STHU */
if ((insn & 0xFC000000) != 0xB4000000) printf("unrecognized: %08x\n", insn);
printf("sthu r%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 44:
/* STH */
if ((insn & 0xFC000000) != 0xB0000000) printf("unrecognized: %08x\n", insn);
printf("sth r%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 52:
/* STFS */
if ((insn & 0xFC000000) != 0xD0000000) printf("unrecognized: %08x\n", insn);
printf("stfs fr%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 55:
/* STFDU */
if ((insn & 0xFC000000) != 0xDC000000) printf("unrecognized: %08x\n", insn);
printf("stfdu fr%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 54:
/* STFD */
if ((insn & 0xFC000000) != 0xD8000000) printf("unrecognized: %08x\n", insn);
printf("stfd fr%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 39:
/* STBU */
if ((insn & 0xFC000000) != 0x9C000000) printf("unrecognized: %08x\n", insn);
printf("stbu r%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 38:
/* STB */
if ((insn & 0xFC000000) != 0x98000000) printf("unrecognized: %08x\n", insn);
printf("stb r%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 17:
/* SC */
if ((insn & 0xFFFFFFFF) != 0x44000002) printf("unrecognized: %08x\n", insn);
printf("sc");
break;
case 23:
switch (((insn >> 0) & 0x1)) {
case 1:
/* RLWNM. */
if ((insn & 0xFC000001) != 0x5C000001) printf("unrecognized: %08x\n", insn);
printf("rlwnm r%u,r%u,r%u,%u,%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F), (unsigned)((insn >> 6) & 0x1F), (unsigned)((insn >> 1) & 0x1F));
break;
case 0:
/* RLWNM */
if ((insn & 0xFC000001) != 0x5C000000) printf("unrecognized: %08x\n", insn);
printf("rlwnm r%u,r%u,r%u,%u,%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F), (unsigned)((insn >> 6) & 0x1F), (unsigned)((insn >> 1) & 0x1F));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 21:
switch (((insn >> 0) & 0x1)) {
case 1:
/* RLWINM. */
if ((insn & 0xFC000001) != 0x54000001) printf("unrecognized: %08x\n", insn);
printf("rlwinm. r%u,r%u,%u,%u,%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F), (unsigned)((insn >> 6) & 0x1F), (unsigned)((insn >> 1) & 0x1F));
break;
case 0:
/* RLWINM */
if ((insn & 0xFC000001) != 0x54000000) printf("unrecognized: %08x\n", insn);
printf("rlwinm r%u,r%u,%u,%u,%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F), (unsigned)((insn >> 6) & 0x1F), (unsigned)((insn >> 1) & 0x1F));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 20:
/* RLWIMI */
if ((insn & 0xFC000001) != 0x50000000) printf("unrecognized: %08x\n", insn);
printf("rlwimi r%u,r%u,%u,%u,%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F), (unsigned)((insn >> 6) & 0x1F), (unsigned)((insn >> 1) & 0x1F));
break;
case 25:
/* ORIS */
if ((insn & 0xFC000000) != 0x64000000) printf("unrecognized: %08x\n", insn);
printf("oris r%u,r%u,%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 0) & 0xFFFF));
break;
case 24:
/* ORI */
if ((insn & 0xFC000000) != 0x60000000) printf("unrecognized: %08x\n", insn);
printf("ori r%u,r%u,%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 0) & 0xFFFF));
break;
case 7:
/* MULLI */
if ((insn & 0xFC000000) != 0x1C000000) printf("unrecognized: %08x\n", insn);
printf("mulli r%u,r%u,%d", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)));
break;
case 63:
switch (((insn >> 0) & 0x3F)) {
case 12:
switch (((insn >> 6) & 0x3F)) {
case 4:
/* MTFSFI */
if ((insn & 0xFC7F0FFF) != 0xFC00010C) printf("unrecognized: %08x\n", insn);
printf("mtfsfi cr%u,%u", (unsigned)((insn >> 23) & 0x7), (unsigned)((insn >> 12) & 0xF));
break;
case 2:
/* MTFSB0 */
if ((insn & 0xFC1FFFFF) != 0xFC00008C) printf("unrecognized: %08x\n", insn);
printf("mtfsb0 crb%u", (unsigned)((insn >> 21) & 0x1F));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 14:
switch (((insn >> 6) & 0x1F)) {
case 22:
/* MTFSF */
if ((insn & 0xFFFF07FF) != 0xFDFE058E) printf("unrecognized: %08x\n", insn);
printf("mtfsf 0xff,fr%u", (unsigned)((insn >> 11) & 0x1F));
break;
case 18:
/* MFFS */
if ((insn & 0xFC1FFFFF) != 0xFC00048E) printf("unrecognized: %08x\n", insn);
printf("mffs fr%u", (unsigned)((insn >> 21) & 0x1F));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 40:
/* FSUB */
if ((insn & 0xFC0007FF) != 0xFC000028) printf("unrecognized: %08x\n", insn);
printf("fsub fr%u,fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 24:
/* FRSP */
if ((insn & 0xFC1F07FF) != 0xFC000018) printf("unrecognized: %08x\n", insn);
printf("frsp fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 60:
/* FNMSUB */
if ((insn & 0xFC00003F) != 0xFC00003C) printf("unrecognized: %08x\n", insn);
printf("fnmsub fr%u,fr%u,fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 6) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 16:
switch (((insn >> 6) & 0x1F)) {
case 1:
/* FNEG */
if ((insn & 0xFC1F07FF) != 0xFC000050) printf("unrecognized: %08x\n", insn);
printf("fneg fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 2:
/* FMR */
if ((insn & 0xFC1F07FF) != 0xFC000090) printf("unrecognized: %08x\n", insn);
printf("fmr fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 8:
/* FABS */
if ((insn & 0xFC1F07FF) != 0xFC000210) printf("unrecognized: %08x\n", insn);
printf("fabs fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 50:
/* FMUL */
if ((insn & 0xFC00F83F) != 0xFC000032) printf("unrecognized: %08x\n", insn);
printf("fmul fr%u,fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 6) & 0x1F));
break;
case 56:
/* FMSUB */
if ((insn & 0xFC00003F) != 0xFC000038) printf("unrecognized: %08x\n", insn);
printf("fmsub fr%u,fr%u,fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 6) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 58:
/* FMADD */
if ((insn & 0xFC00003F) != 0xFC00003A) printf("unrecognized: %08x\n", insn);
printf("fmadd fr%u,fr%u,fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 6) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 36:
/* FDIV */
if ((insn & 0xFC0007FF) != 0xFC000024) printf("unrecognized: %08x\n", insn);
printf("fdiv fr%u,fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 30:
/* FCTIWZ */
if ((insn & 0xFC1F07FF) != 0xFC00001E) printf("unrecognized: %08x\n", insn);
printf("fctiwz fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 0:
/* FCMPU */
if ((insn & 0xFC6007FF) != 0xFC000000) printf("unrecognized: %08x\n", insn);
printf("fcmpu cr%u,fr%u,fr%u", (unsigned)((insn >> 23) & 0x7), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 42:
/* FADD */
if ((insn & 0xFC0007FF) != 0xFC00002A) printf("unrecognized: %08x\n", insn);
printf("fadd fr%u,fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 19:
switch (((insn >> 0) & 0x7FF)) {
case 0:
/* MCRF */
if ((insn & 0xFC63FFFF) != 0x4C000000) printf("unrecognized: %08x\n", insn);
printf("mcrf cr%u,cr%u", (unsigned)((insn >> 23) & 0x7), (unsigned)((insn >> 18) & 0x7));
break;
case 300:
/* ISYNC */
if ((insn & 0xFFFFFFFF) != 0x4C00012C) printf("unrecognized: %08x\n", insn);
printf("isync");
break;
case 386:
/* CRXOR */
if ((insn & 0xFC0007FF) != 0x4C000182) printf("unrecognized: %08x\n", insn);
printf("crxor crb%u,crb%u,crb%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 834:
/* CRORC */
if ((insn & 0xFC0007FF) != 0x4C000342) printf("unrecognized: %08x\n", insn);
printf("crorc crb%u,crb%u,crb%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 898:
/* CROR */
if ((insn & 0xFC0007FF) != 0x4C000382) printf("unrecognized: %08x\n", insn);
printf("cror crb%u,crb%u,crb%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 66:
/* CRNOR */
if ((insn & 0xFC0007FF) != 0x4C000042) printf("unrecognized: %08x\n", insn);
printf("crnor crb%u,crb%u,crb%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 450:
/* CRNAND */
if ((insn & 0xFC0007FF) != 0x4C0001C2) printf("unrecognized: %08x\n", insn);
printf("crnand crb%u,crb%u,crb%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 578:
/* CREQV */
if ((insn & 0xFC0007FF) != 0x4C000242) printf("unrecognized: %08x\n", insn);
printf("creqv crb%u,crb%u,crb%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 258:
/* CRANDC */
if ((insn & 0xFC0007FF) != 0x4C000102) printf("unrecognized: %08x\n", insn);
printf("crandc crb%u,crb%u,crb%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 514:
/* CRAND */
if ((insn & 0xFC0007FF) != 0x4C000202) printf("unrecognized: %08x\n", insn);
printf("crand crb%u,crb%u,crb%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 32:
switch (((insn >> 11) & 0x1F)) {
case 0:
switch (((insn >> 21) & 0x1F)) {
case 5:
/* BNELR+ */
if ((insn & 0xFFE0FFFF) != 0x4CA00020) printf("unrecognized: %08x\n", insn);
printf("bnelr+ %u", (unsigned)((insn >> 16) & 0x1F));
break;
case 4:
/* BNELR */
if ((insn & 0xFFE0FFFF) != 0x4C800020) printf("unrecognized: %08x\n", insn);
printf("bnelr %u", (unsigned)((insn >> 16) & 0x1F));
break;
case 20:
/* BLR */
if ((insn & 0xFFE0FFFF) != 0x4E800020) printf("unrecognized: %08x\n", insn);
printf("blr");
break;
case 12:
/* BEQLR */
if ((insn & 0xFFE0FFFF) != 0x4D800020) printf("unrecognized: %08x\n", insn);
printf("bslr %u", (unsigned)((insn >> 16) & 0x1F));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 33:
/* BLRL */
if ((insn & 0xFFE0FFFF) != 0x4E800021) printf("unrecognized: %08x\n", insn);
printf("blrl");
break;
case 1056:
/* BCTR */
if ((insn & 0xFFE0FFFF) != 0x4E800420) printf("unrecognized: %08x\n", insn);
printf("bctr");
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 33:
/* LWZU */
if ((insn & 0xFC000000) != 0x84000000) printf("unrecognized: %08x\n", insn);
printf("lwzu r%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 32:
/* LWZ */
if ((insn & 0xFC000000) != 0x80000000) printf("unrecognized: %08x\n", insn);
printf("lwz r%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 41:
/* LHZU */
if ((insn & 0xFC000000) != 0xA4000000) printf("unrecognized: %08x\n", insn);
printf("lhzu r%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 40:
/* LHZ */
if ((insn & 0xFC000000) != 0xA0000000) printf("unrecognized: %08x\n", insn);
printf("lhz r%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 43:
/* LHAU */
if ((insn & 0xFC000000) != 0xAC000000) printf("unrecognized: %08x\n", insn);
printf("lhau r%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 42:
/* LHA */
if ((insn & 0xFC000000) != 0xA8000000) printf("unrecognized: %08x\n", insn);
printf("lha r%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 48:
/* LFS */
if ((insn & 0xFC000000) != 0xC0000000) printf("unrecognized: %08x\n", insn);
printf("lfs fr%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 50:
/* LFD */
if ((insn & 0xFC000000) != 0xC8000000) printf("unrecognized: %08x\n", insn);
printf("lfd fr%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 35:
/* LBZU */
if ((insn & 0xFC000000) != 0x8C000000) printf("unrecognized: %08x\n", insn);
printf("lbzu r%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 34:
/* LBZ */
if ((insn & 0xFC000000) != 0x88000000) printf("unrecognized: %08x\n", insn);
printf("lbz r%u,%d(r%u)", (unsigned)((insn >> 21) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)), (unsigned)((insn >> 16) & 0x1F));
break;
case 59:
switch (((insn >> 0) & 0x3F)) {
case 40:
/* FSUBS */
if ((insn & 0xFC0007FF) != 0xEC000028) printf("unrecognized: %08x\n", insn);
printf("fsubs fr%u,fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 50:
/* FMULS */
if ((insn & 0xFC00F83F) != 0xEC000032) printf("unrecognized: %08x\n", insn);
printf("fmuls fr%u,fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 6) & 0x1F));
break;
case 56:
/* FMSUBS */
if ((insn & 0xFC00003F) != 0xEC000038) printf("unrecognized: %08x\n", insn);
printf("fmsubs fr%u,fr%u,fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 6) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 58:
/* FMADDS */
if ((insn & 0xFC00003F) != 0xEC00003A) printf("unrecognized: %08x\n", insn);
printf("fmadds fr%u,fr%u,fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 6) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 36:
/* FDIVS */
if ((insn & 0xFC0007FF) != 0xEC000024) printf("unrecognized: %08x\n", insn);
printf("fdiv fr%u,fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
case 42:
/* FADDS */
if ((insn & 0xFC0007FF) != 0xEC00002A) printf("unrecognized: %08x\n", insn);
printf("fadds fr%u,fr%u,fr%u", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 11) & 0x1F));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 11:
/* CMPWI */
if ((insn & 0xFC600000) != 0x2C000000) printf("unrecognized: %08x\n", insn);
printf("cmpwi cr%u,r%u,%d", (unsigned)((insn >> 23) & 0x7), (unsigned)((insn >> 16) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)));
break;
case 10:
/* CMPLWI */
if ((insn & 0xFC600000) != 0x28000000) printf("unrecognized: %08x\n", insn);
printf("cmplwi cr%u,r%u,%u", (unsigned)((insn >> 23) & 0x7), (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 0) & 0xFFFF));
break;
case 16:
switch (((insn >> 21) & 0x1F)) {
case 5:
/* BNE- */
if ((insn & 0xFFE00003) != 0x40A00000) printf("unrecognized: %08x\n", insn);
printf("bns- %u,0x%x", (unsigned)((insn >> 16) & 0x1F), (unsigned)(addr + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2)));
break;
case 4:
/* BNE */
if ((insn & 0xFFE00003) != 0x40800000) printf("unrecognized: %08x\n", insn);
printf("bns %u,0x%x", (unsigned)((insn >> 16) & 0x1F), (unsigned)(addr + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2)));
break;
case 13:
/* BEQ+ */
if ((insn & 0xFFE00003) != 0x41A00000) printf("unrecognized: %08x\n", insn);
printf("bs+ %u,0x%x", (unsigned)((insn >> 16) & 0x1F), (unsigned)(addr + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2)));
break;
case 12:
/* BEQ */
if ((insn & 0xFFE00003) != 0x41800000) printf("unrecognized: %08x\n", insn);
printf("bs %u,0x%x", (unsigned)((insn >> 16) & 0x1F), (unsigned)(addr + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2)));
break;
case 18:
/* BDZ */
if ((insn & 0xFFE00003) != 0x42400000) printf("unrecognized: %08x\n", insn);
printf("bdz 0x%x", (unsigned)(addr + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2)));
break;
case 16:
/* BDNZ */
if ((insn & 0xFFE00003) != 0x42000000) printf("unrecognized: %08x\n", insn);
printf("bdnz 0x%x", (unsigned)(addr + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2)));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 18:
switch (((insn >> 0) & 0x3)) {
case 1:
/* BL */
if ((insn & 0xFC000003) != 0x48000001) printf("unrecognized: %08x\n", insn);
printf("bl 0x%x", (unsigned)(addr + (((((insn >> 2) & 0xFFFFFF) & 0x800000) ? ((word_32)((insn >> 2) & 0xFFFFFF) | 0xFF000000) : (word_32)((insn >> 2) & 0xFFFFFF)) << 2)));
break;
case 0:
/* B */
if ((insn & 0xFC000003) != 0x48000000) printf("unrecognized: %08x\n", insn);
printf("b 0x%x", (unsigned)(addr + (((((insn >> 2) & 0xFFFFFF) & 0x800000) ? ((word_32)((insn >> 2) & 0xFFFFFF) | 0xFF000000) : (word_32)((insn >> 2) & 0xFFFFFF)) << 2)));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 29:
/* ANDIS. */
if ((insn & 0xFC000000) != 0x74000000) printf("unrecognized: %08x\n", insn);
printf("andis. r%u,r%u,%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 0) & 0xFFFF));
break;
case 28:
/* ANDI. */
if ((insn & 0xFC000000) != 0x70000000) printf("unrecognized: %08x\n", insn);
printf("andi. r%u,r%u,%u", (unsigned)((insn >> 16) & 0x1F), (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 0) & 0xFFFF));
break;
case 15:
/* ADDIS */
if ((insn & 0xFC000000) != 0x3C000000) printf("unrecognized: %08x\n", insn);
printf("addis r%u,r%u,%d", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)));
break;
case 13:
/* ADDIC. */
if ((insn & 0xFC000000) != 0x34000000) printf("unrecognized: %08x\n", insn);
printf("addic. r%u,r%u,%d", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)));
break;
case 12:
/* ADDIC */
if ((insn & 0xFC000000) != 0x30000000) printf("unrecognized: %08x\n", insn);
printf("addic r%u,r%u,%d", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)));
break;
case 14:
/* ADDI */
if ((insn & 0xFC000000) != 0x38000000) printf("unrecognized: %08x\n", insn);
printf("addi r%u,r%u,%d", (unsigned)((insn >> 21) & 0x1F), (unsigned)((insn >> 16) & 0x1F), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)));
break;
default:
printf("unrecognized: %08x\n", insn);
}
}
