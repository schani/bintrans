void gen_kill_ppc_insn (word_32 insn, word_32 pc, word_32 *_gen_CR, word_32 *_kill_CR, word_32 *_gen_XER, word_32 *_kill_XER, word_32 *_gen_GPR, word_32 *_kill_GPR) {
word_32 gen_CR = *_gen_CR, kill_CR = *_kill_CR, gen_CR_save, kill_CR_save, consumed_CR, killed_CR;
word_32 gen_XER = *_gen_XER, kill_XER = *_kill_XER, gen_XER_save, kill_XER_save, consumed_XER, killed_XER;

word_32 gen_GPR = *_gen_GPR, kill_GPR = *_kill_GPR, gen_GPR_save, kill_GPR_save, consumed_GPR, killed_GPR;
switch (((insn >> 26) & 0x3F)) {
case 27:
/* XORIS */
assert((insn & 0xFC000000) == 0x6C000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 26:
/* XORI */
assert((insn & 0xFC000000) == 0x68000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 31:
switch (((insn >> 0) & 0x7FF)) {
case 633:
/* XOR. */
assert((insn & 0xFC0007FF) == 0x7C000279);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 632:
/* XOR */
assert((insn & 0xFC0007FF) == 0x7C000278);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1196:
/* SYNC */
assert((insn & 0xFFFFFFFF) == 0x7C0004AC);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
/* nop */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
/* nop */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
/* nop */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
/* nop */
killed_CR = killed;
}
{
word_32 killed = 0;
/* nop */
killed_XER = killed;
}
{
word_32 killed = 0;
/* nop */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1425:
/* SUBFZEO. */
assert((insn & 0xFC00FFFF) == 0x7C000591);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1424:
/* SUBFZEO */
assert((insn & 0xFC00FFFF) == 0x7C000590);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 401:
/* SUBFZE. */
assert((insn & 0xFC00FFFF) == 0x7C000191);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 400:
/* SUBFZE */
assert((insn & 0xFC00FFFF) == 0x7C000190);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1489:
/* SUBFMEO. */
assert((insn & 0xFC00FFFF) == 0x7C0005D1);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1488:
/* SUBFMEO */
assert((insn & 0xFC00FFFF) == 0x7C0005D0);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 465:
/* SUBFME. */
assert((insn & 0xFC00FFFF) == 0x7C0001D1);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 464:
/* SUBFME */
assert((insn & 0xFC00FFFF) == 0x7C0001D0);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1297:
/* SUBFEO. */
assert((insn & 0xFC0007FF) == 0x7C000511);
gen_CR |= ~kill_CR & (0 | 0| 0);
gen_XER |= ~kill_XER & (0 | 0| 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | (0 | 0x20000000)| 0)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1296:
/* SUBFEO */
assert((insn & 0xFC0007FF) == 0x7C000510);
gen_CR |= ~kill_CR & (0 | 0| 0);
gen_XER |= ~kill_XER & (0 | 0| 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | (0 | 0x20000000)| 0)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 273:
/* SUBFE. */
assert((insn & 0xFC0007FF) == 0x7C000111);
gen_CR |= ~kill_CR & (0 | 0| 0);
gen_XER |= ~kill_XER & (0 | 0| 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | (0 | 0x20000000)| 0)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 272:
/* SUBFE */
assert((insn & 0xFC0007FF) == 0x7C000110);
gen_CR |= ~kill_CR & (0 | 0| 0);
gen_XER |= ~kill_XER & (0 | 0| 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | (0 | 0x20000000)| 0)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1041:
/* SUBFCO. */
assert((insn & 0xFC0007FF) == 0x7C000411);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| 0));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1040:
/* SUBFCO */
assert((insn & 0xFC0007FF) == 0x7C000410);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| 0));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 17:
/* SUBFC. */
assert((insn & 0xFC0007FF) == 0x7C000011);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| 0));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 16:
/* SUBFC */
assert((insn & 0xFC0007FF) == 0x7C000010);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| 0));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1105:
/* SUBFO. */
assert((insn & 0xFC0007FF) == 0x7C000451);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1104:
/* SUBFO */
assert((insn & 0xFC0007FF) == 0x7C000450);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 81:
/* SUBF. */
assert((insn & 0xFC0007FF) == 0x7C000051);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 80:
/* SUBF */
assert((insn & 0xFC0007FF) == 0x7C000050);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 302:
/* STWX */
assert((insn & 0xFC0007FF) == 0x7C00012E);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 366:
/* STWUX */
assert((insn & 0xFC0007FF) == 0x7C00016E);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1324:
/* STWBRX */
assert((insn & 0xFC0007FF) == 0x7C00052C);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 814:
/* STHX */
assert((insn & 0xFC0007FF) == 0x7C00032E);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1836:
/* STHBRX */
assert((insn & 0xFC0007FF) == 0x7C00072C);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1326:
/* STFSX */
assert((insn & 0xFC0007FF) == 0x7C00052E);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1454:
/* STFDX */
assert((insn & 0xFC0007FF) == 0x7C0005AE);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 430:
/* STBX */
assert((insn & 0xFC0007FF) == 0x7C0001AE);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1073:
/* SRW. */
assert((insn & 0xFC0007FF) == 0x7C000431);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1072:
/* SRW */
assert((insn & 0xFC0007FF) == 0x7C000430);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1649:
/* SRAWI. */
assert((insn & 0xFC0007FF) == 0x7C000671);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | ((0 | (0 | 0| (1 << ((insn >> 21) & 0x1F)))| 0) | 0 | 0) | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1648:
/* SRAWI */
assert((insn & 0xFC0007FF) == 0x7C000670);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | ((0 | (0 | 0| (1 << ((insn >> 21) & 0x1F)))| 0) | 0 | 0) | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1585:
/* SRAW. */
assert((insn & 0xFC0007FF) == 0x7C000631);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | ((0 | (0 | (0 | (0 | 0| (0 | (1 << ((insn >> 11) & 0x1F))| 0))| 0)| (1 << ((insn >> 21) & 0x1F)))| 0) | 0 | 0) | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1584:
/* SRAW */
assert((insn & 0xFC0007FF) == 0x7C000630);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | ((0 | (0 | (0 | (0 | 0| (0 | (1 << ((insn >> 11) & 0x1F))| 0))| 0)| (1 << ((insn >> 21) & 0x1F)))| 0) | 0 | 0) | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 49:
/* SLW. */
assert((insn & 0xFC0007FF) == 0x7C000031);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 11) & 0x1F))| 0) | 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F)))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 48:
/* SLW */
assert((insn & 0xFC0007FF) == 0x7C000030);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 11) & 0x1F))| 0) | 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F)))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 825:
/* ORC. */
assert((insn & 0xFC0007FF) == 0x7C000339);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 824:
/* ORC */
assert((insn & 0xFC0007FF) == 0x7C000338);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 889:
/* OR. */
assert((insn & 0xFC0007FF) == 0x7C000379);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 888:
/* OR */
assert((insn & 0xFC0007FF) == 0x7C000378);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 249:
/* NOR. */
assert((insn & 0xFC0007FF) == 0x7C0000F9);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 248:
/* NOR */
assert((insn & 0xFC0007FF) == 0x7C0000F8);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1233:
/* NEGO. */
assert((insn & 0xFC00FFFF) == 0x7C0004D1);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1232:
/* NEGO */
assert((insn & 0xFC00FFFF) == 0x7C0004D0);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 209:
/* NEG. */
assert((insn & 0xFC00FFFF) == 0x7C0000D1);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 208:
/* NEG */
assert((insn & 0xFC00FFFF) == 0x7C0000D0);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 953:
/* NAND. */
assert((insn & 0xFC0007FF) == 0x7C0003B9);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 952:
/* NAND */
assert((insn & 0xFC0007FF) == 0x7C0003B8);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1495:
/* MULLWO. */
assert((insn & 0xFC0007FF) == 0x7C0005D7);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1494:
/* MULLWO */
assert((insn & 0xFC0007FF) == 0x7C0005D6);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 471:
/* MULLW. */
assert((insn & 0xFC0007FF) == 0x7C0001D7);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 470:
/* MULLW */
assert((insn & 0xFC0007FF) == 0x7C0001D6);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 22:
/* MULHWU */
assert((insn & 0xFC0007FF) == 0x7C000016);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (0 | (1 << ((insn >> 11) & 0x1F))))| 0));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 150:
/* MULHW */
assert((insn & 0xFC0007FF) == 0x7C000096);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (0 | (1 << ((insn >> 11) & 0x1F))))| 0));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 934:
switch (((insn >> 11) & 0x3FF)) {
case 32:
/* MTXER */
assert((insn & 0xFC1FFFFF) == 0x7C0103A6);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0xFFFFFFFF;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 256:
/* MTLR */
assert((insn & 0xFC1FFFFF) == 0x7C0803A6);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 288:
/* MTCTR */
assert((insn & 0xFC1FFFFF) == 0x7C0903A6);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
default:
goto unrecognized;
}
break;
case 288:
/* MTCRF */
assert((insn & 0xFC100FFF) == 0x7C000120);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0xFFFFFFFF| 0)| 0);
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | (1 << ((insn >> 21) & 0x1F))| 0));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= 0xFFFFFFFF;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 678:
switch (((insn >> 11) & 0x3FF)) {
case 32:
/* MFXER */
assert((insn & 0xFC1FFFFF) == 0x7C0102A6);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0xFFFFFFFF;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 256:
/* MFLR */
assert((insn & 0xFC1FFFFF) == 0x7C0802A6);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 288:
/* MFCTR */
assert((insn & 0xFC1FFFFF) == 0x7C0902A6);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
default:
goto unrecognized;
}
break;
case 38:
/* MFCR */
assert((insn & 0xFC1FFFFF) == 0x7C000026);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0xFFFFFFFF;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1024:
/* MCRXR */
assert((insn & 0xFC7FFFFF) == 0x7C000400);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (15 << (4 * 7));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (15 << (4 * ((7 - ((insn >> 23) & 0x7)) & 0x7)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 46:
/* LWZX */
assert((insn & 0xFC0007FF) == 0x7C00002E);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 110:
/* LWZUX */
assert((insn & 0xFC0007FF) == 0x7C00006E);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1068:
/* LWBRX */
assert((insn & 0xFC0007FF) == 0x7C00042C);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 558:
/* LHZX */
assert((insn & 0xFC0007FF) == 0x7C00022E);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1580:
/* LHBRX */
assert((insn & 0xFC0007FF) == 0x7C00062C);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 686:
/* LHAX */
assert((insn & 0xFC0007FF) == 0x7C0002AE);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1070:
/* LFSX */
assert((insn & 0xFC0007FF) == 0x7C00042E);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)))))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1198:
/* LFDX */
assert((insn & 0xFC0007FF) == 0x7C0004AE);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 174:
/* LBZX */
assert((insn & 0xFC0007FF) == 0x7C0000AE);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 238:
/* LBZUX */
assert((insn & 0xFC0007FF) == 0x7C0000EE);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1964:
/* ICBI */
assert((insn & 0xFFE007FF) == 0x7C0007AC);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
/* ignore */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
/* ignore */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
/* ignore */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
/* ignore */
killed_CR = killed;
}
{
word_32 killed = 0;
/* ignore */
killed_XER = killed;
}
{
word_32 killed = 0;
/* ignore */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1845:
/* EXTSH. */
assert((insn & 0xFC00FFFF) == 0x7C000735);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1844:
/* EXTSH */
assert((insn & 0xFC00FFFF) == 0x7C000734);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1908:
/* EXTSB */
assert((insn & 0xFC00FFFF) == 0x7C000774);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 569:
/* EQV. */
assert((insn & 0xFC0007FF) == 0x7C000239);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 568:
/* EQV */
assert((insn & 0xFC0007FF) == 0x7C000238);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1943:
/* DIVWUO. */
assert((insn & 0xFC0007FF) == 0x7C000797);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1942:
/* DIVWUO */
assert((insn & 0xFC0007FF) == 0x7C000796);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 919:
/* DIVWU. */
assert((insn & 0xFC0007FF) == 0x7C000397);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 918:
/* DIVWU */
assert((insn & 0xFC0007FF) == 0x7C000396);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 2007:
/* DIVWO. */
assert((insn & 0xFC0007FF) == 0x7C0007D7);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 2006:
/* DIVWO */
assert((insn & 0xFC0007FF) == 0x7C0007D6);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 983:
/* DIVW. */
assert((insn & 0xFC0007FF) == 0x7C0003D7);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 982:
/* DIVW */
assert((insn & 0xFC0007FF) == 0x7C0003D6);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 2028:
/* DCBZ */
assert((insn & 0xFFE007FF) == 0x7C0007EC);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| 0));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 108:
/* DCBST */
assert((insn & 0xFFE007FF) == 0x7C00006C);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
/* ignore */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
/* ignore */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
/* ignore */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
/* ignore */
killed_CR = killed;
}
{
word_32 killed = 0;
/* ignore */
killed_XER = killed;
}
{
word_32 killed = 0;
/* ignore */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 52:
/* CNTLZW */
assert((insn & 0xFC00FFFF) == 0x7C000034);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 0:
/* CMPW */
assert((insn & 0xFC6007FF) == 0x7C000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 64:
/* CMPLW */
assert((insn & 0xFC6007FF) == 0x7C000040);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 121:
/* ANDC. */
assert((insn & 0xFC0007FF) == 0x7C000079);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 120:
/* ANDC */
assert((insn & 0xFC0007FF) == 0x7C000078);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 57:
/* AND. */
assert((insn & 0xFC0007FF) == 0x7C000039);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 56:
/* AND */
assert((insn & 0xFC0007FF) == 0x7C000038);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1429:
/* ADDZEO. */
assert((insn & 0xFC00FFFF) == 0x7C000595);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1428:
/* ADDZEO */
assert((insn & 0xFC00FFFF) == 0x7C000594);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 405:
/* ADDZE. */
assert((insn & 0xFC00FFFF) == 0x7C000195);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 404:
/* ADDZE */
assert((insn & 0xFC00FFFF) == 0x7C000194);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1493:
/* ADDMEO. */
assert((insn & 0xFC00FFFF) == 0x7C0005D5);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0)| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1492:
/* ADDMEO */
assert((insn & 0xFC00FFFF) == 0x7C0005D4);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0)| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 469:
/* ADDME. */
assert((insn & 0xFC00FFFF) == 0x7C0001D5);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0)| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 468:
/* ADDME */
assert((insn & 0xFC00FFFF) == 0x7C0001D4);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0)| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1301:
/* ADDEO. */
assert((insn & 0xFC0007FF) == 0x7C000515);
gen_CR |= ~kill_CR & (0 | 0| 0);
gen_XER |= ~kill_XER & (0 | 0| 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1300:
/* ADDEO */
assert((insn & 0xFC0007FF) == 0x7C000514);
gen_CR |= ~kill_CR & (0 | 0| 0);
gen_XER |= ~kill_XER & (0 | 0| 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 277:
/* ADDE. */
assert((insn & 0xFC0007FF) == 0x7C000115);
gen_CR |= ~kill_CR & (0 | 0| 0);
gen_XER |= ~kill_XER & (0 | 0| 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 276:
/* ADDE */
assert((insn & 0xFC0007FF) == 0x7C000114);
gen_CR |= ~kill_CR & (0 | 0| 0);
gen_XER |= ~kill_XER & (0 | 0| 0);
gen_GPR |= ~kill_GPR & (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1045:
/* ADDCO. */
assert((insn & 0xFC0007FF) == 0x7C000415);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1044:
/* ADDCO */
assert((insn & 0xFC0007FF) == 0x7C000414);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 21:
/* ADDC. */
assert((insn & 0xFC0007FF) == 0x7C000015);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 20:
/* ADDC */
assert((insn & 0xFC0007FF) == 0x7C000014);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1557:
/* ADDO. */
assert((insn & 0xFC0007FF) == 0x7C000615);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1556:
/* ADDO */
assert((insn & 0xFC0007FF) == 0x7C000614);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_CR = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_XER = killed;
}
{
word_32 killed = 0;
assert(0); /* not implemented */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 533:
/* ADD. */
assert((insn & 0xFC0007FF) == 0x7C000215);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 532:
/* ADD */
assert((insn & 0xFC0007FF) == 0x7C000214);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
default:
goto unrecognized;
}
break;
case 8:
/* SUBFIC */
assert((insn & 0xFC000000) == 0x20000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| 0));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 37:
/* STWU */
assert((insn & 0xFC000000) == 0x94000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | (1 << ((insn >> 16) & 0x1F))| 0) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 36:
/* STW */
assert((insn & 0xFC000000) == 0x90000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| 0) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 45:
/* STHU */
assert((insn & 0xFC000000) == 0xB4000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | (1 << ((insn >> 16) & 0x1F))| 0) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 44:
/* STH */
assert((insn & 0xFC000000) == 0xB0000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0)) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 52:
/* STFS */
assert((insn & 0xFC000000) == 0xD0000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| 0) | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 55:
/* STFDU */
assert((insn & 0xFC000000) == 0xDC000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 54:
/* STFD */
assert((insn & 0xFC000000) == 0xD8000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| 0) | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 39:
/* STBU */
assert((insn & 0xFC000000) == 0x9C000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | (1 << ((insn >> 16) & 0x1F))| 0) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 38:
/* STB */
assert((insn & 0xFC000000) == 0x98000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0)) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 17:
/* SC */
assert((insn & 0xFFFFFFFF) == 0x44000002);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed = 0xFFFFFFFF;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed = 0xFFFFFFFF;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed = 0xFFFFFFFF;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed = 0xFFFFFFFF; /* syscall */
killed_CR = killed;
}
{
word_32 killed = 0;
killed = 0xFFFFFFFF; /* syscall */
killed_XER = killed;
}
{
word_32 killed = 0;
killed = 0xFFFFFFFF; /* syscall */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 23:
switch (((insn >> 0) & 0x1)) {
case 1:
/* RLWNM. */
assert((insn & 0xFC000001) == 0x5C000001);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 0:
/* RLWNM */
assert((insn & 0xFC000001) == 0x5C000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
default:
goto unrecognized;
}
break;
case 21:
switch (((insn >> 0) & 0x1)) {
case 1:
/* RLWINM. */
assert((insn & 0xFC000001) == 0x54000001);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0)| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 0:
/* RLWINM */
assert((insn & 0xFC000001) == 0x54000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0)| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
default:
goto unrecognized;
}
break;
case 20:
/* RLWIMI */
assert((insn & 0xFC000001) == 0x50000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0)| 0)| (0 | (1 << ((insn >> 16) & 0x1F))| 0));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 25:
/* ORIS */
assert((insn & 0xFC000000) == 0x64000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 24:
/* ORI */
assert((insn & 0xFC000000) == 0x60000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 7:
/* MULLI */
assert((insn & 0xFC000000) == 0x1C000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 63:
switch (((insn >> 0) & 0x3F)) {
case 12:
switch (((insn >> 6) & 0x3F)) {
case 4:
/* MTFSFI */
assert((insn & 0xFC7F0FFF) == 0xFC00010C);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 2:
/* MTFSB0 */
assert((insn & 0xFC1FFFFF) == 0xFC00008C);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
default:
goto unrecognized;
}
break;
case 14:
switch (((insn >> 6) & 0x1F)) {
case 22:
/* MTFSF */
assert((insn & 0xFFFF07FF) == 0xFDFE058E);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 18:
/* MFFS */
assert((insn & 0xFC1FFFFF) == 0xFC00048E);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
default:
goto unrecognized;
}
break;
case 40:
/* FSUB */
assert((insn & 0xFC0007FF) == 0xFC000028);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 24:
/* FRSP */
assert((insn & 0xFC1F07FF) == 0xFC000018);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 60:
/* FNMSUB */
assert((insn & 0xFC00003F) == 0xFC00003C);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 16:
switch (((insn >> 6) & 0x1F)) {
case 1:
/* FNEG */
assert((insn & 0xFC1F07FF) == 0xFC000050);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 2:
/* FMR */
assert((insn & 0xFC1F07FF) == 0xFC000090);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 8:
/* FABS */
assert((insn & 0xFC1F07FF) == 0xFC000210);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
default:
goto unrecognized;
}
break;
case 50:
/* FMUL */
assert((insn & 0xFC00F83F) == 0xFC000032);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 56:
/* FMSUB */
assert((insn & 0xFC00003F) == 0xFC000038);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 58:
/* FMADD */
assert((insn & 0xFC00003F) == 0xFC00003A);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 36:
/* FDIV */
assert((insn & 0xFC0007FF) == 0xFC000024);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 30:
/* FCTIWZ */
assert((insn & 0xFC1F07FF) == 0xFC00001E);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 0:
/* FCMPU */
assert((insn & 0xFC6007FF) == 0xFC000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 42:
/* FADD */
assert((insn & 0xFC0007FF) == 0xFC00002A);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
default:
goto unrecognized;
}
break;
case 19:
switch (((insn >> 0) & 0x7FF)) {
case 0:
/* MCRF */
assert((insn & 0xFC63FFFF) == 0x4C000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | (15 << (4 * ((7 - ((insn >> 18) & 0x7)) & 0x7)));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (15 << (4 * ((7 - ((insn >> 23) & 0x7)) & 0x7)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 300:
/* ISYNC */
assert((insn & 0xFFFFFFFF) == 0x4C00012C);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
/* nop */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
/* nop */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
/* nop */
consumed_GPR = consumed;
}
{
word_32 killed = 0;
/* nop */
killed_CR = killed;
}
{
word_32 killed = 0;
/* nop */
killed_XER = killed;
}
{
word_32 killed = 0;
/* nop */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 386:
/* CRXOR */
assert((insn & 0xFC0007FF) == 0x4C000182);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 834:
/* CRORC */
assert((insn & 0xFC0007FF) == 0x4C000342);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (0 | (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F)))| 0));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 898:
/* CROR */
assert((insn & 0xFC0007FF) == 0x4C000382);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 66:
/* CRNOR */
assert((insn & 0xFC0007FF) == 0x4C000042);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))))| 0);
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 450:
/* CRNAND */
assert((insn & 0xFC0007FF) == 0x4C0001C2);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))))| 0);
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 578:
/* CREQV */
assert((insn & 0xFC0007FF) == 0x4C000242);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))))| 0);
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 258:
/* CRANDC */
assert((insn & 0xFC0007FF) == 0x4C000102);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (0 | (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F)))| 0));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 514:
/* CRAND */
assert((insn & 0xFC0007FF) == 0x4C000202);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 32:
switch (((insn >> 11) & 0x1F)) {
case 0:
switch (((insn >> 21) & 0x1F)) {
case 5:
/* BNELR+ */
assert((insn & 0xFFE0FFFF) == 0x4CA00020);
gen_CR |= ~kill_CR & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
gen_XER |= ~kill_XER & 0;
gen_GPR |= ~kill_GPR & 0;
gen_CR_save = gen_CR;
kill_CR_save = kill_CR;
gen_XER_save = gen_XER;
kill_XER_save = kill_XER;
gen_GPR_save = gen_GPR;
kill_GPR_save = kill_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
SWAP(gen_CR_save, gen_CR);
SWAP(kill_CR_save, kill_CR);
SWAP(gen_XER_save, gen_XER);
SWAP(kill_XER_save, kill_XER);
SWAP(gen_GPR_save, gen_GPR);
SWAP(kill_GPR_save, kill_GPR);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
gen_CR |= gen_CR_save;
kill_CR |= kill_CR_save;
gen_XER |= gen_XER_save;
kill_XER |= kill_XER_save;
gen_GPR |= gen_GPR_save;
kill_GPR |= kill_GPR_save;
break;
case 4:
/* BNELR */
assert((insn & 0xFFE0FFFF) == 0x4C800020);
gen_CR |= ~kill_CR & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
gen_XER |= ~kill_XER & 0;
gen_GPR |= ~kill_GPR & 0;
gen_CR_save = gen_CR;
kill_CR_save = kill_CR;
gen_XER_save = gen_XER;
kill_XER_save = kill_XER;
gen_GPR_save = gen_GPR;
kill_GPR_save = kill_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
SWAP(gen_CR_save, gen_CR);
SWAP(kill_CR_save, kill_CR);
SWAP(gen_XER_save, gen_XER);
SWAP(kill_XER_save, kill_XER);
SWAP(gen_GPR_save, gen_GPR);
SWAP(kill_GPR_save, kill_GPR);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
gen_CR |= gen_CR_save;
kill_CR |= kill_CR_save;
gen_XER |= gen_XER_save;
kill_XER |= kill_XER_save;
gen_GPR |= gen_GPR_save;
kill_GPR |= kill_GPR_save;
break;
case 20:
/* BLR */
assert((insn & 0xFFE0FFFF) == 0x4E800020);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
/* jump */
killed_CR = killed;
}
{
word_32 killed = 0;
/* jump */
killed_XER = killed;
}
{
word_32 killed = 0;
/* jump */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 12:
/* BEQLR */
assert((insn & 0xFFE0FFFF) == 0x4D800020);
gen_CR |= ~kill_CR & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
gen_XER |= ~kill_XER & 0;
gen_GPR |= ~kill_GPR & 0;
gen_CR_save = gen_CR;
kill_CR_save = kill_CR;
gen_XER_save = gen_XER;
kill_XER_save = kill_XER;
gen_GPR_save = gen_GPR;
kill_GPR_save = kill_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
SWAP(gen_CR_save, gen_CR);
SWAP(kill_CR_save, kill_CR);
SWAP(gen_XER_save, gen_XER);
SWAP(kill_XER_save, kill_XER);
SWAP(gen_GPR_save, gen_GPR);
SWAP(kill_GPR_save, kill_GPR);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
gen_CR |= gen_CR_save;
kill_CR |= kill_CR_save;
gen_XER |= gen_XER_save;
kill_XER |= kill_XER_save;
gen_GPR |= gen_GPR_save;
kill_GPR |= kill_GPR_save;
break;
default:
goto unrecognized;
}
break;
default:
goto unrecognized;
}
break;
case 33:
/* BLRL */
assert((insn & 0xFFE0FFFF) == 0x4E800021);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | 0);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
/* jump */
killed_CR = killed;
}
{
word_32 killed = 0;
/* jump */
killed_XER = killed;
}
{
word_32 killed = 0;
/* jump */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 1056:
/* BCTR */
assert((insn & 0xFFE0FFFF) == 0x4E800420);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
/* jump */
killed_CR = killed;
}
{
word_32 killed = 0;
/* jump */
killed_XER = killed;
}
{
word_32 killed = 0;
/* jump */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
default:
goto unrecognized;
}
break;
case 33:
/* LWZU */
assert((insn & 0xFC000000) == 0x84000000);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 32:
/* LWZ */
assert((insn & 0xFC000000) == 0x80000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0)));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 41:
/* LHZU */
assert((insn & 0xFC000000) == 0xA4000000);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 40:
/* LHZ */
assert((insn & 0xFC000000) == 0xA0000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 43:
/* LHAU */
assert((insn & 0xFC000000) == 0xAC000000);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 42:
/* LHA */
assert((insn & 0xFC000000) == 0xA8000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 48:
/* LFS */
assert((insn & 0xFC000000) == 0xC0000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0)))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 50:
/* LFD */
assert((insn & 0xFC000000) == 0xC8000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 35:
/* LBZU */
assert((insn & 0xFC000000) == 0x8C000000);
gen_CR |= ~kill_CR & (0 | 0);
gen_XER |= ~kill_XER & (0 | 0);
gen_GPR |= ~kill_GPR & (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0));
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 34:
/* LBZ */
assert((insn & 0xFC000000) == 0x88000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0))));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 59:
switch (((insn >> 0) & 0x3F)) {
case 40:
/* FSUBS */
assert((insn & 0xFC0007FF) == 0xEC000028);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 50:
/* FMULS */
assert((insn & 0xFC00F83F) == 0xEC000032);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 56:
/* FMSUBS */
assert((insn & 0xFC00003F) == 0xEC000038);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 58:
/* FMADDS */
assert((insn & 0xFC00003F) == 0xEC00003A);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 36:
/* FDIVS */
assert((insn & 0xFC0007FF) == 0xEC000024);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 42:
/* FADDS */
assert((insn & 0xFC0007FF) == 0xEC00002A);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
default:
goto unrecognized;
}
break;
case 11:
/* CMPWI */
assert((insn & 0xFC600000) == 0x2C000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 10:
/* CMPLWI */
assert((insn & 0xFC600000) == 0x28000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F)));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 16:
switch (((insn >> 21) & 0x1F)) {
case 5:
/* BNE- */
assert((insn & 0xFFE00003) == 0x40A00000);
gen_CR |= ~kill_CR & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
gen_XER |= ~kill_XER & 0;
gen_GPR |= ~kill_GPR & 0;
gen_CR_save = gen_CR;
kill_CR_save = kill_CR;
gen_XER_save = gen_XER;
kill_XER_save = kill_XER;
gen_GPR_save = gen_GPR;
kill_GPR_save = kill_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
SWAP(gen_CR_save, gen_CR);
SWAP(kill_CR_save, kill_CR);
SWAP(gen_XER_save, gen_XER);
SWAP(kill_XER_save, kill_XER);
SWAP(gen_GPR_save, gen_GPR);
SWAP(kill_GPR_save, kill_GPR);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
gen_CR |= gen_CR_save;
kill_CR |= kill_CR_save;
gen_XER |= gen_XER_save;
kill_XER |= kill_XER_save;
gen_GPR |= gen_GPR_save;
kill_GPR |= kill_GPR_save;
break;
case 4:
/* BNE */
assert((insn & 0xFFE00003) == 0x40800000);
gen_CR |= ~kill_CR & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
gen_XER |= ~kill_XER & 0;
gen_GPR |= ~kill_GPR & 0;
gen_CR_save = gen_CR;
kill_CR_save = kill_CR;
gen_XER_save = gen_XER;
kill_XER_save = kill_XER;
gen_GPR_save = gen_GPR;
kill_GPR_save = kill_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
SWAP(gen_CR_save, gen_CR);
SWAP(kill_CR_save, kill_CR);
SWAP(gen_XER_save, gen_XER);
SWAP(kill_XER_save, kill_XER);
SWAP(gen_GPR_save, gen_GPR);
SWAP(kill_GPR_save, kill_GPR);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
gen_CR |= gen_CR_save;
kill_CR |= kill_CR_save;
gen_XER |= gen_XER_save;
kill_XER |= kill_XER_save;
gen_GPR |= gen_GPR_save;
kill_GPR |= kill_GPR_save;
break;
case 13:
/* BEQ+ */
assert((insn & 0xFFE00003) == 0x41A00000);
gen_CR |= ~kill_CR & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
gen_XER |= ~kill_XER & 0;
gen_GPR |= ~kill_GPR & 0;
gen_CR_save = gen_CR;
kill_CR_save = kill_CR;
gen_XER_save = gen_XER;
kill_XER_save = kill_XER;
gen_GPR_save = gen_GPR;
kill_GPR_save = kill_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
SWAP(gen_CR_save, gen_CR);
SWAP(kill_CR_save, kill_CR);
SWAP(gen_XER_save, gen_XER);
SWAP(kill_XER_save, kill_XER);
SWAP(gen_GPR_save, gen_GPR);
SWAP(kill_GPR_save, kill_GPR);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
gen_CR |= gen_CR_save;
kill_CR |= kill_CR_save;
gen_XER |= gen_XER_save;
kill_XER |= kill_XER_save;
gen_GPR |= gen_GPR_save;
kill_GPR |= kill_GPR_save;
break;
case 12:
/* BEQ */
assert((insn & 0xFFE00003) == 0x41800000);
gen_CR |= ~kill_CR & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
gen_XER |= ~kill_XER & 0;
gen_GPR |= ~kill_GPR & 0;
gen_CR_save = gen_CR;
kill_CR_save = kill_CR;
gen_XER_save = gen_XER;
kill_XER_save = kill_XER;
gen_GPR_save = gen_GPR;
kill_GPR_save = kill_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
SWAP(gen_CR_save, gen_CR);
SWAP(kill_CR_save, kill_CR);
SWAP(gen_XER_save, gen_XER);
SWAP(kill_XER_save, kill_XER);
SWAP(gen_GPR_save, gen_GPR);
SWAP(kill_GPR_save, kill_GPR);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
gen_CR |= gen_CR_save;
kill_CR |= kill_CR_save;
gen_XER |= gen_XER_save;
kill_XER |= kill_XER_save;
gen_GPR |= gen_GPR_save;
kill_GPR |= kill_GPR_save;
break;
case 18:
/* BDZ */
assert((insn & 0xFFE00003) == 0x42400000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
gen_CR |= ~kill_CR & 0;
gen_XER |= ~kill_XER & 0;
gen_GPR |= ~kill_GPR & 0;
gen_CR_save = gen_CR;
kill_CR_save = kill_CR;
gen_XER_save = gen_XER;
kill_XER_save = kill_XER;
gen_GPR_save = gen_GPR;
kill_GPR_save = kill_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
SWAP(gen_CR_save, gen_CR);
SWAP(kill_CR_save, kill_CR);
SWAP(gen_XER_save, gen_XER);
SWAP(kill_XER_save, kill_XER);
SWAP(gen_GPR_save, gen_GPR);
SWAP(kill_GPR_save, kill_GPR);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
gen_CR |= gen_CR_save;
kill_CR |= kill_CR_save;
gen_XER |= gen_XER_save;
kill_XER |= kill_XER_save;
gen_GPR |= gen_GPR_save;
kill_GPR |= kill_GPR_save;
break;
case 16:
/* BDNZ */
assert((insn & 0xFFE00003) == 0x42000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
gen_CR |= ~kill_CR & 0;
gen_XER |= ~kill_XER & 0;
gen_GPR |= ~kill_GPR & 0;
gen_CR_save = gen_CR;
kill_CR_save = kill_CR;
gen_XER_save = gen_XER;
kill_XER_save = kill_XER;
gen_GPR_save = gen_GPR;
kill_GPR_save = kill_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
SWAP(gen_CR_save, gen_CR);
SWAP(kill_CR_save, kill_CR);
SWAP(gen_XER_save, gen_XER);
SWAP(kill_XER_save, kill_XER);
SWAP(gen_GPR_save, gen_GPR);
SWAP(kill_GPR_save, kill_GPR);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
gen_CR |= gen_CR_save;
kill_CR |= kill_CR_save;
gen_XER |= gen_XER_save;
kill_XER |= kill_XER_save;
gen_GPR |= gen_GPR_save;
kill_GPR |= kill_GPR_save;
break;
default:
goto unrecognized;
}
break;
case 18:
switch (((insn >> 0) & 0x3)) {
case 1:
/* BL */
assert((insn & 0xFC000003) == 0x48000001);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
/* jump */
killed_CR = killed;
}
{
word_32 killed = 0;
/* jump */
killed_XER = killed;
}
{
word_32 killed = 0;
/* jump */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 0:
/* B */
assert((insn & 0xFC000003) == 0x48000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
/* jump */
killed_CR = killed;
}
{
word_32 killed = 0;
/* jump */
killed_XER = killed;
}
{
word_32 killed = 0;
/* jump */
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
default:
goto unrecognized;
}
break;
case 29:
/* ANDIS. */
assert((insn & 0xFC000000) == 0x74000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 28:
/* ANDI. */
assert((insn & 0xFC000000) == 0x70000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 16) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 15:
/* ADDIS */
assert((insn & 0xFC000000) == 0x3C000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 13:
/* ADDIC. */
assert((insn & 0xFC000000) == 0x34000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 31));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 30));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 29));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed |= (1 << (1 * 28));
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 12:
/* ADDIC */
assert((insn & 0xFC000000) == 0x30000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed |= 0x20000000;
killed_XER = killed;
}
{
word_32 killed = 0;
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
case 14:
/* ADDI */
assert((insn & 0xFC000000) == 0x38000000);
consumed_CR = 0;
consumed_XER = 0;
consumed_GPR = 0;
killed_CR = 0;
killed_XER = 0;
killed_GPR = 0;
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0));
consumed_GPR = consumed;
}
{
word_32 killed = 0;
killed_CR = killed;
}
{
word_32 killed = 0;
killed_XER = killed;
}
{
word_32 killed = 0;
killed |= (1 << ((insn >> 21) & 0x1F));
killed_GPR = killed;
}
gen_CR |= consumed_CR & ~kill_CR;
kill_CR |= killed_CR;
gen_XER |= consumed_XER & ~kill_XER;
kill_XER |= killed_XER;
gen_GPR |= consumed_GPR & ~kill_GPR;
kill_GPR |= killed_GPR;
break;
default:
goto unrecognized;
}
*_gen_CR = gen_CR;
*_kill_CR = kill_CR;
*_gen_XER = gen_XER;
*_kill_XER = kill_XER;
*_gen_GPR = gen_GPR;
*_kill_GPR = kill_GPR;
return;
unrecognized:
*_gen_CR = *_kill_CR = 0xffffffff;
*_gen_XER = *_kill_XER = 0xffffffff;
*_gen_GPR = *_kill_GPR = 0xffffffff;
}
