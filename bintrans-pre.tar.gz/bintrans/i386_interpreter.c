static word_8 mod, reg, rm, sib_scale, sib_index, sib_base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 disp32, imm32;
word_32 tmp_10752 (interpreter_t *intp) {
return (({ word_32 tmp_10784; switch (sib_base) {  case 0: case 1: case 2: case 3: case 4: case 6: case 7: tmp_10784 = (intp->regs_GPR[sib_base]); break;  case 5: tmp_10784 = ({ word_32 tmp_10785; switch (mod) {  case 0: tmp_10785 = disp32; break;  case 1: case 2: case 3: tmp_10785 = (intp->regs_GPR[5]); break; } tmp_10785; }); break; } tmp_10784; }) + ({ word_32 tmp_10786; switch (sib_index) {  case 0: case 1: case 2: case 3: case 5: case 6: case 7: tmp_10786 = ((intp->regs_GPR[sib_index]) << sib_scale); break;  case 4: tmp_10786 = 0; break; } tmp_10786; }));
}
word_32 tmp_9978 (interpreter_t *intp) {
return ({ word_32 tmp_10787; switch (mod) {  case 0: tmp_10787 = ({ word_32 tmp_10788; switch (rm) {  case 0: case 1: case 2: case 3: case 6: case 7: tmp_10788 = (intp->regs_GPR[rm]); break;  case 4: tmp_10788 = tmp_10752(intp); break;  case 5: tmp_10788 = disp32; break; } tmp_10788; }); break;  case 1: tmp_10787 = ({ word_32 tmp_10789; switch (rm) {  case 0: case 1: case 2: case 3: case 5: case 6: case 7: tmp_10789 = ((intp->regs_GPR[rm]) + ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8)); break;  case 4: tmp_10789 = (((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8) + tmp_10752(intp)); break; } tmp_10789; }); break;  case 2: tmp_10787 = ({ word_32 tmp_10790; switch (rm) {  case 0: case 1: case 2: case 3: case 5: case 6: case 7: tmp_10790 = ((intp->regs_GPR[rm]) + disp32); break;  case 4: tmp_10790 = (disp32 + tmp_10752(intp)); break; } tmp_10790; }); break; } tmp_10787; });
}
void tmp_9966 (interpreter_t *intp, word_8 tmp_10791) {
({ switch (opcode_reg) {  case 0: case 1: case 2: case 3: ((intp->regs_GPR[opcode_reg]) = ((intp->regs_GPR[opcode_reg]) & 0xFFFFFF00) | (tmp_10791 << 0)); break;  case 4: case 5: case 6: case 7: ((intp->regs_GPR[((opcode_reg - 4) & 0x7)]) = ((intp->regs_GPR[((opcode_reg - 4) & 0x7)]) & 0xFFFF00FF) | (tmp_10791 << 8)); break; }});
}
void tmp_9488 (interpreter_t *intp, word_8 tmp_10792) {
({ switch (mod) {  case 0: case 1: case 2: mem_set_8(intp, tmp_9978(intp), tmp_10792); break;  case 3: ({ switch (rm) {  case 0: case 1: case 2: case 3: ((intp->regs_GPR[rm]) = ((intp->regs_GPR[rm]) & 0xFFFFFF00) | (tmp_10792 << 0)); break;  case 4: case 5: case 6: case 7: ((intp->regs_GPR[((rm - 4) & 0x7)]) = ((intp->regs_GPR[((rm - 4) & 0x7)]) & 0xFFFF00FF) | (tmp_10792 << 8)); break; }}); break; }});
}
void tmp_9481 (interpreter_t *intp, word_32 tmp_10793) {
({ switch (mod) {  case 0: case 1: case 2: mem_set_32(intp, tmp_9978(intp), tmp_10793); break;  case 3: ((intp->regs_GPR[rm]) = tmp_10793); break; }});
}
void tmp_9474 (interpreter_t *intp, word_16 tmp_10794) {
({ switch (mod) {  case 0: case 1: case 2: mem_set_16(intp, tmp_9978(intp), tmp_10794); break;  case 3: ((intp->regs_GPR[rm]) = ((intp->regs_GPR[rm]) & 0xFFFF0000) | (tmp_10794 << 0)); break; }});
}
void tmp_9467 (interpreter_t *intp, word_8 tmp_10795) {
({ switch (reg) {  case 0: case 1: case 2: case 3: ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFFFF00) | (tmp_10795 << 0)); break;  case 4: case 5: case 6: case 7: ((intp->regs_GPR[((reg - 4) & 0x7)]) = ((intp->regs_GPR[((reg - 4) & 0x7)]) & 0xFFFF00FF) | (tmp_10795 << 8)); break; }});
}
word_8 tmp_9466 (interpreter_t *intp) {
return ({ word_8 tmp_10796; switch (mod) {  case 0: case 1: case 2: tmp_10796 = mem_get_8(intp, tmp_9978(intp)); break;  case 3: tmp_10796 = ({ word_8 tmp_10797; switch (rm) {  case 0: case 1: case 2: case 3: tmp_10797 = (((intp->regs_GPR[rm]) >> 0) & 0xFF); break;  case 4: case 5: case 6: case 7: tmp_10797 = (((intp->regs_GPR[((rm - 4) & 0x7)]) >> 8) & 0xFF); break; } tmp_10797; }); break; } tmp_10796; });
}
word_8 tmp_9465 (interpreter_t *intp) {
return ({ word_8 tmp_10798; switch (reg) {  case 0: case 1: case 2: case 3: tmp_10798 = (((intp->regs_GPR[reg]) >> 0) & 0xFF); break;  case 4: case 5: case 6: case 7: tmp_10798 = (((intp->regs_GPR[((reg - 4) & 0x7)]) >> 8) & 0xFF); break; } tmp_10798; });
}
word_32 tmp_9458 (interpreter_t *intp) {
return ({ word_32 tmp_10799; switch (mod) {  case 0: case 1: case 2: tmp_10799 = mem_get_32(intp, tmp_9978(intp)); break;  case 3: tmp_10799 = (intp->regs_GPR[rm]); break; } tmp_10799; });
}
word_16 tmp_9451 (interpreter_t *intp) {
return ({ word_16 tmp_10800; switch (mod) {  case 0: case 1: case 2: tmp_10800 = mem_get_16(intp, tmp_9978(intp)); break;  case 3: tmp_10800 = (((intp->regs_GPR[rm]) >> 0) & 0xFFFF); break; } tmp_10800; });
}
void interpret_i386_insn (interpreter_t *intp) {
word_8 opcode, opcode2;
word_32 pc, next_pc;
int prefix_flags;
i386_decode_opcode(intp, &prefix_flags, &opcode, &opcode2);
switch (opcode) {
case 51 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_9450 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) ^ tmp_9451(intp)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_9450 << 0)); });
({ word_1 tmp_9452 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9452 << 0)); });
({ word_1 tmp_9453 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9453 << 11)); });
({ word_1 tmp_9454 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9454 << 7)); });
({ word_1 tmp_9455 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9455 << 6)); });
({ word_1 tmp_9456 = parity_even(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9456 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_9457 = ((intp->regs_GPR[reg]) ^ tmp_9458(intp)); ((intp->regs_GPR[reg]) = tmp_9457); });
({ word_1 tmp_9459 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9459 << 0)); });
({ word_1 tmp_9460 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9460 << 11)); });
({ word_1 tmp_9461 = (((intp->regs_GPR[reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9461 << 7)); });
({ word_1 tmp_9462 = (((intp->regs_GPR[reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9462 << 6)); });
({ word_1 tmp_9463 = parity_even(((intp->regs_GPR[reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9463 << 2)); });
}
break;
case 50 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_9464 = (tmp_9465(intp) ^ tmp_9466(intp)); tmp_9467(intp, tmp_9464); });
({ word_1 tmp_9468 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9468 << 0)); });
({ word_1 tmp_9469 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9469 << 11)); });
({ word_1 tmp_9470 = ((tmp_9465(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9470 << 7)); });
({ word_1 tmp_9471 = ((tmp_9465(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9471 << 6)); });
({ word_1 tmp_9472 = parity_even((tmp_9465(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9472 << 2)); });
}
break;
case 49 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_9473 = (tmp_9451(intp) ^ (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); tmp_9474(intp, tmp_9473); });
({ word_1 tmp_9475 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9475 << 0)); });
({ word_1 tmp_9476 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9476 << 11)); });
({ word_1 tmp_9477 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9477 << 7)); });
({ word_1 tmp_9478 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9478 << 6)); });
({ word_1 tmp_9479 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9479 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_9480 = (tmp_9458(intp) ^ (intp->regs_GPR[reg])); tmp_9481(intp, tmp_9480); });
({ word_1 tmp_9482 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9482 << 0)); });
({ word_1 tmp_9483 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9483 << 11)); });
({ word_1 tmp_9484 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9484 << 7)); });
({ word_1 tmp_9485 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9485 << 6)); });
({ word_1 tmp_9486 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9486 << 2)); });
}
break;
case 48 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_9487 = (tmp_9466(intp) ^ tmp_9465(intp)); tmp_9488(intp, tmp_9487); });
({ word_1 tmp_9489 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9489 << 0)); });
({ word_1 tmp_9490 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9490 << 11)); });
({ word_1 tmp_9491 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9491 << 7)); });
({ word_1 tmp_9492 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9492 << 6)); });
({ word_1 tmp_9493 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9493 << 2)); });
}
break;
case 53 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_9494 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) ^ imm16); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_9494 << 0)); });
({ word_1 tmp_9495 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9495 << 0)); });
({ word_1 tmp_9496 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9496 << 11)); });
({ word_1 tmp_9497 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9497 << 7)); });
({ word_1 tmp_9498 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9498 << 6)); });
({ word_1 tmp_9499 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9499 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_9500 = ((intp->regs_GPR[0]) ^ imm32); ((intp->regs_GPR[0]) = tmp_9500); });
({ word_1 tmp_9501 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9501 << 0)); });
({ word_1 tmp_9502 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9502 << 11)); });
({ word_1 tmp_9503 = (((intp->regs_GPR[0]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9503 << 7)); });
({ word_1 tmp_9504 = (((intp->regs_GPR[0]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9504 << 6)); });
({ word_1 tmp_9505 = parity_even(((intp->regs_GPR[0]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9505 << 2)); });
}
break;
case 52 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_9506 = (((intp->regs_GPR[0] >> 0) & 0xFF) ^ imm8); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_9506 << 0)); });
({ word_1 tmp_9507 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9507 << 0)); });
({ word_1 tmp_9508 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9508 << 11)); });
({ word_1 tmp_9509 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9509 << 7)); });
({ word_1 tmp_9510 = ((((intp->regs_GPR[0] >> 0) & 0xFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9510 << 6)); });
({ word_1 tmp_9511 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9511 << 2)); });
}
break;
case 135 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_9512 = (((intp->regs_GPR[reg]) >> 0) & 0xFFFF);
({ word_16 tmp_9513 = tmp_9451(intp); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_9513 << 0)); });
({ word_16 tmp_9514 = tmp_9512; tmp_9474(intp, tmp_9514); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_9515 = (intp->regs_GPR[reg]);
({ word_32 tmp_9516 = tmp_9458(intp); ((intp->regs_GPR[reg]) = tmp_9516); });
({ word_32 tmp_9517 = tmp_9515; tmp_9481(intp, tmp_9517); });
})
;
}
break;
case 134 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_8 tmp_9518 = tmp_9465(intp);
({ word_8 tmp_9519 = tmp_9466(intp); tmp_9467(intp, tmp_9519); });
({ word_8 tmp_9520 = tmp_9518; tmp_9488(intp, tmp_9520); });
})
;
}
break;
case 144 :
case 145 :
case 146 :
case 147 :
case 148 :
case 149 :
case 150 :
case 151 :
opcode_reg = opcode - 144;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_9521 = ((intp->regs_GPR[0] >> 0) & 0xFFFF);
({ word_16 tmp_9522 = (((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_9522 << 0)); });
({ word_16 tmp_9523 = tmp_9521; ((intp->regs_GPR[opcode_reg]) = ((intp->regs_GPR[opcode_reg]) & 0xFFFF0000) | (tmp_9523 << 0)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_9524 = (intp->regs_GPR[0]);
({ word_32 tmp_9525 = (intp->regs_GPR[opcode_reg]); ((intp->regs_GPR[0]) = tmp_9525); });
({ word_32 tmp_9526 = tmp_9524; ((intp->regs_GPR[opcode_reg]) = tmp_9526); });
})
;
}
break;
case 133 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_9527 = (tmp_9451(intp) & (((intp->regs_GPR[reg]) >> 0) & 0xFFFF));
({ word_1 tmp_9528 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9528 << 0)); });
({ word_1 tmp_9529 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9529 << 11)); });
({ word_1 tmp_9530 = ((tmp_9527 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9530 << 7)); });
({ word_1 tmp_9531 = ((tmp_9527 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9531 << 6)); });
({ word_1 tmp_9532 = parity_even((tmp_9527 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9532 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_9533 = (tmp_9458(intp) & (intp->regs_GPR[reg]));
({ word_1 tmp_9534 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9534 << 0)); });
({ word_1 tmp_9535 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9535 << 11)); });
({ word_1 tmp_9536 = ((tmp_9533 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9536 << 7)); });
({ word_1 tmp_9537 = ((tmp_9533 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9537 << 6)); });
({ word_1 tmp_9538 = parity_even((tmp_9533 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9538 << 2)); });
})
;
}
break;
case 132 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_8 tmp_9539 = (tmp_9466(intp) & tmp_9465(intp));
({ word_1 tmp_9540 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9540 << 0)); });
({ word_1 tmp_9541 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9541 << 11)); });
({ word_1 tmp_9542 = ((tmp_9539 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9542 << 7)); });
({ word_1 tmp_9543 = ((tmp_9539 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9543 << 6)); });
({ word_1 tmp_9544 = parity_even((tmp_9539 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9544 << 2)); });
})
;
}
break;
case 169 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_9545 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) & imm16);
({ word_1 tmp_9546 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9546 << 0)); });
({ word_1 tmp_9547 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9547 << 11)); });
({ word_1 tmp_9548 = ((tmp_9545 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9548 << 7)); });
({ word_1 tmp_9549 = ((tmp_9545 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9549 << 6)); });
({ word_1 tmp_9550 = parity_even((tmp_9545 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9550 << 2)); });
})
;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_9551 = ((intp->regs_GPR[0]) & imm32);
({ word_1 tmp_9552 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9552 << 0)); });
({ word_1 tmp_9553 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9553 << 11)); });
({ word_1 tmp_9554 = ((tmp_9551 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9554 << 7)); });
({ word_1 tmp_9555 = ((tmp_9551 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9555 << 6)); });
({ word_1 tmp_9556 = parity_even((tmp_9551 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9556 << 2)); });
})
;
}
break;
case 168 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_8 tmp_9557 = (((intp->regs_GPR[0] >> 0) & 0xFF) & imm8);
({ word_1 tmp_9558 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9558 << 0)); });
({ word_1 tmp_9559 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9559 << 11)); });
({ word_1 tmp_9560 = ((tmp_9557 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9560 << 7)); });
({ word_1 tmp_9561 = ((tmp_9557 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9561 << 6)); });
({ word_1 tmp_9562 = parity_even((tmp_9557 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9562 << 2)); });
})
;
}
break;
case 43 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_9563 = subcarry_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), tmp_9451(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9563 << 0)); });
({ word_1 tmp_9564 = addoverflow_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), (((word_16)~tmp_9451(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9564 << 11)); });
({ word_16 tmp_9565 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) - tmp_9451(intp)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_9565 << 0)); });
({ word_1 tmp_9566 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9566 << 7)); });
({ word_1 tmp_9567 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9567 << 6)); });
({ word_1 tmp_9568 = parity_even(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9568 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_9569 = subcarry_32((intp->regs_GPR[reg]), tmp_9458(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9569 << 0)); });
({ word_1 tmp_9570 = addoverflow_32((intp->regs_GPR[reg]), (((word_32)~tmp_9458(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9570 << 11)); });
({ word_32 tmp_9571 = ((intp->regs_GPR[reg]) - tmp_9458(intp)); ((intp->regs_GPR[reg]) = tmp_9571); });
({ word_1 tmp_9572 = (((intp->regs_GPR[reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9572 << 7)); });
({ word_1 tmp_9573 = (((intp->regs_GPR[reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9573 << 6)); });
({ word_1 tmp_9574 = parity_even(((intp->regs_GPR[reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9574 << 2)); });
}
break;
case 42 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_9575 = subcarry_8(tmp_9465(intp), tmp_9466(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9575 << 0)); });
({ word_1 tmp_9576 = addoverflow_8(tmp_9465(intp), (((word_8)~tmp_9466(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9576 << 11)); });
({ word_8 tmp_9577 = (tmp_9465(intp) - tmp_9466(intp)); tmp_9467(intp, tmp_9577); });
({ word_1 tmp_9578 = ((tmp_9465(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9578 << 7)); });
({ word_1 tmp_9579 = ((tmp_9465(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9579 << 6)); });
({ word_1 tmp_9580 = parity_even((tmp_9465(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9580 << 2)); });
}
break;
case 41 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_9581 = subcarry_16(tmp_9451(intp), (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9581 << 0)); });
({ word_1 tmp_9582 = addoverflow_16(tmp_9451(intp), (((word_16)~(((intp->regs_GPR[reg]) >> 0) & 0xFFFF)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9582 << 11)); });
({ word_16 tmp_9583 = (tmp_9451(intp) - (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); tmp_9474(intp, tmp_9583); });
({ word_1 tmp_9584 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9584 << 7)); });
({ word_1 tmp_9585 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9585 << 6)); });
({ word_1 tmp_9586 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9586 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_9587 = subcarry_32(tmp_9458(intp), (intp->regs_GPR[reg])); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9587 << 0)); });
({ word_1 tmp_9588 = addoverflow_32(tmp_9458(intp), (((word_32)~(intp->regs_GPR[reg])) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9588 << 11)); });
({ word_32 tmp_9589 = (tmp_9458(intp) - (intp->regs_GPR[reg])); tmp_9481(intp, tmp_9589); });
({ word_1 tmp_9590 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9590 << 7)); });
({ word_1 tmp_9591 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9591 << 6)); });
({ word_1 tmp_9592 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9592 << 2)); });
}
break;
case 40 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_9593 = subcarry_8(tmp_9466(intp), tmp_9465(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9593 << 0)); });
({ word_1 tmp_9594 = addoverflow_8(tmp_9466(intp), (((word_8)~tmp_9465(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9594 << 11)); });
({ word_8 tmp_9595 = (tmp_9466(intp) - tmp_9465(intp)); tmp_9488(intp, tmp_9595); });
({ word_1 tmp_9596 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9596 << 7)); });
({ word_1 tmp_9597 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9597 << 6)); });
({ word_1 tmp_9598 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9598 << 2)); });
}
break;
case 45 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_9599 = subcarry_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9599 << 0)); });
({ word_1 tmp_9600 = addoverflow_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), (((word_16)~imm16) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9600 << 11)); });
({ word_16 tmp_9601 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) - imm16); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_9601 << 0)); });
({ word_1 tmp_9602 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9602 << 7)); });
({ word_1 tmp_9603 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9603 << 6)); });
({ word_1 tmp_9604 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9604 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_9605 = subcarry_32((intp->regs_GPR[0]), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9605 << 0)); });
({ word_1 tmp_9606 = addoverflow_32((intp->regs_GPR[0]), (((word_32)~imm32) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9606 << 11)); });
({ word_32 tmp_9607 = ((intp->regs_GPR[0]) - imm32); ((intp->regs_GPR[0]) = tmp_9607); });
({ word_1 tmp_9608 = (((intp->regs_GPR[0]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9608 << 7)); });
({ word_1 tmp_9609 = (((intp->regs_GPR[0]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9609 << 6)); });
({ word_1 tmp_9610 = parity_even(((intp->regs_GPR[0]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9610 << 2)); });
}
break;
case 44 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_9611 = subcarry_8(((intp->regs_GPR[0] >> 0) & 0xFF), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9611 << 0)); });
({ word_1 tmp_9612 = addoverflow_8(((intp->regs_GPR[0] >> 0) & 0xFF), (((word_8)~imm8) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9612 << 11)); });
({ word_8 tmp_9613 = (((intp->regs_GPR[0] >> 0) & 0xFF) - imm8); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_9613 << 0)); });
({ word_1 tmp_9614 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9614 << 7)); });
({ word_1 tmp_9615 = ((((intp->regs_GPR[0] >> 0) & 0xFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9615 << 6)); });
({ word_1 tmp_9616 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9616 << 2)); });
}
break;
case 171 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_9617 = ((intp->regs_GPR[0] >> 0) & 0xFFFF); mem_set_16(intp, (intp->regs_GPR[7]), tmp_9617); });
({ word_32 tmp_9618 = ((intp->regs_GPR[7]) + 2); ((intp->regs_GPR[7]) = tmp_9618); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_9619 = (intp->regs_GPR[0]); mem_set_32(intp, (intp->regs_GPR[7]), tmp_9619); });
({ word_32 tmp_9620 = ((intp->regs_GPR[7]) + 4); ((intp->regs_GPR[7]) = tmp_9620); });
}
break;
case 170 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_9621 = ((intp->regs_GPR[0] >> 0) & 0xFF); mem_set_8(intp, (intp->regs_GPR[7]), tmp_9621); });
({ word_32 tmp_9622 = ((intp->regs_GPR[7]) + 1); ((intp->regs_GPR[7]) = tmp_9622); });
}
break;
case 27 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_9623 = (tmp_9451(intp) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_9624 = subcarry_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), tmp_9623); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9624 << 0)); });
({ word_1 tmp_9625 = addoverflow_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), (((word_16)~tmp_9623) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9625 << 11)); });
({ word_16 tmp_9626 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) - tmp_9623); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_9626 << 0)); });
({ word_1 tmp_9627 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9627 << 7)); });
({ word_1 tmp_9628 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9628 << 6)); });
({ word_1 tmp_9629 = parity_even(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9629 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_9630 = (tmp_9458(intp) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_9631 = subcarry_32((intp->regs_GPR[reg]), tmp_9630); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9631 << 0)); });
({ word_1 tmp_9632 = addoverflow_32((intp->regs_GPR[reg]), (((word_32)~tmp_9630) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9632 << 11)); });
({ word_32 tmp_9633 = ((intp->regs_GPR[reg]) - tmp_9630); ((intp->regs_GPR[reg]) = tmp_9633); });
({ word_1 tmp_9634 = (((intp->regs_GPR[reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9634 << 7)); });
({ word_1 tmp_9635 = (((intp->regs_GPR[reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9635 << 6)); });
({ word_1 tmp_9636 = parity_even(((intp->regs_GPR[reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9636 << 2)); });
})
;
}
break;
case 26 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_8 tmp_9637 = (tmp_9466(intp) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_9638 = subcarry_8(tmp_9465(intp), tmp_9637); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9638 << 0)); });
({ word_1 tmp_9639 = addoverflow_8(tmp_9465(intp), (((word_8)~tmp_9637) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9639 << 11)); });
({ word_8 tmp_9640 = (tmp_9465(intp) - tmp_9637); tmp_9467(intp, tmp_9640); });
({ word_1 tmp_9641 = ((tmp_9465(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9641 << 7)); });
({ word_1 tmp_9642 = ((tmp_9465(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9642 << 6)); });
({ word_1 tmp_9643 = parity_even((tmp_9465(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9643 << 2)); });
})
;
}
break;
case 25 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_9644 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_9645 = subcarry_16(tmp_9451(intp), tmp_9644); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9645 << 0)); });
({ word_1 tmp_9646 = addoverflow_16(tmp_9451(intp), (((word_16)~tmp_9644) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9646 << 11)); });
({ word_16 tmp_9647 = (tmp_9451(intp) - tmp_9644); tmp_9474(intp, tmp_9647); });
({ word_1 tmp_9648 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9648 << 7)); });
({ word_1 tmp_9649 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9649 << 6)); });
({ word_1 tmp_9650 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9650 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_9651 = ((intp->regs_GPR[reg]) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_9652 = subcarry_32(tmp_9458(intp), tmp_9651); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9652 << 0)); });
({ word_1 tmp_9653 = addoverflow_32(tmp_9458(intp), (((word_32)~tmp_9651) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9653 << 11)); });
({ word_32 tmp_9654 = (tmp_9458(intp) - tmp_9651); tmp_9481(intp, tmp_9654); });
({ word_1 tmp_9655 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9655 << 7)); });
({ word_1 tmp_9656 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9656 << 6)); });
({ word_1 tmp_9657 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9657 << 2)); });
})
;
}
break;
case 24 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_8 tmp_9658 = (tmp_9465(intp) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_9659 = subcarry_8(tmp_9466(intp), tmp_9658); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9659 << 0)); });
({ word_1 tmp_9660 = addoverflow_8(tmp_9466(intp), (((word_8)~tmp_9658) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9660 << 11)); });
({ word_8 tmp_9661 = (tmp_9466(intp) - tmp_9658); tmp_9488(intp, tmp_9661); });
({ word_1 tmp_9662 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9662 << 7)); });
({ word_1 tmp_9663 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9663 << 6)); });
({ word_1 tmp_9664 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9664 << 2)); });
})
;
}
break;
case 29 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_9665 = (imm16 + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_9666 = subcarry_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), tmp_9665); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9666 << 0)); });
({ word_1 tmp_9667 = addoverflow_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), (((word_16)~tmp_9665) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9667 << 11)); });
({ word_16 tmp_9668 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) - tmp_9665); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_9668 << 0)); });
({ word_1 tmp_9669 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9669 << 7)); });
({ word_1 tmp_9670 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9670 << 6)); });
({ word_1 tmp_9671 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9671 << 2)); });
})
;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_9672 = (imm32 + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_9673 = subcarry_32((intp->regs_GPR[0]), tmp_9672); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9673 << 0)); });
({ word_1 tmp_9674 = addoverflow_32((intp->regs_GPR[0]), (((word_32)~tmp_9672) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9674 << 11)); });
({ word_32 tmp_9675 = ((intp->regs_GPR[0]) - tmp_9672); ((intp->regs_GPR[0]) = tmp_9675); });
({ word_1 tmp_9676 = (((intp->regs_GPR[0]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9676 << 7)); });
({ word_1 tmp_9677 = (((intp->regs_GPR[0]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9677 << 6)); });
({ word_1 tmp_9678 = parity_even(((intp->regs_GPR[0]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9678 << 2)); });
})
;
}
break;
case 28 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_8 tmp_9679 = (imm8 + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_9680 = subcarry_8(((intp->regs_GPR[0] >> 0) & 0xFF), tmp_9679); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9680 << 0)); });
({ word_1 tmp_9681 = addoverflow_8(((intp->regs_GPR[0] >> 0) & 0xFF), (((word_8)~tmp_9679) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9681 << 11)); });
({ word_8 tmp_9682 = (((intp->regs_GPR[0] >> 0) & 0xFF) - tmp_9679); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_9682 << 0)); });
({ word_1 tmp_9683 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9683 << 7)); });
({ word_1 tmp_9684 = ((((intp->regs_GPR[0] >> 0) & 0xFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9684 << 6)); });
({ word_1 tmp_9685 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9685 << 2)); });
})
;
}
break;
case 209 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_32 tmp_9686 = (1 & 31);
({ word_1 tmp_9687 = ((tmp_9451(intp) & (1 << tmp_9686)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9687 << 0)); });
({ word_16 tmp_9688 = (tmp_9451(intp) >> tmp_9686); tmp_9474(intp, tmp_9688); });
({ word_1 tmp_9689 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9451(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9689 << 11)); });
({ word_1 tmp_9690 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9690 << 7)); });
({ word_1 tmp_9691 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9691 << 6)); });
({ word_1 tmp_9692 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9692 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_9693 = (1 & 31);
({ word_1 tmp_9694 = ((tmp_9458(intp) & (1 << tmp_9693)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9694 << 0)); });
({ word_32 tmp_9695 = (tmp_9458(intp) >> tmp_9693); tmp_9481(intp, tmp_9695); });
({ word_1 tmp_9696 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9458(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9696 << 11)); });
({ word_1 tmp_9697 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9697 << 7)); });
({ word_1 tmp_9698 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9698 << 6)); });
({ word_1 tmp_9699 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9699 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_32 tmp_9700 = (1 & 31);
({ word_1 tmp_9701 = ((tmp_9451(intp) & (1 << (16 - tmp_9700))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9701 << 0)); });
({ word_16 tmp_9702 = (tmp_9451(intp) << tmp_9700); tmp_9474(intp, tmp_9702); });
({ word_1 tmp_9703 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9703 << 11)); });
({ word_1 tmp_9704 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9704 << 7)); });
({ word_1 tmp_9705 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9705 << 6)); });
({ word_1 tmp_9706 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9706 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_9707 = (1 & 31);
({ word_1 tmp_9708 = ((tmp_9458(intp) & (1 << (32 - tmp_9707))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9708 << 0)); });
({ word_32 tmp_9709 = (tmp_9458(intp) << tmp_9707); tmp_9481(intp, tmp_9709); });
({ word_1 tmp_9710 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9710 << 11)); });
({ word_1 tmp_9711 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9711 << 7)); });
({ word_1 tmp_9712 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9712 << 6)); });
({ word_1 tmp_9713 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9713 << 2)); });
})
;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_9714 = ((tmp_9451(intp) >> (1 & 31)) | ((tmp_9451(intp) & (1 << 15)) ? ~((1 << (16 - (1 & 31))) - 1) : 0)); tmp_9474(intp, tmp_9714); });
({ word_1 tmp_9715 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9715 << 7)); });
({ word_1 tmp_9716 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9716 << 6)); });
({ word_1 tmp_9717 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9717 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_9718 = ((tmp_9458(intp) >> (1 & 31)) | ((tmp_9458(intp) & (1 << 31)) ? ~((1 << (32 - (1 & 31))) - 1) : 0)); tmp_9481(intp, tmp_9718); });
({ word_1 tmp_9719 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9719 << 7)); });
({ word_1 tmp_9720 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9720 << 6)); });
({ word_1 tmp_9721 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9721 << 2)); });
}
break;
default :
assert(0);
}
}
break;
case 192 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_9722 = (imm8 & 31);
({ word_1 tmp_9723 = ((tmp_9466(intp) & (1 << tmp_9722)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9723 << 0)); });
({ word_8 tmp_9724 = (tmp_9466(intp) >> tmp_9722); tmp_9488(intp, tmp_9724); });
({ word_1 tmp_9725 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9466(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9725 << 11)); });
({ word_1 tmp_9726 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9726 << 7)); });
({ word_1 tmp_9727 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9727 << 6)); });
({ word_1 tmp_9728 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9728 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_9729 = (imm8 & 31);
({ word_1 tmp_9730 = ((tmp_9466(intp) & (1 << (8 - tmp_9729))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9730 << 0)); });
({ word_8 tmp_9731 = (tmp_9466(intp) << tmp_9729); tmp_9488(intp, tmp_9731); });
({ word_1 tmp_9732 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9732 << 11)); });
({ word_1 tmp_9733 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9733 << 7)); });
({ word_1 tmp_9734 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9734 << 6)); });
({ word_1 tmp_9735 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9735 << 2)); });
})
;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_9736 = ((tmp_9466(intp) >> (imm8 & 31)) | ((tmp_9466(intp) & (1 << 7)) ? ~((1 << (8 - (imm8 & 31))) - 1) : 0)); tmp_9488(intp, tmp_9736); });
({ word_1 tmp_9737 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9737 << 7)); });
({ word_1 tmp_9738 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9738 << 6)); });
({ word_1 tmp_9739 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9739 << 2)); });
}
break;
default :
assert(0);
}
}
break;
case 210 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_9740 = (((intp->regs_GPR[1] >> 0) & 0xFF) & 31);
({ word_1 tmp_9741 = ((tmp_9466(intp) & (1 << tmp_9740)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9741 << 0)); });
({ word_8 tmp_9742 = (tmp_9466(intp) >> tmp_9740); tmp_9488(intp, tmp_9742); });
({ word_1 tmp_9743 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9466(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9743 << 11)); });
({ word_1 tmp_9744 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9744 << 7)); });
({ word_1 tmp_9745 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9745 << 6)); });
({ word_1 tmp_9746 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9746 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_9747 = (((intp->regs_GPR[1] >> 0) & 0xFF) & 31);
({ word_1 tmp_9748 = ((tmp_9466(intp) & (1 << (8 - tmp_9747))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9748 << 0)); });
({ word_8 tmp_9749 = (tmp_9466(intp) << tmp_9747); tmp_9488(intp, tmp_9749); });
({ word_1 tmp_9750 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9750 << 11)); });
({ word_1 tmp_9751 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9751 << 7)); });
({ word_1 tmp_9752 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9752 << 6)); });
({ word_1 tmp_9753 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9753 << 2)); });
})
;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_9754 = ((tmp_9466(intp) >> (((intp->regs_GPR[1] >> 0) & 0xFF) & 31)) | ((tmp_9466(intp) & (1 << 7)) ? ~((1 << (8 - (((intp->regs_GPR[1] >> 0) & 0xFF) & 31))) - 1) : 0)); tmp_9488(intp, tmp_9754); });
({ word_1 tmp_9755 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9755 << 7)); });
({ word_1 tmp_9756 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9756 << 6)); });
({ word_1 tmp_9757 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9757 << 2)); });
}
break;
default :
assert(0);
}
}
break;
case 208 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_9758 = (1 & 31);
({ word_1 tmp_9759 = ((tmp_9466(intp) & (1 << tmp_9758)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9759 << 0)); });
({ word_8 tmp_9760 = (tmp_9466(intp) >> tmp_9758); tmp_9488(intp, tmp_9760); });
({ word_1 tmp_9761 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9466(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9761 << 11)); });
({ word_1 tmp_9762 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9762 << 7)); });
({ word_1 tmp_9763 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9763 << 6)); });
({ word_1 tmp_9764 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9764 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_9765 = (1 & 31);
({ word_1 tmp_9766 = ((tmp_9466(intp) & (1 << (8 - tmp_9765))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9766 << 0)); });
({ word_8 tmp_9767 = (tmp_9466(intp) << tmp_9765); tmp_9488(intp, tmp_9767); });
({ word_1 tmp_9768 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9768 << 11)); });
({ word_1 tmp_9769 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9769 << 7)); });
({ word_1 tmp_9770 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9770 << 6)); });
({ word_1 tmp_9771 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9771 << 2)); });
})
;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_9772 = ((tmp_9466(intp) >> (1 & 31)) | ((tmp_9466(intp) & (1 << 7)) ? ~((1 << (8 - (1 & 31))) - 1) : 0)); tmp_9488(intp, tmp_9772); });
({ word_1 tmp_9773 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9773 << 7)); });
({ word_1 tmp_9774 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9774 << 6)); });
({ word_1 tmp_9775 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9775 << 2)); });
}
break;
default :
assert(0);
}
}
break;
case 193 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_9776 = (imm8 & 31);
({ word_1 tmp_9777 = ((tmp_9451(intp) & (1 << tmp_9776)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9777 << 0)); });
({ word_16 tmp_9778 = (tmp_9451(intp) >> tmp_9776); tmp_9474(intp, tmp_9778); });
({ word_1 tmp_9779 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9451(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9779 << 11)); });
({ word_1 tmp_9780 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9780 << 7)); });
({ word_1 tmp_9781 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9781 << 6)); });
({ word_1 tmp_9782 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9782 << 2)); });
})
;
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_9783 = (imm8 & 31);
({ word_1 tmp_9784 = ((tmp_9458(intp) & (1 << tmp_9783)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9784 << 0)); });
({ word_32 tmp_9785 = (tmp_9458(intp) >> tmp_9783); tmp_9481(intp, tmp_9785); });
({ word_1 tmp_9786 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9458(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9786 << 11)); });
({ word_1 tmp_9787 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9787 << 7)); });
({ word_1 tmp_9788 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9788 << 6)); });
({ word_1 tmp_9789 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9789 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_9790 = (imm8 & 31);
({ word_1 tmp_9791 = ((tmp_9451(intp) & (1 << (16 - tmp_9790))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9791 << 0)); });
({ word_16 tmp_9792 = (tmp_9451(intp) << tmp_9790); tmp_9474(intp, tmp_9792); });
({ word_1 tmp_9793 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9793 << 11)); });
({ word_1 tmp_9794 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9794 << 7)); });
({ word_1 tmp_9795 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9795 << 6)); });
({ word_1 tmp_9796 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9796 << 2)); });
})
;
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_9797 = (imm8 & 31);
({ word_1 tmp_9798 = ((tmp_9458(intp) & (1 << (32 - tmp_9797))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9798 << 0)); });
({ word_32 tmp_9799 = (tmp_9458(intp) << tmp_9797); tmp_9481(intp, tmp_9799); });
({ word_1 tmp_9800 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9800 << 11)); });
({ word_1 tmp_9801 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9801 << 7)); });
({ word_1 tmp_9802 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9802 << 6)); });
({ word_1 tmp_9803 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9803 << 2)); });
})
;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_9804 = ((tmp_9451(intp) >> (imm8 & 31)) | ((tmp_9451(intp) & (1 << 15)) ? ~((1 << (16 - (imm8 & 31))) - 1) : 0)); tmp_9474(intp, tmp_9804); });
({ word_1 tmp_9805 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9805 << 7)); });
({ word_1 tmp_9806 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9806 << 6)); });
({ word_1 tmp_9807 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9807 << 2)); });
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_9808 = ((tmp_9458(intp) >> (imm8 & 31)) | ((tmp_9458(intp) & (1 << 31)) ? ~((1 << (32 - (imm8 & 31))) - 1) : 0)); tmp_9481(intp, tmp_9808); });
({ word_1 tmp_9809 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9809 << 7)); });
({ word_1 tmp_9810 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9810 << 6)); });
({ word_1 tmp_9811 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9811 << 2)); });
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_9812 = (imm8 & (16 - 1));
({ word_16 tmp_9813 = rotl_16(tmp_9451(intp), (16 - tmp_9812)); tmp_9474(intp, tmp_9813); });
({ word_1 tmp_9814 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9814 << 0)); });
((tmp_9812 == 1) ? ({ word_1 tmp_9815 = ((((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0) ^ ((tmp_9451(intp) & (1 << (16 - 2))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9815 << 11)); }) : 0 /* nop */);
})
;
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_9816 = (imm8 & (32 - 1));
({ word_32 tmp_9817 = rotl_32(tmp_9458(intp), (32 - tmp_9816)); tmp_9481(intp, tmp_9817); });
({ word_1 tmp_9818 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9818 << 0)); });
((tmp_9816 == 1) ? ({ word_1 tmp_9819 = ((((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0) ^ ((tmp_9458(intp) & (1 << (32 - 2))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9819 << 11)); }) : 0 /* nop */);
})
;
}
break;
default :
assert(0);
}
}
break;
case 211 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_32 tmp_9820 = (((intp->regs_GPR[1] >> 0) & 0xFF) & 31);
({ word_1 tmp_9821 = ((tmp_9451(intp) & (1 << tmp_9820)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9821 << 0)); });
({ word_16 tmp_9822 = (tmp_9451(intp) >> tmp_9820); tmp_9474(intp, tmp_9822); });
({ word_1 tmp_9823 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9451(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9823 << 11)); });
({ word_1 tmp_9824 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9824 << 7)); });
({ word_1 tmp_9825 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9825 << 6)); });
({ word_1 tmp_9826 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9826 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_9827 = (((intp->regs_GPR[1] >> 0) & 0xFF) & 31);
({ word_1 tmp_9828 = ((tmp_9458(intp) & (1 << tmp_9827)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9828 << 0)); });
({ word_32 tmp_9829 = (tmp_9458(intp) >> tmp_9827); tmp_9481(intp, tmp_9829); });
({ word_1 tmp_9830 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9458(intp) & (1 << 0)) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9830 << 11)); });
({ word_1 tmp_9831 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9831 << 7)); });
({ word_1 tmp_9832 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9832 << 6)); });
({ word_1 tmp_9833 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9833 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_32 tmp_9834 = (((intp->regs_GPR[1] >> 0) & 0xFF) & 31);
({ word_1 tmp_9835 = ((tmp_9451(intp) & (1 << (16 - tmp_9834))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9835 << 0)); });
({ word_16 tmp_9836 = (tmp_9451(intp) << tmp_9834); tmp_9474(intp, tmp_9836); });
({ word_1 tmp_9837 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9837 << 11)); });
({ word_1 tmp_9838 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9838 << 7)); });
({ word_1 tmp_9839 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9839 << 6)); });
({ word_1 tmp_9840 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9840 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_9841 = (((intp->regs_GPR[1] >> 0) & 0xFF) & 31);
({ word_1 tmp_9842 = ((tmp_9458(intp) & (1 << (32 - tmp_9841))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9842 << 0)); });
({ word_32 tmp_9843 = (tmp_9458(intp) << tmp_9841); tmp_9481(intp, tmp_9843); });
({ word_1 tmp_9844 = ((((intp->regs_SPR[0] >> 0) & 0x1) & ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9844 << 11)); });
({ word_1 tmp_9845 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9845 << 7)); });
({ word_1 tmp_9846 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9846 << 6)); });
({ word_1 tmp_9847 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9847 << 2)); });
})
;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_9848 = ((tmp_9451(intp) >> (((intp->regs_GPR[1] >> 0) & 0xFF) & 31)) | ((tmp_9451(intp) & (1 << 15)) ? ~((1 << (16 - (((intp->regs_GPR[1] >> 0) & 0xFF) & 31))) - 1) : 0)); tmp_9474(intp, tmp_9848); });
({ word_1 tmp_9849 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9849 << 7)); });
({ word_1 tmp_9850 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9850 << 6)); });
({ word_1 tmp_9851 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9851 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_9852 = ((tmp_9458(intp) >> (((intp->regs_GPR[1] >> 0) & 0xFF) & 31)) | ((tmp_9458(intp) & (1 << 31)) ? ~((1 << (32 - (((intp->regs_GPR[1] >> 0) & 0xFF) & 31))) - 1) : 0)); tmp_9481(intp, tmp_9852); });
({ word_1 tmp_9853 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9853 << 7)); });
({ word_1 tmp_9854 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9854 << 6)); });
({ word_1 tmp_9855 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9855 << 2)); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_32 tmp_9856 = (((intp->regs_GPR[1] >> 0) & 0xFF) & (16 - 1));
({ word_16 tmp_9857 = rotl_16(tmp_9451(intp), tmp_9856); tmp_9474(intp, tmp_9857); });
({ word_1 tmp_9858 = ((tmp_9451(intp) & (1 << 0)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9858 << 0)); });
((tmp_9856 == 1) ? ({ word_1 tmp_9859 = ((((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0) ^ ((intp->regs_SPR[0] >> 0) & 0x1)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9859 << 11)); }) : 0 /* nop */);
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_9860 = (((intp->regs_GPR[1] >> 0) & 0xFF) & (32 - 1));
({ word_32 tmp_9861 = rotl_32(tmp_9458(intp), tmp_9860); tmp_9481(intp, tmp_9861); });
({ word_1 tmp_9862 = ((tmp_9458(intp) & (1 << 0)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9862 << 0)); });
((tmp_9860 == 1) ? ({ word_1 tmp_9863 = ((((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0) ^ ((intp->regs_SPR[0] >> 0) & 0x1)) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9863 << 11)); }) : 0 /* nop */);
})
;
}
break;
default :
assert(0);
}
}
break;
case 194 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
({ word_32 tmp_9864 = (((intp->regs_GPR[4]) + imm16) + 4); ((intp->regs_GPR[4]) = tmp_9864); });
(next_pc = mem_get_32(intp, (((intp->regs_GPR[4]) - imm16) - 4)));
}
break;
case 195 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
intp->have_jumped = 1;
({ word_32 tmp_9865 = ((intp->regs_GPR[4]) + 4); ((intp->regs_GPR[4]) = tmp_9865); });
(next_pc = mem_get_32(intp, ((intp->regs_GPR[4]) - 4)));
}
break;
case 242 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 174 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
(((intp->regs_GPR[1]) == 0) ? 0 /* nop */ : 
({ do {
({
word_8 tmp_9866 = (((intp->regs_GPR[0] >> 0) & 0xFF) - mem_get_8(intp, (intp->regs_GPR[7])));
({ word_1 tmp_9867 = subcarry_8(((intp->regs_GPR[0] >> 0) & 0xFF), mem_get_8(intp, (intp->regs_GPR[7]))); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9867 << 0)); });
({ word_1 tmp_9868 = ((tmp_9866 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9868 << 6)); });
({ word_1 tmp_9869 = ((tmp_9866 & (1 << 7)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9869 << 7)); });
})
;
({ word_32 tmp_9870 = ((intp->regs_GPR[7]) + 1); ((intp->regs_GPR[7]) = tmp_9870); });
({ word_32 tmp_9871 = ((intp->regs_GPR[1]) - 1); ((intp->regs_GPR[1]) = tmp_9871); });
} while (((((intp->regs_SPR[0] >> 6) & 0x1) == 0) && (!((intp->regs_GPR[1]) == 0)))); })
);
}
break;
default :
switch (reg) {
default :
assert(0);
}
}
break;
case 243 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 171 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
(((intp->regs_GPR[1]) == 0) ? 0 /* nop */ : 
({ do {
({ word_32 tmp_9872 = (intp->regs_GPR[0]); mem_set_32(intp, (intp->regs_GPR[7]), tmp_9872); });
({ word_32 tmp_9873 = ((intp->regs_GPR[7]) + 4); ((intp->regs_GPR[7]) = tmp_9873); });
({ word_32 tmp_9874 = ((intp->regs_GPR[1]) - 1); ((intp->regs_GPR[1]) = tmp_9874); });
} while ((!((intp->regs_GPR[1]) == 0))); })
);
}
break;
case 170 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
(((intp->regs_GPR[1]) == 0) ? 0 /* nop */ : 
({ do {
({ word_8 tmp_9875 = ((intp->regs_GPR[0] >> 0) & 0xFF); mem_set_8(intp, (intp->regs_GPR[7]), tmp_9875); });
({ word_32 tmp_9876 = ((intp->regs_GPR[7]) + 1); ((intp->regs_GPR[7]) = tmp_9876); });
({ word_32 tmp_9877 = ((intp->regs_GPR[1]) - 1); ((intp->regs_GPR[1]) = tmp_9877); });
} while ((!((intp->regs_GPR[1]) == 0))); })
);
}
break;
case 165 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
(((intp->regs_GPR[1]) == 0) ? 0 /* nop */ : 
({ do {
({ word_32 tmp_9878 = mem_get_32(intp, (intp->regs_GPR[6])); mem_set_32(intp, (intp->regs_GPR[7]), tmp_9878); });
({ word_32 tmp_9879 = ((intp->regs_GPR[6]) + 4); ((intp->regs_GPR[6]) = tmp_9879); });
({ word_32 tmp_9880 = ((intp->regs_GPR[7]) + 4); ((intp->regs_GPR[7]) = tmp_9880); });
({ word_32 tmp_9881 = ((intp->regs_GPR[1]) - 1); ((intp->regs_GPR[1]) = tmp_9881); });
} while ((!((intp->regs_GPR[1]) == 0))); })
);
}
break;
case 164 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
(((intp->regs_GPR[1]) == 0) ? 0 /* nop */ : 
({ do {
({ word_8 tmp_9882 = mem_get_8(intp, (intp->regs_GPR[6])); mem_set_8(intp, (intp->regs_GPR[7]), tmp_9882); });
({ word_32 tmp_9883 = ((intp->regs_GPR[6]) + 1); ((intp->regs_GPR[6]) = tmp_9883); });
({ word_32 tmp_9884 = ((intp->regs_GPR[7]) + 1); ((intp->regs_GPR[7]) = tmp_9884); });
({ word_32 tmp_9885 = ((intp->regs_GPR[1]) - 1); ((intp->regs_GPR[1]) = tmp_9885); });
} while ((!((intp->regs_GPR[1]) == 0))); })
);
}
break;
case 166 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
(((intp->regs_GPR[1]) == 0) ? 0 /* nop */ : 
({ do {
({
word_8 tmp_9886 = mem_get_8(intp, (intp->regs_GPR[6]));
word_8 tmp_9887 = mem_get_8(intp, (intp->regs_GPR[7]));
({
word_8 tmp_9888 = (tmp_9886 - tmp_9887);
({ word_1 tmp_9889 = subcarry_8(tmp_9886, tmp_9887); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9889 << 0)); });
({ word_1 tmp_9890 = ((tmp_9888 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9890 << 6)); });
({ word_1 tmp_9891 = ((tmp_9888 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9891 << 7)); });
({ word_1 tmp_9892 = addoverflow_8(tmp_9886, (((word_8)~tmp_9887) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9892 << 11)); });
})
;
})
;
({ word_32 tmp_9893 = ((intp->regs_GPR[6]) + 1); ((intp->regs_GPR[6]) = tmp_9893); });
({ word_32 tmp_9894 = ((intp->regs_GPR[7]) + 1); ((intp->regs_GPR[7]) = tmp_9894); });
({ word_32 tmp_9895 = ((intp->regs_GPR[1]) - 1); ((intp->regs_GPR[1]) = tmp_9895); });
} while (((((intp->regs_SPR[0] >> 6) & 0x1) == 1) && (!((intp->regs_GPR[1]) == 0)))); })
);
}
break;
default :
switch (reg) {
default :
assert(0);
}
}
break;
case 104 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_9896 = imm32; mem_set_32(intp, ((intp->regs_GPR[4]) - 4), tmp_9896); });
({ word_32 tmp_9897 = ((intp->regs_GPR[4]) - 4); ((intp->regs_GPR[4]) = tmp_9897); });
}
break;
case 106 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_9898 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8); mem_set_32(intp, ((intp->regs_GPR[4]) - 4), tmp_9898); });
({ word_32 tmp_9899 = ((intp->regs_GPR[4]) - 4); ((intp->regs_GPR[4]) = tmp_9899); });
}
break;
case 80 :
case 81 :
case 82 :
case 83 :
case 84 :
case 85 :
case 86 :
case 87 :
opcode_reg = opcode - 80;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_9900 = (intp->regs_GPR[opcode_reg]); mem_set_32(intp, ((intp->regs_GPR[4]) - 4), tmp_9900); });
({ word_32 tmp_9901 = ((intp->regs_GPR[4]) - 4); ((intp->regs_GPR[4]) = tmp_9901); });
}
break;
case 88 :
case 89 :
case 90 :
case 91 :
case 92 :
case 93 :
case 94 :
case 95 :
opcode_reg = opcode - 88;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_9902 = ((intp->regs_GPR[4]) + 4); ((intp->regs_GPR[4]) = tmp_9902); });
({ word_32 tmp_9903 = mem_get_32(intp, ((intp->regs_GPR[4]) - 4)); ((intp->regs_GPR[opcode_reg]) = tmp_9903); });
}
break;
case 143 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_9904 = ((intp->regs_GPR[4]) + 4); ((intp->regs_GPR[4]) = tmp_9904); });
({ word_32 tmp_9905 = mem_get_32(intp, ((intp->regs_GPR[4]) - 4)); tmp_9481(intp, tmp_9905); });
}
break;
default :
assert(0);
}
}
break;
case 11 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_9906 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) | tmp_9451(intp)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_9906 << 0)); });
({ word_1 tmp_9907 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9907 << 0)); });
({ word_1 tmp_9908 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9908 << 11)); });
({ word_1 tmp_9909 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9909 << 7)); });
({ word_1 tmp_9910 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9910 << 6)); });
({ word_1 tmp_9911 = parity_even(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9911 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_9912 = ((intp->regs_GPR[reg]) | tmp_9458(intp)); ((intp->regs_GPR[reg]) = tmp_9912); });
({ word_1 tmp_9913 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9913 << 0)); });
({ word_1 tmp_9914 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9914 << 11)); });
({ word_1 tmp_9915 = (((intp->regs_GPR[reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9915 << 7)); });
({ word_1 tmp_9916 = (((intp->regs_GPR[reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9916 << 6)); });
({ word_1 tmp_9917 = parity_even(((intp->regs_GPR[reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9917 << 2)); });
}
break;
case 10 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_9918 = (tmp_9465(intp) | tmp_9466(intp)); tmp_9467(intp, tmp_9918); });
({ word_1 tmp_9919 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9919 << 0)); });
({ word_1 tmp_9920 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9920 << 11)); });
({ word_1 tmp_9921 = ((tmp_9465(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9921 << 7)); });
({ word_1 tmp_9922 = ((tmp_9465(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9922 << 6)); });
({ word_1 tmp_9923 = parity_even((tmp_9465(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9923 << 2)); });
}
break;
case 9 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_9924 = (tmp_9451(intp) | (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); tmp_9474(intp, tmp_9924); });
({ word_1 tmp_9925 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9925 << 0)); });
({ word_1 tmp_9926 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9926 << 11)); });
({ word_1 tmp_9927 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9927 << 7)); });
({ word_1 tmp_9928 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9928 << 6)); });
({ word_1 tmp_9929 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9929 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_9930 = (tmp_9458(intp) | (intp->regs_GPR[reg])); tmp_9481(intp, tmp_9930); });
({ word_1 tmp_9931 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9931 << 0)); });
({ word_1 tmp_9932 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9932 << 11)); });
({ word_1 tmp_9933 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9933 << 7)); });
({ word_1 tmp_9934 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9934 << 6)); });
({ word_1 tmp_9935 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9935 << 2)); });
}
break;
case 8 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_9936 = (tmp_9466(intp) | tmp_9465(intp)); tmp_9488(intp, tmp_9936); });
({ word_1 tmp_9937 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9937 << 0)); });
({ word_1 tmp_9938 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9938 << 11)); });
({ word_1 tmp_9939 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9939 << 7)); });
({ word_1 tmp_9940 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9940 << 6)); });
({ word_1 tmp_9941 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9941 << 2)); });
}
break;
case 13 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_9942 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) | imm16); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_9942 << 0)); });
({ word_1 tmp_9943 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9943 << 0)); });
({ word_1 tmp_9944 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9944 << 11)); });
({ word_1 tmp_9945 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9945 << 7)); });
({ word_1 tmp_9946 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9946 << 6)); });
({ word_1 tmp_9947 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9947 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_9948 = ((intp->regs_GPR[0]) | imm32); ((intp->regs_GPR[0]) = tmp_9948); });
({ word_1 tmp_9949 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9949 << 0)); });
({ word_1 tmp_9950 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9950 << 11)); });
({ word_1 tmp_9951 = (((intp->regs_GPR[0]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9951 << 7)); });
({ word_1 tmp_9952 = (((intp->regs_GPR[0]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9952 << 6)); });
({ word_1 tmp_9953 = parity_even(((intp->regs_GPR[0]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9953 << 2)); });
}
break;
case 12 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_9954 = (((intp->regs_GPR[0] >> 0) & 0xFF) | imm8); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_9954 << 0)); });
({ word_1 tmp_9955 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9955 << 0)); });
({ word_1 tmp_9956 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9956 << 11)); });
({ word_1 tmp_9957 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9957 << 7)); });
({ word_1 tmp_9958 = ((((intp->regs_GPR[0] >> 0) & 0xFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9958 << 6)); });
({ word_1 tmp_9959 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9959 << 2)); });
}
break;
case 199 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_9960 = imm16; tmp_9474(intp, tmp_9960); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_9961 = imm32; tmp_9481(intp, tmp_9961); });
}
break;
default :
assert(0);
}
}
break;
case 198 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_9962 = imm8; tmp_9488(intp, tmp_9962); });
}
break;
default :
assert(0);
}
}
break;
case 184 :
case 185 :
case 186 :
case 187 :
case 188 :
case 189 :
case 190 :
case 191 :
opcode_reg = opcode - 184;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_9963 = imm16; ((intp->regs_GPR[opcode_reg]) = ((intp->regs_GPR[opcode_reg]) & 0xFFFF0000) | (tmp_9963 << 0)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_9964 = imm32; ((intp->regs_GPR[opcode_reg]) = tmp_9964); });
}
break;
case 176 :
case 177 :
case 178 :
case 179 :
case 180 :
case 181 :
case 182 :
case 183 :
opcode_reg = opcode - 176;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_9965 = imm8; tmp_9966(intp, tmp_9965); });
}
break;
case 163 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_9967 = ((intp->regs_GPR[0] >> 0) & 0xFFFF); mem_set_16(intp, imm32, tmp_9967); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_9968 = (intp->regs_GPR[0]); mem_set_32(intp, imm32, tmp_9968); });
}
break;
case 161 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_9969 = mem_get_16(intp, imm32); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_9969 << 0)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_9970 = mem_get_32(intp, imm32); ((intp->regs_GPR[0]) = tmp_9970); });
}
break;
case 139 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_9971 = tmp_9451(intp); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_9971 << 0)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_9972 = tmp_9458(intp); ((intp->regs_GPR[reg]) = tmp_9972); });
}
break;
case 138 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_9973 = tmp_9466(intp); tmp_9467(intp, tmp_9973); });
}
break;
case 137 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_9974 = (((intp->regs_GPR[reg]) >> 0) & 0xFFFF); tmp_9474(intp, tmp_9974); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_9975 = (intp->regs_GPR[reg]); tmp_9481(intp, tmp_9975); });
}
break;
case 136 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_9976 = tmp_9465(intp); tmp_9488(intp, tmp_9976); });
}
break;
case 141 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_9977 = tmp_9978(intp); ((intp->regs_GPR[reg]) = tmp_9977); });
}
break;
case 120 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == 1) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 122 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 2) & 0x1) == 1) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 121 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == 0) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 123 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 2) & 0x1) == 0) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 117 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 6) & 0x1) == 0) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 233 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(next_pc = (pc + imm32));
}
break;
case 235 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)));
}
break;
case 126 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 6) & 0x1) == 1) || (!(((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)))) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 124 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)) ? 0 /* nop */ : (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))));
}
break;
case 125 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 127 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 6) & 0x1) == 0) && (((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1))) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 116 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 6) & 0x1) == 1) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 118 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 0) & 0x1) == 1) || (((intp->regs_SPR[0] >> 6) & 0x1) == 1)) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 114 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 0) & 0x1) == 1) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 115 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 0) & 0x1) == 0) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 119 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 0) & 0x1) == 0) && (((intp->regs_SPR[0] >> 6) & 0x1) == 0)) ? (next_pc = (pc + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8))) : 0 /* nop */);
}
break;
case 205 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
handle_system_call(intp);
}
break;
case 64 :
case 65 :
case 66 :
case 67 :
case 68 :
case 69 :
case 70 :
case 71 :
opcode_reg = opcode - 64;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_9979 = addoverflow_16((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9979 << 11)); });
({ word_16 tmp_9980 = ((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) + 1); ((intp->regs_GPR[opcode_reg]) = ((intp->regs_GPR[opcode_reg]) & 0xFFFF0000) | (tmp_9980 << 0)); });
({ word_1 tmp_9981 = (((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9981 << 7)); });
({ word_1 tmp_9982 = (((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9982 << 6)); });
({ word_1 tmp_9983 = parity_even(((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9983 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_9984 = addoverflow_32((intp->regs_GPR[opcode_reg]), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9984 << 11)); });
({ word_32 tmp_9985 = ((intp->regs_GPR[opcode_reg]) + 1); ((intp->regs_GPR[opcode_reg]) = tmp_9985); });
({ word_1 tmp_9986 = (((intp->regs_GPR[opcode_reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_9986 << 7)); });
({ word_1 tmp_9987 = (((intp->regs_GPR[opcode_reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_9987 << 6)); });
({ word_1 tmp_9988 = parity_even(((intp->regs_GPR[opcode_reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_9988 << 2)); });
}
break;
case 105 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_9989 = ((word_16)((((imm16 & 0x8000) ? ((word_32)imm16 | 0xFFFF0000) : (word_32)imm16) * ((tmp_9451(intp) & 0x8000) ? ((word_32)tmp_9451(intp) | 0xFFFF0000) : (word_32)tmp_9451(intp))) >> 16));
({ word_1 tmp_9990 = (((tmp_9989 == 0) || (tmp_9989 == ((word_16)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9990 << 0)); });
({ word_1 tmp_9991 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9991 << 11)); });
})
;
({ word_16 tmp_9992 = (imm16 * tmp_9451(intp)); tmp_9474(intp, tmp_9992); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_9993 = ((word_32)((((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32) * ((tmp_9458(intp) & 0x80000000) ? ((word_64)tmp_9458(intp) | 0xFFFFFFFF00000000) : (word_64)tmp_9458(intp))) >> 32));
({ word_1 tmp_9994 = (((tmp_9993 == 0) || (tmp_9993 == ((word_32)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_9994 << 0)); });
({ word_1 tmp_9995 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_9995 << 11)); });
})
;
({ word_32 tmp_9996 = (imm32 * tmp_9458(intp)); tmp_9481(intp, tmp_9996); });
}
break;
case 221 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 232 :
case 233 :
case 234 :
case 235 :
case 236 :
case 237 :
case 238 :
case 239 :
opcode_reg = opcode2 - 232;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_9997 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_9997 << 8)); });
({ word_1 tmp_9998 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_9998 << 10)); });
({ word_1 tmp_9999 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_9999 << 14)); });
({ word_3 tmp_10000 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10000 << 11)); });
}
break;
case 224 :
case 225 :
case 226 :
case 227 :
case 228 :
case 229 :
case 230 :
case 231 :
opcode_reg = opcode2 - 224;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10001 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_10001 << 8)); });
({ word_1 tmp_10002 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_10002 << 10)); });
({ word_1 tmp_10003 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_10003 << 14)); });
}
break;
case 216 :
case 217 :
case 218 :
case 219 :
case 220 :
case 221 :
case 222 :
case 223 :
opcode_reg = opcode2 - 216;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10004 = (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_10004); });
({ word_3 tmp_10005 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10005 << 11)); });
}
break;
case 208 :
case 209 :
case 210 :
case 211 :
case 212 :
case 213 :
case 214 :
case 215 :
opcode_reg = opcode2 - 208;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10006 = (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_10006); });
}
break;
default :
assert(opcode2 <= 0xbf);
switch (reg) {
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_64 tmp_10007 = ({ double tmp = (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]); *(word_64*)&tmp; }); mem_set_64(intp, tmp_9978(intp), tmp_10007); });
({ word_3 tmp_10008 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10008 << 11)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_64 tmp_10009 = ({ double tmp = (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]); *(word_64*)&tmp; }); mem_set_64(intp, tmp_9978(intp), tmp_10009); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_10010 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10010 << 11)); });
({ double tmp_10011 = ({ word_64 tmp = mem_get_64(intp, tmp_9978(intp)); *(double*)&tmp; }); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10011); });
}
break;
default :
assert(0);
}
}
break;
case 219 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
assert(opcode2 <= 0xbf);
switch (reg) {
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_64 tmp_10012 = ({ double tmp = (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]); *(word_64*)&tmp; }); mem_set_64(intp, tmp_9978(intp), tmp_10012); });
({ word_3 tmp_10013 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10013 << 11)); });
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_10014 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10014 << 11)); });
({ double tmp_10015 = ({ word_64 tmp = mem_get_64(intp, tmp_9978(intp)); *(double*)&tmp; }); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10015); });
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_10016 = ((word_32)(sword_32)(intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); tmp_9481(intp, tmp_10016); });
({ word_3 tmp_10017 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10017 << 11)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_10018 = ((word_32)(sword_32)(intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); tmp_9481(intp, tmp_10018); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_10019 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10019 << 11)); });
({ double tmp_10020 = ((double)(sword_32)tmp_9458(intp)); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10020); });
}
break;
default :
assert(0);
}
}
break;
case 223 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 224 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_16 tmp_10021 = (intp->regs_FSPR[0]); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_10021 << 0)); });
}
break;
default :
assert(opcode2 <= 0xbf);
switch (reg) {
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_64 tmp_10022 = ((word_64)(sword_64)(intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); mem_set_64(intp, tmp_9978(intp), tmp_10022); });
({ word_3 tmp_10023 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10023 << 11)); });
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_10024 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10024 << 11)); });
({ double tmp_10025 = ((double)(sword_64)mem_get_64(intp, tmp_9978(intp))); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10025); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_10026 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10026 << 11)); });
({ double tmp_10027 = ((double)(sword_16)tmp_9451(intp)); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10027); });
}
break;
default :
assert(0);
}
}
break;
case 218 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 233 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10028 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_10028 << 8)); });
({ word_1 tmp_10029 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_10029 << 10)); });
({ word_1 tmp_10030 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_10030 << 14)); });
({ word_3 tmp_10031 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 2) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10031 << 11)); });
}
break;
default :
assert(opcode2 <= 0xbf);
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10032 = (((double)(sword_32)tmp_9458(intp)) - (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10032); });
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10033 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) * ((double)(sword_32)tmp_9458(intp))); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10033); });
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10034 = (((double)(sword_32)tmp_9458(intp)) / (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10034); });
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10035 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) / ((double)(sword_32)tmp_9458(intp))); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10035); });
}
break;
default :
assert(0);
}
}
break;
case 222 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 224 :
case 225 :
case 226 :
case 227 :
case 228 :
case 229 :
case 230 :
case 231 :
opcode_reg = opcode2 - 224;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10036 = ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) - (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_10036); });
({ word_3 tmp_10037 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10037 << 11)); });
}
break;
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10038 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) * (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_10038); });
({ word_3 tmp_10039 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10039 << 11)); });
}
break;
case 240 :
case 241 :
case 242 :
case 243 :
case 244 :
case 245 :
case 246 :
case 247 :
opcode_reg = opcode2 - 240;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10040 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) / (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_10040); });
({ word_3 tmp_10041 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10041 << 11)); });
}
break;
case 248 :
case 249 :
case 250 :
case 251 :
case 252 :
case 253 :
case 254 :
case 255 :
opcode_reg = opcode2 - 248;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10042 = ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) / (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_10042); });
({ word_3 tmp_10043 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10043 << 11)); });
}
break;
case 217 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10044 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_10044 << 8)); });
({ word_1 tmp_10045 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_10045 << 10)); });
({ word_1 tmp_10046 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_10046 << 14)); });
({ word_3 tmp_10047 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 2) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10047 << 11)); });
}
break;
case 192 :
case 193 :
case 194 :
case 195 :
case 196 :
case 197 :
case 198 :
case 199 :
opcode_reg = opcode2 - 192;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10048 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) + (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_10048); });
({ word_3 tmp_10049 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10049 << 11)); });
}
break;
default :
assert(opcode2 <= 0xbf);
switch (reg) {
default :
assert(0);
}
}
break;
case 220 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10050 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) * (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_10050); });
}
break;
default :
assert(opcode2 <= 0xbf);
switch (reg) {
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10051 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) - ({ word_64 tmp = mem_get_64(intp, tmp_9978(intp)); *(double*)&tmp; })); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10051); });
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10052 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) * ({ word_64 tmp = mem_get_64(intp, tmp_9978(intp)); *(double*)&tmp; })); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10052); });
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10053 = (({ word_64 tmp = mem_get_64(intp, tmp_9978(intp)); *(double*)&tmp; }) / (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10053); });
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10054 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) / ({ word_64 tmp = mem_get_64(intp, tmp_9978(intp)); *(double*)&tmp; })); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10054); });
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10055 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < ({ word_64 tmp = mem_get_64(intp, tmp_9978(intp)); *(double*)&tmp; })) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_10055 << 8)); });
({ word_1 tmp_10056 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_10056 << 10)); });
({ word_1 tmp_10057 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == ({ word_64 tmp = mem_get_64(intp, tmp_9978(intp)); *(double*)&tmp; })) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_10057 << 14)); });
({ word_3 tmp_10058 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10058 << 11)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10059 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < ({ word_64 tmp = mem_get_64(intp, tmp_9978(intp)); *(double*)&tmp; })) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_10059 << 8)); });
({ word_1 tmp_10060 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_10060 << 10)); });
({ word_1 tmp_10061 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == ({ word_64 tmp = mem_get_64(intp, tmp_9978(intp)); *(double*)&tmp; })) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_10061 << 14)); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10062 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) + ({ word_64 tmp = mem_get_64(intp, tmp_9978(intp)); *(double*)&tmp; })); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10062); });
}
break;
default :
assert(0);
}
}
break;
case 216 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 224 :
case 225 :
case 226 :
case 227 :
case 228 :
case 229 :
case 230 :
case 231 :
opcode_reg = opcode2 - 224;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10063 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) - (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10063); });
}
break;
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10064 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) * (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10064); });
}
break;
case 240 :
case 241 :
case 242 :
case 243 :
case 244 :
case 245 :
case 246 :
case 247 :
opcode_reg = opcode2 - 240;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10065 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) / (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10065); });
}
break;
case 216 :
case 217 :
case 218 :
case 219 :
case 220 :
case 221 :
case 222 :
case 223 :
opcode_reg = opcode2 - 216;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10066 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_10066 << 8)); });
({ word_1 tmp_10067 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_10067 << 10)); });
({ word_1 tmp_10068 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_10068 << 14)); });
({ word_3 tmp_10069 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10069 << 11)); });
}
break;
case 208 :
case 209 :
case 210 :
case 211 :
case 212 :
case 213 :
case 214 :
case 215 :
opcode_reg = opcode2 - 208;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10070 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) < (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFEFF) | (tmp_10070 << 8)); });
({ word_1 tmp_10071 = 0; (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xFBFF) | (tmp_10071 << 10)); });
({ word_1 tmp_10072 = (((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) == (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)])) ? 1 : 0); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xBFFF) | (tmp_10072 << 14)); });
}
break;
default :
assert(opcode2 <= 0xbf);
switch (reg) {
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10073 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) - ((double)({ word_32 tmp = tmp_9458(intp); *(float*)&tmp; }))); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10073); });
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10074 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) / ((double)({ word_32 tmp = tmp_9458(intp); *(float*)&tmp; }))); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10074); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10075 = ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) + ((double)({ word_32 tmp = tmp_9458(intp); *(float*)&tmp; }))); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10075); });
}
break;
default :
assert(0);
}
}
break;
case 217 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 241 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ assert(0); 0; }) /* not implemented */;
}
break;
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
double tmp_10076 = (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]);
({ double tmp_10077 = (intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]) = tmp_10077); });
({ double tmp_10078 = tmp_10076; ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10078); });
})
;
}
break;
case 253 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ assert(0); 0; }) /* not implemented */;
}
break;
case 252 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ assert(0); 0; }) /* not implemented */;
}
break;
case 238 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_10079 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10079 << 11)); });
({ double tmp_10080 = ((double)0.0); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10080); });
}
break;
case 232 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_10081 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10081 << 11)); });
({ double tmp_10082 = ((double)1.0); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10082); });
}
break;
case 192 :
case 193 :
case 194 :
case 195 :
case 196 :
case 197 :
case 198 :
case 199 :
opcode_reg = opcode2 - 192;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10083 = (intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) + opcode_reg) & 0x7)]); ((intp->regs_FPST[((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7)]) = tmp_10083); });
({ word_3 tmp_10084 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10084 << 11)); });
}
break;
case 224 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ double tmp_10085 = (-(intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10085); });
}
break;
case 240 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ assert(0); 0; }) /* not implemented */;
}
break;
default :
assert(opcode2 <= 0xbf);
switch (reg) {
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_10086 = ({ float tmp = ((float)(intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); *(word_32*)&tmp; }); tmp_9481(intp, tmp_10086); });
({ word_3 tmp_10087 = ((((intp->regs_FSPR[0] >> 11) & 0x7) + 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10087 << 11)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_10088 = ({ float tmp = ((float)(intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)])); *(word_32*)&tmp; }); tmp_9481(intp, tmp_10088); });
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_16 tmp_10089 = (intp->regs_FSPR[1]); tmp_9474(intp, tmp_10089); });
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_16 tmp_10090 = tmp_9451(intp); ((intp->regs_FSPR[1]) = tmp_10090); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_3 tmp_10091 = ((((intp->regs_FSPR[0] >> 11) & 0x7) - 1) & 0x7); (intp->regs_FSPR[0] = (intp->regs_FSPR[0] & 0xC7FF) | (tmp_10091 << 11)); });
({ double tmp_10092 = ((double)({ word_32 tmp = tmp_9458(intp); *(float*)&tmp; })); ((intp->regs_FPST[((intp->regs_FSPR[0] >> 11) & 0x7)]) = tmp_10092); });
}
break;
default :
assert(0);
}
}
break;
case 247 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_10093 = (tmp_9451(intp) & imm16);
({ word_1 tmp_10094 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10094 << 0)); });
({ word_1 tmp_10095 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10095 << 11)); });
({ word_1 tmp_10096 = ((tmp_10093 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10096 << 7)); });
({ word_1 tmp_10097 = ((tmp_10093 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10097 << 6)); });
({ word_1 tmp_10098 = parity_even((tmp_10093 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10098 << 2)); });
})
;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_10099 = (tmp_9458(intp) & imm32);
({ word_1 tmp_10100 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10100 << 0)); });
({ word_1 tmp_10101 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10101 << 11)); });
({ word_1 tmp_10102 = ((tmp_10099 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10102 << 7)); });
({ word_1 tmp_10103 = ((tmp_10099 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10103 << 6)); });
({ word_1 tmp_10104 = parity_even((tmp_10099 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10104 << 2)); });
})
;
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_10105 = ((word_16)~tmp_9451(intp)); tmp_9474(intp, tmp_10105); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_10106 = ((word_32)~tmp_9458(intp)); tmp_9481(intp, tmp_10106); });
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_10107 = ((tmp_9451(intp) == 0) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10107 << 0)); });
({ word_1 tmp_10108 = addoverflow_16(((word_16)~tmp_9451(intp)), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10108 << 11)); });
({ word_16 tmp_10109 = ((word_16)-tmp_9451(intp)); tmp_9474(intp, tmp_10109); });
({ word_1 tmp_10110 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10110 << 7)); });
({ word_1 tmp_10111 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10111 << 6)); });
({ word_1 tmp_10112 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10112 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10113 = ((tmp_9458(intp) == 0) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10113 << 0)); });
({ word_1 tmp_10114 = addoverflow_32(((word_32)~tmp_9458(intp)), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10114 << 11)); });
({ word_32 tmp_10115 = ((word_32)-tmp_9458(intp)); tmp_9481(intp, tmp_10115); });
({ word_1 tmp_10116 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10116 << 7)); });
({ word_1 tmp_10117 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10117 << 6)); });
({ word_1 tmp_10118 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10118 << 2)); });
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_10119 = (intp->regs_GPR[0]);
word_32 tmp_10120 = tmp_9458(intp);
({ word_32 tmp_10121 = (tmp_10119 * tmp_10120); ((intp->regs_GPR[0]) = tmp_10121); });
({ word_32 tmp_10122 = ((word_32)((((word_64)tmp_10119) * ((word_64)tmp_10120)) >> 32)); ((intp->regs_GPR[2]) = tmp_10122); });
({ word_1 tmp_10123 = (((intp->regs_GPR[2]) == 0) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10123 << 0)); });
({ word_1 tmp_10124 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10124 << 11)); });
})
;
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
((16 == 32) ? 
({
word_32 tmp_10125 = (intp->regs_GPR[0]);
word_32 tmp_10126 = ((word_32)tmp_9451(intp));
({ word_32 tmp_10127 = (tmp_10125 * tmp_10126); ((intp->regs_GPR[0]) = tmp_10127); });
({ word_32 tmp_10128 = ((word_32)((((tmp_10125 & 0x80000000) ? ((word_64)tmp_10125 | 0xFFFFFFFF00000000) : (word_64)tmp_10125) * ((tmp_10126 & 0x80000000) ? ((word_64)tmp_10126 | 0xFFFFFFFF00000000) : (word_64)tmp_10126)) >> 32)); ((intp->regs_GPR[2]) = tmp_10128); });
({ word_1 tmp_10129 = ((((intp->regs_GPR[2]) == 0) || ((intp->regs_GPR[2]) == ((word_32)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10129 << 0)); });
({ word_1 tmp_10130 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10130 << 11)); });
})
 : 
({
word_16 tmp_10131 = ((intp->regs_GPR[0] >> 0) & 0xFFFF);
word_16 tmp_10132 = ((word_16)tmp_9451(intp));
({ word_16 tmp_10133 = (tmp_10131 * tmp_10132); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_10133 << 0)); });
({ word_16 tmp_10134 = ((word_16)((((tmp_10131 & 0x8000) ? ((word_32)tmp_10131 | 0xFFFF0000) : (word_32)tmp_10131) * ((tmp_10132 & 0x8000) ? ((word_32)tmp_10132 | 0xFFFF0000) : (word_32)tmp_10132)) >> 16)); (intp->regs_GPR[2] = (intp->regs_GPR[2] & 0xFFFF0000) | (tmp_10134 << 0)); });
({ word_1 tmp_10135 = (((((intp->regs_GPR[2] >> 0) & 0xFFFF) == 0) || (((intp->regs_GPR[2] >> 0) & 0xFFFF) == ((word_16)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10135 << 0)); });
({ word_1 tmp_10136 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10136 << 11)); });
})
);
} else {
next_pc = pc = intp->pc;
((32 == 32) ? 
({
word_32 tmp_10137 = (intp->regs_GPR[0]);
word_32 tmp_10138 = ((word_32)tmp_9458(intp));
({ word_32 tmp_10139 = (tmp_10137 * tmp_10138); ((intp->regs_GPR[0]) = tmp_10139); });
({ word_32 tmp_10140 = ((word_32)((((tmp_10137 & 0x80000000) ? ((word_64)tmp_10137 | 0xFFFFFFFF00000000) : (word_64)tmp_10137) * ((tmp_10138 & 0x80000000) ? ((word_64)tmp_10138 | 0xFFFFFFFF00000000) : (word_64)tmp_10138)) >> 32)); ((intp->regs_GPR[2]) = tmp_10140); });
({ word_1 tmp_10141 = ((((intp->regs_GPR[2]) == 0) || ((intp->regs_GPR[2]) == ((word_32)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10141 << 0)); });
({ word_1 tmp_10142 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10142 << 11)); });
})
 : 
({
word_16 tmp_10143 = ((intp->regs_GPR[0] >> 0) & 0xFFFF);
word_16 tmp_10144 = ((word_16)tmp_9458(intp));
({ word_16 tmp_10145 = (tmp_10143 * tmp_10144); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_10145 << 0)); });
({ word_16 tmp_10146 = ((word_16)((((tmp_10143 & 0x8000) ? ((word_32)tmp_10143 | 0xFFFF0000) : (word_32)tmp_10143) * ((tmp_10144 & 0x8000) ? ((word_32)tmp_10144 | 0xFFFF0000) : (word_32)tmp_10144)) >> 16)); (intp->regs_GPR[2] = (intp->regs_GPR[2] & 0xFFFF0000) | (tmp_10146 << 0)); });
({ word_1 tmp_10147 = (((((intp->regs_GPR[2] >> 0) & 0xFFFF) == 0) || (((intp->regs_GPR[2] >> 0) & 0xFFFF) == ((word_16)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10147 << 0)); });
({ word_1 tmp_10148 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10148 << 11)); });
})
);
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_10149 = (intp->regs_GPR[0]);
word_32 tmp_10150 = tmp_9458(intp);
({ word_32 tmp_10151 = ((word_32)((sword_32)tmp_10149 / (sword_32)tmp_10150)); ((intp->regs_GPR[0]) = tmp_10151); });
({ word_32 tmp_10152 = ((word_32)((sword_32)tmp_10149 % (sword_32)tmp_10150)); ((intp->regs_GPR[2]) = tmp_10152); });
})
;
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_64 tmp_10153 = ((((word_64)(intp->regs_GPR[2])) << 32) | ((word_64)(intp->regs_GPR[0])));
word_64 tmp_10154 = ((word_64)tmp_9458(intp));
({ word_32 tmp_10155 = ((word_32)((tmp_10153 / tmp_10154) & mask_64(0, 31))); ((intp->regs_GPR[0]) = tmp_10155); });
({ word_32 tmp_10156 = ((word_32)(tmp_10153 % tmp_10154)); ((intp->regs_GPR[2]) = tmp_10156); });
})
;
}
break;
default :
assert(0);
}
}
break;
case 246 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_8 tmp_10157 = (tmp_9466(intp) & imm8);
({ word_1 tmp_10158 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10158 << 0)); });
({ word_1 tmp_10159 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10159 << 11)); });
({ word_1 tmp_10160 = ((tmp_10157 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10160 << 7)); });
({ word_1 tmp_10161 = ((tmp_10157 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10161 << 6)); });
({ word_1 tmp_10162 = parity_even((tmp_10157 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10162 << 2)); });
})
;
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_10163 = ((word_8)~tmp_9466(intp)); tmp_9488(intp, tmp_10163); });
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10164 = ((tmp_9466(intp) == 0) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10164 << 0)); });
({ word_1 tmp_10165 = addoverflow_8(((word_8)~tmp_9466(intp)), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10165 << 11)); });
({ word_8 tmp_10166 = ((word_8)-tmp_9466(intp)); tmp_9488(intp, tmp_10166); });
({ word_1 tmp_10167 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10167 << 7)); });
({ word_1 tmp_10168 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10168 << 6)); });
({ word_1 tmp_10169 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10169 << 2)); });
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_16 tmp_10170 = (tmp_9466(intp) * ((intp->regs_GPR[0] >> 0) & 0xFF)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_10170 << 0)); });
({ word_1 tmp_10171 = ((((intp->regs_GPR[0] >> 8) & 0xFF) == 0) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10171 << 0)); });
({ word_1 tmp_10172 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10172 << 11)); });
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_16 tmp_10173 = (((tmp_9466(intp) & 0x80) ? ((word_32)tmp_9466(intp) | 0xFF00) : (word_32)tmp_9466(intp)) * ((((intp->regs_GPR[0] >> 0) & 0xFF) & 0x80) ? ((word_32)((intp->regs_GPR[0] >> 0) & 0xFF) | 0xFF00) : (word_32)((intp->regs_GPR[0] >> 0) & 0xFF))); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_10173 << 0)); });
({ word_1 tmp_10174 = (((((intp->regs_GPR[0] >> 8) & 0xFF) == 0) || (((intp->regs_GPR[0] >> 8) & 0xFF) == 255)) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10174 << 0)); });
({ word_1 tmp_10175 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10175 << 11)); });
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_8 tmp_10176 = ((intp->regs_GPR[0] >> 0) & 0xFF);
word_8 tmp_10177 = tmp_9466(intp);
({ word_8 tmp_10178 = ((word_8)((sword_8)tmp_10176 / (sword_8)tmp_10177)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_10178 << 0)); });
({ word_8 tmp_10179 = ((word_8)((sword_8)tmp_10176 % (sword_8)tmp_10177)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF00FF) | (tmp_10179 << 8)); });
})
;
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_16 tmp_10180 = ((intp->regs_GPR[0] >> 0) & 0xFFFF);
word_16 tmp_10181 = tmp_9466(intp);
({ word_8 tmp_10182 = ((word_8)((tmp_10180 / tmp_10181) & 255)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_10182 << 0)); });
({ word_8 tmp_10183 = ((word_8)(tmp_10180 % tmp_10181)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF00FF) | (tmp_10183 << 8)); });
})
;
}
break;
default :
assert(0);
}
}
break;
case 72 :
case 73 :
case 74 :
case 75 :
case 76 :
case 77 :
case 78 :
case 79 :
opcode_reg = opcode - 72;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_10184 = addoverflow_16((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF), ((word_16)~0)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10184 << 11)); });
({ word_16 tmp_10185 = ((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) - 1); ((intp->regs_GPR[opcode_reg]) = ((intp->regs_GPR[opcode_reg]) & 0xFFFF0000) | (tmp_10185 << 0)); });
({ word_1 tmp_10186 = (((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10186 << 7)); });
({ word_1 tmp_10187 = (((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10187 << 6)); });
({ word_1 tmp_10188 = parity_even(((((intp->regs_GPR[opcode_reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10188 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10189 = addoverflow_32((intp->regs_GPR[opcode_reg]), ((word_32)~0)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10189 << 11)); });
({ word_32 tmp_10190 = ((intp->regs_GPR[opcode_reg]) - 1); ((intp->regs_GPR[opcode_reg]) = tmp_10190); });
({ word_1 tmp_10191 = (((intp->regs_GPR[opcode_reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10191 << 7)); });
({ word_1 tmp_10192 = (((intp->regs_GPR[opcode_reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10192 << 6)); });
({ word_1 tmp_10193 = parity_even(((intp->regs_GPR[opcode_reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10193 << 2)); });
}
break;
case 254 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10194 = addoverflow_8(tmp_9466(intp), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10194 << 11)); });
({ word_8 tmp_10195 = (tmp_9466(intp) + 1); tmp_9488(intp, tmp_10195); });
({ word_1 tmp_10196 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10196 << 7)); });
({ word_1 tmp_10197 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10197 << 6)); });
({ word_1 tmp_10198 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10198 << 2)); });
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10199 = addoverflow_8(tmp_9466(intp), ((word_8)~0)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10199 << 11)); });
({ word_8 tmp_10200 = (tmp_9466(intp) - 1); tmp_9488(intp, tmp_10200); });
({ word_1 tmp_10201 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10201 << 7)); });
({ word_1 tmp_10202 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10202 << 6)); });
({ word_1 tmp_10203 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10203 << 2)); });
}
break;
default :
assert(0);
}
}
break;
case 59 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_10204 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) - tmp_9451(intp));
({ word_1 tmp_10205 = subcarry_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), tmp_9451(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10205 << 0)); });
({ word_1 tmp_10206 = ((tmp_10204 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10206 << 6)); });
({ word_1 tmp_10207 = ((tmp_10204 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10207 << 7)); });
({ word_1 tmp_10208 = addoverflow_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), (((word_16)~tmp_9451(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10208 << 11)); });
({ word_1 tmp_10209 = parity_even((tmp_10204 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10209 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_10210 = ((intp->regs_GPR[reg]) - tmp_9458(intp));
({ word_1 tmp_10211 = subcarry_32((intp->regs_GPR[reg]), tmp_9458(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10211 << 0)); });
({ word_1 tmp_10212 = ((tmp_10210 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10212 << 6)); });
({ word_1 tmp_10213 = ((tmp_10210 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10213 << 7)); });
({ word_1 tmp_10214 = addoverflow_32((intp->regs_GPR[reg]), (((word_32)~tmp_9458(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10214 << 11)); });
({ word_1 tmp_10215 = parity_even((tmp_10210 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10215 << 2)); });
})
;
}
break;
case 58 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_8 tmp_10216 = (tmp_9465(intp) - tmp_9466(intp));
({ word_1 tmp_10217 = subcarry_8(tmp_9465(intp), tmp_9466(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10217 << 0)); });
({ word_1 tmp_10218 = ((tmp_10216 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10218 << 6)); });
({ word_1 tmp_10219 = ((tmp_10216 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10219 << 7)); });
({ word_1 tmp_10220 = addoverflow_8(tmp_9465(intp), (((word_8)~tmp_9466(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10220 << 11)); });
({ word_1 tmp_10221 = parity_even((tmp_10216 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10221 << 2)); });
})
;
}
break;
case 57 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_10222 = (tmp_9451(intp) - (((intp->regs_GPR[reg]) >> 0) & 0xFFFF));
({ word_1 tmp_10223 = subcarry_16(tmp_9451(intp), (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10223 << 0)); });
({ word_1 tmp_10224 = ((tmp_10222 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10224 << 6)); });
({ word_1 tmp_10225 = ((tmp_10222 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10225 << 7)); });
({ word_1 tmp_10226 = addoverflow_16(tmp_9451(intp), (((word_16)~(((intp->regs_GPR[reg]) >> 0) & 0xFFFF)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10226 << 11)); });
({ word_1 tmp_10227 = parity_even((tmp_10222 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10227 << 2)); });
})
;
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_10228 = (tmp_9458(intp) - (intp->regs_GPR[reg]));
({ word_1 tmp_10229 = subcarry_32(tmp_9458(intp), (intp->regs_GPR[reg])); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10229 << 0)); });
({ word_1 tmp_10230 = ((tmp_10228 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10230 << 6)); });
({ word_1 tmp_10231 = ((tmp_10228 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10231 << 7)); });
({ word_1 tmp_10232 = addoverflow_32(tmp_9458(intp), (((word_32)~(intp->regs_GPR[reg])) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10232 << 11)); });
({ word_1 tmp_10233 = parity_even((tmp_10228 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10233 << 2)); });
})
;
}
break;
case 56 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_8 tmp_10234 = (tmp_9466(intp) - tmp_9465(intp));
({ word_1 tmp_10235 = subcarry_8(tmp_9466(intp), tmp_9465(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10235 << 0)); });
({ word_1 tmp_10236 = ((tmp_10234 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10236 << 6)); });
({ word_1 tmp_10237 = ((tmp_10234 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10237 << 7)); });
({ word_1 tmp_10238 = addoverflow_8(tmp_9466(intp), (((word_8)~tmp_9465(intp)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10238 << 11)); });
({ word_1 tmp_10239 = parity_even((tmp_10234 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10239 << 2)); });
})
;
}
break;
case 61 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_10240 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) - imm16);
({ word_1 tmp_10241 = subcarry_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10241 << 0)); });
({ word_1 tmp_10242 = ((tmp_10240 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10242 << 6)); });
({ word_1 tmp_10243 = ((tmp_10240 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10243 << 7)); });
({ word_1 tmp_10244 = addoverflow_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), (((word_16)~imm16) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10244 << 11)); });
({ word_1 tmp_10245 = parity_even((tmp_10240 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10245 << 2)); });
})
;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_10246 = ((intp->regs_GPR[0]) - imm32);
({ word_1 tmp_10247 = subcarry_32((intp->regs_GPR[0]), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10247 << 0)); });
({ word_1 tmp_10248 = ((tmp_10246 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10248 << 6)); });
({ word_1 tmp_10249 = ((tmp_10246 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10249 << 7)); });
({ word_1 tmp_10250 = addoverflow_32((intp->regs_GPR[0]), (((word_32)~imm32) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10250 << 11)); });
({ word_1 tmp_10251 = parity_even((tmp_10246 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10251 << 2)); });
})
;
}
break;
case 60 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_8 tmp_10252 = (((intp->regs_GPR[0] >> 0) & 0xFF) - imm8);
({ word_1 tmp_10253 = subcarry_8(((intp->regs_GPR[0] >> 0) & 0xFF), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10253 << 0)); });
({ word_1 tmp_10254 = ((tmp_10252 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10254 << 6)); });
({ word_1 tmp_10255 = ((tmp_10252 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10255 << 7)); });
({ word_1 tmp_10256 = addoverflow_8(((intp->regs_GPR[0] >> 0) & 0xFF), (((word_8)~imm8) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10256 << 11)); });
({ word_1 tmp_10257 = parity_even((tmp_10252 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10257 << 2)); });
})
;
}
break;
case 252 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10258 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFBFF) | (tmp_10258 << 10)); });
}
break;
case 153 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
(((intp->regs_GPR[0]) & (1 << 31)) ? ({ word_32 tmp_10259 = mask_32(0, 31); ((intp->regs_GPR[2]) = tmp_10259); }) : ({ word_32 tmp_10260 = 0; ((intp->regs_GPR[2]) = tmp_10260); }));
}
break;
case 152 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_10261 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & 0x80) ? ((word_32)((intp->regs_GPR[0] >> 0) & 0xFF) | 0xFF00) : (word_32)((intp->regs_GPR[0] >> 0) & 0xFF)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_10261 << 0)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_10262 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((intp->regs_GPR[0] >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((intp->regs_GPR[0] >> 0) & 0xFFFF)); ((intp->regs_GPR[0]) = tmp_10262); });
}
break;
case 255 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_10263 = tmp_9458(intp); mem_set_32(intp, ((intp->regs_GPR[4]) - 4), tmp_10263); });
({ word_32 tmp_10264 = ((intp->regs_GPR[4]) - 4); ((intp->regs_GPR[4]) = tmp_10264); });
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(next_pc = tmp_9458(intp));
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_10265 = addoverflow_16(tmp_9451(intp), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10265 << 11)); });
({ word_16 tmp_10266 = (tmp_9451(intp) + 1); tmp_9474(intp, tmp_10266); });
({ word_1 tmp_10267 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10267 << 7)); });
({ word_1 tmp_10268 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10268 << 6)); });
({ word_1 tmp_10269 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10269 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10270 = addoverflow_32(tmp_9458(intp), 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10270 << 11)); });
({ word_32 tmp_10271 = (tmp_9458(intp) + 1); tmp_9481(intp, tmp_10271); });
({ word_1 tmp_10272 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10272 << 7)); });
({ word_1 tmp_10273 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10273 << 6)); });
({ word_1 tmp_10274 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10274 << 2)); });
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_10275 = addoverflow_16(tmp_9451(intp), ((word_16)~0)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10275 << 11)); });
({ word_16 tmp_10276 = (tmp_9451(intp) - 1); tmp_9474(intp, tmp_10276); });
({ word_1 tmp_10277 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10277 << 7)); });
({ word_1 tmp_10278 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10278 << 6)); });
({ word_1 tmp_10279 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10279 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10280 = addoverflow_32(tmp_9458(intp), ((word_32)~0)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10280 << 11)); });
({ word_32 tmp_10281 = (tmp_9458(intp) - 1); tmp_9481(intp, tmp_10281); });
({ word_1 tmp_10282 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10282 << 7)); });
({ word_1 tmp_10283 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10283 << 6)); });
({ word_1 tmp_10284 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10284 << 2)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
intp->have_jumped = 1;
({ word_32 tmp_10285 = ((intp->regs_GPR[4]) - 4); ((intp->regs_GPR[4]) = tmp_10285); });
({ word_32 tmp_10286 = pc; mem_set_32(intp, (intp->regs_GPR[4]), tmp_10286); });
(next_pc = tmp_9458(intp));
}
break;
default :
assert(0);
}
}
break;
case 232 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
({ word_32 tmp_10287 = ((intp->regs_GPR[4]) - 4); ((intp->regs_GPR[4]) = tmp_10287); });
({ word_32 tmp_10288 = pc; mem_set_32(intp, (intp->regs_GPR[4]), tmp_10288); });
(next_pc = (pc + imm32));
}
break;
case 15 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 172 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
(((imm8 & 31) == 0) ? 0 /* nop */ : 
({
word_32 tmp_10289 = (imm8 & 31);
({ word_1 tmp_10290 = ((tmp_9458(intp) & (1 << (tmp_10289 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10290 << 0)); });
({ word_32 tmp_10291 = ((tmp_9458(intp) >> tmp_10289) | ((intp->regs_GPR[reg]) << (32 - tmp_10289))); tmp_9481(intp, tmp_10291); });
({ word_1 tmp_10292 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10292 << 7)); });
({ word_1 tmp_10293 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10293 << 6)); });
({ word_1 tmp_10294 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10294 << 2)); });
})
);
}
break;
case 173 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
((((intp->regs_GPR[1]) & 31) == 0) ? 0 /* nop */ : 
({
word_32 tmp_10295 = ((intp->regs_GPR[1]) & 31);
({ word_1 tmp_10296 = ((tmp_9458(intp) & (1 << (tmp_10295 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10296 << 0)); });
({ word_32 tmp_10297 = ((tmp_9458(intp) >> tmp_10295) | ((intp->regs_GPR[reg]) << (32 - tmp_10295))); tmp_9481(intp, tmp_10297); });
({ word_1 tmp_10298 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10298 << 7)); });
({ word_1 tmp_10299 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10299 << 6)); });
({ word_1 tmp_10300 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10300 << 2)); });
})
);
}
break;
case 164 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
(((imm8 & 31) == 0) ? 0 /* nop */ : 
({
word_32 tmp_10301 = (imm8 & 31);
({ word_1 tmp_10302 = ((tmp_9458(intp) & (1 << (32 - tmp_10301))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10302 << 0)); });
({ word_32 tmp_10303 = ((tmp_9458(intp) << tmp_10301) | ((intp->regs_GPR[reg]) >> (32 - tmp_10301))); tmp_9481(intp, tmp_10303); });
({ word_1 tmp_10304 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10304 << 7)); });
({ word_1 tmp_10305 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10305 << 6)); });
({ word_1 tmp_10306 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10306 << 2)); });
})
);
}
break;
case 165 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
((((intp->regs_GPR[1]) & 31) == 0) ? 0 /* nop */ : 
({
word_32 tmp_10307 = ((intp->regs_GPR[1]) & 31);
({ word_1 tmp_10308 = ((tmp_9458(intp) & (1 << (32 - tmp_10307))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10308 << 0)); });
({ word_32 tmp_10309 = ((tmp_9458(intp) << tmp_10307) | ((intp->regs_GPR[reg]) >> (32 - tmp_10307))); tmp_9481(intp, tmp_10309); });
({ word_1 tmp_10310 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10310 << 7)); });
({ word_1 tmp_10311 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10311 << 6)); });
({ word_1 tmp_10312 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10312 << 2)); });
})
);
}
break;
case 149 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_10313 = (((intp->regs_SPR[0] >> 6) & 0x1) ^ 1); tmp_9488(intp, tmp_10313); });
}
break;
case 151 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_10314 = (((((intp->regs_SPR[0] >> 0) & 0x1) == 0) && (((intp->regs_SPR[0] >> 6) & 0x1) == 0)) ? 1 : 0); tmp_9488(intp, tmp_10314); });
}
break;
case 146 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_10315 = ((intp->regs_SPR[0] >> 0) & 0x1); tmp_9488(intp, tmp_10315); });
}
break;
case 158 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_10316 = (((((intp->regs_SPR[0] >> 6) & 0x1) == 1) || (!(((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)))) ? 1 : 0); tmp_9488(intp, tmp_10316); });
}
break;
case 156 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_10317 = ((((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)) ? 0 : 1); tmp_9488(intp, tmp_10317); });
}
break;
case 159 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_10318 = (((((intp->regs_SPR[0] >> 6) & 0x1) == 0) && (((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1))) ? 1 : 0); tmp_9488(intp, tmp_10318); });
}
break;
case 148 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_10319 = ((intp->regs_SPR[0] >> 6) & 0x1); tmp_9488(intp, tmp_10319); });
}
break;
case 150 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_10320 = (((((intp->regs_SPR[0] >> 0) & 0x1) == 1) || (((intp->regs_SPR[0] >> 6) & 0x1) == 1)) ? 1 : 0); tmp_9488(intp, tmp_10320); });
}
break;
case 183 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_10321 = tmp_9451(intp); ((intp->regs_GPR[reg]) = tmp_10321); });
}
break;
case 182 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_10322 = tmp_9466(intp); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_10322 << 0)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_10323 = tmp_9466(intp); ((intp->regs_GPR[reg]) = tmp_10323); });
}
break;
case 191 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_10324 = ((tmp_9451(intp) & 0x8000) ? ((word_32)tmp_9451(intp) | 0xFFFF0000) : (word_32)tmp_9451(intp)); ((intp->regs_GPR[reg]) = tmp_10324); });
}
break;
case 190 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_10325 = ((tmp_9466(intp) & 0x80) ? ((word_32)tmp_9466(intp) | 0xFF00) : (word_32)tmp_9466(intp)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_10325 << 0)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_10326 = ((tmp_9466(intp) & 0x80) ? ((word_32)tmp_9466(intp) | 0xFFFFFF00) : (word_32)tmp_9466(intp)); ((intp->regs_GPR[reg]) = tmp_10326); });
}
break;
case 136 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == 1) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 138 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 2) & 0x1) == 1) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 137 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == 0) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 139 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 2) & 0x1) == 0) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 133 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 6) & 0x1) == 0) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 142 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 6) & 0x1) == 1) || (!(((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)))) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 140 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)) ? 0 /* nop */ : (next_pc = (pc + imm32)));
}
break;
case 141 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1)) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 143 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 6) & 0x1) == 0) && (((intp->regs_SPR[0] >> 7) & 0x1) == ((intp->regs_SPR[0] >> 11) & 0x1))) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 132 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 6) & 0x1) == 1) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 134 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 0) & 0x1) == 1) || (((intp->regs_SPR[0] >> 6) & 0x1) == 1)) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 130 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 0) & 0x1) == 1) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 131 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
((((intp->regs_SPR[0] >> 0) & 0x1) == 0) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 135 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
intp->have_jumped = 1;
(((((intp->regs_SPR[0] >> 0) & 0x1) == 0) && (((intp->regs_SPR[0] >> 6) & 0x1) == 0)) ? (next_pc = (pc + imm32)) : 0 /* nop */);
}
break;
case 175 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({
word_16 tmp_10327 = ((word_16)((((tmp_9451(intp) & 0x8000) ? ((word_32)tmp_9451(intp) | 0xFFFF0000) : (word_32)tmp_9451(intp)) * (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 0x8000) ? ((word_32)(((intp->regs_GPR[reg]) >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)(((intp->regs_GPR[reg]) >> 0) & 0xFFFF))) >> 16));
({ word_1 tmp_10328 = (((tmp_10327 == 0) || (tmp_10327 == ((word_16)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10328 << 0)); });
({ word_1 tmp_10329 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10329 << 11)); });
})
;
({ word_16 tmp_10330 = (tmp_9451(intp) * (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_10330 << 0)); });
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_10331 = ((word_32)((((tmp_9458(intp) & 0x80000000) ? ((word_64)tmp_9458(intp) | 0xFFFFFFFF00000000) : (word_64)tmp_9458(intp)) * (((intp->regs_GPR[reg]) & 0x80000000) ? ((word_64)(intp->regs_GPR[reg]) | 0xFFFFFFFF00000000) : (word_64)(intp->regs_GPR[reg]))) >> 32));
({ word_1 tmp_10332 = (((tmp_10331 == 0) || (tmp_10331 == ((word_32)~0))) ? 0 : 1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10332 << 0)); });
({ word_1 tmp_10333 = ((intp->regs_SPR[0] >> 0) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10333 << 11)); });
})
;
({ word_32 tmp_10334 = (tmp_9458(intp) * (intp->regs_GPR[reg])); ((intp->regs_GPR[reg]) = tmp_10334); });
}
break;
case 171 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({
word_32 tmp_10335 = ((intp->regs_GPR[reg]) & 31);
({ word_1 tmp_10336 = ((((mod == 3) ? (intp->regs_GPR[rm]) : mem_get_32(intp, (tmp_9978(intp) + ((((intp->regs_GPR[reg]) >> 5) | (((intp->regs_GPR[reg]) & (1 << 31)) ? ~((1 << (32 - 5)) - 1) : 0)) << 2)))) & (1 << tmp_10335)) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10336 << 0)); });
({ word_32 tmp_10337 = (((mod == 3) ? (intp->regs_GPR[rm]) : mem_get_32(intp, (tmp_9978(intp) + ((((intp->regs_GPR[reg]) >> 5) | (((intp->regs_GPR[reg]) & (1 << 31)) ? ~((1 << (32 - 5)) - 1) : 0)) << 2)))) | (1 << tmp_10335)); ((mod == 3) ? ((intp->regs_GPR[rm]) = tmp_10337) : mem_set_32(intp, (tmp_9978(intp) + ((((intp->regs_GPR[reg]) >> 5) | (((intp->regs_GPR[reg]) & (1 << 31)) ? ~((1 << (32 - 5)) - 1) : 0)) << 2)), tmp_10337)); });
})
;
}
break;
case 163 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10338 = ((((mod == 3) ? (intp->regs_GPR[rm]) : mem_get_32(intp, (tmp_9978(intp) + ((((intp->regs_GPR[reg]) >> 5) | (((intp->regs_GPR[reg]) & (1 << 31)) ? ~((1 << (32 - 5)) - 1) : 0)) << 2)))) & (1 << ((intp->regs_GPR[reg]) & 31))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10338 << 0)); });
}
break;
case 189 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_10339 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10339 << 6)); });
({ word_16 tmp_10340 = (31 - leading_zeros(tmp_9451(intp))); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_10340 << 0)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10341 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10341 << 6)); });
({ word_32 tmp_10342 = (31 - leading_zeros(tmp_9458(intp))); ((intp->regs_GPR[reg]) = tmp_10342); });
}
break;
default :
switch (reg) {
default :
assert(0);
}
}
break;
case 35 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_10343 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & tmp_9451(intp)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_10343 << 0)); });
({ word_1 tmp_10344 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10344 << 11)); });
({ word_1 tmp_10345 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10345 << 0)); });
({ word_1 tmp_10346 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10346 << 7)); });
({ word_1 tmp_10347 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10347 << 6)); });
({ word_1 tmp_10348 = parity_even(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10348 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_10349 = ((intp->regs_GPR[reg]) & tmp_9458(intp)); ((intp->regs_GPR[reg]) = tmp_10349); });
({ word_1 tmp_10350 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10350 << 11)); });
({ word_1 tmp_10351 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10351 << 0)); });
({ word_1 tmp_10352 = (((intp->regs_GPR[reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10352 << 7)); });
({ word_1 tmp_10353 = (((intp->regs_GPR[reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10353 << 6)); });
({ word_1 tmp_10354 = parity_even(((intp->regs_GPR[reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10354 << 2)); });
}
break;
case 34 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_10355 = (tmp_9465(intp) & tmp_9466(intp)); tmp_9467(intp, tmp_10355); });
({ word_1 tmp_10356 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10356 << 11)); });
({ word_1 tmp_10357 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10357 << 0)); });
({ word_1 tmp_10358 = ((tmp_9465(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10358 << 7)); });
({ word_1 tmp_10359 = ((tmp_9465(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10359 << 6)); });
({ word_1 tmp_10360 = parity_even((tmp_9465(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10360 << 2)); });
}
break;
case 33 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_16 tmp_10361 = (tmp_9451(intp) & (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); tmp_9474(intp, tmp_10361); });
({ word_1 tmp_10362 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10362 << 11)); });
({ word_1 tmp_10363 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10363 << 0)); });
({ word_1 tmp_10364 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10364 << 7)); });
({ word_1 tmp_10365 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10365 << 6)); });
({ word_1 tmp_10366 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10366 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_32 tmp_10367 = (tmp_9458(intp) & (intp->regs_GPR[reg])); tmp_9481(intp, tmp_10367); });
({ word_1 tmp_10368 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10368 << 11)); });
({ word_1 tmp_10369 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10369 << 0)); });
({ word_1 tmp_10370 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10370 << 7)); });
({ word_1 tmp_10371 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10371 << 6)); });
({ word_1 tmp_10372 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10372 << 2)); });
}
break;
case 32 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_8 tmp_10373 = (tmp_9466(intp) & tmp_9465(intp)); tmp_9488(intp, tmp_10373); });
({ word_1 tmp_10374 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10374 << 11)); });
({ word_1 tmp_10375 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10375 << 0)); });
({ word_1 tmp_10376 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10376 << 7)); });
({ word_1 tmp_10377 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10377 << 6)); });
({ word_1 tmp_10378 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10378 << 2)); });
}
break;
case 37 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_10379 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) & imm16); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_10379 << 0)); });
({ word_1 tmp_10380 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10380 << 11)); });
({ word_1 tmp_10381 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10381 << 0)); });
({ word_1 tmp_10382 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10382 << 7)); });
({ word_1 tmp_10383 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10383 << 6)); });
({ word_1 tmp_10384 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10384 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_10385 = ((intp->regs_GPR[0]) & imm32); ((intp->regs_GPR[0]) = tmp_10385); });
({ word_1 tmp_10386 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10386 << 11)); });
({ word_1 tmp_10387 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10387 << 0)); });
({ word_1 tmp_10388 = (((intp->regs_GPR[0]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10388 << 7)); });
({ word_1 tmp_10389 = (((intp->regs_GPR[0]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10389 << 6)); });
({ word_1 tmp_10390 = parity_even(((intp->regs_GPR[0]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10390 << 2)); });
}
break;
case 36 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_10391 = (((intp->regs_GPR[0] >> 0) & 0xFF) & imm8); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_10391 << 0)); });
({ word_1 tmp_10392 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10392 << 11)); });
({ word_1 tmp_10393 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10393 << 0)); });
({ word_1 tmp_10394 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10394 << 7)); });
({ word_1 tmp_10395 = ((((intp->regs_GPR[0] >> 0) & 0xFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10395 << 6)); });
({ word_1 tmp_10396 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10396 << 2)); });
}
break;
case 3 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_10397 = addoverflow_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), tmp_9451(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10397 << 11)); });
({ word_1 tmp_10398 = addcarry_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), tmp_9451(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10398 << 0)); });
({ word_16 tmp_10399 = ((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) + tmp_9451(intp)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_10399 << 0)); });
({ word_1 tmp_10400 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10400 << 7)); });
({ word_1 tmp_10401 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10401 << 6)); });
({ word_1 tmp_10402 = parity_even(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10402 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10403 = addoverflow_32((intp->regs_GPR[reg]), tmp_9458(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10403 << 11)); });
({ word_1 tmp_10404 = addcarry_32((intp->regs_GPR[reg]), tmp_9458(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10404 << 0)); });
({ word_32 tmp_10405 = ((intp->regs_GPR[reg]) + tmp_9458(intp)); ((intp->regs_GPR[reg]) = tmp_10405); });
({ word_1 tmp_10406 = (((intp->regs_GPR[reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10406 << 7)); });
({ word_1 tmp_10407 = (((intp->regs_GPR[reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10407 << 6)); });
({ word_1 tmp_10408 = parity_even(((intp->regs_GPR[reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10408 << 2)); });
}
break;
case 2 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10409 = addoverflow_8(tmp_9465(intp), tmp_9466(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10409 << 11)); });
({ word_1 tmp_10410 = addcarry_8(tmp_9465(intp), tmp_9466(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10410 << 0)); });
({ word_8 tmp_10411 = (tmp_9465(intp) + tmp_9466(intp)); tmp_9467(intp, tmp_10411); });
({ word_1 tmp_10412 = ((tmp_9465(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10412 << 7)); });
({ word_1 tmp_10413 = ((tmp_9465(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10413 << 6)); });
({ word_1 tmp_10414 = parity_even((tmp_9465(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10414 << 2)); });
}
break;
case 1 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_10415 = addoverflow_16(tmp_9451(intp), (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10415 << 11)); });
({ word_1 tmp_10416 = addcarry_16(tmp_9451(intp), (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10416 << 0)); });
({ word_16 tmp_10417 = (tmp_9451(intp) + (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)); tmp_9474(intp, tmp_10417); });
({ word_1 tmp_10418 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10418 << 7)); });
({ word_1 tmp_10419 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10419 << 6)); });
({ word_1 tmp_10420 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10420 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10421 = addoverflow_32(tmp_9458(intp), (intp->regs_GPR[reg])); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10421 << 11)); });
({ word_1 tmp_10422 = addcarry_32(tmp_9458(intp), (intp->regs_GPR[reg])); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10422 << 0)); });
({ word_32 tmp_10423 = (tmp_9458(intp) + (intp->regs_GPR[reg])); tmp_9481(intp, tmp_10423); });
({ word_1 tmp_10424 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10424 << 7)); });
({ word_1 tmp_10425 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10425 << 6)); });
({ word_1 tmp_10426 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10426 << 2)); });
}
break;
case 0 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10427 = addoverflow_8(tmp_9466(intp), tmp_9465(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10427 << 11)); });
({ word_1 tmp_10428 = addcarry_8(tmp_9466(intp), tmp_9465(intp)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10428 << 0)); });
({ word_8 tmp_10429 = (tmp_9466(intp) + tmp_9465(intp)); tmp_9488(intp, tmp_10429); });
({ word_1 tmp_10430 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10430 << 7)); });
({ word_1 tmp_10431 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10431 << 6)); });
({ word_1 tmp_10432 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10432 << 2)); });
}
break;
case 5 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10433 = addoverflow_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10433 << 11)); });
({ word_1 tmp_10434 = addcarry_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10434 << 0)); });
({ word_16 tmp_10435 = (((intp->regs_GPR[0] >> 0) & 0xFFFF) + imm16); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_10435 << 0)); });
({ word_1 tmp_10436 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10436 << 7)); });
({ word_1 tmp_10437 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10437 << 6)); });
({ word_1 tmp_10438 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10438 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10439 = addoverflow_32((intp->regs_GPR[0]), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10439 << 11)); });
({ word_1 tmp_10440 = addcarry_32((intp->regs_GPR[0]), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10440 << 0)); });
({ word_32 tmp_10441 = ((intp->regs_GPR[0]) + imm32); ((intp->regs_GPR[0]) = tmp_10441); });
({ word_1 tmp_10442 = (((intp->regs_GPR[0]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10442 << 7)); });
({ word_1 tmp_10443 = (((intp->regs_GPR[0]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10443 << 6)); });
({ word_1 tmp_10444 = parity_even(((intp->regs_GPR[0]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10444 << 2)); });
}
break;
case 4 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10445 = addoverflow_8(((intp->regs_GPR[0] >> 0) & 0xFF), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10445 << 11)); });
({ word_1 tmp_10446 = addcarry_8(((intp->regs_GPR[0] >> 0) & 0xFF), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10446 << 0)); });
({ word_8 tmp_10447 = (((intp->regs_GPR[0] >> 0) & 0xFF) + imm8); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_10447 << 0)); });
({ word_1 tmp_10448 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10448 << 7)); });
({ word_1 tmp_10449 = ((((intp->regs_GPR[0] >> 0) & 0xFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10449 << 6)); });
({ word_1 tmp_10450 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10450 << 2)); });
}
break;
case 19 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_10451 = ((addoverflow_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), tmp_9451(intp)) | addoverflow_16(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) + tmp_9451(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10451 << 11)); });
({ word_1 tmp_10452 = ((addcarry_16((((intp->regs_GPR[reg]) >> 0) & 0xFFFF), tmp_9451(intp)) | addcarry_16(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) + tmp_9451(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10452 << 0)); });
({ word_16 tmp_10453 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) + tmp_9451(intp)) + ((intp->regs_SPR[0] >> 0) & 0x1)); ((intp->regs_GPR[reg]) = ((intp->regs_GPR[reg]) & 0xFFFF0000) | (tmp_10453 << 0)); });
({ word_1 tmp_10454 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10454 << 7)); });
({ word_1 tmp_10455 = (((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10455 << 6)); });
({ word_1 tmp_10456 = parity_even(((((intp->regs_GPR[reg]) >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10456 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10457 = ((addoverflow_32((intp->regs_GPR[reg]), tmp_9458(intp)) | addoverflow_32(((intp->regs_GPR[reg]) + tmp_9458(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10457 << 11)); });
({ word_1 tmp_10458 = ((addcarry_32((intp->regs_GPR[reg]), tmp_9458(intp)) | addcarry_32(((intp->regs_GPR[reg]) + tmp_9458(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10458 << 0)); });
({ word_32 tmp_10459 = (((intp->regs_GPR[reg]) + tmp_9458(intp)) + ((intp->regs_SPR[0] >> 0) & 0x1)); ((intp->regs_GPR[reg]) = tmp_10459); });
({ word_1 tmp_10460 = (((intp->regs_GPR[reg]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10460 << 7)); });
({ word_1 tmp_10461 = (((intp->regs_GPR[reg]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10461 << 6)); });
({ word_1 tmp_10462 = parity_even(((intp->regs_GPR[reg]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10462 << 2)); });
}
break;
case 18 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10463 = ((addoverflow_8(tmp_9465(intp), tmp_9466(intp)) | addoverflow_8((tmp_9465(intp) + tmp_9466(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10463 << 11)); });
({ word_1 tmp_10464 = ((addcarry_8(tmp_9465(intp), tmp_9466(intp)) | addcarry_8((tmp_9465(intp) + tmp_9466(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10464 << 0)); });
({ word_8 tmp_10465 = ((tmp_9465(intp) + tmp_9466(intp)) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_9467(intp, tmp_10465); });
({ word_1 tmp_10466 = ((tmp_9465(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10466 << 7)); });
({ word_1 tmp_10467 = ((tmp_9465(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10467 << 6)); });
({ word_1 tmp_10468 = parity_even((tmp_9465(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10468 << 2)); });
}
break;
case 17 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
({ word_1 tmp_10469 = ((addoverflow_16(tmp_9451(intp), (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)) | addoverflow_16((tmp_9451(intp) + (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10469 << 11)); });
({ word_1 tmp_10470 = ((addcarry_16(tmp_9451(intp), (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)) | addcarry_16((tmp_9451(intp) + (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10470 << 0)); });
({ word_16 tmp_10471 = ((tmp_9451(intp) + (((intp->regs_GPR[reg]) >> 0) & 0xFFFF)) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_9474(intp, tmp_10471); });
({ word_1 tmp_10472 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10472 << 7)); });
({ word_1 tmp_10473 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10473 << 6)); });
({ word_1 tmp_10474 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10474 << 2)); });
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10475 = ((addoverflow_32(tmp_9458(intp), (intp->regs_GPR[reg])) | addoverflow_32((tmp_9458(intp) + (intp->regs_GPR[reg])), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10475 << 11)); });
({ word_1 tmp_10476 = ((addcarry_32(tmp_9458(intp), (intp->regs_GPR[reg])) | addcarry_32((tmp_9458(intp) + (intp->regs_GPR[reg])), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10476 << 0)); });
({ word_32 tmp_10477 = ((tmp_9458(intp) + (intp->regs_GPR[reg])) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_9481(intp, tmp_10477); });
({ word_1 tmp_10478 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10478 << 7)); });
({ word_1 tmp_10479 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10479 << 6)); });
({ word_1 tmp_10480 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10480 << 2)); });
}
break;
case 16 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
({ word_1 tmp_10481 = ((addoverflow_8(tmp_9466(intp), tmp_9465(intp)) | addoverflow_8((tmp_9466(intp) + tmp_9465(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10481 << 11)); });
({ word_1 tmp_10482 = ((addcarry_8(tmp_9466(intp), tmp_9465(intp)) | addcarry_8((tmp_9466(intp) + tmp_9465(intp)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10482 << 0)); });
({ word_8 tmp_10483 = ((tmp_9466(intp) + tmp_9465(intp)) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_9488(intp, tmp_10483); });
({ word_1 tmp_10484 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10484 << 7)); });
({ word_1 tmp_10485 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10485 << 6)); });
({ word_1 tmp_10486 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10486 << 2)); });
}
break;
case 131 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_10487 = (tmp_9451(intp) ^ ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); tmp_9474(intp, tmp_10487); });
({ word_1 tmp_10488 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10488 << 0)); });
({ word_1 tmp_10489 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10489 << 11)); });
({ word_1 tmp_10490 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10490 << 7)); });
({ word_1 tmp_10491 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10491 << 6)); });
({ word_1 tmp_10492 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10492 << 2)); });
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_10493 = (tmp_9458(intp) ^ ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); tmp_9481(intp, tmp_10493); });
({ word_1 tmp_10494 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10494 << 0)); });
({ word_1 tmp_10495 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10495 << 11)); });
({ word_1 tmp_10496 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10496 << 7)); });
({ word_1 tmp_10497 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10497 << 6)); });
({ word_1 tmp_10498 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10498 << 2)); });
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10499 = subcarry_16(tmp_9451(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10499 << 0)); });
({ word_1 tmp_10500 = addoverflow_16(tmp_9451(intp), (((word_16)~((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10500 << 11)); });
({ word_16 tmp_10501 = (tmp_9451(intp) - ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); tmp_9474(intp, tmp_10501); });
({ word_1 tmp_10502 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10502 << 7)); });
({ word_1 tmp_10503 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10503 << 6)); });
({ word_1 tmp_10504 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10504 << 2)); });
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10505 = subcarry_32(tmp_9458(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10505 << 0)); });
({ word_1 tmp_10506 = addoverflow_32(tmp_9458(intp), (((word_32)~((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10506 << 11)); });
({ word_32 tmp_10507 = (tmp_9458(intp) - ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); tmp_9481(intp, tmp_10507); });
({ word_1 tmp_10508 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10508 << 7)); });
({ word_1 tmp_10509 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10509 << 6)); });
({ word_1 tmp_10510 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10510 << 2)); });
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_10511 = (((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_10512 = subcarry_16(tmp_9451(intp), tmp_10511); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10512 << 0)); });
({ word_1 tmp_10513 = addoverflow_16(tmp_9451(intp), (((word_16)~tmp_10511) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10513 << 11)); });
({ word_16 tmp_10514 = (tmp_9451(intp) - tmp_10511); tmp_9474(intp, tmp_10514); });
({ word_1 tmp_10515 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10515 << 7)); });
({ word_1 tmp_10516 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10516 << 6)); });
({ word_1 tmp_10517 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10517 << 2)); });
})
;
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_10518 = (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_10519 = subcarry_32(tmp_9458(intp), tmp_10518); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10519 << 0)); });
({ word_1 tmp_10520 = addoverflow_32(tmp_9458(intp), (((word_32)~tmp_10518) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10520 << 11)); });
({ word_32 tmp_10521 = (tmp_9458(intp) - tmp_10518); tmp_9481(intp, tmp_10521); });
({ word_1 tmp_10522 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10522 << 7)); });
({ word_1 tmp_10523 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10523 << 6)); });
({ word_1 tmp_10524 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10524 << 2)); });
})
;
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_10525 = (tmp_9451(intp) | ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); tmp_9474(intp, tmp_10525); });
({ word_1 tmp_10526 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10526 << 0)); });
({ word_1 tmp_10527 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10527 << 11)); });
({ word_1 tmp_10528 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10528 << 7)); });
({ word_1 tmp_10529 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10529 << 6)); });
({ word_1 tmp_10530 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10530 << 2)); });
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_10531 = (tmp_9458(intp) | ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); tmp_9481(intp, tmp_10531); });
({ word_1 tmp_10532 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10532 << 0)); });
({ word_1 tmp_10533 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10533 << 11)); });
({ word_1 tmp_10534 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10534 << 7)); });
({ word_1 tmp_10535 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10535 << 6)); });
({ word_1 tmp_10536 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10536 << 2)); });
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_10537 = (tmp_9451(intp) - ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8));
({ word_1 tmp_10538 = subcarry_16(tmp_9451(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10538 << 0)); });
({ word_1 tmp_10539 = ((tmp_10537 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10539 << 6)); });
({ word_1 tmp_10540 = ((tmp_10537 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10540 << 7)); });
({ word_1 tmp_10541 = addoverflow_16(tmp_9451(intp), (((word_16)~((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10541 << 11)); });
({ word_1 tmp_10542 = parity_even((tmp_10537 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10542 << 2)); });
})
;
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_10543 = (tmp_9458(intp) - ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
({ word_1 tmp_10544 = subcarry_32(tmp_9458(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10544 << 0)); });
({ word_1 tmp_10545 = ((tmp_10543 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10545 << 6)); });
({ word_1 tmp_10546 = ((tmp_10543 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10546 << 7)); });
({ word_1 tmp_10547 = addoverflow_32(tmp_9458(intp), (((word_32)~((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10547 << 11)); });
({ word_1 tmp_10548 = parity_even((tmp_10543 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10548 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_10549 = (tmp_9451(intp) & ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); tmp_9474(intp, tmp_10549); });
({ word_1 tmp_10550 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10550 << 11)); });
({ word_1 tmp_10551 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10551 << 0)); });
({ word_1 tmp_10552 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10552 << 7)); });
({ word_1 tmp_10553 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10553 << 6)); });
({ word_1 tmp_10554 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10554 << 2)); });
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_10555 = (tmp_9458(intp) & ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); tmp_9481(intp, tmp_10555); });
({ word_1 tmp_10556 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10556 << 11)); });
({ word_1 tmp_10557 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10557 << 0)); });
({ word_1 tmp_10558 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10558 << 7)); });
({ word_1 tmp_10559 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10559 << 6)); });
({ word_1 tmp_10560 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10560 << 2)); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10561 = addoverflow_16(tmp_9451(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10561 << 11)); });
({ word_1 tmp_10562 = addcarry_16(tmp_9451(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10562 << 0)); });
({ word_16 tmp_10563 = (tmp_9451(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)); tmp_9474(intp, tmp_10563); });
({ word_1 tmp_10564 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10564 << 7)); });
({ word_1 tmp_10565 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10565 << 6)); });
({ word_1 tmp_10566 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10566 << 2)); });
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10567 = addoverflow_32(tmp_9458(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10567 << 11)); });
({ word_1 tmp_10568 = addcarry_32(tmp_9458(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10568 << 0)); });
({ word_32 tmp_10569 = (tmp_9458(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)); tmp_9481(intp, tmp_10569); });
({ word_1 tmp_10570 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10570 << 7)); });
({ word_1 tmp_10571 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10571 << 6)); });
({ word_1 tmp_10572 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10572 << 2)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10573 = ((addoverflow_16(tmp_9451(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)) | addoverflow_16((tmp_9451(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10573 << 11)); });
({ word_1 tmp_10574 = ((addcarry_16(tmp_9451(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)) | addcarry_16((tmp_9451(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10574 << 0)); });
({ word_16 tmp_10575 = ((tmp_9451(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFF00) : (word_32)imm8)) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_9474(intp, tmp_10575); });
({ word_1 tmp_10576 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10576 << 7)); });
({ word_1 tmp_10577 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10577 << 6)); });
({ word_1 tmp_10578 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10578 << 2)); });
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10579 = ((addoverflow_32(tmp_9458(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)) | addoverflow_32((tmp_9458(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10579 << 11)); });
({ word_1 tmp_10580 = ((addcarry_32(tmp_9458(intp), ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)) | addcarry_32((tmp_9458(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10580 << 0)); });
({ word_32 tmp_10581 = ((tmp_9458(intp) + ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_9481(intp, tmp_10581); });
({ word_1 tmp_10582 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10582 << 7)); });
({ word_1 tmp_10583 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10583 << 6)); });
({ word_1 tmp_10584 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10584 << 2)); });
}
break;
default :
assert(0);
}
}
break;
case 129 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_10585 = (tmp_9451(intp) ^ imm16); tmp_9474(intp, tmp_10585); });
({ word_1 tmp_10586 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10586 << 0)); });
({ word_1 tmp_10587 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10587 << 11)); });
({ word_1 tmp_10588 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10588 << 7)); });
({ word_1 tmp_10589 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10589 << 6)); });
({ word_1 tmp_10590 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10590 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_10591 = (tmp_9458(intp) ^ imm32); tmp_9481(intp, tmp_10591); });
({ word_1 tmp_10592 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10592 << 0)); });
({ word_1 tmp_10593 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10593 << 11)); });
({ word_1 tmp_10594 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10594 << 7)); });
({ word_1 tmp_10595 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10595 << 6)); });
({ word_1 tmp_10596 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10596 << 2)); });
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10597 = subcarry_16(tmp_9451(intp), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10597 << 0)); });
({ word_1 tmp_10598 = addoverflow_16(tmp_9451(intp), (((word_16)~imm16) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10598 << 11)); });
({ word_16 tmp_10599 = (tmp_9451(intp) - imm16); tmp_9474(intp, tmp_10599); });
({ word_1 tmp_10600 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10600 << 7)); });
({ word_1 tmp_10601 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10601 << 6)); });
({ word_1 tmp_10602 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10602 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10603 = subcarry_32(tmp_9458(intp), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10603 << 0)); });
({ word_1 tmp_10604 = addoverflow_32(tmp_9458(intp), (((word_32)~imm32) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10604 << 11)); });
({ word_32 tmp_10605 = (tmp_9458(intp) - imm32); tmp_9481(intp, tmp_10605); });
({ word_1 tmp_10606 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10606 << 7)); });
({ word_1 tmp_10607 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10607 << 6)); });
({ word_1 tmp_10608 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10608 << 2)); });
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_10609 = (imm16 + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_10610 = subcarry_16(tmp_9451(intp), tmp_10609); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10610 << 0)); });
({ word_1 tmp_10611 = addoverflow_16(tmp_9451(intp), (((word_16)~tmp_10609) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10611 << 11)); });
({ word_16 tmp_10612 = (tmp_9451(intp) - tmp_10609); tmp_9474(intp, tmp_10612); });
({ word_1 tmp_10613 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10613 << 7)); });
({ word_1 tmp_10614 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10614 << 6)); });
({ word_1 tmp_10615 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10615 << 2)); });
})
;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_10616 = (imm32 + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_10617 = subcarry_32(tmp_9458(intp), tmp_10616); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10617 << 0)); });
({ word_1 tmp_10618 = addoverflow_32(tmp_9458(intp), (((word_32)~tmp_10616) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10618 << 11)); });
({ word_32 tmp_10619 = (tmp_9458(intp) - tmp_10616); tmp_9481(intp, tmp_10619); });
({ word_1 tmp_10620 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10620 << 7)); });
({ word_1 tmp_10621 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10621 << 6)); });
({ word_1 tmp_10622 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10622 << 2)); });
})
;
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_10623 = (tmp_9451(intp) | imm16); tmp_9474(intp, tmp_10623); });
({ word_1 tmp_10624 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10624 << 0)); });
({ word_1 tmp_10625 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10625 << 11)); });
({ word_1 tmp_10626 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10626 << 7)); });
({ word_1 tmp_10627 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10627 << 6)); });
({ word_1 tmp_10628 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10628 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_10629 = (tmp_9458(intp) | imm32); tmp_9481(intp, tmp_10629); });
({ word_1 tmp_10630 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10630 << 0)); });
({ word_1 tmp_10631 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10631 << 11)); });
({ word_1 tmp_10632 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10632 << 7)); });
({ word_1 tmp_10633 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10633 << 6)); });
({ word_1 tmp_10634 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10634 << 2)); });
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({
word_16 tmp_10635 = (tmp_9451(intp) - imm16);
({ word_1 tmp_10636 = subcarry_16(tmp_9451(intp), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10636 << 0)); });
({ word_1 tmp_10637 = ((tmp_10635 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10637 << 6)); });
({ word_1 tmp_10638 = ((tmp_10635 & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10638 << 7)); });
({ word_1 tmp_10639 = addoverflow_16(tmp_9451(intp), (((word_16)~imm16) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10639 << 11)); });
({ word_1 tmp_10640 = parity_even((tmp_10635 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10640 << 2)); });
})
;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({
word_32 tmp_10641 = (tmp_9458(intp) - imm32);
({ word_1 tmp_10642 = subcarry_32(tmp_9458(intp), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10642 << 0)); });
({ word_1 tmp_10643 = ((tmp_10641 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10643 << 6)); });
({ word_1 tmp_10644 = ((tmp_10641 & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10644 << 7)); });
({ word_1 tmp_10645 = addoverflow_32(tmp_9458(intp), (((word_32)~imm32) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10645 << 11)); });
({ word_1 tmp_10646 = parity_even((tmp_10641 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10646 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_16 tmp_10647 = (tmp_9451(intp) & imm16); tmp_9474(intp, tmp_10647); });
({ word_1 tmp_10648 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10648 << 11)); });
({ word_1 tmp_10649 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10649 << 0)); });
({ word_1 tmp_10650 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10650 << 7)); });
({ word_1 tmp_10651 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10651 << 6)); });
({ word_1 tmp_10652 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10652 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_32 tmp_10653 = (tmp_9458(intp) & imm32); tmp_9481(intp, tmp_10653); });
({ word_1 tmp_10654 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10654 << 11)); });
({ word_1 tmp_10655 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10655 << 0)); });
({ word_1 tmp_10656 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10656 << 7)); });
({ word_1 tmp_10657 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10657 << 6)); });
({ word_1 tmp_10658 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10658 << 2)); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10659 = addoverflow_16(tmp_9451(intp), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10659 << 11)); });
({ word_1 tmp_10660 = addcarry_16(tmp_9451(intp), imm16); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10660 << 0)); });
({ word_16 tmp_10661 = (tmp_9451(intp) + imm16); tmp_9474(intp, tmp_10661); });
({ word_1 tmp_10662 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10662 << 7)); });
({ word_1 tmp_10663 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10663 << 6)); });
({ word_1 tmp_10664 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10664 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10665 = addoverflow_32(tmp_9458(intp), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10665 << 11)); });
({ word_1 tmp_10666 = addcarry_32(tmp_9458(intp), imm32); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10666 << 0)); });
({ word_32 tmp_10667 = (tmp_9458(intp) + imm32); tmp_9481(intp, tmp_10667); });
({ word_1 tmp_10668 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10668 << 7)); });
({ word_1 tmp_10669 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10669 << 6)); });
({ word_1 tmp_10670 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10670 << 2)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10671 = ((addoverflow_16(tmp_9451(intp), imm16) | addoverflow_16((tmp_9451(intp) + imm16), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10671 << 11)); });
({ word_1 tmp_10672 = ((addcarry_16(tmp_9451(intp), imm16) | addcarry_16((tmp_9451(intp) + imm16), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10672 << 0)); });
({ word_16 tmp_10673 = ((tmp_9451(intp) + imm16) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_9474(intp, tmp_10673); });
({ word_1 tmp_10674 = ((tmp_9451(intp) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10674 << 7)); });
({ word_1 tmp_10675 = ((tmp_9451(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10675 << 6)); });
({ word_1 tmp_10676 = parity_even((tmp_9451(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10676 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10677 = ((addoverflow_32(tmp_9458(intp), imm32) | addoverflow_32((tmp_9458(intp) + imm32), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10677 << 11)); });
({ word_1 tmp_10678 = ((addcarry_32(tmp_9458(intp), imm32) | addcarry_32((tmp_9458(intp) + imm32), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10678 << 0)); });
({ word_32 tmp_10679 = ((tmp_9458(intp) + imm32) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_9481(intp, tmp_10679); });
({ word_1 tmp_10680 = ((tmp_9458(intp) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10680 << 7)); });
({ word_1 tmp_10681 = ((tmp_9458(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10681 << 6)); });
({ word_1 tmp_10682 = parity_even((tmp_9458(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10682 << 2)); });
}
break;
default :
assert(0);
}
}
break;
case 128 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_10683 = (tmp_9466(intp) ^ imm8); tmp_9488(intp, tmp_10683); });
({ word_1 tmp_10684 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10684 << 0)); });
({ word_1 tmp_10685 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10685 << 11)); });
({ word_1 tmp_10686 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10686 << 7)); });
({ word_1 tmp_10687 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10687 << 6)); });
({ word_1 tmp_10688 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10688 << 2)); });
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10689 = subcarry_8(tmp_9466(intp), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10689 << 0)); });
({ word_1 tmp_10690 = addoverflow_8(tmp_9466(intp), (((word_8)~imm8) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10690 << 11)); });
({ word_8 tmp_10691 = (tmp_9466(intp) - imm8); tmp_9488(intp, tmp_10691); });
({ word_1 tmp_10692 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10692 << 7)); });
({ word_1 tmp_10693 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10693 << 6)); });
({ word_1 tmp_10694 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10694 << 2)); });
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_8 tmp_10695 = (imm8 + ((intp->regs_SPR[0] >> 0) & 0x1));
({ word_1 tmp_10696 = subcarry_8(tmp_9466(intp), tmp_10695); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10696 << 0)); });
({ word_1 tmp_10697 = addoverflow_8(tmp_9466(intp), (((word_8)~tmp_10695) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10697 << 11)); });
({ word_8 tmp_10698 = (tmp_9466(intp) - tmp_10695); tmp_9488(intp, tmp_10698); });
({ word_1 tmp_10699 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10699 << 7)); });
({ word_1 tmp_10700 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10700 << 6)); });
({ word_1 tmp_10701 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10701 << 2)); });
})
;
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_10702 = (tmp_9466(intp) | imm8); tmp_9488(intp, tmp_10702); });
({ word_1 tmp_10703 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10703 << 0)); });
({ word_1 tmp_10704 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10704 << 11)); });
({ word_1 tmp_10705 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10705 << 7)); });
({ word_1 tmp_10706 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10706 << 6)); });
({ word_1 tmp_10707 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10707 << 2)); });
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({
word_8 tmp_10708 = (tmp_9466(intp) - imm8);
({ word_1 tmp_10709 = subcarry_8(tmp_9466(intp), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10709 << 0)); });
({ word_1 tmp_10710 = ((tmp_10708 == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10710 << 6)); });
({ word_1 tmp_10711 = ((tmp_10708 & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10711 << 7)); });
({ word_1 tmp_10712 = addoverflow_8(tmp_9466(intp), (((word_8)~imm8) + 1)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10712 << 11)); });
({ word_1 tmp_10713 = parity_even((tmp_10708 & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10713 << 2)); });
})
;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_8 tmp_10714 = (tmp_9466(intp) & imm8); tmp_9488(intp, tmp_10714); });
({ word_1 tmp_10715 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10715 << 11)); });
({ word_1 tmp_10716 = 0; (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10716 << 0)); });
({ word_1 tmp_10717 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10717 << 7)); });
({ word_1 tmp_10718 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10718 << 6)); });
({ word_1 tmp_10719 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10719 << 2)); });
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10720 = addoverflow_8(tmp_9466(intp), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10720 << 11)); });
({ word_1 tmp_10721 = addcarry_8(tmp_9466(intp), imm8); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10721 << 0)); });
({ word_8 tmp_10722 = (tmp_9466(intp) + imm8); tmp_9488(intp, tmp_10722); });
({ word_1 tmp_10723 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10723 << 7)); });
({ word_1 tmp_10724 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10724 << 6)); });
({ word_1 tmp_10725 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10725 << 2)); });
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10726 = ((addoverflow_8(tmp_9466(intp), imm8) | addoverflow_8((tmp_9466(intp) + imm8), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10726 << 11)); });
({ word_1 tmp_10727 = ((addcarry_8(tmp_9466(intp), imm8) | addcarry_8((tmp_9466(intp) + imm8), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10727 << 0)); });
({ word_8 tmp_10728 = ((tmp_9466(intp) + imm8) + ((intp->regs_SPR[0] >> 0) & 0x1)); tmp_9488(intp, tmp_10728); });
({ word_1 tmp_10729 = ((tmp_9466(intp) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10729 << 7)); });
({ word_1 tmp_10730 = ((tmp_9466(intp) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10730 << 6)); });
({ word_1 tmp_10731 = parity_even((tmp_9466(intp) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10731 << 2)); });
}
break;
default :
assert(0);
}
}
break;
case 21 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10732 = ((addoverflow_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), imm16) | addoverflow_16((((intp->regs_GPR[0] >> 0) & 0xFFFF) + imm16), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10732 << 11)); });
({ word_1 tmp_10733 = ((addcarry_16(((intp->regs_GPR[0] >> 0) & 0xFFFF), imm16) | addcarry_16((((intp->regs_GPR[0] >> 0) & 0xFFFF) + imm16), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10733 << 0)); });
({ word_16 tmp_10734 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) + imm16) + ((intp->regs_SPR[0] >> 0) & 0x1)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFF0000) | (tmp_10734 << 0)); });
({ word_1 tmp_10735 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) & (1 << (16 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10735 << 7)); });
({ word_1 tmp_10736 = ((((intp->regs_GPR[0] >> 0) & 0xFFFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10736 << 6)); });
({ word_1 tmp_10737 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFFFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10737 << 2)); });
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10738 = ((addoverflow_32((intp->regs_GPR[0]), imm32) | addoverflow_32(((intp->regs_GPR[0]) + imm32), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10738 << 11)); });
({ word_1 tmp_10739 = ((addcarry_32((intp->regs_GPR[0]), imm32) | addcarry_32(((intp->regs_GPR[0]) + imm32), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10739 << 0)); });
({ word_32 tmp_10740 = (((intp->regs_GPR[0]) + imm32) + ((intp->regs_SPR[0] >> 0) & 0x1)); ((intp->regs_GPR[0]) = tmp_10740); });
({ word_1 tmp_10741 = (((intp->regs_GPR[0]) & (1 << (32 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10741 << 7)); });
({ word_1 tmp_10742 = (((intp->regs_GPR[0]) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10742 << 6)); });
({ word_1 tmp_10743 = parity_even(((intp->regs_GPR[0]) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10743 << 2)); });
}
break;
case 20 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
({ word_1 tmp_10744 = ((addoverflow_8(((intp->regs_GPR[0] >> 0) & 0xFF), imm8) | addoverflow_8((((intp->regs_GPR[0] >> 0) & 0xFF) + imm8), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFF7FF) | (tmp_10744 << 11)); });
({ word_1 tmp_10745 = ((addcarry_8(((intp->regs_GPR[0] >> 0) & 0xFF), imm8) | addcarry_8((((intp->regs_GPR[0] >> 0) & 0xFF) + imm8), ((intp->regs_SPR[0] >> 0) & 0x1))) & 0x1); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFE) | (tmp_10745 << 0)); });
({ word_8 tmp_10746 = ((((intp->regs_GPR[0] >> 0) & 0xFF) + imm8) + ((intp->regs_SPR[0] >> 0) & 0x1)); (intp->regs_GPR[0] = (intp->regs_GPR[0] & 0xFFFFFF00) | (tmp_10746 << 0)); });
({ word_1 tmp_10747 = ((((intp->regs_GPR[0] >> 0) & 0xFF) & (1 << (8 - 1))) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFF7F) | (tmp_10747 << 7)); });
({ word_1 tmp_10748 = ((((intp->regs_GPR[0] >> 0) & 0xFF) == 0) ? 1 : 0); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFBF) | (tmp_10748 << 6)); });
({ word_1 tmp_10749 = parity_even((((intp->regs_GPR[0] >> 0) & 0xFF) & 255)); (intp->regs_SPR[0] = (intp->regs_SPR[0] & 0xFFFFFFFB) | (tmp_10749 << 2)); });
}
break;
default:
assert(0);
}
intp->pc = next_pc;
}
void dump_i386_registers (interpreter_t *intp) {
printf("EAX: 0x%x\n", intp->regs_GPR[0]);
printf("ECX: 0x%x\n", intp->regs_GPR[1]);
printf("EDX: 0x%x\n", intp->regs_GPR[2]);
printf("EBX: 0x%x\n", intp->regs_GPR[3]);
printf("ESP: 0x%x\n", intp->regs_GPR[4]);
printf("EBP: 0x%x\n", intp->regs_GPR[5]);
printf("ESI: 0x%x\n", intp->regs_GPR[6]);
printf("EDI: 0x%x\n", intp->regs_GPR[7]);
printf("EFLAGS: 0x%x\n", intp->regs_SPR[0]);
printf("FPSW: 0x%x\n", intp->regs_FSPR[0]);
printf("FPCW: 0x%x\n", intp->regs_FSPR[1]);
printf("FPST0: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[0], intp->regs_FPST[0]);
printf("FPST1: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[1], intp->regs_FPST[1]);
printf("FPST2: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[2], intp->regs_FPST[2]);
printf("FPST3: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[3], intp->regs_FPST[3]);
printf("FPST4: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[4], intp->regs_FPST[4]);
printf("FPST5: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[5], intp->regs_FPST[5]);
printf("FPST6: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[6], intp->regs_FPST[6]);
printf("FPST7: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPST[7], intp->regs_FPST[7]);
printf("PC: 0x%x\n", intp->pc);
}
