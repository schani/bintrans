void disassemble_alpha_insn (word_32 insn, word_64 addr) {
switch (((insn >> 26) & 0x3F)) {
case 18:
switch (((insn >> 5) & 0xFF)) {
case 177:
/* ZAPNOT_IMM */
assert((insn & 0xFC001FE0) == 0x48001620);
printf("zapnot $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 49:
/* ZAPNOT */
assert((insn & 0xFC00FFE0) == 0x48000620);
printf("zapnot $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 176:
/* ZAP_IMM */
assert((insn & 0xFC001FE0) == 0x48001600);
printf("zap $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 48:
/* ZAP */
assert((insn & 0xFC00FFE0) == 0x48000600);
printf("zap $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 180:
/* SRL_IMM */
assert((insn & 0xFC001FE0) == 0x48001680);
printf("srl $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 52:
/* SRL */
assert((insn & 0xFC00FFE0) == 0x48000680);
printf("srl $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 188:
/* SRA_IMM */
assert((insn & 0xFC001FE0) == 0x48001780);
printf("sra $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 60:
/* SRA */
assert((insn & 0xFC00FFE0) == 0x48000780);
printf("sra $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 185:
/* SLL_IMM */
assert((insn & 0xFC001FE0) == 0x48001720);
printf("sll $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 57:
/* SLL */
assert((insn & 0xFC00FFE0) == 0x48000720);
printf("sll $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 146:
/* MSKWL_IMM */
assert((insn & 0xFC001FE0) == 0x48001240);
printf("mskwl $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 18:
/* MSKWL */
assert((insn & 0xFC00FFE0) == 0x48000240);
printf("mskwl $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 210:
/* MSKWH_IMM */
assert((insn & 0xFC001FE0) == 0x48001A40);
printf("mskwh $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 82:
/* MSKWH */
assert((insn & 0xFC00FFE0) == 0x48000A40);
printf("mskwh $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 178:
/* MSKQL_IMM */
assert((insn & 0xFC001FE0) == 0x48001640);
printf("mskql $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 50:
/* MSKQL */
assert((insn & 0xFC00FFE0) == 0x48000640);
printf("mskql $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 242:
/* MSKQH_IMM */
assert((insn & 0xFC001FE0) == 0x48001E40);
printf("mskqh $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 114:
/* MSKQH */
assert((insn & 0xFC00FFE0) == 0x48000E40);
printf("mskqh $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 162:
/* MSKLL_IMM */
assert((insn & 0xFC001FE0) == 0x48001440);
printf("mskll $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 34:
/* MSKLL */
assert((insn & 0xFC00FFE0) == 0x48000440);
printf("mskll $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 226:
/* MSKLH_IMM */
assert((insn & 0xFC001FE0) == 0x48001C40);
printf("msklh $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 98:
/* MSKLH */
assert((insn & 0xFC00FFE0) == 0x48000C40);
printf("msklh $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 130:
/* MSKBL_IMM */
assert((insn & 0xFC001FE0) == 0x48001040);
printf("mskbl $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 2:
/* MSKBL */
assert((insn & 0xFC00FFE0) == 0x48000040);
printf("mskbl $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 155:
/* INSWL_IMM */
assert((insn & 0xFC001FE0) == 0x48001360);
printf("inswl $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 27:
/* INSWL */
assert((insn & 0xFC00FFE0) == 0x48000360);
printf("inswl $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 215:
/* INSWH_IMM */
assert((insn & 0xFC001FE0) == 0x48001AE0);
printf("inswh $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 87:
/* INSWH */
assert((insn & 0xFC00FFE0) == 0x48000AE0);
printf("inswh $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 187:
/* INSQL_IMM */
assert((insn & 0xFC001FE0) == 0x48001760);
printf("insql $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 59:
/* INSQL */
assert((insn & 0xFC00FFE0) == 0x48000760);
printf("insql $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 247:
/* INSQH_IMM */
assert((insn & 0xFC001FE0) == 0x48001EE0);
printf("insqh $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 119:
/* INSQH */
assert((insn & 0xFC00FFE0) == 0x48000EE0);
printf("insqh $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 171:
/* INSLL_IMM */
assert((insn & 0xFC001FE0) == 0x48001560);
printf("insll $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 43:
/* INSLL */
assert((insn & 0xFC00FFE0) == 0x48000560);
printf("insll $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 231:
/* INSLH_IMM */
assert((insn & 0xFC001FE0) == 0x48001CE0);
printf("inslh $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 103:
/* INSLH */
assert((insn & 0xFC00FFE0) == 0x48000CE0);
printf("inslh $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 139:
/* INSBL_IMM */
assert((insn & 0xFC001FE0) == 0x48001160);
printf("insbl $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 11:
/* INSBL */
assert((insn & 0xFC00FFE0) == 0x48000160);
printf("insbl $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 150:
/* EXTWL_IMM */
assert((insn & 0xFC001FE0) == 0x480012C0);
printf("extwl $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 22:
/* EXTWL */
assert((insn & 0xFC00FFE0) == 0x480002C0);
printf("extwl $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 218:
/* EXTWH_IMM */
assert((insn & 0xFC001FE0) == 0x48001B40);
printf("extwh $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 90:
/* EXTWH */
assert((insn & 0xFC00FFE0) == 0x48000B40);
printf("extwh $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 182:
/* EXTQL_IMM */
assert((insn & 0xFC001FE0) == 0x480016C0);
printf("extql $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 54:
/* EXTQL */
assert((insn & 0xFC00FFE0) == 0x480006C0);
printf("extql $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 250:
/* EXTQH_IMM */
assert((insn & 0xFC001FE0) == 0x48001F40);
printf("extqh $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 122:
/* EXTQH */
assert((insn & 0xFC00FFE0) == 0x48000F40);
printf("extqh $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 166:
/* EXTLL_IMM */
assert((insn & 0xFC001FE0) == 0x480014C0);
printf("extll $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 38:
/* EXTLL */
assert((insn & 0xFC00FFE0) == 0x480004C0);
printf("extll $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 234:
/* EXTLH_IMM */
assert((insn & 0xFC001FE0) == 0x48001D40);
printf("extlh $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 106:
/* EXTLH */
assert((insn & 0xFC00FFE0) == 0x48000D40);
printf("extlh $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 134:
/* EXTBL_IMM */
assert((insn & 0xFC001FE0) == 0x480010C0);
printf("extbl $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 6:
/* EXTBL */
assert((insn & 0xFC00FFE0) == 0x480000C0);
printf("extbl $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 17:
switch (((insn >> 5) & 0xFF)) {
case 192:
/* XOR_IMM */
assert((insn & 0xFC001FE0) == 0x44001800);
printf("xor $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 64:
/* XOR */
assert((insn & 0xFC00FFE0) == 0x44000800);
printf("xor $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 168:
/* ORNOT_IMM */
assert((insn & 0xFC001FE0) == 0x44001500);
printf("ornot $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 40:
/* ORNOT */
assert((insn & 0xFC00FFE0) == 0x44000500);
printf("ornot $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 236:
/* IMPLVER */
assert((insn & 0xFFFFFFE0) == 0x47E03D80);
printf("implver $%u", (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 200:
/* EQV_IMM */
assert((insn & 0xFC001FE0) == 0x44001900);
printf("eqv $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 72:
/* EQV */
assert((insn & 0xFC00FFE0) == 0x44000900);
printf("eqv $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 166:
/* CMOVNE_IMM */
assert((insn & 0xFC001FE0) == 0x440014C0);
printf("cmovne $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 38:
/* CMOVNE */
assert((insn & 0xFC00FFE0) == 0x440004C0);
printf("cmovne $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 196:
/* CMOVLT_IMM */
assert((insn & 0xFC001FE0) == 0x44001880);
printf("cmovlt $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 68:
/* CMOVLT */
assert((insn & 0xFC00FFE0) == 0x44000880);
printf("cmovlt $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 228:
/* CMOVLE_IMM */
assert((insn & 0xFC001FE0) == 0x44001C80);
printf("cmovle $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 100:
/* CMOVLE */
assert((insn & 0xFC00FFE0) == 0x44000C80);
printf("cmovle $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 148:
/* CMOVLBS_IMM */
assert((insn & 0xFC001FE0) == 0x44001280);
printf("cmovlbs $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 20:
/* CMOVLBS */
assert((insn & 0xFC00FFE0) == 0x44000280);
printf("cmovlbs $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 150:
/* CMOVLBC_IMM */
assert((insn & 0xFC001FE0) == 0x440012C0);
printf("cmovlbc $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 22:
/* CMOVLBC */
assert((insn & 0xFC00FFE0) == 0x440002C0);
printf("cmovlbc $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 230:
/* CMOVGT_IMM */
assert((insn & 0xFC001FE0) == 0x44001CC0);
printf("cmovgt $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 102:
/* CMOVGT */
assert((insn & 0xFC00FFE0) == 0x44000CC0);
printf("cmovgt $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 198:
/* CMOVGE_IMM */
assert((insn & 0xFC001FE0) == 0x440018C0);
printf("cmovge $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 70:
/* CMOVGE */
assert((insn & 0xFC00FFE0) == 0x440008C0);
printf("cmovge $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 164:
/* CMOVEQ_IMM */
assert((insn & 0xFC001FE0) == 0x44001480);
printf("cmoveq $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 36:
/* CMOVEQ */
assert((insn & 0xFC00FFE0) == 0x44000480);
printf("cmoveq $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 160:
/* BIS_IMM */
assert((insn & 0xFC001FE0) == 0x44001400);
printf("bis $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 32:
/* BIS */
assert((insn & 0xFC00FFE0) == 0x44000400);
printf("bis $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 136:
/* BIC_IMM */
assert((insn & 0xFC001FE0) == 0x44001100);
printf("bic $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 8:
/* BIC */
assert((insn & 0xFC00FFE0) == 0x44000100);
printf("bic $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 128:
/* AND_IMM */
assert((insn & 0xFC001FE0) == 0x44001000);
printf("and $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 0:
/* AND */
assert((insn & 0xFC00FFE0) == 0x44000000);
printf("and $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 225:
/* AMASK_IMM */
assert((insn & 0xFFE01FE0) == 0x47E01C20);
printf("amask $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 97:
/* AMASK */
assert((insn & 0xFFE0FFE0) == 0x47E00C20);
printf("amask $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 24:
switch (((insn >> 0) & 0xFFFF)) {
case 17408:
/* WMB */
assert((insn & 0xFC00FFFF) == 0x60004400);
printf("wmb $%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 63488:
/* WH64 */
assert((insn & 0xFC00FFFF) == 0x6000F800);
printf("wh64 $%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 0:
/* TRAPB */
assert((insn & 0xFC00FFFF) == 0x60000000);
printf("trapb $%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 49152:
/* RPCC */
assert((insn & 0xFC00FFFF) == 0x6000C000);
printf("rpcc $%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 16384:
/* MB */
assert((insn & 0xFC00FFFF) == 0x60004000);
printf("mb $%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 40960:
/* FETCH_M */
assert((insn & 0xFC00FFFF) == 0x6000A000);
printf("fetch_m $%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 32768:
/* FETCH */
assert((insn & 0xFC00FFFF) == 0x60008000);
printf("fetch $%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 1024:
/* EXCB */
assert((insn & 0xFC00FFFF) == 0x60000400);
printf("excb $%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 59392:
/* ECB */
assert((insn & 0xFC00FFFF) == 0x6000E800);
printf("ecb $%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 19:
switch (((insn >> 5) & 0xFF)) {
case 176:
/* UMULH_IMM */
assert((insn & 0xFC001FE0) == 0x4C001600);
printf("umulh $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 48:
/* UMULH */
assert((insn & 0xFC00FFE0) == 0x4C000600);
printf("umulh $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 160:
/* MULQ_IMM */
assert((insn & 0xFC001FE0) == 0x4C001400);
printf("mulq $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 32:
/* MULQ */
assert((insn & 0xFC00FFE0) == 0x4C000400);
printf("mulq $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 128:
/* MULL_IMM */
assert((insn & 0xFC001FE0) == 0x4C001000);
printf("mull $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 0:
/* MULL */
assert((insn & 0xFC00FFE0) == 0x4C000000);
printf("mull $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 22:
switch (((insn >> 5) & 0x7FF)) {
case 161:
/* SUBT */
assert((insn & 0xFC00FFE0) == 0x58001420);
printf("subt $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 129:
/* SUBS */
assert((insn & 0xFC00FFE0) == 0x58001020);
printf("subs $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 162:
/* MULT */
assert((insn & 0xFC00FFE0) == 0x58001440);
printf("mult $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 130:
/* MULS */
assert((insn & 0xFC00FFE0) == 0x58001040);
printf("muls $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 163:
/* DIVT */
assert((insn & 0xFC00FFE0) == 0x58001460);
printf("divt $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 131:
/* DIVS */
assert((insn & 0xFC00FFE0) == 0x58001060);
printf("divs $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 172:
/* CVTTS */
assert((insn & 0xFC00FFE0) == 0x58001580);
printf("cvtts $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 47:
/* CVTTQC */
assert((insn & 0xFFE0FFE0) == 0x5BE005E0);
printf("cvttqc $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 175:
/* CVTTQ */
assert((insn & 0xFFE0FFE0) == 0x5BE015E0);
printf("cvttq $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 684:
/* CVTST */
assert((insn & 0xFC00FFE0) == 0x58005580);
printf("cvtst $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 62:
/* CVTQTC */
assert((insn & 0xFFE0FFE0) == 0x5BE007C0);
printf("cvtqtc $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 190:
/* CVTQT */
assert((insn & 0xFFE0FFE0) == 0x5BE017C0);
printf("cvtqt $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 188:
/* CVTQS */
assert((insn & 0xFC00FFE0) == 0x58001780);
printf("cvtqs $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 164:
/* CMPTUN */
assert((insn & 0xFC00FFE0) == 0x58001480);
printf("cmptun $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 166:
/* CMPTLT */
assert((insn & 0xFC00FFE0) == 0x580014C0);
printf("cmptlt $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 167:
/* CMPTLE */
assert((insn & 0xFC00FFE0) == 0x580014E0);
printf("cmptle $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 165:
/* CMPTEQ */
assert((insn & 0xFC00FFE0) == 0x580014A0);
printf("cmpteq $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 160:
/* ADDT */
assert((insn & 0xFC00FFE0) == 0x58001400);
printf("addt $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 128:
/* ADDS */
assert((insn & 0xFC00FFE0) == 0x58001000);
printf("adds $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 16:
switch (((insn >> 5) & 0xFF)) {
case 169:
/* SUBQ_IMM */
assert((insn & 0xFC001FE0) == 0x40001520);
printf("subq $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 41:
/* SUBQ */
assert((insn & 0xFC00FFE0) == 0x40000520);
printf("subq $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 137:
/* SUBL_IMM */
assert((insn & 0xFC001FE0) == 0x40001120);
printf("subl $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 9:
/* SUBL */
assert((insn & 0xFC00FFE0) == 0x40000120);
printf("subl $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 187:
/* S8SUBQ_IMM */
assert((insn & 0xFC001FE0) == 0x40001760);
printf("s8subq $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 59:
/* S8SUBQ */
assert((insn & 0xFC00FFE0) == 0x40000760);
printf("s8subq $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 155:
/* S8SUBL_IMM */
assert((insn & 0xFC001FE0) == 0x40001360);
printf("s8subl $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 27:
/* S8SUBL */
assert((insn & 0xFC00FFE0) == 0x40000360);
printf("s8subl $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 178:
/* S8ADDQ_IMM */
assert((insn & 0xFC001FE0) == 0x40001640);
printf("s8addq $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 50:
/* S8ADDQ */
assert((insn & 0xFC00FFE0) == 0x40000640);
printf("s8addq $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 146:
/* S8ADDL_IMM */
assert((insn & 0xFC001FE0) == 0x40001240);
printf("s8addl $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 18:
/* S8ADDL */
assert((insn & 0xFC00FFE0) == 0x40000240);
printf("s8addl $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 171:
/* S4SUBQ_IMM */
assert((insn & 0xFC001FE0) == 0x40001560);
printf("s4subq $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 43:
/* S4SUBQ */
assert((insn & 0xFC00FFE0) == 0x40000560);
printf("s4subq $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 139:
/* S4SUBL_IMM */
assert((insn & 0xFC001FE0) == 0x40001160);
printf("s4subl $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 11:
/* S4SUBL */
assert((insn & 0xFC00FFE0) == 0x40000160);
printf("s4subl $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 162:
/* S4ADDQ_IMM */
assert((insn & 0xFC001FE0) == 0x40001440);
printf("s4addq $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 34:
/* S4ADDQ */
assert((insn & 0xFC00FFE0) == 0x40000440);
printf("s4addq $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 130:
/* S4ADDL_IMM */
assert((insn & 0xFC001FE0) == 0x40001040);
printf("s4addl $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 2:
/* S4ADDL */
assert((insn & 0xFC00FFE0) == 0x40000040);
printf("s4addl $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 157:
/* CMPULT_IMM */
assert((insn & 0xFC001FE0) == 0x400013A0);
printf("cmpult $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 29:
/* CMPULT */
assert((insn & 0xFC00FFE0) == 0x400003A0);
printf("cmpult $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 189:
/* CMPULE_IMM */
assert((insn & 0xFC001FE0) == 0x400017A0);
printf("cmpule $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 61:
/* CMPULE */
assert((insn & 0xFC00FFE0) == 0x400007A0);
printf("cmpule $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 205:
/* CMPLT_IMM */
assert((insn & 0xFC001FE0) == 0x400019A0);
printf("cmplt $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 77:
/* CMPLT */
assert((insn & 0xFC00FFE0) == 0x400009A0);
printf("cmplt $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 237:
/* CMPLE_IMM */
assert((insn & 0xFC001FE0) == 0x40001DA0);
printf("cmple $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 109:
/* CMPLE */
assert((insn & 0xFC00FFE0) == 0x40000DA0);
printf("cmple $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 173:
/* CMPEQ_IMM */
assert((insn & 0xFC001FE0) == 0x400015A0);
printf("cmpeq $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 45:
/* CMPEQ */
assert((insn & 0xFC00FFE0) == 0x400005A0);
printf("cmpeq $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 143:
/* CMPBGE_IMM */
assert((insn & 0xFC001FE0) == 0x400011E0);
printf("cmpbge $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 15:
/* CMPBGE */
assert((insn & 0xFC00FFE0) == 0x400001E0);
printf("cmpbge $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 160:
/* ADDQ_IMM */
assert((insn & 0xFC001FE0) == 0x40001400);
printf("addq $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 32:
/* ADDQ */
assert((insn & 0xFC00FFE0) == 0x40000400);
printf("addq $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 128:
/* ADDL_IMM */
assert((insn & 0xFC001FE0) == 0x40001000);
printf("addl $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 0:
/* ADDL */
assert((insn & 0xFC00FFE0) == 0x40000000);
printf("addl $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 13:
/* STW */
assert((insn & 0xFC000000) == 0x34000000);
printf("stw $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 39:
/* STT */
assert((insn & 0xFC000000) == 0x9C000000);
printf("stt $f%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 38:
/* STS */
assert((insn & 0xFC000000) == 0x98000000);
printf("sts $f%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 15:
/* STQ_U */
assert((insn & 0xFC000000) == 0x3C000000);
printf("stq_u $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 47:
/* STQ_C */
assert((insn & 0xFC000000) == 0xBC000000);
printf("stq_c $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 45:
/* STQ */
assert((insn & 0xFC000000) == 0xB4000000);
printf("stq $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 46:
/* STL_C */
assert((insn & 0xFC000000) == 0xB8000000);
printf("stl_c $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 44:
/* STL */
assert((insn & 0xFC000000) == 0xB0000000);
printf("stl $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 14:
/* STB */
assert((insn & 0xFC000000) == 0x38000000);
printf("stb $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 20:
switch (((insn >> 5) & 0x7FF)) {
case 171:
/* SQRTT */
assert((insn & 0xFFE0FFE0) == 0x53E01560);
printf("sqrtt $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 139:
/* SQRTS */
assert((insn & 0xFFE0FFE0) == 0x53E01160);
printf("sqrts $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 36:
/* ITOFT */
assert((insn & 0xFC1FFFE0) == 0x501F0480);
printf("itoft $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 4:
/* ITOFS */
assert((insn & 0xFC1FFFE0) == 0x501F0080);
printf("itofs $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 28:
switch (((insn >> 5) & 0xFF)) {
case 129:
/* SEXTW_IMM */
assert((insn & 0xFFE01FE0) == 0x73E01020);
printf("sextw $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 1:
/* SEXTW */
assert((insn & 0xFFE0FFE0) == 0x73E00020);
printf("sextw $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 128:
/* SEXTB_IMM */
assert((insn & 0xFFE01FE0) == 0x73E01000);
printf("sextb $%u,%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 13) & 0xFF)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 0:
/* SEXTB */
assert((insn & 0xFFE0FFE0) == 0x73E00000);
printf("sextb $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 112:
/* FTOIT */
assert((insn & 0xFC1FFFE0) == 0x701F0E00);
printf("ftoit $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 120:
/* FTOIS */
assert((insn & 0xFC1FFFE0) == 0x701F0F00);
printf("ftois $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 51:
/* CTTZ */
assert((insn & 0xFFE0FFE0) == 0x73E00660);
printf("cttz $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 48:
/* CTPOP */
assert((insn & 0xFFE0FFE0) == 0x73E00600);
printf("ctpop $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 50:
/* CTLZ */
assert((insn & 0xFFE0FFE0) == 0x73E00640);
printf("ctlz $%u,$%u,$%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 23:
switch (((insn >> 5) & 0x7FF)) {
case 36:
/* MT_FPCR */
assert((insn & 0xFC00FFE0) == 0x5C000480);
printf("mt_fpcr $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 37:
/* MF_FPCR */
assert((insn & 0xFC00FFE0) == 0x5C0004A0);
printf("mf_fpcr $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 43:
/* FCMOVNE */
assert((insn & 0xFC00FFE0) == 0x5C000560);
printf("fcmovne $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 44:
/* FCMOVLT */
assert((insn & 0xFC00FFE0) == 0x5C000580);
printf("fcmovlt $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 46:
/* FCMOVLE */
assert((insn & 0xFC00FFE0) == 0x5C0005C0);
printf("fcmovle $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 47:
/* FCMOVGT */
assert((insn & 0xFC00FFE0) == 0x5C0005E0);
printf("fcmovgt $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 45:
/* FCMOVGE */
assert((insn & 0xFC00FFE0) == 0x5C0005A0);
printf("fcmovge $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 42:
/* FCMOVEQ */
assert((insn & 0xFC00FFE0) == 0x5C000540);
printf("fcmoveq $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 48:
/* CVTQL */
assert((insn & 0xFFE0FFE0) == 0x5FE00600);
printf("cvtql $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 16:
/* CVTLQ */
assert((insn & 0xFC00FFE0) == 0x5C000200);
printf("cvtlq $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 33:
/* CPYSN */
assert((insn & 0xFC00FFE0) == 0x5C000420);
printf("cpysn $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 34:
/* CPYSE */
assert((insn & 0xFC00FFE0) == 0x5C000440);
printf("cpyse $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
case 32:
/* CPYS */
assert((insn & 0xFC00FFE0) == 0x5C000400);
printf("cpys $f%u,$f%u,$f%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 0) & 0x1F)));
break;
default:
printf("unrecognized: %08x\n", insn);
}
break;
case 35:
/* LDT */
assert((insn & 0xFC000000) == 0x8C000000);
printf("ldt $f%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 34:
/* LDS */
assert((insn & 0xFC000000) == 0x88000000);
printf("lds $f%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 11:
/* LDQ_U */
assert((insn & 0xFC000000) == 0x2C000000);
printf("ldq_u $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 43:
/* LDQ_L */
assert((insn & 0xFC000000) == 0xAC000000);
printf("ldq_l $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 41:
/* LDQ */
assert((insn & 0xFC000000) == 0xA4000000);
printf("ldq $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 42:
/* LDL_L */
assert((insn & 0xFC000000) == 0xA8000000);
printf("ldl_l $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 40:
/* LDL */
assert((insn & 0xFC000000) == 0xA0000000);
printf("ldl $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 12:
/* LDWU */
assert((insn & 0xFC000000) == 0x30000000);
printf("ldwu $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 10:
/* LDBU */
assert((insn & 0xFC000000) == 0x28000000);
printf("ldbu $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 9:
/* LDAH */
assert((insn & 0xFC000000) == 0x24000000);
printf("ldah $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 8:
/* LDA */
assert((insn & 0xFC000000) == 0x20000000);
printf("lda $%u,%d($%u)", (unsigned)((word_64)((insn >> 21) & 0x1F)), (int)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_64)((insn >> 0) & 0xFFFF) | 0xFFFFFFFFFFFF0000) : (word_64)((insn >> 0) & 0xFFFF)), (unsigned)((word_64)((insn >> 16) & 0x1F)));
break;
case 26:
/* JMP */
assert((insn & 0xFC000000) == 0x68000000);
printf("jmp $%u,($%u),%u", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)((insn >> 16) & 0x1F)), (unsigned)((word_64)((insn >> 14) & 0x3)));
break;
case 53:
/* FBNE */
assert((insn & 0xFC000000) == 0xD4000000);
printf("fbne 0x%x", (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
case 50:
/* FBLT */
assert((insn & 0xFC000000) == 0xC8000000);
printf("fblt 0x%x", (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
case 51:
/* FBLE */
assert((insn & 0xFC000000) == 0xCC000000);
printf("fble 0x%x", (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
case 55:
/* FBGT */
assert((insn & 0xFC000000) == 0xDC000000);
printf("fbgt 0x%x", (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
case 54:
/* FBGE */
assert((insn & 0xFC000000) == 0xD8000000);
printf("fbge 0x%x", (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
case 49:
/* FBEQ */
assert((insn & 0xFC000000) == 0xC4000000);
printf("fbeq 0x%x", (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
case 0:
/* CALL_PAL */
assert((insn & 0xFC000000) == 0x0);
printf("call_pal %u", (unsigned)((word_64)((insn >> 0) & 0x3FFFFFF)));
break;
case 52:
/* BSR */
assert((insn & 0xFC000000) == 0xD0000000);
printf("bsr $%u,0x%x", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
case 48:
/* BR */
assert((insn & 0xFC000000) == 0xC0000000);
printf("br $%u,0x%x", (unsigned)((word_64)((insn >> 21) & 0x1F)), (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
case 61:
/* BNE */
assert((insn & 0xFC000000) == 0xF4000000);
printf("bne 0x%x", (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
case 58:
/* BLT */
assert((insn & 0xFC000000) == 0xE8000000);
printf("blt 0x%x", (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
case 59:
/* BLE */
assert((insn & 0xFC000000) == 0xEC000000);
printf("ble 0x%x", (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
case 60:
/* BLBS */
assert((insn & 0xFC000000) == 0xF0000000);
printf("blbs 0x%x", (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
case 56:
/* BLBC */
assert((insn & 0xFC000000) == 0xE0000000);
printf("blbc 0x%x", (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
case 63:
/* BGT */
assert((insn & 0xFC000000) == 0xFC000000);
printf("bgt 0x%x", (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
case 62:
/* BGE */
assert((insn & 0xFC000000) == 0xF8000000);
printf("bge 0x%x", (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
case 57:
/* BEQ */
assert((insn & 0xFC000000) == 0xE4000000);
printf("beq 0x%x", (unsigned)((word_64)(addr + ((((((insn >> 0) & 0x1FFFFF) & 0x100000) ? ((word_64)((insn >> 0) & 0x1FFFFF) | 0xFFFFFFFFFFE00000) : (word_64)((insn >> 0) & 0x1FFFFF)) << 2) + 4))));
break;
default:
printf("unrecognized: %08x\n", insn);
}
}
