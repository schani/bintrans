#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compile_push_imm32_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 )
{
genfunc_tmp_886659();
goto next_tmp_886524;
next_tmp_886524:
goto finish_tmp_886523;
finish_tmp_886523:
}
if (1 )
{
genfunc_tmp_886792();
goto next_tmp_886662;
next_tmp_886662:
goto finish_tmp_886661;
finish_tmp_886661:
}
}
void genfunc_tmp_886792 (void) {
/* SUBL_IMM */
{
word_5 tmp_731114;
word_5 field_rc;
word_5 tmp_731115;
word_5 field_ra;
word_32 tmp_731117;
word_8 field_imm;
tmp_731117 = 4;
field_imm = 4;
/* commit */
tmp_731115 = ref_gpr_reg_for_reading(0 + 4);
tmp_731114 = ref_gpr_reg_for_writing(0 + 4);
field_rc = tmp_731114;
field_ra = tmp_731115;
emit(COMPOSE_SUBL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731114);
unref_gpr_reg(tmp_731115);
/* can fail: NIL   num insns: 1 */
}
done_tmp_886791:
}
reg_t genfunc_tmp_886742 (void) {
reg_t tmp_731906;
/* SUBL_IMM */
{
word_5 tmp_731114;
word_5 field_rc;
word_5 tmp_731115;
word_5 field_ra;
word_32 tmp_731117;
word_8 field_imm;
tmp_731117 = 4;
field_imm = 4;
/* commit */
tmp_731115 = ref_gpr_reg_for_reading(0 + 4);
tmp_731114 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731114;
field_ra = tmp_731115;
emit(COMPOSE_SUBL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731115);
/* can fail: NIL   num insns: 1 */
}
done_tmp_886741:
return tmp_731906;
}
reg_t genfunc_tmp_886705 (void) {
reg_t tmp_731898;
/* SUBL_IMM */
{
word_5 tmp_731114;
word_5 field_rc;
word_5 tmp_731115;
word_5 field_ra;
word_32 tmp_731117;
word_8 field_imm;
tmp_731117 = 4;
field_imm = 4;
/* commit */
tmp_731115 = ref_gpr_reg_for_reading(0 + 4);
tmp_731114 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731114;
field_ra = tmp_731115;
emit(COMPOSE_SUBL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731115);
/* can fail: NIL   num insns: 1 */
}
done_tmp_886704:
return tmp_731898;
}
void genfunc_tmp_886659 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_886650;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_886648();
goto next_tmp_886652;
next_tmp_886652:
goto tmp_886651;
tmp_886651:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 3 */
}
goto done_tmp_886658;
fail_tmp_886650:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_886654;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_886648();
goto next_tmp_886656;
next_tmp_886656:
goto tmp_886655;
tmp_886655:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 3 */
}
goto done_tmp_886658;
fail_tmp_886654:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_886648();
goto next_tmp_886527;
next_tmp_886527:
goto tmp_886526;
tmp_886526:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_886658:
}
reg_t genfunc_tmp_886648 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_886615 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_886615 >> 8) == 0)
field_imm = tmp_886615;
else goto fail_tmp_886614;
}
/* commit */
{
tmp_731858 = genfunc_tmp_886559();
goto next_tmp_886617;
next_tmp_886617:
goto tmp_886616;
tmp_886616:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_886647;
fail_tmp_886614:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_886639 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_886639))
field_imm = inv_maskmask(8, tmp_886639);
else goto fail_tmp_886638;
}
/* commit */
{
tmp_731075 = genfunc_tmp_886559();
goto next_tmp_886641;
next_tmp_886641:
goto tmp_886640;
tmp_886640:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_886647;
fail_tmp_886638:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_886559();
goto next_tmp_886645;
next_tmp_886645:
goto tmp_886644;
tmp_886644:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_886647:
return tmp_731142;
}
reg_t genfunc_tmp_886612 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_886581 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_886581 >> 8) == 0)
field_imm = tmp_886581;
else goto fail_tmp_886580;
}
/* commit */
{
tmp_731858 = genfunc_tmp_886559();
goto next_tmp_886583;
next_tmp_886583:
goto tmp_886582;
tmp_886582:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_886611;
fail_tmp_886580:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_886603 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_886603))
field_imm = inv_maskmask(8, tmp_886603);
else goto fail_tmp_886602;
}
/* commit */
{
tmp_731075 = genfunc_tmp_886559();
goto next_tmp_886605;
next_tmp_886605:
goto tmp_886604;
tmp_886604:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_886611;
fail_tmp_886602:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_886559();
goto next_tmp_886609;
next_tmp_886609:
goto tmp_886608;
tmp_886608:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_886611:
return tmp_731862;
}
reg_t genfunc_tmp_886559 (void) {
reg_t tmp_731876;
/* SUBQ_IMM */
{
word_5 tmp_731106;
word_5 field_rc;
word_5 tmp_731107;
word_5 field_ra;
word_64 tmp_731109;
word_8 field_imm;
tmp_731109 = 4;
field_imm = 4;
/* commit */
tmp_731107 = ref_gpr_reg_for_reading(0 + 4);
tmp_731106 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731106;
field_ra = tmp_731107;
emit(COMPOSE_SUBQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731107);
/* can fail: NIL   num insns: 1 */
}
done_tmp_886558:
return tmp_731876;
}
