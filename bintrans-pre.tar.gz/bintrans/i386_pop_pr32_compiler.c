#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compile_pop_pr32_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 )
{
genfunc_tmp_893944();
goto next_tmp_893656;
next_tmp_893656:
goto finish_tmp_893655;
finish_tmp_893655:
}
if (1 )
{
genfunc_tmp_894071();
goto next_tmp_893947;
next_tmp_893947:
goto finish_tmp_893946;
finish_tmp_893946:
}
}
void genfunc_tmp_894071 (void) {
/* ADDL_IMM */
{
word_5 tmp_731901;
word_5 field_rc;
word_5 tmp_731902;
word_5 field_ra;
word_32 tmp_731904;
word_8 field_imm;
tmp_731904 = 4;
field_imm = 4;
/* commit */
tmp_731902 = ref_gpr_reg_for_reading(0 + 4);
tmp_731901 = ref_gpr_reg_for_writing(0 + 4);
field_rc = tmp_731901;
field_ra = tmp_731902;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731901);
unref_gpr_reg(tmp_731902);
/* can fail: NIL   num insns: 1 */
}
done_tmp_894070:
}
reg_t genfunc_tmp_894022 (void) {
reg_t tmp_731906;
/* ADDL_IMM */
{
word_5 tmp_731901;
word_5 field_rc;
word_5 tmp_731902;
word_5 field_ra;
word_32 tmp_731904;
word_8 field_imm;
tmp_731904 = 4;
field_imm = 4;
/* commit */
tmp_731902 = ref_gpr_reg_for_reading(0 + 4);
tmp_731901 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731901;
field_ra = tmp_731902;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731902);
/* can fail: NIL   num insns: 1 */
}
done_tmp_894021:
return tmp_731906;
}
reg_t genfunc_tmp_893991 (void) {
reg_t tmp_731898;
/* ADDL_IMM */
{
word_5 tmp_731901;
word_5 field_rc;
word_5 tmp_731902;
word_5 field_ra;
word_32 tmp_731904;
word_8 field_imm;
tmp_731904 = 4;
field_imm = 4;
/* commit */
tmp_731902 = ref_gpr_reg_for_reading(0 + 4);
tmp_731901 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731901;
field_ra = tmp_731902;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731902);
/* can fail: NIL   num insns: 1 */
}
done_tmp_893990:
return tmp_731898;
}
void genfunc_tmp_893944 (void) {
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_893773();
goto next_tmp_893941;
next_tmp_893941:
goto tmp_893940;
tmp_893940:
}
tmp_731381 = ref_gpr_reg_for_writing(0 + opcode_reg);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731381);
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_893943:
}
reg_t genfunc_tmp_893893 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_893773();
goto next_tmp_893870;
next_tmp_893870:
goto tmp_893869;
tmp_893869:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_893892:
return tmp_731906;
}
reg_t genfunc_tmp_893845 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_893814 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_893814 >> 8) == 0)
field_imm = tmp_893814;
else goto fail_tmp_893813;
}
/* commit */
{
tmp_731858 = genfunc_tmp_893776();
goto next_tmp_893816;
next_tmp_893816:
goto tmp_893815;
tmp_893815:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_893844;
fail_tmp_893813:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_893836 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_893836))
field_imm = inv_maskmask(8, tmp_893836);
else goto fail_tmp_893835;
}
/* commit */
{
tmp_731075 = genfunc_tmp_893776();
goto next_tmp_893838;
next_tmp_893838:
goto tmp_893837;
tmp_893837:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_893844;
fail_tmp_893835:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_893776();
goto next_tmp_893842;
next_tmp_893842:
goto tmp_893841;
tmp_893841:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_893844:
return tmp_731862;
}
reg_t genfunc_tmp_893776 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_893773();
goto next_tmp_893697;
next_tmp_893697:
goto tmp_893696;
tmp_893696:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_893775:
return tmp_731898;
}
reg_t genfunc_tmp_893773 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_893749 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_893749 >> 8) == 0)
field_imm = tmp_893749;
else goto fail_tmp_893748;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + 4);
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_893772;
fail_tmp_893748:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_893770 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_893770))
field_imm = inv_maskmask(8, tmp_893770);
else goto fail_tmp_893769;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + 4);
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_893772;
fail_tmp_893769:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + 4);
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_893772:
return tmp_731382;
}
reg_t genfunc_tmp_893746 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_893724 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_893724 >> 8) == 0)
field_imm = tmp_893724;
else goto fail_tmp_893723;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + 4);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_893745;
fail_tmp_893723:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_893743 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_893743))
field_imm = inv_maskmask(8, tmp_893743);
else goto fail_tmp_893742;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + 4);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_893745;
fail_tmp_893742:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + 4);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_893745:
return tmp_731862;
}
