#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compile_lea_r32_rm32_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_4230();
goto next_tmp_4218;
next_tmp_4218:
goto finish_tmp_4217;
finish_tmp_4217:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_4438();
goto next_tmp_4233;
next_tmp_4233:
goto finish_tmp_4232;
finish_tmp_4232:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_5288();
goto next_tmp_4441;
next_tmp_4441:
goto finish_tmp_4440;
finish_tmp_4440:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_5387();
goto next_tmp_5291;
next_tmp_5291:
goto finish_tmp_5290;
finish_tmp_5290:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_5595();
goto next_tmp_5390;
next_tmp_5390:
goto finish_tmp_5389;
finish_tmp_5389:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_5815();
goto next_tmp_5598;
next_tmp_5598:
goto finish_tmp_5597;
finish_tmp_5597:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_5902();
goto next_tmp_5818;
next_tmp_5818:
goto finish_tmp_5817;
finish_tmp_5817:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; }))
{
genfunc_tmp_5902();
goto next_tmp_5905;
next_tmp_5905:
goto finish_tmp_5904;
finish_tmp_5904:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_6119();
goto next_tmp_5908;
next_tmp_5908:
goto finish_tmp_5907;
finish_tmp_5907:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_6339();
goto next_tmp_6122;
next_tmp_6122:
goto finish_tmp_6121;
finish_tmp_6121:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_6559();
goto next_tmp_6342;
next_tmp_6342:
goto finish_tmp_6341;
finish_tmp_6341:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_6767();
goto next_tmp_6562;
next_tmp_6562:
goto finish_tmp_6561;
finish_tmp_6561:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_7109();
goto next_tmp_6770;
next_tmp_6770:
goto finish_tmp_6769;
finish_tmp_6769:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_7459();
goto next_tmp_7112;
next_tmp_7112:
goto finish_tmp_7111;
finish_tmp_7111:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_7667();
goto next_tmp_7462;
next_tmp_7462:
goto finish_tmp_7461;
finish_tmp_7461:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_7881();
goto next_tmp_7670;
next_tmp_7670:
goto finish_tmp_7669;
finish_tmp_7669:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_8101();
goto next_tmp_7884;
next_tmp_7884:
goto finish_tmp_7883;
finish_tmp_7883:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_8321();
goto next_tmp_8104;
next_tmp_8104:
goto finish_tmp_8103;
finish_tmp_8103:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_8529();
goto next_tmp_8324;
next_tmp_8324:
goto finish_tmp_8323;
finish_tmp_8323:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_8749();
goto next_tmp_8532;
next_tmp_8532:
goto finish_tmp_8531;
finish_tmp_8531:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_8969();
goto next_tmp_8752;
next_tmp_8752:
goto finish_tmp_8751;
finish_tmp_8751:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_9177();
goto next_tmp_8972;
next_tmp_8972:
goto finish_tmp_8971;
finish_tmp_8971:
}
}
void genfunc_tmp_9177 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
tmp_4216 = ref_gpr_reg_for_reading(0 + 5);
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_9176:
}
reg_t genfunc_tmp_9098 (void) {
reg_t tmp_8974;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
tmp_4216 = ref_gpr_reg_for_reading(0 + 5);
tmp_4213 = tmp_8974 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_9097:
return tmp_8974;
}
reg_t genfunc_tmp_9044 (void) {
reg_t tmp_8991;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
tmp_4216 = ref_gpr_reg_for_reading(0 + 5);
tmp_4213 = tmp_8991 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_9043:
return tmp_8991;
}
void genfunc_tmp_8969 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
{
tmp_4216 = genfunc_tmp_7253();
goto next_tmp_8891;
next_tmp_8891:
goto tmp_8890;
tmp_8890:
}
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 4 */
}
done_tmp_8968:
}
reg_t genfunc_tmp_8886 (void) {
reg_t tmp_8754;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
{
tmp_4216 = genfunc_tmp_7253();
goto next_tmp_8763;
next_tmp_8763:
goto tmp_8762;
tmp_8762:
}
tmp_4213 = tmp_8754 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 4 */
}
done_tmp_8885:
return tmp_8754;
}
reg_t genfunc_tmp_8832 (void) {
reg_t tmp_8775;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
{
tmp_4216 = genfunc_tmp_7253();
goto next_tmp_8784;
next_tmp_8784:
goto tmp_8783;
tmp_8783:
}
tmp_4213 = tmp_8775 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 4 */
}
done_tmp_8831:
return tmp_8775;
}
void genfunc_tmp_8749 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
{
tmp_4216 = genfunc_tmp_6903();
goto next_tmp_8671;
next_tmp_8671:
goto tmp_8670;
tmp_8670:
}
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 3 */
}
done_tmp_8748:
}
reg_t genfunc_tmp_8666 (void) {
reg_t tmp_8534;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
{
tmp_4216 = genfunc_tmp_6903();
goto next_tmp_8543;
next_tmp_8543:
goto tmp_8542;
tmp_8542:
}
tmp_4213 = tmp_8534 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 3 */
}
done_tmp_8665:
return tmp_8534;
}
reg_t genfunc_tmp_8612 (void) {
reg_t tmp_8555;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
{
tmp_4216 = genfunc_tmp_6903();
goto next_tmp_8564;
next_tmp_8564:
goto tmp_8563;
tmp_8563:
}
tmp_4213 = tmp_8555 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 3 */
}
done_tmp_8611:
return tmp_8555;
}
void genfunc_tmp_8529 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
tmp_4216 = ref_gpr_reg_for_reading(0 + base);
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_8528:
}
reg_t genfunc_tmp_8450 (void) {
reg_t tmp_8326;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
tmp_4216 = ref_gpr_reg_for_reading(0 + base);
tmp_4213 = tmp_8326 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_8449:
return tmp_8326;
}
reg_t genfunc_tmp_8396 (void) {
reg_t tmp_8343;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
tmp_4216 = ref_gpr_reg_for_reading(0 + base);
tmp_4213 = tmp_8343 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_8395:
return tmp_8343;
}
void genfunc_tmp_8321 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
{
tmp_4216 = genfunc_tmp_5205();
goto next_tmp_8243;
next_tmp_8243:
goto tmp_8242;
tmp_8242:
}
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 4 */
}
done_tmp_8320:
}
reg_t genfunc_tmp_8238 (void) {
reg_t tmp_8106;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
{
tmp_4216 = genfunc_tmp_5205();
goto next_tmp_8115;
next_tmp_8115:
goto tmp_8114;
tmp_8114:
}
tmp_4213 = tmp_8106 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 4 */
}
done_tmp_8237:
return tmp_8106;
}
reg_t genfunc_tmp_8184 (void) {
reg_t tmp_8127;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
{
tmp_4216 = genfunc_tmp_5205();
goto next_tmp_8136;
next_tmp_8136:
goto tmp_8135;
tmp_8135:
}
tmp_4213 = tmp_8127 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 4 */
}
done_tmp_8183:
return tmp_8127;
}
void genfunc_tmp_8101 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
{
tmp_4216 = genfunc_tmp_4359();
goto next_tmp_8023;
next_tmp_8023:
goto tmp_8022;
tmp_8022:
}
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 3 */
}
done_tmp_8100:
}
reg_t genfunc_tmp_8018 (void) {
reg_t tmp_7886;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
{
tmp_4216 = genfunc_tmp_4359();
goto next_tmp_7895;
next_tmp_7895:
goto tmp_7894;
tmp_7894:
}
tmp_4213 = tmp_7886 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 3 */
}
done_tmp_8017:
return tmp_7886;
}
reg_t genfunc_tmp_7964 (void) {
reg_t tmp_7907;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
{
tmp_4216 = genfunc_tmp_4359();
goto next_tmp_7916;
next_tmp_7916:
goto tmp_7915;
tmp_7915:
}
tmp_4213 = tmp_7907 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 3 */
}
done_tmp_7963:
return tmp_7907;
}
void genfunc_tmp_7881 (void) {
/* ADDL_IMM */
{
word_5 tmp_4209;
word_5 field_rc;
word_5 tmp_4210;
word_5 field_ra;
word_32 tmp_4212;
word_8 field_imm;
tmp_4212 = disp32;
{
word_32 tmp_7819 = tmp_4212;
if ((tmp_7819 >> 8) == 0)
field_imm = tmp_7819;
else goto fail_tmp_7818;
}
/* commit */
tmp_4210 = ref_gpr_reg_for_reading(0 + rm);
tmp_4209 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4209;
field_ra = tmp_4210;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_4209);
unref_gpr_reg(tmp_4210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_7880;
fail_tmp_7818:
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + rm);
tmp_4216 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4216, disp32);
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_7880:
}
reg_t genfunc_tmp_7800 (void) {
reg_t tmp_7672;
/* ADDL_IMM */
{
word_5 tmp_4209;
word_5 field_rc;
word_5 tmp_4210;
word_5 field_ra;
word_32 tmp_4212;
word_8 field_imm;
tmp_4212 = disp32;
{
word_32 tmp_7689 = tmp_4212;
if ((tmp_7689 >> 8) == 0)
field_imm = tmp_7689;
else goto fail_tmp_7688;
}
/* commit */
tmp_4210 = ref_gpr_reg_for_reading(0 + rm);
tmp_4209 = tmp_7672 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4209;
field_ra = tmp_4210;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_4210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_7799;
fail_tmp_7688:
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + rm);
tmp_4216 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4216, disp32);
tmp_4213 = tmp_7672 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_7799:
return tmp_7672;
}
reg_t genfunc_tmp_7746 (void) {
reg_t tmp_7691;
/* ADDL_IMM */
{
word_5 tmp_4209;
word_5 field_rc;
word_5 tmp_4210;
word_5 field_ra;
word_32 tmp_4212;
word_8 field_imm;
tmp_4212 = disp32;
{
word_32 tmp_7708 = tmp_4212;
if ((tmp_7708 >> 8) == 0)
field_imm = tmp_7708;
else goto fail_tmp_7707;
}
/* commit */
tmp_4210 = ref_gpr_reg_for_reading(0 + rm);
tmp_4209 = tmp_7691 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4209;
field_ra = tmp_4210;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_4210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_7745;
fail_tmp_7707:
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + rm);
tmp_4216 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4216, disp32);
tmp_4213 = tmp_7691 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_7745:
return tmp_7691;
}
void genfunc_tmp_7667 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
tmp_4216 = ref_gpr_reg_for_reading(0 + 5);
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_7666:
}
reg_t genfunc_tmp_7588 (void) {
reg_t tmp_7464;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
tmp_4216 = ref_gpr_reg_for_reading(0 + 5);
tmp_4213 = tmp_7464 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_7587:
return tmp_7464;
}
reg_t genfunc_tmp_7534 (void) {
reg_t tmp_7481;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
tmp_4216 = ref_gpr_reg_for_reading(0 + 5);
tmp_4213 = tmp_7481 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_7533:
return tmp_7481;
}
void genfunc_tmp_7459 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
{
tmp_4216 = genfunc_tmp_7253();
goto next_tmp_7381;
next_tmp_7381:
goto tmp_7380;
tmp_7380:
}
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 4 */
}
done_tmp_7458:
}
reg_t genfunc_tmp_7376 (void) {
reg_t tmp_7114;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
{
tmp_4216 = genfunc_tmp_7253();
goto next_tmp_7123;
next_tmp_7123:
goto tmp_7122;
tmp_7122:
}
tmp_4213 = tmp_7114 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 4 */
}
done_tmp_7375:
return tmp_7114;
}
reg_t genfunc_tmp_7322 (void) {
reg_t tmp_7265;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
{
tmp_4216 = genfunc_tmp_7253();
goto next_tmp_7274;
next_tmp_7274:
goto tmp_7273;
tmp_7273:
}
tmp_4213 = tmp_7265 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 4 */
}
done_tmp_7321:
return tmp_7265;
}
reg_t genfunc_tmp_7253 (void) {
reg_t tmp_7121;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + 5);
{
tmp_4216 = genfunc_tmp_5082();
goto next_tmp_7130;
next_tmp_7130:
goto tmp_7129;
tmp_7129:
}
tmp_4213 = tmp_7121 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_7252:
return tmp_7121;
}
reg_t genfunc_tmp_7199 (void) {
reg_t tmp_7142;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + 5);
{
tmp_4216 = genfunc_tmp_5082();
goto next_tmp_7151;
next_tmp_7151:
goto tmp_7150;
tmp_7150:
}
tmp_4213 = tmp_7142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_7198:
return tmp_7142;
}
void genfunc_tmp_7109 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
{
tmp_4216 = genfunc_tmp_6903();
goto next_tmp_7031;
next_tmp_7031:
goto tmp_7030;
tmp_7030:
}
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 3 */
}
done_tmp_7108:
}
reg_t genfunc_tmp_7026 (void) {
reg_t tmp_6772;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
{
tmp_4216 = genfunc_tmp_6903();
goto next_tmp_6781;
next_tmp_6781:
goto tmp_6780;
tmp_6780:
}
tmp_4213 = tmp_6772 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 3 */
}
done_tmp_7025:
return tmp_6772;
}
reg_t genfunc_tmp_6972 (void) {
reg_t tmp_6915;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
{
tmp_4216 = genfunc_tmp_6903();
goto next_tmp_6924;
next_tmp_6924:
goto tmp_6923;
tmp_6923:
}
tmp_4213 = tmp_6915 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 3 */
}
done_tmp_6971:
return tmp_6915;
}
reg_t genfunc_tmp_6903 (void) {
reg_t tmp_6779;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + 5);
tmp_4216 = ref_gpr_reg_for_reading(0 + index);
tmp_4213 = tmp_6779 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 1 */
}
done_tmp_6902:
return tmp_6779;
}
reg_t genfunc_tmp_6849 (void) {
reg_t tmp_6796;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + 5);
tmp_4216 = ref_gpr_reg_for_reading(0 + index);
tmp_4213 = tmp_6796 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 1 */
}
done_tmp_6848:
return tmp_6796;
}
void genfunc_tmp_6767 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
tmp_4216 = ref_gpr_reg_for_reading(0 + base);
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_6766:
}
reg_t genfunc_tmp_6688 (void) {
reg_t tmp_6564;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
tmp_4216 = ref_gpr_reg_for_reading(0 + base);
tmp_4213 = tmp_6564 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_6687:
return tmp_6564;
}
reg_t genfunc_tmp_6634 (void) {
reg_t tmp_6581;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
tmp_4216 = ref_gpr_reg_for_reading(0 + base);
tmp_4213 = tmp_6581 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_6633:
return tmp_6581;
}
void genfunc_tmp_6559 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
{
tmp_4216 = genfunc_tmp_5205();
goto next_tmp_6481;
next_tmp_6481:
goto tmp_6480;
tmp_6480:
}
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 4 */
}
done_tmp_6558:
}
reg_t genfunc_tmp_6476 (void) {
reg_t tmp_6344;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
{
tmp_4216 = genfunc_tmp_5205();
goto next_tmp_6353;
next_tmp_6353:
goto tmp_6352;
tmp_6352:
}
tmp_4213 = tmp_6344 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 4 */
}
done_tmp_6475:
return tmp_6344;
}
reg_t genfunc_tmp_6422 (void) {
reg_t tmp_6365;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
{
tmp_4216 = genfunc_tmp_5205();
goto next_tmp_6374;
next_tmp_6374:
goto tmp_6373;
tmp_6373:
}
tmp_4213 = tmp_6365 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 4 */
}
done_tmp_6421:
return tmp_6365;
}
void genfunc_tmp_6339 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
{
tmp_4216 = genfunc_tmp_4359();
goto next_tmp_6261;
next_tmp_6261:
goto tmp_6260;
tmp_6260:
}
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 3 */
}
done_tmp_6338:
}
reg_t genfunc_tmp_6256 (void) {
reg_t tmp_6124;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
{
tmp_4216 = genfunc_tmp_4359();
goto next_tmp_6133;
next_tmp_6133:
goto tmp_6132;
tmp_6132:
}
tmp_4213 = tmp_6124 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 3 */
}
done_tmp_6255:
return tmp_6124;
}
reg_t genfunc_tmp_6202 (void) {
reg_t tmp_6145;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
{
tmp_4216 = genfunc_tmp_4359();
goto next_tmp_6154;
next_tmp_6154:
goto tmp_6153;
tmp_6153:
}
tmp_4213 = tmp_6145 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 3 */
}
done_tmp_6201:
return tmp_6145;
}
void genfunc_tmp_6119 (void) {
/* ADDL_IMM */
{
word_5 tmp_4209;
word_5 field_rc;
word_5 tmp_4210;
word_5 field_ra;
word_32 tmp_4212;
word_8 field_imm;
tmp_4212 = ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8);
{
word_32 tmp_6057 = tmp_4212;
if ((tmp_6057 >> 8) == 0)
field_imm = tmp_6057;
else goto fail_tmp_6056;
}
/* commit */
tmp_4210 = ref_gpr_reg_for_reading(0 + rm);
tmp_4209 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4209;
field_ra = tmp_4210;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_4209);
unref_gpr_reg(tmp_4210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_6118;
fail_tmp_6056:
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + rm);
tmp_4216 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4216, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_6118:
}
reg_t genfunc_tmp_6038 (void) {
reg_t tmp_5910;
/* ADDL_IMM */
{
word_5 tmp_4209;
word_5 field_rc;
word_5 tmp_4210;
word_5 field_ra;
word_32 tmp_4212;
word_8 field_imm;
tmp_4212 = ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8);
{
word_32 tmp_5927 = tmp_4212;
if ((tmp_5927 >> 8) == 0)
field_imm = tmp_5927;
else goto fail_tmp_5926;
}
/* commit */
tmp_4210 = ref_gpr_reg_for_reading(0 + rm);
tmp_4209 = tmp_5910 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4209;
field_ra = tmp_4210;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_4210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_6037;
fail_tmp_5926:
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + rm);
tmp_4216 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4216, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
tmp_4213 = tmp_5910 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_6037:
return tmp_5910;
}
reg_t genfunc_tmp_5984 (void) {
reg_t tmp_5929;
/* ADDL_IMM */
{
word_5 tmp_4209;
word_5 field_rc;
word_5 tmp_4210;
word_5 field_ra;
word_32 tmp_4212;
word_8 field_imm;
tmp_4212 = ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8);
{
word_32 tmp_5946 = tmp_4212;
if ((tmp_5946 >> 8) == 0)
field_imm = tmp_5946;
else goto fail_tmp_5945;
}
/* commit */
tmp_4210 = ref_gpr_reg_for_reading(0 + rm);
tmp_4209 = tmp_5929 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4209;
field_ra = tmp_4210;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_4210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5983;
fail_tmp_5945:
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + rm);
tmp_4216 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4216, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
tmp_4213 = tmp_5929 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_5983:
return tmp_5929;
}
void genfunc_tmp_5902 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5822;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5822:
/* ADDL_IMM */
{
word_5 tmp_4209;
word_5 field_rc;
word_5 field_ra;
word_32 tmp_4211;
word_8 field_imm;
tmp_4211 = disp32;
field_ra = 31;
{
word_32 tmp_5825 = tmp_4211;
if ((tmp_5825 >> 8) == 0)
field_imm = tmp_5825;
else goto fail_tmp_5824;
}
/* commit */
tmp_4209 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4209;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_4209);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5824:
/* ADDQ */
{
word_5 tmp_4205;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5829;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_4205 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4205;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4205);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5829:
/* ADDQ_IMM */
{
word_5 tmp_4201;
word_5 field_rc;
word_5 field_ra;
word_64 tmp_4203;
word_8 field_imm;
tmp_4203 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
field_ra = 31;
{
word_64 tmp_5832 = tmp_4203;
if ((tmp_5832 >> 8) == 0)
field_imm = tmp_5832;
else goto fail_tmp_5831;
}
/* commit */
tmp_4201 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4201;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_4201);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5831:
/* AND */
{
word_5 tmp_4183;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5833;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_4183 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4183;
emit(COMPOSE_AND(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4183);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5833:
/* BIC */
{
word_5 tmp_4169;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5834;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_4169 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4169;
emit(COMPOSE_BIC(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4169);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5834:
/* BIS */
{
word_5 tmp_4161;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5837;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_4161 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4161;
emit(COMPOSE_BIS(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4161);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5837:
/* BIS_IMM */
{
word_5 tmp_4157;
word_5 field_rc;
word_5 field_ra;
word_64 tmp_4159;
word_8 field_imm;
tmp_4159 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
field_ra = 31;
{
word_64 tmp_5839 = tmp_4159;
if ((tmp_5839 >> 8) == 0)
field_imm = tmp_5839;
else goto fail_tmp_5838;
}
/* commit */
tmp_4157 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4157;
emit(COMPOSE_BIS_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_4157);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5838:
/* CMPEQ */
{
word_5 tmp_4062;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (1 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5840;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_4062 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4062;
emit(COMPOSE_CMPEQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4062);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5840:
/* CMPLE */
{
word_5 tmp_4054;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (1 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5841;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_4054 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4054;
emit(COMPOSE_CMPLE(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4054);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5841:
/* CMPLT */
{
word_5 tmp_4046;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5842;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_4046 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4046;
emit(COMPOSE_CMPLT(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4046);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5842:
/* CMPULE */
{
word_5 tmp_4024;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (1 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5843;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_4024 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4024;
emit(COMPOSE_CMPULE(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4024);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5843:
/* CMPULT */
{
word_5 tmp_4016;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5844;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_4016 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4016;
emit(COMPOSE_CMPULT(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4016);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5844:
/* CTLZ */
{
word_5 tmp_4002;
word_5 field_rc;
word_5 field_rb;
if (64 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5845;
field_rb = 31;
/* commit */
tmp_4002 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4002;
emit(COMPOSE_CTLZ(field_rb, field_rc));
unref_gpr_reg(tmp_4002);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5845:
/* CTPOP */
{
word_5 tmp_4000;
word_5 field_rc;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5846;
field_rb = 31;
/* commit */
tmp_4000 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4000;
emit(COMPOSE_CTPOP(field_rb, field_rc));
unref_gpr_reg(tmp_4000);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5846:
/* CTTZ */
{
word_5 tmp_3998;
word_5 field_rc;
word_5 field_rb;
if (64 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5847;
field_rb = 31;
/* commit */
tmp_3998 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3998;
emit(COMPOSE_CTTZ(field_rb, field_rc));
unref_gpr_reg(tmp_3998);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5847:
/* EQV */
{
word_5 tmp_3976;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5848;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3976 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3976;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3976);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5848:
/* EXTQH */
{
word_5 tmp_3926;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5849;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3926 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3926;
emit(COMPOSE_EXTQH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3926);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5849:
/* EXTQL */
{
word_5 tmp_3918;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5850;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3918 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3918;
emit(COMPOSE_EXTQL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3918);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5850:
/* FTOIS */
{
word_5 tmp_3842;
word_5 field_rc;
word_5 field_fa;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5851;
field_fa = 31;
/* commit */
tmp_3842 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3842;
emit(COMPOSE_FTOIS(field_fa, field_rc));
unref_gpr_reg(tmp_3842);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5851:
/* FTOIT */
{
word_5 tmp_3840;
word_5 field_rc;
word_5 field_fa;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5852;
field_fa = 31;
/* commit */
tmp_3840 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3840;
emit(COMPOSE_FTOIT(field_fa, field_rc));
unref_gpr_reg(tmp_3840);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5852:
/* LDA */
{
word_5 tmp_3705;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_3707;
word_16 field_memory_disp;
tmp_3707 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
field_rb = 31;
{
word_64 tmp_5855 = tmp_3707;
if ((tmp_5855 >> 16) == 0xFFFFFFFFFFFF || (tmp_5855 >> 16) == 0)
field_memory_disp = (tmp_5855 & 0xFFFF);
else goto fail_tmp_5854;
}
/* commit */
tmp_3705 = ref_gpr_reg_for_writing(0 + reg);
field_ra = tmp_3705;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_3705);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5854:
/* LDAH */
{
word_5 tmp_3701;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_3703;
word_16 field_memory_disp;
tmp_3703 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
field_rb = 31;
{
word_64 tmp_5858 = tmp_3703;
if ((tmp_5858 & 0xFFFF) == 0)
{
word_64 tmp_5859 = (tmp_5858 >> 16);
if ((tmp_5859 >> 16) == 0xFFFFFFFFFFFF || (tmp_5859 >> 16) == 0)
field_memory_disp = (tmp_5859 & 0xFFFF);
else goto fail_tmp_5857;
}
else goto fail_tmp_5857;
}
/* commit */
tmp_3701 = ref_gpr_reg_for_writing(0 + reg);
field_ra = tmp_3701;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_3701);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5857:
/* MULL */
{
word_5 tmp_3588;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5860;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3588 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3588;
emit(COMPOSE_MULL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3588);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5860:
/* MULQ */
{
word_5 tmp_3580;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5861;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3580 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3580;
emit(COMPOSE_MULQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3580);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5861:
/* ORNOT */
{
word_5 tmp_3564;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5862;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3564 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3564;
emit(COMPOSE_ORNOT(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3564);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5862:
/* ORNOT_IMM */
{
word_5 tmp_3560;
word_5 field_rc;
word_5 field_ra;
word_64 tmp_3562;
word_8 field_imm;
tmp_3562 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
field_ra = 31;
{
word_64 tmp_5864 = (~tmp_3562 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_5864 >> 8) == 0)
field_imm = tmp_5864;
else goto fail_tmp_5863;
}
/* commit */
tmp_3560 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3560;
emit(COMPOSE_ORNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_3560);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5863:
/* S4ADDL */
{
word_5 tmp_3556;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5866;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3556 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3556;
emit(COMPOSE_S4ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3556);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5866:
/* S4ADDL_IMM */
{
word_5 tmp_3552;
word_5 field_rc;
word_5 field_ra;
word_32 tmp_3554;
word_8 field_imm;
tmp_3554 = disp32;
field_ra = 31;
{
word_32 tmp_5868 = tmp_3554;
if ((tmp_5868 >> 8) == 0)
field_imm = tmp_5868;
else goto fail_tmp_5867;
}
/* commit */
tmp_3552 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3552;
emit(COMPOSE_S4ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_3552);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5867:
/* S4ADDQ */
{
word_5 tmp_3548;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5870;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3548 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3548;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3548);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5870:
/* S4ADDQ_IMM */
{
word_5 tmp_3544;
word_5 field_rc;
word_5 field_ra;
word_64 tmp_3546;
word_8 field_imm;
tmp_3546 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
field_ra = 31;
{
word_64 tmp_5872 = tmp_3546;
if ((tmp_5872 >> 8) == 0)
field_imm = tmp_5872;
else goto fail_tmp_5871;
}
/* commit */
tmp_3544 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3544;
emit(COMPOSE_S4ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_3544);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5871:
/* S4SUBL */
{
word_5 tmp_3540;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5873;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3540 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3540;
emit(COMPOSE_S4SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3540);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5873:
/* S4SUBQ */
{
word_5 tmp_3532;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5874;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3532 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3532;
emit(COMPOSE_S4SUBQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3532);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5874:
/* S8ADDL */
{
word_5 tmp_3524;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5876;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3524 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3524;
emit(COMPOSE_S8ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3524);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5876:
/* S8ADDL_IMM */
{
word_5 tmp_3520;
word_5 field_rc;
word_5 field_ra;
word_32 tmp_3522;
word_8 field_imm;
tmp_3522 = disp32;
field_ra = 31;
{
word_32 tmp_5878 = tmp_3522;
if ((tmp_5878 >> 8) == 0)
field_imm = tmp_5878;
else goto fail_tmp_5877;
}
/* commit */
tmp_3520 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3520;
emit(COMPOSE_S8ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_3520);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5877:
/* S8ADDQ */
{
word_5 tmp_3516;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5880;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3516 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3516;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3516);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5880:
/* S8ADDQ_IMM */
{
word_5 tmp_3512;
word_5 field_rc;
word_5 field_ra;
word_64 tmp_3514;
word_8 field_imm;
tmp_3514 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
field_ra = 31;
{
word_64 tmp_5882 = tmp_3514;
if ((tmp_5882 >> 8) == 0)
field_imm = tmp_5882;
else goto fail_tmp_5881;
}
/* commit */
tmp_3512 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3512;
emit(COMPOSE_S8ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_3512);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5881:
/* S8SUBL */
{
word_5 tmp_3508;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5883;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3508 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3508;
emit(COMPOSE_S8SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3508);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5883:
/* S8SUBQ */
{
word_5 tmp_3500;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5884;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3500 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3500;
emit(COMPOSE_S8SUBQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3500);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5884:
/* SEXTB */
{
word_5 tmp_3494;
word_5 field_rc;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5885;
field_rb = 31;
/* commit */
tmp_3494 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3494;
emit(COMPOSE_SEXTB(field_rb, field_rc));
unref_gpr_reg(tmp_3494);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5885:
/* SEXTB_IMM */
{
word_5 tmp_3492;
word_5 field_rc;
word_64 tmp_3493;
word_8 field_imm;
tmp_3493 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_5887 = tmp_3493;
if ((tmp_5887 >> 8) == 0xFFFFFFFFFFFFFF || (tmp_5887 >> 8) == 0)
field_imm = (tmp_5887 & 0xFF);
else goto fail_tmp_5886;
}
/* commit */
tmp_3492 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3492;
emit(COMPOSE_SEXTB_IMM(field_imm, field_rc));
unref_gpr_reg(tmp_3492);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5886:
/* SEXTW */
{
word_5 tmp_3490;
word_5 field_rc;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5888;
field_rb = 31;
/* commit */
tmp_3490 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3490;
emit(COMPOSE_SEXTW(field_rb, field_rc));
unref_gpr_reg(tmp_3490);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5888:
/* SEXTW_IMM */
{
word_5 tmp_3488;
word_5 field_rc;
word_64 tmp_3489;
word_8 field_imm;
tmp_3489 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_5890 = tmp_3489;
if ((tmp_5890 >> 16) == 0xFFFFFFFFFFFF || (tmp_5890 >> 16) == 0)
{
word_16 tmp_5891 = (tmp_5890 & 0xFFFF);
if ((tmp_5891 >> 8) == 0)
field_imm = tmp_5891;
else goto fail_tmp_5889;
}
else goto fail_tmp_5889;
}
/* commit */
tmp_3488 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3488;
emit(COMPOSE_SEXTW_IMM(field_imm, field_rc));
unref_gpr_reg(tmp_3488);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5889:
/* SLL */
{
word_5 tmp_3484;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5892;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3484 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3484;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3484);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5892:
/* SRA */
{
word_5 tmp_3472;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5893;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3472 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3472;
emit(COMPOSE_SRA(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3472);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5893:
/* SRL */
{
word_5 tmp_3464;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5894;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3464 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3464;
emit(COMPOSE_SRL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3464);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5894:
/* SUBL */
{
word_5 tmp_3426;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5895;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3426 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3426;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3426);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5895:
/* SUBQ */
{
word_5 tmp_3418;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5896;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3418 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3418;
emit(COMPOSE_SUBQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3418);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5896:
/* UMULH */
{
word_5 tmp_3402;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5897;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3402 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3402;
emit(COMPOSE_UMULH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3402);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5897:
/* XOR */
{
word_5 tmp_3394;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5898;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3394 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3394;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3394);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5898:
/* ZAP */
{
word_5 tmp_3386;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5899;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3386 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3386;
emit(COMPOSE_ZAP(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3386);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5899:
/* ZAPNOT */
{
word_5 tmp_3378;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_5900;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_3378 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_3378;
emit(COMPOSE_ZAPNOT(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3378);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5901;
fail_tmp_5900:
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 field_rb;
field_rb = 31;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_5901:
}
void genfunc_tmp_5815 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
{
tmp_4216 = genfunc_tmp_5082();
goto next_tmp_5737;
next_tmp_5737:
goto tmp_5736;
tmp_5736:
}
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 3 */
}
done_tmp_5814:
}
reg_t genfunc_tmp_5732 (void) {
reg_t tmp_5600;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
{
tmp_4216 = genfunc_tmp_5082();
goto next_tmp_5609;
next_tmp_5609:
goto tmp_5608;
tmp_5608:
}
tmp_4213 = tmp_5600 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 3 */
}
done_tmp_5731:
return tmp_5600;
}
reg_t genfunc_tmp_5678 (void) {
reg_t tmp_5621;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
{
tmp_4216 = genfunc_tmp_5082();
goto next_tmp_5630;
next_tmp_5630:
goto tmp_5629;
tmp_5629:
}
tmp_4213 = tmp_5621 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 3 */
}
done_tmp_5677:
return tmp_5621;
}
void genfunc_tmp_5595 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
tmp_4216 = ref_gpr_reg_for_reading(0 + index);
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_5594:
}
reg_t genfunc_tmp_5516 (void) {
reg_t tmp_5392;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
tmp_4216 = ref_gpr_reg_for_reading(0 + index);
tmp_4213 = tmp_5392 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_5515:
return tmp_5392;
}
reg_t genfunc_tmp_5462 (void) {
reg_t tmp_5409;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_4214, disp32);
tmp_4216 = ref_gpr_reg_for_reading(0 + index);
tmp_4213 = tmp_5409 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_5461:
return tmp_5409;
}
void genfunc_tmp_5387 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 field_rb;
field_rb = 31;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + base);
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 1 */
}
done_tmp_5386:
}
reg_t genfunc_tmp_5337 (void) {
reg_t tmp_5297;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 field_rb;
field_rb = 31;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + base);
tmp_4213 = tmp_5297 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 1 */
}
done_tmp_5336:
return tmp_5297;
}
void genfunc_tmp_5288 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + base);
{
tmp_4216 = genfunc_tmp_5082();
goto next_tmp_5210;
next_tmp_5210:
goto tmp_5209;
tmp_5209:
}
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_5287:
}
reg_t genfunc_tmp_5205 (void) {
reg_t tmp_4443;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + base);
{
tmp_4216 = genfunc_tmp_5082();
goto next_tmp_4452;
next_tmp_4452:
goto tmp_4451;
tmp_4451:
}
tmp_4213 = tmp_4443 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_5204:
return tmp_4443;
}
reg_t genfunc_tmp_5151 (void) {
reg_t tmp_5094;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + base);
{
tmp_4216 = genfunc_tmp_5082();
goto next_tmp_5103;
next_tmp_5103:
goto tmp_5102;
tmp_5102:
}
tmp_4213 = tmp_5094 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 2 */
}
done_tmp_5150:
return tmp_5094;
}
reg_t genfunc_tmp_5082 (void) {
reg_t tmp_4450;
/* EXTQH */
{
word_5 tmp_3926;
word_5 field_rc;
word_5 tmp_3927;
word_5 field_ra;
word_5 field_rb;
if (64 != ((word_64)scale)) goto fail_tmp_4819;
field_rb = 31;
/* commit */
tmp_3927 = ref_gpr_reg_for_reading(0 + index);
tmp_3926 = tmp_4450 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_3926;
field_ra = tmp_3927;
emit(COMPOSE_EXTQH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3927);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5081;
fail_tmp_4819:
/* EXTQH_IMM */
{
word_5 tmp_3922;
word_5 field_rc;
word_5 tmp_3923;
word_5 field_ra;
word_64 tmp_3925;
word_8 field_imm;
tmp_3925 = ((word_64)scale);
{
word_64 tmp_4821 = ((64 - tmp_3925) & 0xFFFFFFFFFFFFFFFF);
if (tmp_4821 % 8 == 0)
{
word_64 tmp_4822 = (tmp_4821 / 8);
if ((tmp_4822 & 7) == tmp_4822)
{
word_64 tmp_4823 = tmp_4822;
if ((tmp_4823 >> 8) == 0)
field_imm = tmp_4823;
else goto fail_tmp_4820;
}
else goto fail_tmp_4820;
}
else goto fail_tmp_4820;
}
/* commit */
tmp_3923 = ref_gpr_reg_for_reading(0 + index);
tmp_3922 = tmp_4450 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_3922;
field_ra = tmp_3923;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_3923);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5081;
fail_tmp_4820:
/* S4ADDL */
{
word_5 tmp_3556;
word_5 field_rc;
word_5 tmp_3557;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_4943;
field_rb = 31;
/* commit */
tmp_3557 = ref_gpr_reg_for_reading(0 + index);
tmp_3556 = tmp_4450 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_3556;
field_ra = tmp_3557;
emit(COMPOSE_S4ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3557);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5081;
fail_tmp_4943:
/* S4ADDL_IMM */
{
word_5 tmp_3552;
word_5 field_rc;
word_5 tmp_3553;
word_5 field_ra;
word_32 tmp_3555;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_4947;
tmp_3555 = 0;
field_imm = 0;
/* commit */
tmp_3553 = ref_gpr_reg_for_reading(0 + index);
tmp_3552 = tmp_4450 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_3552;
field_ra = tmp_3553;
emit(COMPOSE_S4ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_3553);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5081;
fail_tmp_4947:
/* S4ADDQ */
{
word_5 tmp_3548;
word_5 field_rc;
word_5 tmp_3549;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_4949;
field_rb = 31;
/* commit */
tmp_3549 = ref_gpr_reg_for_reading(0 + index);
tmp_3548 = tmp_4450 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_3548;
field_ra = tmp_3549;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3549);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5081;
fail_tmp_4949:
/* S4ADDQ_IMM */
{
word_5 tmp_3544;
word_5 field_rc;
word_5 tmp_3545;
word_5 field_ra;
word_64 tmp_3547;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_5009;
tmp_3547 = 0;
field_imm = 0;
/* commit */
tmp_3545 = ref_gpr_reg_for_reading(0 + index);
tmp_3544 = tmp_4450 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_3544;
field_ra = tmp_3545;
emit(COMPOSE_S4ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_3545);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5081;
fail_tmp_5009:
/* S8ADDL */
{
word_5 tmp_3524;
word_5 field_rc;
word_5 tmp_3525;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_5011;
field_rb = 31;
/* commit */
tmp_3525 = ref_gpr_reg_for_reading(0 + index);
tmp_3524 = tmp_4450 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_3524;
field_ra = tmp_3525;
emit(COMPOSE_S8ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3525);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5081;
fail_tmp_5011:
/* S8ADDL_IMM */
{
word_5 tmp_3520;
word_5 field_rc;
word_5 tmp_3521;
word_5 field_ra;
word_32 tmp_3523;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_5015;
tmp_3523 = 0;
field_imm = 0;
/* commit */
tmp_3521 = ref_gpr_reg_for_reading(0 + index);
tmp_3520 = tmp_4450 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_3520;
field_ra = tmp_3521;
emit(COMPOSE_S8ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_3521);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5081;
fail_tmp_5015:
/* S8ADDQ */
{
word_5 tmp_3516;
word_5 field_rc;
word_5 tmp_3517;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_5017;
field_rb = 31;
/* commit */
tmp_3517 = ref_gpr_reg_for_reading(0 + index);
tmp_3516 = tmp_4450 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_3516;
field_ra = tmp_3517;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3517);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5081;
fail_tmp_5017:
/* S8ADDQ_IMM */
{
word_5 tmp_3512;
word_5 field_rc;
word_5 tmp_3513;
word_5 field_ra;
word_64 tmp_3515;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_5077;
tmp_3515 = 0;
field_imm = 0;
/* commit */
tmp_3513 = ref_gpr_reg_for_reading(0 + index);
tmp_3512 = tmp_4450 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_3512;
field_ra = tmp_3513;
emit(COMPOSE_S8ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_3513);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5081;
fail_tmp_5077:
/* SLL */
{
word_5 tmp_3484;
word_5 field_rc;
word_5 tmp_3485;
word_5 field_ra;
word_5 field_rb;
if (0 != ((word_64)scale)) goto fail_tmp_5078;
field_rb = 31;
/* commit */
tmp_3485 = ref_gpr_reg_for_reading(0 + index);
tmp_3484 = tmp_4450 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_3484;
field_ra = tmp_3485;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_3485);
/* can fail: T   num insns: 1 */
}
goto done_tmp_5081;
fail_tmp_5078:
/* SLL_IMM */
{
word_5 tmp_3480;
word_5 field_rc;
word_5 tmp_3481;
word_5 field_ra;
word_64 tmp_3483;
word_8 field_imm;
tmp_3483 = ((word_64)scale);
field_imm = tmp_3483;
/* commit */
tmp_3481 = ref_gpr_reg_for_reading(0 + index);
tmp_3480 = tmp_4450 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_3480;
field_ra = tmp_3481;
emit(COMPOSE_SLL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_3481);
/* can fail: NIL   num insns: 1 */
}
done_tmp_5081:
return tmp_4450;
}
void genfunc_tmp_4438 (void) {
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + base);
tmp_4216 = ref_gpr_reg_for_reading(0 + index);
tmp_4213 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4213);
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 1 */
}
done_tmp_4437:
}
reg_t genfunc_tmp_4359 (void) {
reg_t tmp_4235;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + base);
tmp_4216 = ref_gpr_reg_for_reading(0 + index);
tmp_4213 = tmp_4235 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 1 */
}
done_tmp_4358:
return tmp_4235;
}
reg_t genfunc_tmp_4305 (void) {
reg_t tmp_4252;
/* ADDL */
{
word_5 tmp_4213;
word_5 field_rc;
word_5 tmp_4214;
word_5 field_ra;
word_5 tmp_4216;
word_5 field_rb;
/* commit */
tmp_4214 = ref_gpr_reg_for_reading(0 + base);
tmp_4216 = ref_gpr_reg_for_reading(0 + index);
tmp_4213 = tmp_4252 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_4213;
field_ra = tmp_4214;
field_rb = tmp_4216;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4216);
unref_gpr_reg(tmp_4214);
/* can fail: NIL   num insns: 1 */
}
done_tmp_4304:
return tmp_4252;
}
void genfunc_tmp_4230 (void) {
/* ADDQ */
{
word_5 tmp_4205;
word_5 field_rc;
word_5 tmp_4206;
word_5 field_ra;
word_5 field_rb;
field_rb = 31;
/* commit */
tmp_4206 = ref_gpr_reg_for_reading(0 + rm);
tmp_4205 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_4205;
field_ra = tmp_4206;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_4205);
unref_gpr_reg(tmp_4206);
/* can fail: NIL   num insns: 1 */
}
done_tmp_4229:
}
