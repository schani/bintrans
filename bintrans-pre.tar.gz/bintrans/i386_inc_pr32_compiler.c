#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compiler_tmp_963167 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_963157 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963162 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_963166 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963155 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_963145 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963154 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963153 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963150 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_963016 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_963009 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963015 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963013 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963167 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 6 6 T)
*/
{
{
reg_t tmp_963168;
rhs_func(&tmp_963168, 11, env);
emit(COMPOSE_AND_IMM(tmp_963168, 1, tmp_963168));
unref_integer_reg(tmp_963168);
}
}

void compiler_tmp_963157 (reg_t *target, int foreign_target, void **env)
/*
(IF (= (REGISTER NIL GPR (FIELD OPCODE-REG NIL NIL)) (INTEGER 0)) (INTEGER 1)
 (INTEGER 0))
*/
{
{
label_t tmp_963159 = alloc_label(), tmp_963160 = alloc_label(), tmp_963161 = alloc_label();
reg_t tmp_963158;
compiler_tmp_963162(tmp_963159, tmp_963160, env);

tmp_963158 = ref_integer_reg_for_writing(-1);
emit_label(tmp_963159);
push_alloc();
compiler_tmp_963153(&tmp_963158, tmp_963158 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_963161);
emit_label(tmp_963160);
push_alloc();
compiler_tmp_963154(&tmp_963158, tmp_963158 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_963161);
free_label(tmp_963159);
free_label(tmp_963160);
free_label(tmp_963161);
if (foreign_target == -1)
*target = tmp_963158;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_963158, *target));
unref_integer_reg(tmp_963158);
}

}
}

void compiler_tmp_963162 (label_t true_label, label_t false_label, void **env)
/*
(= (REGISTER NIL GPR (FIELD OPCODE-REG NIL NIL)) (INTEGER 0))
*/
{
{
reg_t tmp_963163, tmp_963164, tmp_963165;
compiler_tmp_963013(&tmp_963163, -1, env);
compiler_tmp_963166(&tmp_963164, -1, env);
tmp_963165 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_CMPEQ(tmp_963163, tmp_963164, tmp_963165));
unref_integer_reg(tmp_963163);
unref_integer_reg(tmp_963164);
emit_branch(COMPOSE_BEQ(tmp_963165, 0), false_label);
unref_integer_reg(tmp_963165);
emit_branch(COMPOSE_BR(31, 0), true_label);
}
}

void compiler_tmp_963166 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_963155 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 7 7 T)
*/
{
{
reg_t tmp_963156;
rhs_func(&tmp_963156, 12, env);
emit(COMPOSE_AND_IMM(tmp_963156, 1, tmp_963156));
unref_integer_reg(tmp_963156);
}
}

void compiler_tmp_963145 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (BIT-SET-P (REGISTER NIL GPR (FIELD OPCODE-REG NIL NIL))
  (- (INTEGER 32) (INTEGER 1)))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_963147 = alloc_label(), tmp_963148 = alloc_label(), tmp_963149 = alloc_label();
reg_t tmp_963146;
compiler_tmp_963150(tmp_963147, tmp_963148, env);

tmp_963146 = ref_integer_reg_for_writing(-1);
emit_label(tmp_963147);
push_alloc();
compiler_tmp_963153(&tmp_963146, tmp_963146 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_963149);
emit_label(tmp_963148);
push_alloc();
compiler_tmp_963154(&tmp_963146, tmp_963146 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_963149);
free_label(tmp_963147);
free_label(tmp_963148);
free_label(tmp_963149);
if (foreign_target == -1)
*target = tmp_963146;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_963146, *target));
unref_integer_reg(tmp_963146);
}

}
}

void compiler_tmp_963154 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_963153 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 1)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 1);
}

void compiler_tmp_963150 (label_t true_label, label_t false_label, void **env)
/*
(BIT-SET-P (REGISTER NIL GPR (FIELD OPCODE-REG NIL NIL))
 (- (INTEGER 32) (INTEGER 1)))
*/
{
{
reg_t tmp_963151, tmp_963152;
compiler_tmp_963013(&tmp_963151, -1, env);
tmp_963152 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_SRL_IMM(tmp_963151, (32 - 1), tmp_963152));
unref_integer_reg(tmp_963151);
emit_branch(COMPOSE_BLBS(tmp_963152, 0), true_label);
unref_integer_reg(tmp_963152);
emit_branch(COMPOSE_BR(31, 0), false_label);
}
}

void compiler_tmp_963016 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 11 11 T)
*/
{
{
reg_t tmp_963017;
rhs_func(&tmp_963017, 13, env);
emit(COMPOSE_AND_IMM(tmp_963017, 1, tmp_963017));
unref_integer_reg(tmp_963017);
}
}

void compiler_tmp_963009 (reg_t *target, int foreign_target, void **env)
/*
(+OVERFLOW (REGISTER NIL GPR (FIELD OPCODE-REG NIL NIL)) (INTEGER 1))
*/
{
{
reg_t tmp_963010, tmp_963011, tmp_963012;
compiler_tmp_963013(&tmp_963010, -1, env);
compiler_tmp_963015(&tmp_963011, -1, env);
tmp_963012 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ADDQ(tmp_963010, tmp_963011, tmp_963012));
unref_integer_reg(tmp_963010);
unref_integer_reg(tmp_963011);
emit(COMPOSE_SRA_IMM(tmp_963012, 32, tmp_963012));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDQ_IMM(31, 1, *target));
emit(COMPOSE_CMOVEQ_IMM(tmp_963012, 0, *target));
emit(COMPOSE_NOT(tmp_963012, tmp_963012));
emit(COMPOSE_CMOVEQ_IMM(tmp_963012, 0, *target));
unref_integer_reg(tmp_963012);
}
}

void compiler_tmp_963015 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 1)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 1);
}

void compiler_tmp_963013 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD OPCODE-REG NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + opcode_reg));
else {
reg_t tmp_963014 = ref_integer_reg_for_reading((0 + opcode_reg));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_963014, *target));
unref_integer_reg(tmp_963014);
}
}

void compile_inc_pr32_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_963009;
killed |= 0x800;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_963016(rhs_func, env);
}
}
if (1 )
{
genfunc_tmp_963143();
goto next_tmp_963019;
next_tmp_963019:
goto finish_tmp_963018;
finish_tmp_963018:
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_963145;
killed |= 0x80;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_963155(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_963157;
killed |= 0x40;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_963167(rhs_func, env);
}
}
}
void genfunc_tmp_963143 (void) {
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
tmp_952084 = ref_gpr_reg_for_reading(0 + opcode_reg);
tmp_952083 = ref_gpr_reg_for_writing(0 + opcode_reg);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952083);
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 1 */
}
done_tmp_963142:
}
reg_t genfunc_tmp_963094 (void) {
reg_t tmp_952088;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
tmp_952084 = ref_gpr_reg_for_reading(0 + opcode_reg);
tmp_952083 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 1 */
}
done_tmp_963093:
return tmp_952088;
}
reg_t genfunc_tmp_963063 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
tmp_952084 = ref_gpr_reg_for_reading(0 + opcode_reg);
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 1 */
}
done_tmp_963062:
return tmp_952080;
}
