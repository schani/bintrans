#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compiler_tmp_910157 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_910148 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910153 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_910144 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_910094 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910143 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910099 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_910102 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910103 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910106 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910136 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910140 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910137 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910128 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910133 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910129 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910132 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910107 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910110 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910120 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910127 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910121 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910126 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910124 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910113 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910116 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910118 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910117 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910114 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910108 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910090 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_910086 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_910085 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_910157 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 6 6 T)
*/
{
{
reg_t tmp_910159, tmp_910160, tmp_910158;
rhs_func(&tmp_910159, -1, env);
emit(COMPOSE_SLL_IMM(tmp_910159, 63, tmp_910159));
emit(COMPOSE_SRL_IMM(tmp_910159, 57, tmp_910159));
tmp_910160 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_910160, -1);
emit(COMPOSE_SLL_IMM(tmp_910160, 63, tmp_910160));
emit(COMPOSE_SRL_IMM(tmp_910160, 57, tmp_910160));
tmp_910158 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_910158, tmp_910160, tmp_910158));
unref_integer_reg(tmp_910160);
emit(COMPOSE_BIS(tmp_910158, tmp_910159, tmp_910158));
unref_integer_reg(tmp_910159);
unref_integer_reg(tmp_910158);
}
}

void compiler_tmp_910148 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (=
  (CASE
   ((0 1 2)
    (MEM
     (CASE
      ((0)
       (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
        ((4)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))
        ((5) (FIELD DISP32 NIL NIL))))
      ((1)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
        ((4)
         (+ (SEX (FIELD DISP8 NIL NIL))
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0))))))))
      ((2)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
        ((4)
         (+ (FIELD DISP32 NIL NIL)
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0)))))))))))
   ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
  (INTEGER 0))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_910150 = alloc_label(), tmp_910151 = alloc_label(), tmp_910152 = alloc_label();
reg_t tmp_910149;
compiler_tmp_910153(tmp_910150, tmp_910151, env);

tmp_910149 = ref_integer_reg_for_writing(-1);
emit_label(tmp_910150);
push_alloc();
compiler_tmp_910143(&tmp_910149, tmp_910149 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_910152);
emit_label(tmp_910151);
push_alloc();
compiler_tmp_910085(&tmp_910149, tmp_910149 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_910152);
free_label(tmp_910150);
free_label(tmp_910151);
free_label(tmp_910152);
if (foreign_target == -1)
*target = tmp_910149;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_910149, *target));
unref_integer_reg(tmp_910149);
}

}
}

void compiler_tmp_910153 (label_t true_label, label_t false_label, void **env)
/*
(=
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (INTEGER 0))
*/
{
{
reg_t tmp_910154, tmp_910155, tmp_910156;
compiler_tmp_910102(&tmp_910154, -1, env);
compiler_tmp_910127(&tmp_910155, -1, env);
tmp_910156 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_CMPEQ(tmp_910154, tmp_910155, tmp_910156));
unref_integer_reg(tmp_910154);
unref_integer_reg(tmp_910155);
emit_branch(COMPOSE_BEQ(tmp_910156, 0), false_label);
unref_integer_reg(tmp_910156);
emit_branch(COMPOSE_BR(31, 0), true_label);
}
}

void compiler_tmp_910144 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 7 7 T)
*/
{
{
reg_t tmp_910146, tmp_910147, tmp_910145;
rhs_func(&tmp_910146, -1, env);
emit(COMPOSE_SLL_IMM(tmp_910146, 63, tmp_910146));
emit(COMPOSE_SRL_IMM(tmp_910146, 56, tmp_910146));
tmp_910147 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_910147, -1);
emit(COMPOSE_SLL_IMM(tmp_910147, 63, tmp_910147));
emit(COMPOSE_SRL_IMM(tmp_910147, 56, tmp_910147));
tmp_910145 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_910145, tmp_910147, tmp_910145));
unref_integer_reg(tmp_910147);
emit(COMPOSE_BIS(tmp_910145, tmp_910146, tmp_910145));
unref_integer_reg(tmp_910146);
unref_integer_reg(tmp_910145);
}
}

void compiler_tmp_910094 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (BIT-SET-P
  (CASE
   ((0 1 2)
    (MEM
     (CASE
      ((0)
       (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
        ((4)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))
        ((5) (FIELD DISP32 NIL NIL))))
      ((1)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
        ((4)
         (+ (SEX (FIELD DISP8 NIL NIL))
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0))))))))
      ((2)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
        ((4)
         (+ (FIELD DISP32 NIL NIL)
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0)))))))))))
   ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
  (- (INTEGER 32) (INTEGER 1)))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_910096 = alloc_label(), tmp_910097 = alloc_label(), tmp_910098 = alloc_label();
reg_t tmp_910095;
compiler_tmp_910099(tmp_910096, tmp_910097, env);

tmp_910095 = ref_integer_reg_for_writing(-1);
emit_label(tmp_910096);
push_alloc();
compiler_tmp_910143(&tmp_910095, tmp_910095 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_910098);
emit_label(tmp_910097);
push_alloc();
compiler_tmp_910085(&tmp_910095, tmp_910095 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_910098);
free_label(tmp_910096);
free_label(tmp_910097);
free_label(tmp_910098);
if (foreign_target == -1)
*target = tmp_910095;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_910095, *target));
unref_integer_reg(tmp_910095);
}

}
}

void compiler_tmp_910143 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 1)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 1);
}

void compiler_tmp_910099 (label_t true_label, label_t false_label, void **env)
/*
(BIT-SET-P
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (- (INTEGER 32) (INTEGER 1)))
*/
{
{
reg_t tmp_910100, tmp_910101;
compiler_tmp_910102(&tmp_910100, -1, env);
tmp_910101 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_SRL_IMM(tmp_910100, (32 - 1), tmp_910101));
unref_integer_reg(tmp_910100);
emit_branch(COMPOSE_BLBS(tmp_910101, 0), true_label);
unref_integer_reg(tmp_910101);
emit_branch(COMPOSE_BR(31, 0), false_label);
}
}

void compiler_tmp_910102 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2)
  (MEM
   (CASE
    ((0)
     (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
      ((4)
       (+
        (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
         ((5)
          (CASE ((0) (FIELD DISP32 NIL NIL))
           ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
        (CASE
         ((0 1 2 3 5 6 7)
          (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
           (ZEX (FIELD SCALE NIL NIL))))
         ((4) (INTEGER 0)))))
      ((5) (FIELD DISP32 NIL NIL))))
    ((1)
     (CASE
      ((0 1 2 3 5 6 7)
       (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
      ((4)
       (+ (SEX (FIELD DISP8 NIL NIL))
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0))))))))
    ((2)
     (CASE
      ((0 1 2 3 5 6 7)
       (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
      ((4)
       (+ (FIELD DISP32 NIL NIL)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))))))))
 ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
*/
{
switch (mod) {
case 0:
case 1:
case 2:
compiler_tmp_910103(&(*target), foreign_target, env);
break;
case 3:
compiler_tmp_910108(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_910103 (reg_t *target, int foreign_target, void **env)
/*
(MEM
 (CASE
  ((0)
   (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
    ((4)
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0)))))
    ((5) (FIELD DISP32 NIL NIL))))
  ((1)
   (CASE
    ((0 1 2 3 5 6 7)
     (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
    ((4)
     (+ (SEX (FIELD DISP8 NIL NIL))
      (+
       (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
        ((5)
         (CASE ((0) (FIELD DISP32 NIL NIL))
          ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
       (CASE
        ((0 1 2 3 5 6 7)
         (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
          (ZEX (FIELD SCALE NIL NIL))))
        ((4) (INTEGER 0))))))))
  ((2)
   (CASE
    ((0 1 2 3 5 6 7)
     (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
    ((4)
     (+ (FIELD DISP32 NIL NIL)
      (+
       (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
        ((5)
         (CASE ((0) (FIELD DISP32 NIL NIL))
          ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
       (CASE
        ((0 1 2 3 5 6 7)
         (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
          (ZEX (FIELD SCALE NIL NIL))))
        ((4) (INTEGER 0))))))))))
*/
{
{
reg_t tmp_910104, tmp_910105;
compiler_tmp_910106(&tmp_910104, -1, env);
#ifdef EMU_I386
tmp_910105 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ZAPNOT_IMM(tmp_910104, 15, tmp_910105));
unref_integer_reg(tmp_910104);
#else
tmp_910105 = tmp_910104;
#endif
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_mem_32(*target, tmp_910105);
unref_integer_reg(tmp_910105);
}
}

void compiler_tmp_910106 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0)
  (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
   ((4)
    (+
     (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
      ((5)
       (CASE ((0) (FIELD DISP32 NIL NIL))
        ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
     (CASE
      ((0 1 2 3 5 6 7)
       (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
        (ZEX (FIELD SCALE NIL NIL))))
      ((4) (INTEGER 0)))))
   ((5) (FIELD DISP32 NIL NIL))))
 ((1)
  (CASE
   ((0 1 2 3 5 6 7)
    (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
   ((4)
    (+ (SEX (FIELD DISP8 NIL NIL))
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0))))))))
 ((2)
  (CASE
   ((0 1 2 3 5 6 7)
    (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
   ((4)
    (+ (FIELD DISP32 NIL NIL)
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0)))))))))
*/
{
switch (mod) {
case 0:
compiler_tmp_910107(&(*target), foreign_target, env);
break;
case 1:
compiler_tmp_910128(&(*target), foreign_target, env);
break;
case 2:
compiler_tmp_910136(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_910136 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
 ((4)
  (+ (FIELD DISP32 NIL NIL)
   (+
    (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
     ((5)
      (CASE ((0) (FIELD DISP32 NIL NIL))
       ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
    (CASE
     ((0 1 2 3 5 6 7)
      (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
       (ZEX (FIELD SCALE NIL NIL))))
     ((4) (INTEGER 0)))))))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_910137(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_910140(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_910140 (reg_t *target, int foreign_target, void **env)
/*
(+ (FIELD DISP32 NIL NIL)
 (+
  (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
   ((5)
    (CASE ((0) (FIELD DISP32 NIL NIL))
     ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
  (CASE
   ((0 1 2 3 5 6 7)
    (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
     (ZEX (FIELD SCALE NIL NIL))))
   ((4) (INTEGER 0)))))
*/
{
{
reg_t tmp_910141, tmp_910142;
compiler_tmp_910117(&tmp_910141, -1, env);
compiler_tmp_910110(&tmp_910142, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_910141, tmp_910142, *target));
unref_integer_reg(tmp_910141);
unref_integer_reg(tmp_910142);
}
}

void compiler_tmp_910137 (reg_t *target, int foreign_target, void **env)
/*
(+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL))
*/
{
{
reg_t tmp_910138, tmp_910139;
compiler_tmp_910108(&tmp_910138, -1, env);
compiler_tmp_910117(&tmp_910139, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_910138, tmp_910139, *target));
unref_integer_reg(tmp_910138);
unref_integer_reg(tmp_910139);
}
}

void compiler_tmp_910128 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
 ((4)
  (+ (SEX (FIELD DISP8 NIL NIL))
   (+
    (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
     ((5)
      (CASE ((0) (FIELD DISP32 NIL NIL))
       ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
    (CASE
     ((0 1 2 3 5 6 7)
      (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
       (ZEX (FIELD SCALE NIL NIL))))
     ((4) (INTEGER 0)))))))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_910129(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_910133(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_910133 (reg_t *target, int foreign_target, void **env)
/*
(+ (SEX (FIELD DISP8 NIL NIL))
 (+
  (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
   ((5)
    (CASE ((0) (FIELD DISP32 NIL NIL))
     ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
  (CASE
   ((0 1 2 3 5 6 7)
    (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
     (ZEX (FIELD SCALE NIL NIL))))
   ((4) (INTEGER 0)))))
*/
{
{
reg_t tmp_910134, tmp_910135;
compiler_tmp_910132(&tmp_910134, -1, env);
compiler_tmp_910110(&tmp_910135, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_910134, tmp_910135, *target));
unref_integer_reg(tmp_910134);
unref_integer_reg(tmp_910135);
}
}

void compiler_tmp_910129 (reg_t *target, int foreign_target, void **env)
/*
(+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL)))
*/
{
{
reg_t tmp_910130, tmp_910131;
compiler_tmp_910108(&tmp_910130, -1, env);
compiler_tmp_910132(&tmp_910131, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_910130, tmp_910131, *target));
unref_integer_reg(tmp_910130);
unref_integer_reg(tmp_910131);
}
}

void compiler_tmp_910132 (reg_t *target, int foreign_target, void **env)
/*
(SEX (FIELD DISP8 NIL NIL))
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
}

void compiler_tmp_910107 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
 ((4)
  (+
   (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
    ((5)
     (CASE ((0) (FIELD DISP32 NIL NIL))
      ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
   (CASE
    ((0 1 2 3 5 6 7)
     (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
      (ZEX (FIELD SCALE NIL NIL))))
    ((4) (INTEGER 0)))))
 ((5) (FIELD DISP32 NIL NIL)))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 6:
case 7:
compiler_tmp_910108(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_910110(&(*target), foreign_target, env);
break;
case 5:
compiler_tmp_910117(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_910110 (reg_t *target, int foreign_target, void **env)
/*
(+
 (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
  ((5)
   (CASE ((0) (FIELD DISP32 NIL NIL))
    ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
 (CASE
  ((0 1 2 3 5 6 7)
   (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
    (ZEX (FIELD SCALE NIL NIL))))
  ((4) (INTEGER 0))))
*/
{
{
reg_t tmp_910111, tmp_910112;
compiler_tmp_910113(&tmp_910111, -1, env);
compiler_tmp_910120(&tmp_910112, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_910111, tmp_910112, *target));
unref_integer_reg(tmp_910111);
unref_integer_reg(tmp_910112);
}
}

void compiler_tmp_910120 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
   (ZEX (FIELD SCALE NIL NIL))))
 ((4) (INTEGER 0)))
*/
{
switch (index) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_910121(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_910127(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_910127 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_910121 (reg_t *target, int foreign_target, void **env)
/*
(SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL)) (ZEX (FIELD SCALE NIL NIL)))
*/
{
{
reg_t tmp_910122, tmp_910123;
compiler_tmp_910124(&tmp_910122, -1, env);
compiler_tmp_910126(&tmp_910123, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_SLL(tmp_910122, tmp_910123, *target));
unref_integer_reg(tmp_910122);
unref_integer_reg(tmp_910123);
emit(COMPOSE_ADDL((*target), 31, (*target)));
}
}

void compiler_tmp_910126 (reg_t *target, int foreign_target, void **env)
/*
(ZEX (FIELD SCALE NIL NIL))
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, scale);
}

void compiler_tmp_910124 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD INDEX NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + index));
else {
reg_t tmp_910125 = ref_integer_reg_for_reading((0 + index));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_910125, *target));
unref_integer_reg(tmp_910125);
}
}

void compiler_tmp_910113 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
 ((5)
  (CASE ((0) (FIELD DISP32 NIL NIL))
   ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
*/
{
switch (base) {
case 0:
case 1:
case 2:
case 3:
case 4:
case 6:
case 7:
compiler_tmp_910114(&(*target), foreign_target, env);
break;
case 5:
compiler_tmp_910116(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_910116 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0) (FIELD DISP32 NIL NIL)) ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))
*/
{
switch (mod) {
case 0:
compiler_tmp_910117(&(*target), foreign_target, env);
break;
case 1:
case 2:
case 3:
compiler_tmp_910118(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_910118 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER EBP GPR (INTEGER 5))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading(5);
else {
reg_t tmp_910119 = ref_integer_reg_for_reading(5);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_910119, *target));
unref_integer_reg(tmp_910119);
}
}

void compiler_tmp_910117 (reg_t *target, int foreign_target, void **env)
/*
(FIELD DISP32 NIL NIL)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, disp32);
}

void compiler_tmp_910114 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD BASE NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + base));
else {
reg_t tmp_910115 = ref_integer_reg_for_reading((0 + base));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_910115, *target));
unref_integer_reg(tmp_910115);
}
}

void compiler_tmp_910108 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD RM NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + rm));
else {
reg_t tmp_910109 = ref_integer_reg_for_reading((0 + rm));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_910109, *target));
unref_integer_reg(tmp_910109);
}
}

void compiler_tmp_910090 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 11 11 T)
*/
{
{
reg_t tmp_910092, tmp_910093, tmp_910091;
rhs_func(&tmp_910092, -1, env);
emit(COMPOSE_SLL_IMM(tmp_910092, 63, tmp_910092));
emit(COMPOSE_SRL_IMM(tmp_910092, 52, tmp_910092));
tmp_910093 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_910093, -1);
emit(COMPOSE_SLL_IMM(tmp_910093, 63, tmp_910093));
emit(COMPOSE_SRL_IMM(tmp_910093, 52, tmp_910093));
tmp_910091 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_910091, tmp_910093, tmp_910091));
unref_integer_reg(tmp_910093);
emit(COMPOSE_BIS(tmp_910091, tmp_910092, tmp_910091));
unref_integer_reg(tmp_910092);
unref_integer_reg(tmp_910091);
}
}

void compiler_tmp_910086 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 0 0 T)
*/
{
{
reg_t tmp_910088, tmp_910089, tmp_910087;
rhs_func(&tmp_910088, -1, env);
emit(COMPOSE_SLL_IMM(tmp_910088, 63, tmp_910088));
emit(COMPOSE_SRL_IMM(tmp_910088, 63, tmp_910088));
tmp_910089 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_910089, -1);
emit(COMPOSE_SLL_IMM(tmp_910089, 63, tmp_910089));
emit(COMPOSE_SRL_IMM(tmp_910089, 63, tmp_910089));
tmp_910087 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_910087, tmp_910089, tmp_910087));
unref_integer_reg(tmp_910089);
emit(COMPOSE_BIS(tmp_910087, tmp_910088, tmp_910087));
unref_integer_reg(tmp_910088);
unref_integer_reg(tmp_910087);
}
}

void compiler_tmp_910085 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compile_xor_rm32_imm32_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; })&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_898716();
goto next_tmp_898473;
next_tmp_898473:
goto finish_tmp_898472;
finish_tmp_898472:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; })&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_898976();
goto next_tmp_898719;
next_tmp_898719:
goto finish_tmp_898718;
finish_tmp_898718:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_899265();
goto next_tmp_898979;
next_tmp_898979:
goto finish_tmp_898978;
finish_tmp_898978:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_899525();
goto next_tmp_899268;
next_tmp_899268:
goto finish_tmp_899267;
finish_tmp_899267:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_899849();
goto next_tmp_899528;
next_tmp_899528:
goto finish_tmp_899527;
finish_tmp_899527:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_900109();
goto next_tmp_899852;
next_tmp_899852:
goto finish_tmp_899851;
finish_tmp_899851:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_900355();
goto next_tmp_900112;
next_tmp_900112:
goto finish_tmp_900111;
finish_tmp_900111:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_900615();
goto next_tmp_900358;
next_tmp_900358:
goto finish_tmp_900357;
finish_tmp_900357:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_900906();
goto next_tmp_900618;
next_tmp_900618:
goto finish_tmp_900617;
finish_tmp_900617:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_901166();
goto next_tmp_900909;
next_tmp_900909:
goto finish_tmp_900908;
finish_tmp_900908:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_901466();
goto next_tmp_901169;
next_tmp_901169:
goto finish_tmp_901168;
finish_tmp_901168:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_901726();
goto next_tmp_901469;
next_tmp_901469:
goto finish_tmp_901468;
finish_tmp_901468:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_901896();
goto next_tmp_901729;
next_tmp_901729:
goto finish_tmp_901728;
finish_tmp_901728:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_902158();
goto next_tmp_901899;
next_tmp_901899:
goto finish_tmp_901898;
finish_tmp_901898:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; })&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; }))
{
genfunc_tmp_901896();
goto next_tmp_902161;
next_tmp_902161:
goto finish_tmp_902160;
finish_tmp_902160:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; })&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; }))
{
genfunc_tmp_902158();
goto next_tmp_902164;
next_tmp_902164:
goto finish_tmp_902163;
finish_tmp_902163:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_902460();
goto next_tmp_902167;
next_tmp_902167:
goto finish_tmp_902166;
finish_tmp_902166:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_902720();
goto next_tmp_902463;
next_tmp_902463:
goto finish_tmp_902462;
finish_tmp_902462:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_903020();
goto next_tmp_902723;
next_tmp_902723:
goto finish_tmp_902722;
finish_tmp_902722:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_903280();
goto next_tmp_903023;
next_tmp_903023:
goto finish_tmp_903022;
finish_tmp_903022:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_903580();
goto next_tmp_903283;
next_tmp_903283:
goto finish_tmp_903282;
finish_tmp_903282:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_903840();
goto next_tmp_903583;
next_tmp_903583:
goto finish_tmp_903582;
finish_tmp_903582:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_904131();
goto next_tmp_903843;
next_tmp_903843:
goto finish_tmp_903842;
finish_tmp_903842:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_904391();
goto next_tmp_904134;
next_tmp_904134:
goto finish_tmp_904133;
finish_tmp_904133:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_904710();
goto next_tmp_904394;
next_tmp_904394:
goto finish_tmp_904393;
finish_tmp_904393:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_904970();
goto next_tmp_904713;
next_tmp_904713:
goto finish_tmp_904712;
finish_tmp_904712:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_905292();
goto next_tmp_904973;
next_tmp_904973:
goto finish_tmp_904972;
finish_tmp_904972:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_905552();
goto next_tmp_905295;
next_tmp_905295:
goto finish_tmp_905294;
finish_tmp_905294:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_905843();
goto next_tmp_905555;
next_tmp_905555:
goto finish_tmp_905554;
finish_tmp_905554:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_906103();
goto next_tmp_905846;
next_tmp_905846:
goto finish_tmp_905845;
finish_tmp_905845:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_906399();
goto next_tmp_906106;
next_tmp_906106:
goto finish_tmp_906105;
finish_tmp_906105:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_906659();
goto next_tmp_906402;
next_tmp_906402:
goto finish_tmp_906401;
finish_tmp_906401:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_906959();
goto next_tmp_906662;
next_tmp_906662:
goto finish_tmp_906661;
finish_tmp_906661:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_907219();
goto next_tmp_906962;
next_tmp_906962:
goto finish_tmp_906961;
finish_tmp_906961:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_907519();
goto next_tmp_907222;
next_tmp_907222:
goto finish_tmp_907221;
finish_tmp_907221:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_907779();
goto next_tmp_907522;
next_tmp_907522:
goto finish_tmp_907521;
finish_tmp_907521:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_908070();
goto next_tmp_907782;
next_tmp_907782:
goto finish_tmp_907781;
finish_tmp_907781:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_908330();
goto next_tmp_908073;
next_tmp_908073:
goto finish_tmp_908072;
finish_tmp_908072:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_908630();
goto next_tmp_908333;
next_tmp_908333:
goto finish_tmp_908332;
finish_tmp_908332:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_908890();
goto next_tmp_908633;
next_tmp_908633:
goto finish_tmp_908632;
finish_tmp_908632:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_909190();
goto next_tmp_908893;
next_tmp_908893:
goto finish_tmp_908892;
finish_tmp_908892:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_909450();
goto next_tmp_909193;
next_tmp_909193:
goto finish_tmp_909192;
finish_tmp_909192:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_909741();
goto next_tmp_909453;
next_tmp_909453:
goto finish_tmp_909452;
finish_tmp_909452:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_910001();
goto next_tmp_909744;
next_tmp_909744:
goto finish_tmp_909743;
finish_tmp_909743:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 3; })&& (imm32 == 0)&& ({ word_2 tmp = mod; 0 || tmp == 3; }))
{
genfunc_tmp_910014();
goto next_tmp_910004;
next_tmp_910004:
goto finish_tmp_910003;
finish_tmp_910003:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 3; })&& (!(imm32 == 0))&& ({ word_2 tmp = mod; 0 || tmp == 3; }))
{
genfunc_tmp_910083();
goto next_tmp_910017;
next_tmp_910017:
goto finish_tmp_910016;
finish_tmp_910016:
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_910085;
killed |= 0x1;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_910086(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_910085;
killed |= 0x800;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_910090(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_910094;
killed |= 0x80;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_910144(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_910148;
killed |= 0x40;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_910157(rhs_func, env);
}
}
}
void genfunc_tmp_910083 (void) {
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_910067;
field_rb = 31;
/* commit */
tmp_731669 = ref_gpr_reg_for_reading(0 + rm);
tmp_731668 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731668);
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 1 */
}
goto done_tmp_910082;
fail_tmp_910067:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_910069 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_910069 >> 8) == 0)
field_imm = tmp_910069;
else goto fail_tmp_910068;
}
/* commit */
tmp_731665 = ref_gpr_reg_for_reading(0 + rm);
tmp_731664 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731664);
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 1 */
}
goto done_tmp_910082;
fail_tmp_910068:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_910079;
field_rb = 31;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + rm);
tmp_731086 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 1 */
}
goto done_tmp_910082;
fail_tmp_910079:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_910081 = tmp_731085;
if ((tmp_910081 >> 8) == 0)
field_imm = tmp_910081;
else goto fail_tmp_910080;
}
/* commit */
tmp_731083 = ref_gpr_reg_for_reading(0 + rm);
tmp_731082 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731082);
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 1 */
}
goto done_tmp_910082;
fail_tmp_910080:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + rm);
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 2 */
}
done_tmp_910082:
}
reg_t genfunc_tmp_910045 (void) {
reg_t tmp_731898;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_910033;
field_rb = 31;
/* commit */
tmp_731669 = ref_gpr_reg_for_reading(0 + rm);
tmp_731668 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 1 */
}
goto done_tmp_910044;
fail_tmp_910033:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_910035 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_910035 >> 8) == 0)
field_imm = tmp_910035;
else goto fail_tmp_910034;
}
/* commit */
tmp_731665 = ref_gpr_reg_for_reading(0 + rm);
tmp_731664 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 1 */
}
goto done_tmp_910044;
fail_tmp_910034:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_910041;
field_rb = 31;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + rm);
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 1 */
}
goto done_tmp_910044;
fail_tmp_910041:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_910043 = tmp_731085;
if ((tmp_910043 >> 8) == 0)
field_imm = tmp_910043;
else goto fail_tmp_910042;
}
/* commit */
tmp_731083 = ref_gpr_reg_for_reading(0 + rm);
tmp_731082 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 1 */
}
goto done_tmp_910044;
fail_tmp_910042:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + rm);
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 2 */
}
done_tmp_910044:
return tmp_731898;
}
void genfunc_tmp_910014 (void) {
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 field_rb;
field_rb = 31;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731897 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731897;
field_ra = tmp_731898;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731897);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_910013:
}
void genfunc_tmp_910001 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_909577();
goto next_tmp_909747;
next_tmp_909747:
goto tmp_909746;
tmp_909746:
}
{
tmp_731146 = genfunc_tmp_909998();
goto next_tmp_909750;
next_tmp_909750:
goto tmp_909749;
tmp_909749:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_910000:
}
reg_t genfunc_tmp_909998 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_909921;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_909621();
goto next_tmp_909923;
next_tmp_909923:
goto tmp_909922;
tmp_909922:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_909997;
fail_tmp_909921:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_909926 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_909926 >> 8) == 0)
field_imm = tmp_909926;
else goto fail_tmp_909925;
}
/* commit */
{
tmp_731665 = genfunc_tmp_909621();
goto next_tmp_909928;
next_tmp_909928:
goto tmp_909927;
tmp_909927:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_909997;
fail_tmp_909925:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_909988;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_909621();
goto next_tmp_909990;
next_tmp_909990:
goto tmp_909989;
tmp_909989:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_909997;
fail_tmp_909988:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_909993 = tmp_731085;
if ((tmp_909993 >> 8) == 0)
field_imm = tmp_909993;
else goto fail_tmp_909992;
}
/* commit */
{
tmp_731083 = genfunc_tmp_909621();
goto next_tmp_909995;
next_tmp_909995:
goto tmp_909994;
tmp_909994:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_909997;
fail_tmp_909992:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_909621();
goto next_tmp_909986;
next_tmp_909986:
goto tmp_909985;
tmp_909985:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_909997:
return tmp_731146;
}
void genfunc_tmp_909741 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_909577();
goto next_tmp_909456;
next_tmp_909456:
goto tmp_909455;
tmp_909455:
}
{
tmp_731146 = genfunc_tmp_909738();
goto next_tmp_909580;
next_tmp_909580:
goto tmp_909579;
tmp_909579:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_909740:
}
reg_t genfunc_tmp_909738 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_909577();
goto next_tmp_909715;
next_tmp_909715:
goto tmp_909714;
tmp_909714:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_909737:
return tmp_731146;
}
reg_t genfunc_tmp_909690 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_909659 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_909659 >> 8) == 0)
field_imm = tmp_909659;
else goto fail_tmp_909658;
}
/* commit */
{
tmp_731858 = genfunc_tmp_909621();
goto next_tmp_909661;
next_tmp_909661:
goto tmp_909660;
tmp_909660:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_909689;
fail_tmp_909658:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_909681 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_909681))
field_imm = inv_maskmask(8, tmp_909681);
else goto fail_tmp_909680;
}
/* commit */
{
tmp_731075 = genfunc_tmp_909621();
goto next_tmp_909683;
next_tmp_909683:
goto tmp_909682;
tmp_909682:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_909689;
fail_tmp_909680:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_909621();
goto next_tmp_909687;
next_tmp_909687:
goto tmp_909686;
tmp_909686:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_909689:
return tmp_731862;
}
reg_t genfunc_tmp_909621 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_909577();
goto next_tmp_909618;
next_tmp_909618:
goto tmp_909617;
tmp_909617:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_909620:
return tmp_731898;
}
reg_t genfunc_tmp_909577 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_909544 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_909544 >> 8) == 0)
field_imm = tmp_909544;
else goto fail_tmp_909543;
}
/* commit */
{
tmp_731858 = genfunc_tmp_909488();
goto next_tmp_909546;
next_tmp_909546:
goto tmp_909545;
tmp_909545:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_909576;
fail_tmp_909543:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_909568 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_909568))
field_imm = inv_maskmask(8, tmp_909568);
else goto fail_tmp_909567;
}
/* commit */
{
tmp_731075 = genfunc_tmp_909488();
goto next_tmp_909570;
next_tmp_909570:
goto tmp_909569;
tmp_909569:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_909576;
fail_tmp_909567:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_909488();
goto next_tmp_909574;
next_tmp_909574:
goto tmp_909573;
tmp_909573:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_909576:
return tmp_731142;
}
reg_t genfunc_tmp_909541 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_909510 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_909510 >> 8) == 0)
field_imm = tmp_909510;
else goto fail_tmp_909509;
}
/* commit */
{
tmp_731858 = genfunc_tmp_909488();
goto next_tmp_909512;
next_tmp_909512:
goto tmp_909511;
tmp_909511:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_909540;
fail_tmp_909509:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_909532 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_909532))
field_imm = inv_maskmask(8, tmp_909532);
else goto fail_tmp_909531;
}
/* commit */
{
tmp_731075 = genfunc_tmp_909488();
goto next_tmp_909534;
next_tmp_909534:
goto tmp_909533;
tmp_909533:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_909540;
fail_tmp_909531:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_909488();
goto next_tmp_909538;
next_tmp_909538:
goto tmp_909537;
tmp_909537:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_909540:
return tmp_731862;
}
reg_t genfunc_tmp_909488 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_909485;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + 5);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_909487;
fail_tmp_909485:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_909486;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + 5);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_909487;
fail_tmp_909486:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + 5);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_909487:
return tmp_731876;
}
void genfunc_tmp_909450 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_909026();
goto next_tmp_909196;
next_tmp_909196:
goto tmp_909195;
tmp_909195:
}
{
tmp_731146 = genfunc_tmp_909447();
goto next_tmp_909199;
next_tmp_909199:
goto tmp_909198;
tmp_909198:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 14 */
}
done_tmp_909449:
}
reg_t genfunc_tmp_909447 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_909370;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_909070();
goto next_tmp_909372;
next_tmp_909372:
goto tmp_909371;
tmp_909371:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 7 */
}
goto done_tmp_909446;
fail_tmp_909370:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_909375 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_909375 >> 8) == 0)
field_imm = tmp_909375;
else goto fail_tmp_909374;
}
/* commit */
{
tmp_731665 = genfunc_tmp_909070();
goto next_tmp_909377;
next_tmp_909377:
goto tmp_909376;
tmp_909376:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 7 */
}
goto done_tmp_909446;
fail_tmp_909374:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_909437;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_909070();
goto next_tmp_909439;
next_tmp_909439:
goto tmp_909438;
tmp_909438:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 7 */
}
goto done_tmp_909446;
fail_tmp_909437:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_909442 = tmp_731085;
if ((tmp_909442 >> 8) == 0)
field_imm = tmp_909442;
else goto fail_tmp_909441;
}
/* commit */
{
tmp_731083 = genfunc_tmp_909070();
goto next_tmp_909444;
next_tmp_909444:
goto tmp_909443;
tmp_909443:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 7 */
}
goto done_tmp_909446;
fail_tmp_909441:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_909070();
goto next_tmp_909435;
next_tmp_909435:
goto tmp_909434;
tmp_909434:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 8 */
}
done_tmp_909446:
return tmp_731146;
}
void genfunc_tmp_909190 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_909026();
goto next_tmp_908896;
next_tmp_908896:
goto tmp_908895;
tmp_908895:
}
{
tmp_731146 = genfunc_tmp_909187();
goto next_tmp_909029;
next_tmp_909029:
goto tmp_909028;
tmp_909028:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_909189:
}
reg_t genfunc_tmp_909187 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_909026();
goto next_tmp_909164;
next_tmp_909164:
goto tmp_909163;
tmp_909163:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_909186:
return tmp_731146;
}
reg_t genfunc_tmp_909139 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_909108 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_909108 >> 8) == 0)
field_imm = tmp_909108;
else goto fail_tmp_909107;
}
/* commit */
{
tmp_731858 = genfunc_tmp_909070();
goto next_tmp_909110;
next_tmp_909110:
goto tmp_909109;
tmp_909109:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 7 */
}
goto done_tmp_909138;
fail_tmp_909107:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_909130 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_909130))
field_imm = inv_maskmask(8, tmp_909130);
else goto fail_tmp_909129;
}
/* commit */
{
tmp_731075 = genfunc_tmp_909070();
goto next_tmp_909132;
next_tmp_909132:
goto tmp_909131;
tmp_909131:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 7 */
}
goto done_tmp_909138;
fail_tmp_909129:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_909070();
goto next_tmp_909136;
next_tmp_909136:
goto tmp_909135;
tmp_909135:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 7 */
}
done_tmp_909138:
return tmp_731862;
}
reg_t genfunc_tmp_909070 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_909026();
goto next_tmp_909067;
next_tmp_909067:
goto tmp_909066;
tmp_909066:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_909069:
return tmp_731898;
}
reg_t genfunc_tmp_909026 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_908993 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_908993 >> 8) == 0)
field_imm = tmp_908993;
else goto fail_tmp_908992;
}
/* commit */
{
tmp_731858 = genfunc_tmp_908937();
goto next_tmp_908995;
next_tmp_908995:
goto tmp_908994;
tmp_908994:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_909025;
fail_tmp_908992:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_909017 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_909017))
field_imm = inv_maskmask(8, tmp_909017);
else goto fail_tmp_909016;
}
/* commit */
{
tmp_731075 = genfunc_tmp_908937();
goto next_tmp_909019;
next_tmp_909019:
goto tmp_909018;
tmp_909018:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_909025;
fail_tmp_909016:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_908937();
goto next_tmp_909023;
next_tmp_909023:
goto tmp_909022;
tmp_909022:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_909025:
return tmp_731142;
}
reg_t genfunc_tmp_908990 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_908959 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_908959 >> 8) == 0)
field_imm = tmp_908959;
else goto fail_tmp_908958;
}
/* commit */
{
tmp_731858 = genfunc_tmp_908937();
goto next_tmp_908961;
next_tmp_908961:
goto tmp_908960;
tmp_908960:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_908989;
fail_tmp_908958:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_908981 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_908981))
field_imm = inv_maskmask(8, tmp_908981);
else goto fail_tmp_908980;
}
/* commit */
{
tmp_731075 = genfunc_tmp_908937();
goto next_tmp_908983;
next_tmp_908983:
goto tmp_908982;
tmp_908982:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_908989;
fail_tmp_908980:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_908937();
goto next_tmp_908987;
next_tmp_908987:
goto tmp_908986;
tmp_908986:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_908989:
return tmp_731862;
}
reg_t genfunc_tmp_908937 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_908928;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_905014();
goto next_tmp_908930;
next_tmp_908930:
goto tmp_908929;
tmp_908929:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_908936;
fail_tmp_908928:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_908932;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_905014();
goto next_tmp_908934;
next_tmp_908934:
goto tmp_908933;
tmp_908933:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_908936;
fail_tmp_908932:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_905014();
goto next_tmp_908912;
next_tmp_908912:
goto tmp_908911;
tmp_908911:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_908936:
return tmp_731876;
}
void genfunc_tmp_908890 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_908466();
goto next_tmp_908636;
next_tmp_908636:
goto tmp_908635;
tmp_908635:
}
{
tmp_731146 = genfunc_tmp_908887();
goto next_tmp_908639;
next_tmp_908639:
goto tmp_908638;
tmp_908638:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_908889:
}
reg_t genfunc_tmp_908887 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_908810;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_908510();
goto next_tmp_908812;
next_tmp_908812:
goto tmp_908811;
tmp_908811:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 6 */
}
goto done_tmp_908886;
fail_tmp_908810:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_908815 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_908815 >> 8) == 0)
field_imm = tmp_908815;
else goto fail_tmp_908814;
}
/* commit */
{
tmp_731665 = genfunc_tmp_908510();
goto next_tmp_908817;
next_tmp_908817:
goto tmp_908816;
tmp_908816:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 6 */
}
goto done_tmp_908886;
fail_tmp_908814:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_908877;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_908510();
goto next_tmp_908879;
next_tmp_908879:
goto tmp_908878;
tmp_908878:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 6 */
}
goto done_tmp_908886;
fail_tmp_908877:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_908882 = tmp_731085;
if ((tmp_908882 >> 8) == 0)
field_imm = tmp_908882;
else goto fail_tmp_908881;
}
/* commit */
{
tmp_731083 = genfunc_tmp_908510();
goto next_tmp_908884;
next_tmp_908884:
goto tmp_908883;
tmp_908883:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 6 */
}
goto done_tmp_908886;
fail_tmp_908881:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_908510();
goto next_tmp_908875;
next_tmp_908875:
goto tmp_908874;
tmp_908874:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_908886:
return tmp_731146;
}
void genfunc_tmp_908630 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_908466();
goto next_tmp_908336;
next_tmp_908336:
goto tmp_908335;
tmp_908335:
}
{
tmp_731146 = genfunc_tmp_908627();
goto next_tmp_908469;
next_tmp_908469:
goto tmp_908468;
tmp_908468:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_908629:
}
reg_t genfunc_tmp_908627 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_908466();
goto next_tmp_908604;
next_tmp_908604:
goto tmp_908603;
tmp_908603:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_908626:
return tmp_731146;
}
reg_t genfunc_tmp_908579 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_908548 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_908548 >> 8) == 0)
field_imm = tmp_908548;
else goto fail_tmp_908547;
}
/* commit */
{
tmp_731858 = genfunc_tmp_908510();
goto next_tmp_908550;
next_tmp_908550:
goto tmp_908549;
tmp_908549:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 6 */
}
goto done_tmp_908578;
fail_tmp_908547:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_908570 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_908570))
field_imm = inv_maskmask(8, tmp_908570);
else goto fail_tmp_908569;
}
/* commit */
{
tmp_731075 = genfunc_tmp_908510();
goto next_tmp_908572;
next_tmp_908572:
goto tmp_908571;
tmp_908571:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 6 */
}
goto done_tmp_908578;
fail_tmp_908569:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_908510();
goto next_tmp_908576;
next_tmp_908576:
goto tmp_908575;
tmp_908575:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 6 */
}
done_tmp_908578:
return tmp_731862;
}
reg_t genfunc_tmp_908510 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_908466();
goto next_tmp_908507;
next_tmp_908507:
goto tmp_908506;
tmp_908506:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_908509:
return tmp_731898;
}
reg_t genfunc_tmp_908466 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_908433 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_908433 >> 8) == 0)
field_imm = tmp_908433;
else goto fail_tmp_908432;
}
/* commit */
{
tmp_731858 = genfunc_tmp_908377();
goto next_tmp_908435;
next_tmp_908435:
goto tmp_908434;
tmp_908434:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_908465;
fail_tmp_908432:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_908457 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_908457))
field_imm = inv_maskmask(8, tmp_908457);
else goto fail_tmp_908456;
}
/* commit */
{
tmp_731075 = genfunc_tmp_908377();
goto next_tmp_908459;
next_tmp_908459:
goto tmp_908458;
tmp_908458:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_908465;
fail_tmp_908456:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_908377();
goto next_tmp_908463;
next_tmp_908463:
goto tmp_908462;
tmp_908462:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_908465:
return tmp_731142;
}
reg_t genfunc_tmp_908430 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_908399 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_908399 >> 8) == 0)
field_imm = tmp_908399;
else goto fail_tmp_908398;
}
/* commit */
{
tmp_731858 = genfunc_tmp_908377();
goto next_tmp_908401;
next_tmp_908401:
goto tmp_908400;
tmp_908400:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_908429;
fail_tmp_908398:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_908421 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_908421))
field_imm = inv_maskmask(8, tmp_908421);
else goto fail_tmp_908420;
}
/* commit */
{
tmp_731075 = genfunc_tmp_908377();
goto next_tmp_908423;
next_tmp_908423:
goto tmp_908422;
tmp_908422:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_908429;
fail_tmp_908420:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_908377();
goto next_tmp_908427;
next_tmp_908427:
goto tmp_908426;
tmp_908426:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_908429:
return tmp_731862;
}
reg_t genfunc_tmp_908377 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_908368;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_904432();
goto next_tmp_908370;
next_tmp_908370:
goto tmp_908369;
tmp_908369:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_908376;
fail_tmp_908368:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_908372;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_904432();
goto next_tmp_908374;
next_tmp_908374:
goto tmp_908373;
tmp_908373:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_908376;
fail_tmp_908372:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_904432();
goto next_tmp_908352;
next_tmp_908352:
goto tmp_908351;
tmp_908351:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_908376:
return tmp_731876;
}
void genfunc_tmp_908330 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_907906();
goto next_tmp_908076;
next_tmp_908076:
goto tmp_908075;
tmp_908075:
}
{
tmp_731146 = genfunc_tmp_908327();
goto next_tmp_908079;
next_tmp_908079:
goto tmp_908078;
tmp_908078:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_908329:
}
reg_t genfunc_tmp_908327 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_908250;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_907950();
goto next_tmp_908252;
next_tmp_908252:
goto tmp_908251;
tmp_908251:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_908326;
fail_tmp_908250:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_908255 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_908255 >> 8) == 0)
field_imm = tmp_908255;
else goto fail_tmp_908254;
}
/* commit */
{
tmp_731665 = genfunc_tmp_907950();
goto next_tmp_908257;
next_tmp_908257:
goto tmp_908256;
tmp_908256:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_908326;
fail_tmp_908254:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_908317;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_907950();
goto next_tmp_908319;
next_tmp_908319:
goto tmp_908318;
tmp_908318:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_908326;
fail_tmp_908317:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_908322 = tmp_731085;
if ((tmp_908322 >> 8) == 0)
field_imm = tmp_908322;
else goto fail_tmp_908321;
}
/* commit */
{
tmp_731083 = genfunc_tmp_907950();
goto next_tmp_908324;
next_tmp_908324:
goto tmp_908323;
tmp_908323:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_908326;
fail_tmp_908321:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_907950();
goto next_tmp_908315;
next_tmp_908315:
goto tmp_908314;
tmp_908314:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_908326:
return tmp_731146;
}
void genfunc_tmp_908070 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_907906();
goto next_tmp_907785;
next_tmp_907785:
goto tmp_907784;
tmp_907784:
}
{
tmp_731146 = genfunc_tmp_908067();
goto next_tmp_907909;
next_tmp_907909:
goto tmp_907908;
tmp_907908:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_908069:
}
reg_t genfunc_tmp_908067 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_907906();
goto next_tmp_908044;
next_tmp_908044:
goto tmp_908043;
tmp_908043:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_908066:
return tmp_731146;
}
reg_t genfunc_tmp_908019 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_907988 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_907988 >> 8) == 0)
field_imm = tmp_907988;
else goto fail_tmp_907987;
}
/* commit */
{
tmp_731858 = genfunc_tmp_907950();
goto next_tmp_907990;
next_tmp_907990:
goto tmp_907989;
tmp_907989:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_908018;
fail_tmp_907987:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_908010 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_908010))
field_imm = inv_maskmask(8, tmp_908010);
else goto fail_tmp_908009;
}
/* commit */
{
tmp_731075 = genfunc_tmp_907950();
goto next_tmp_908012;
next_tmp_908012:
goto tmp_908011;
tmp_908011:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_908018;
fail_tmp_908009:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_907950();
goto next_tmp_908016;
next_tmp_908016:
goto tmp_908015;
tmp_908015:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_908018:
return tmp_731862;
}
reg_t genfunc_tmp_907950 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_907906();
goto next_tmp_907947;
next_tmp_907947:
goto tmp_907946;
tmp_907946:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_907949:
return tmp_731898;
}
reg_t genfunc_tmp_907906 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_907873 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_907873 >> 8) == 0)
field_imm = tmp_907873;
else goto fail_tmp_907872;
}
/* commit */
{
tmp_731858 = genfunc_tmp_907817();
goto next_tmp_907875;
next_tmp_907875:
goto tmp_907874;
tmp_907874:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_907905;
fail_tmp_907872:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_907897 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_907897))
field_imm = inv_maskmask(8, tmp_907897);
else goto fail_tmp_907896;
}
/* commit */
{
tmp_731075 = genfunc_tmp_907817();
goto next_tmp_907899;
next_tmp_907899:
goto tmp_907898;
tmp_907898:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_907905;
fail_tmp_907896:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_907817();
goto next_tmp_907903;
next_tmp_907903:
goto tmp_907902;
tmp_907902:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_907905:
return tmp_731142;
}
reg_t genfunc_tmp_907870 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_907839 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_907839 >> 8) == 0)
field_imm = tmp_907839;
else goto fail_tmp_907838;
}
/* commit */
{
tmp_731858 = genfunc_tmp_907817();
goto next_tmp_907841;
next_tmp_907841:
goto tmp_907840;
tmp_907840:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_907869;
fail_tmp_907838:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_907861 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_907861))
field_imm = inv_maskmask(8, tmp_907861);
else goto fail_tmp_907860;
}
/* commit */
{
tmp_731075 = genfunc_tmp_907817();
goto next_tmp_907863;
next_tmp_907863:
goto tmp_907862;
tmp_907862:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_907869;
fail_tmp_907860:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_907817();
goto next_tmp_907867;
next_tmp_907867:
goto tmp_907866;
tmp_907866:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_907869:
return tmp_731862;
}
reg_t genfunc_tmp_907817 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_907814;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + base);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_907816;
fail_tmp_907814:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_907815;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + base);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_907816;
fail_tmp_907815:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + base);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_907816:
return tmp_731876;
}
void genfunc_tmp_907779 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_907355();
goto next_tmp_907525;
next_tmp_907525:
goto tmp_907524;
tmp_907524:
}
{
tmp_731146 = genfunc_tmp_907776();
goto next_tmp_907528;
next_tmp_907528:
goto tmp_907527;
tmp_907527:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 14 */
}
done_tmp_907778:
}
reg_t genfunc_tmp_907776 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_907699;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_907399();
goto next_tmp_907701;
next_tmp_907701:
goto tmp_907700;
tmp_907700:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 7 */
}
goto done_tmp_907775;
fail_tmp_907699:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_907704 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_907704 >> 8) == 0)
field_imm = tmp_907704;
else goto fail_tmp_907703;
}
/* commit */
{
tmp_731665 = genfunc_tmp_907399();
goto next_tmp_907706;
next_tmp_907706:
goto tmp_907705;
tmp_907705:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 7 */
}
goto done_tmp_907775;
fail_tmp_907703:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_907766;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_907399();
goto next_tmp_907768;
next_tmp_907768:
goto tmp_907767;
tmp_907767:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 7 */
}
goto done_tmp_907775;
fail_tmp_907766:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_907771 = tmp_731085;
if ((tmp_907771 >> 8) == 0)
field_imm = tmp_907771;
else goto fail_tmp_907770;
}
/* commit */
{
tmp_731083 = genfunc_tmp_907399();
goto next_tmp_907773;
next_tmp_907773:
goto tmp_907772;
tmp_907772:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 7 */
}
goto done_tmp_907775;
fail_tmp_907770:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_907399();
goto next_tmp_907764;
next_tmp_907764:
goto tmp_907763;
tmp_907763:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 8 */
}
done_tmp_907775:
return tmp_731146;
}
void genfunc_tmp_907519 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_907355();
goto next_tmp_907225;
next_tmp_907225:
goto tmp_907224;
tmp_907224:
}
{
tmp_731146 = genfunc_tmp_907516();
goto next_tmp_907358;
next_tmp_907358:
goto tmp_907357;
tmp_907357:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_907518:
}
reg_t genfunc_tmp_907516 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_907355();
goto next_tmp_907493;
next_tmp_907493:
goto tmp_907492;
tmp_907492:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_907515:
return tmp_731146;
}
reg_t genfunc_tmp_907468 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_907437 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_907437 >> 8) == 0)
field_imm = tmp_907437;
else goto fail_tmp_907436;
}
/* commit */
{
tmp_731858 = genfunc_tmp_907399();
goto next_tmp_907439;
next_tmp_907439:
goto tmp_907438;
tmp_907438:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 7 */
}
goto done_tmp_907467;
fail_tmp_907436:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_907459 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_907459))
field_imm = inv_maskmask(8, tmp_907459);
else goto fail_tmp_907458;
}
/* commit */
{
tmp_731075 = genfunc_tmp_907399();
goto next_tmp_907461;
next_tmp_907461:
goto tmp_907460;
tmp_907460:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 7 */
}
goto done_tmp_907467;
fail_tmp_907458:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_907399();
goto next_tmp_907465;
next_tmp_907465:
goto tmp_907464;
tmp_907464:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 7 */
}
done_tmp_907467:
return tmp_731862;
}
reg_t genfunc_tmp_907399 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_907355();
goto next_tmp_907396;
next_tmp_907396:
goto tmp_907395;
tmp_907395:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_907398:
return tmp_731898;
}
reg_t genfunc_tmp_907355 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_907322 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_907322 >> 8) == 0)
field_imm = tmp_907322;
else goto fail_tmp_907321;
}
/* commit */
{
tmp_731858 = genfunc_tmp_907266();
goto next_tmp_907324;
next_tmp_907324:
goto tmp_907323;
tmp_907323:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_907354;
fail_tmp_907321:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_907346 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_907346))
field_imm = inv_maskmask(8, tmp_907346);
else goto fail_tmp_907345;
}
/* commit */
{
tmp_731075 = genfunc_tmp_907266();
goto next_tmp_907348;
next_tmp_907348:
goto tmp_907347;
tmp_907347:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_907354;
fail_tmp_907345:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_907266();
goto next_tmp_907352;
next_tmp_907352:
goto tmp_907351;
tmp_907351:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_907354:
return tmp_731142;
}
reg_t genfunc_tmp_907319 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_907288 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_907288 >> 8) == 0)
field_imm = tmp_907288;
else goto fail_tmp_907287;
}
/* commit */
{
tmp_731858 = genfunc_tmp_907266();
goto next_tmp_907290;
next_tmp_907290:
goto tmp_907289;
tmp_907289:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_907318;
fail_tmp_907287:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_907310 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_907310))
field_imm = inv_maskmask(8, tmp_907310);
else goto fail_tmp_907309;
}
/* commit */
{
tmp_731075 = genfunc_tmp_907266();
goto next_tmp_907312;
next_tmp_907312:
goto tmp_907311;
tmp_907311:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_907318;
fail_tmp_907309:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_907266();
goto next_tmp_907316;
next_tmp_907316:
goto tmp_907315;
tmp_907315:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_907318:
return tmp_731862;
}
reg_t genfunc_tmp_907266 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_907257;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_899596();
goto next_tmp_907259;
next_tmp_907259:
goto tmp_907258;
tmp_907258:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_907265;
fail_tmp_907257:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_907261;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_899596();
goto next_tmp_907263;
next_tmp_907263:
goto tmp_907262;
tmp_907262:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_907265;
fail_tmp_907261:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_899596();
goto next_tmp_907241;
next_tmp_907241:
goto tmp_907240;
tmp_907240:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_907265:
return tmp_731876;
}
void genfunc_tmp_907219 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_906795();
goto next_tmp_906965;
next_tmp_906965:
goto tmp_906964;
tmp_906964:
}
{
tmp_731146 = genfunc_tmp_907216();
goto next_tmp_906968;
next_tmp_906968:
goto tmp_906967;
tmp_906967:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_907218:
}
reg_t genfunc_tmp_907216 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_907139;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_906839();
goto next_tmp_907141;
next_tmp_907141:
goto tmp_907140;
tmp_907140:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 6 */
}
goto done_tmp_907215;
fail_tmp_907139:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_907144 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_907144 >> 8) == 0)
field_imm = tmp_907144;
else goto fail_tmp_907143;
}
/* commit */
{
tmp_731665 = genfunc_tmp_906839();
goto next_tmp_907146;
next_tmp_907146:
goto tmp_907145;
tmp_907145:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 6 */
}
goto done_tmp_907215;
fail_tmp_907143:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_907206;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_906839();
goto next_tmp_907208;
next_tmp_907208:
goto tmp_907207;
tmp_907207:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 6 */
}
goto done_tmp_907215;
fail_tmp_907206:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_907211 = tmp_731085;
if ((tmp_907211 >> 8) == 0)
field_imm = tmp_907211;
else goto fail_tmp_907210;
}
/* commit */
{
tmp_731083 = genfunc_tmp_906839();
goto next_tmp_907213;
next_tmp_907213:
goto tmp_907212;
tmp_907212:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 6 */
}
goto done_tmp_907215;
fail_tmp_907210:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_906839();
goto next_tmp_907204;
next_tmp_907204:
goto tmp_907203;
tmp_907203:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_907215:
return tmp_731146;
}
void genfunc_tmp_906959 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_906795();
goto next_tmp_906665;
next_tmp_906665:
goto tmp_906664;
tmp_906664:
}
{
tmp_731146 = genfunc_tmp_906956();
goto next_tmp_906798;
next_tmp_906798:
goto tmp_906797;
tmp_906797:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_906958:
}
reg_t genfunc_tmp_906956 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_906795();
goto next_tmp_906933;
next_tmp_906933:
goto tmp_906932;
tmp_906932:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_906955:
return tmp_731146;
}
reg_t genfunc_tmp_906908 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_906877 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_906877 >> 8) == 0)
field_imm = tmp_906877;
else goto fail_tmp_906876;
}
/* commit */
{
tmp_731858 = genfunc_tmp_906839();
goto next_tmp_906879;
next_tmp_906879:
goto tmp_906878;
tmp_906878:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 6 */
}
goto done_tmp_906907;
fail_tmp_906876:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_906899 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_906899))
field_imm = inv_maskmask(8, tmp_906899);
else goto fail_tmp_906898;
}
/* commit */
{
tmp_731075 = genfunc_tmp_906839();
goto next_tmp_906901;
next_tmp_906901:
goto tmp_906900;
tmp_906900:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 6 */
}
goto done_tmp_906907;
fail_tmp_906898:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_906839();
goto next_tmp_906905;
next_tmp_906905:
goto tmp_906904;
tmp_906904:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 6 */
}
done_tmp_906907:
return tmp_731862;
}
reg_t genfunc_tmp_906839 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_906795();
goto next_tmp_906836;
next_tmp_906836:
goto tmp_906835;
tmp_906835:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_906838:
return tmp_731898;
}
reg_t genfunc_tmp_906795 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_906762 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_906762 >> 8) == 0)
field_imm = tmp_906762;
else goto fail_tmp_906761;
}
/* commit */
{
tmp_731858 = genfunc_tmp_906706();
goto next_tmp_906764;
next_tmp_906764:
goto tmp_906763;
tmp_906763:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_906794;
fail_tmp_906761:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_906786 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_906786))
field_imm = inv_maskmask(8, tmp_906786);
else goto fail_tmp_906785;
}
/* commit */
{
tmp_731075 = genfunc_tmp_906706();
goto next_tmp_906788;
next_tmp_906788:
goto tmp_906787;
tmp_906787:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_906794;
fail_tmp_906785:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_906706();
goto next_tmp_906792;
next_tmp_906792:
goto tmp_906791;
tmp_906791:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_906794:
return tmp_731142;
}
reg_t genfunc_tmp_906759 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_906728 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_906728 >> 8) == 0)
field_imm = tmp_906728;
else goto fail_tmp_906727;
}
/* commit */
{
tmp_731858 = genfunc_tmp_906706();
goto next_tmp_906730;
next_tmp_906730:
goto tmp_906729;
tmp_906729:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_906758;
fail_tmp_906727:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_906750 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_906750))
field_imm = inv_maskmask(8, tmp_906750);
else goto fail_tmp_906749;
}
/* commit */
{
tmp_731075 = genfunc_tmp_906706();
goto next_tmp_906752;
next_tmp_906752:
goto tmp_906751;
tmp_906751:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_906758;
fail_tmp_906749:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_906706();
goto next_tmp_906756;
next_tmp_906756:
goto tmp_906755;
tmp_906755:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_906758:
return tmp_731862;
}
reg_t genfunc_tmp_906706 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_906697;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_899012();
goto next_tmp_906699;
next_tmp_906699:
goto tmp_906698;
tmp_906698:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_906705;
fail_tmp_906697:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_906701;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_899012();
goto next_tmp_906703;
next_tmp_906703:
goto tmp_906702;
tmp_906702:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_906705;
fail_tmp_906701:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_899012();
goto next_tmp_906681;
next_tmp_906681:
goto tmp_906680;
tmp_906680:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_906705:
return tmp_731876;
}
void genfunc_tmp_906659 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_906235();
goto next_tmp_906405;
next_tmp_906405:
goto tmp_906404;
tmp_906404:
}
{
tmp_731146 = genfunc_tmp_906656();
goto next_tmp_906408;
next_tmp_906408:
goto tmp_906407;
tmp_906407:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_906658:
}
reg_t genfunc_tmp_906656 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_906579;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_906279();
goto next_tmp_906581;
next_tmp_906581:
goto tmp_906580;
tmp_906580:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_906655;
fail_tmp_906579:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_906584 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_906584 >> 8) == 0)
field_imm = tmp_906584;
else goto fail_tmp_906583;
}
/* commit */
{
tmp_731665 = genfunc_tmp_906279();
goto next_tmp_906586;
next_tmp_906586:
goto tmp_906585;
tmp_906585:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_906655;
fail_tmp_906583:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_906646;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_906279();
goto next_tmp_906648;
next_tmp_906648:
goto tmp_906647;
tmp_906647:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_906655;
fail_tmp_906646:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_906651 = tmp_731085;
if ((tmp_906651 >> 8) == 0)
field_imm = tmp_906651;
else goto fail_tmp_906650;
}
/* commit */
{
tmp_731083 = genfunc_tmp_906279();
goto next_tmp_906653;
next_tmp_906653:
goto tmp_906652;
tmp_906652:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_906655;
fail_tmp_906650:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_906279();
goto next_tmp_906644;
next_tmp_906644:
goto tmp_906643;
tmp_906643:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_906655:
return tmp_731146;
}
void genfunc_tmp_906399 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_906235();
goto next_tmp_906109;
next_tmp_906109:
goto tmp_906108;
tmp_906108:
}
{
tmp_731146 = genfunc_tmp_906396();
goto next_tmp_906238;
next_tmp_906238:
goto tmp_906237;
tmp_906237:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_906398:
}
reg_t genfunc_tmp_906396 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_906235();
goto next_tmp_906373;
next_tmp_906373:
goto tmp_906372;
tmp_906372:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_906395:
return tmp_731146;
}
reg_t genfunc_tmp_906348 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_906317 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_906317 >> 8) == 0)
field_imm = tmp_906317;
else goto fail_tmp_906316;
}
/* commit */
{
tmp_731858 = genfunc_tmp_906279();
goto next_tmp_906319;
next_tmp_906319:
goto tmp_906318;
tmp_906318:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_906347;
fail_tmp_906316:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_906339 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_906339))
field_imm = inv_maskmask(8, tmp_906339);
else goto fail_tmp_906338;
}
/* commit */
{
tmp_731075 = genfunc_tmp_906279();
goto next_tmp_906341;
next_tmp_906341:
goto tmp_906340;
tmp_906340:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_906347;
fail_tmp_906338:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_906279();
goto next_tmp_906345;
next_tmp_906345:
goto tmp_906344;
tmp_906344:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_906347:
return tmp_731862;
}
reg_t genfunc_tmp_906279 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_906235();
goto next_tmp_906276;
next_tmp_906276:
goto tmp_906275;
tmp_906275:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_906278:
return tmp_731898;
}
reg_t genfunc_tmp_906235 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_906202 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_906202 >> 8) == 0)
field_imm = tmp_906202;
else goto fail_tmp_906201;
}
/* commit */
{
tmp_731858 = genfunc_tmp_906146();
goto next_tmp_906204;
next_tmp_906204:
goto tmp_906203;
tmp_906203:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_906234;
fail_tmp_906201:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_906226 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_906226))
field_imm = inv_maskmask(8, tmp_906226);
else goto fail_tmp_906225;
}
/* commit */
{
tmp_731075 = genfunc_tmp_906146();
goto next_tmp_906228;
next_tmp_906228:
goto tmp_906227;
tmp_906227:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_906234;
fail_tmp_906225:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_906146();
goto next_tmp_906232;
next_tmp_906232:
goto tmp_906231;
tmp_906231:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_906234:
return tmp_731142;
}
reg_t genfunc_tmp_906199 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_906168 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_906168 >> 8) == 0)
field_imm = tmp_906168;
else goto fail_tmp_906167;
}
/* commit */
{
tmp_731858 = genfunc_tmp_906146();
goto next_tmp_906170;
next_tmp_906170:
goto tmp_906169;
tmp_906169:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_906198;
fail_tmp_906167:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_906190 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_906190))
field_imm = inv_maskmask(8, tmp_906190);
else goto fail_tmp_906189;
}
/* commit */
{
tmp_731075 = genfunc_tmp_906146();
goto next_tmp_906192;
next_tmp_906192:
goto tmp_906191;
tmp_906191:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_906198;
fail_tmp_906189:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_906146();
goto next_tmp_906196;
next_tmp_906196:
goto tmp_906195;
tmp_906195:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_906198:
return tmp_731862;
}
reg_t genfunc_tmp_906146 (void) {
reg_t tmp_731876;
/* ADDQ_IMM */
{
word_5 tmp_731893;
word_5 field_rc;
word_5 tmp_731894;
word_5 field_ra;
word_64 tmp_731896;
word_8 field_imm;
tmp_731896 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_906131 = tmp_731896;
if ((tmp_906131 >> 8) == 0)
field_imm = tmp_906131;
else goto fail_tmp_906130;
}
/* commit */
tmp_731894 = ref_gpr_reg_for_reading(0 + rm);
tmp_731893 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731893;
field_ra = tmp_731894;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731894);
/* can fail: T   num insns: 1 */
}
goto done_tmp_906145;
fail_tmp_906130:
/* LDA */
{
word_5 tmp_731397;
word_5 field_ra;
word_5 tmp_731398;
word_5 field_rb;
word_64 tmp_731400;
word_16 field_memory_disp;
tmp_731400 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_906139 = tmp_731400;
if ((tmp_906139 >> 16) == 0xFFFFFFFFFFFF || (tmp_906139 >> 16) == 0)
field_memory_disp = (tmp_906139 & 0xFFFF);
else goto fail_tmp_906138;
}
/* commit */
tmp_731398 = ref_gpr_reg_for_reading(0 + rm);
tmp_731397 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731397;
field_rb = tmp_731398;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731398);
/* can fail: T   num insns: 1 */
}
goto done_tmp_906145;
fail_tmp_906138:
/* LDAH */
{
word_5 tmp_731393;
word_5 field_ra;
word_5 tmp_731394;
word_5 field_rb;
word_64 tmp_731396;
word_16 field_memory_disp;
tmp_731396 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_906143 = tmp_731396;
if ((tmp_906143 & 0xFFFF) == 0)
{
word_64 tmp_906144 = (tmp_906143 >> 16);
if ((tmp_906144 >> 16) == 0xFFFFFFFFFFFF || (tmp_906144 >> 16) == 0)
field_memory_disp = (tmp_906144 & 0xFFFF);
else goto fail_tmp_906142;
}
else goto fail_tmp_906142;
}
/* commit */
tmp_731394 = ref_gpr_reg_for_reading(0 + rm);
tmp_731393 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731393;
field_rb = tmp_731394;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731394);
/* can fail: T   num insns: 1 */
}
goto done_tmp_906145;
fail_tmp_906142:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731900 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731900, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_906145:
return tmp_731876;
}
void genfunc_tmp_906103 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_905679();
goto next_tmp_905849;
next_tmp_905849:
goto tmp_905848;
tmp_905848:
}
{
tmp_731146 = genfunc_tmp_906100();
goto next_tmp_905852;
next_tmp_905852:
goto tmp_905851;
tmp_905851:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_906102:
}
reg_t genfunc_tmp_906100 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_906023;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_905723();
goto next_tmp_906025;
next_tmp_906025:
goto tmp_906024;
tmp_906024:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_906099;
fail_tmp_906023:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_906028 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_906028 >> 8) == 0)
field_imm = tmp_906028;
else goto fail_tmp_906027;
}
/* commit */
{
tmp_731665 = genfunc_tmp_905723();
goto next_tmp_906030;
next_tmp_906030:
goto tmp_906029;
tmp_906029:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_906099;
fail_tmp_906027:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_906090;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_905723();
goto next_tmp_906092;
next_tmp_906092:
goto tmp_906091;
tmp_906091:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_906099;
fail_tmp_906090:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_906095 = tmp_731085;
if ((tmp_906095 >> 8) == 0)
field_imm = tmp_906095;
else goto fail_tmp_906094;
}
/* commit */
{
tmp_731083 = genfunc_tmp_905723();
goto next_tmp_906097;
next_tmp_906097:
goto tmp_906096;
tmp_906096:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_906099;
fail_tmp_906094:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_905723();
goto next_tmp_906088;
next_tmp_906088:
goto tmp_906087;
tmp_906087:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_906099:
return tmp_731146;
}
void genfunc_tmp_905843 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_905679();
goto next_tmp_905558;
next_tmp_905558:
goto tmp_905557;
tmp_905557:
}
{
tmp_731146 = genfunc_tmp_905840();
goto next_tmp_905682;
next_tmp_905682:
goto tmp_905681;
tmp_905681:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_905842:
}
reg_t genfunc_tmp_905840 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_905679();
goto next_tmp_905817;
next_tmp_905817:
goto tmp_905816;
tmp_905816:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_905839:
return tmp_731146;
}
reg_t genfunc_tmp_905792 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_905761 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_905761 >> 8) == 0)
field_imm = tmp_905761;
else goto fail_tmp_905760;
}
/* commit */
{
tmp_731858 = genfunc_tmp_905723();
goto next_tmp_905763;
next_tmp_905763:
goto tmp_905762;
tmp_905762:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_905791;
fail_tmp_905760:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_905783 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_905783))
field_imm = inv_maskmask(8, tmp_905783);
else goto fail_tmp_905782;
}
/* commit */
{
tmp_731075 = genfunc_tmp_905723();
goto next_tmp_905785;
next_tmp_905785:
goto tmp_905784;
tmp_905784:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_905791;
fail_tmp_905782:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_905723();
goto next_tmp_905789;
next_tmp_905789:
goto tmp_905788;
tmp_905788:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_905791:
return tmp_731862;
}
reg_t genfunc_tmp_905723 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_905679();
goto next_tmp_905720;
next_tmp_905720:
goto tmp_905719;
tmp_905719:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_905722:
return tmp_731898;
}
reg_t genfunc_tmp_905679 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_905646 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_905646 >> 8) == 0)
field_imm = tmp_905646;
else goto fail_tmp_905645;
}
/* commit */
{
tmp_731858 = genfunc_tmp_905590();
goto next_tmp_905648;
next_tmp_905648:
goto tmp_905647;
tmp_905647:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_905678;
fail_tmp_905645:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_905670 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_905670))
field_imm = inv_maskmask(8, tmp_905670);
else goto fail_tmp_905669;
}
/* commit */
{
tmp_731075 = genfunc_tmp_905590();
goto next_tmp_905672;
next_tmp_905672:
goto tmp_905671;
tmp_905671:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_905678;
fail_tmp_905669:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_905590();
goto next_tmp_905676;
next_tmp_905676:
goto tmp_905675;
tmp_905675:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_905678:
return tmp_731142;
}
reg_t genfunc_tmp_905643 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_905612 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_905612 >> 8) == 0)
field_imm = tmp_905612;
else goto fail_tmp_905611;
}
/* commit */
{
tmp_731858 = genfunc_tmp_905590();
goto next_tmp_905614;
next_tmp_905614:
goto tmp_905613;
tmp_905613:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_905642;
fail_tmp_905611:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_905634 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_905634))
field_imm = inv_maskmask(8, tmp_905634);
else goto fail_tmp_905633;
}
/* commit */
{
tmp_731075 = genfunc_tmp_905590();
goto next_tmp_905636;
next_tmp_905636:
goto tmp_905635;
tmp_905635:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_905642;
fail_tmp_905633:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_905590();
goto next_tmp_905640;
next_tmp_905640:
goto tmp_905639;
tmp_905639:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_905642:
return tmp_731862;
}
reg_t genfunc_tmp_905590 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_905587;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + 5);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_905589;
fail_tmp_905587:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_905588;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + 5);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_905589;
fail_tmp_905588:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731900 = ref_gpr_reg_for_reading(0 + 5);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_905589:
return tmp_731876;
}
void genfunc_tmp_905552 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_905128();
goto next_tmp_905298;
next_tmp_905298:
goto tmp_905297;
tmp_905297:
}
{
tmp_731146 = genfunc_tmp_905549();
goto next_tmp_905301;
next_tmp_905301:
goto tmp_905300;
tmp_905300:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 14 */
}
done_tmp_905551:
}
reg_t genfunc_tmp_905549 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_905472;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_905172();
goto next_tmp_905474;
next_tmp_905474:
goto tmp_905473;
tmp_905473:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 7 */
}
goto done_tmp_905548;
fail_tmp_905472:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_905477 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_905477 >> 8) == 0)
field_imm = tmp_905477;
else goto fail_tmp_905476;
}
/* commit */
{
tmp_731665 = genfunc_tmp_905172();
goto next_tmp_905479;
next_tmp_905479:
goto tmp_905478;
tmp_905478:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 7 */
}
goto done_tmp_905548;
fail_tmp_905476:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_905539;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_905172();
goto next_tmp_905541;
next_tmp_905541:
goto tmp_905540;
tmp_905540:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 7 */
}
goto done_tmp_905548;
fail_tmp_905539:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_905544 = tmp_731085;
if ((tmp_905544 >> 8) == 0)
field_imm = tmp_905544;
else goto fail_tmp_905543;
}
/* commit */
{
tmp_731083 = genfunc_tmp_905172();
goto next_tmp_905546;
next_tmp_905546:
goto tmp_905545;
tmp_905545:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 7 */
}
goto done_tmp_905548;
fail_tmp_905543:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_905172();
goto next_tmp_905537;
next_tmp_905537:
goto tmp_905536;
tmp_905536:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 8 */
}
done_tmp_905548:
return tmp_731146;
}
void genfunc_tmp_905292 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_905128();
goto next_tmp_904976;
next_tmp_904976:
goto tmp_904975;
tmp_904975:
}
{
tmp_731146 = genfunc_tmp_905289();
goto next_tmp_905131;
next_tmp_905131:
goto tmp_905130;
tmp_905130:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_905291:
}
reg_t genfunc_tmp_905289 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_905128();
goto next_tmp_905266;
next_tmp_905266:
goto tmp_905265;
tmp_905265:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_905288:
return tmp_731146;
}
reg_t genfunc_tmp_905241 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_905210 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_905210 >> 8) == 0)
field_imm = tmp_905210;
else goto fail_tmp_905209;
}
/* commit */
{
tmp_731858 = genfunc_tmp_905172();
goto next_tmp_905212;
next_tmp_905212:
goto tmp_905211;
tmp_905211:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 7 */
}
goto done_tmp_905240;
fail_tmp_905209:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_905232 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_905232))
field_imm = inv_maskmask(8, tmp_905232);
else goto fail_tmp_905231;
}
/* commit */
{
tmp_731075 = genfunc_tmp_905172();
goto next_tmp_905234;
next_tmp_905234:
goto tmp_905233;
tmp_905233:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 7 */
}
goto done_tmp_905240;
fail_tmp_905231:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_905172();
goto next_tmp_905238;
next_tmp_905238:
goto tmp_905237;
tmp_905237:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 7 */
}
done_tmp_905240:
return tmp_731862;
}
reg_t genfunc_tmp_905172 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_905128();
goto next_tmp_905169;
next_tmp_905169:
goto tmp_905168;
tmp_905168:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_905171:
return tmp_731898;
}
reg_t genfunc_tmp_905128 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_905095 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_905095 >> 8) == 0)
field_imm = tmp_905095;
else goto fail_tmp_905094;
}
/* commit */
{
tmp_731858 = genfunc_tmp_905039();
goto next_tmp_905097;
next_tmp_905097:
goto tmp_905096;
tmp_905096:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_905127;
fail_tmp_905094:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_905119 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_905119))
field_imm = inv_maskmask(8, tmp_905119);
else goto fail_tmp_905118;
}
/* commit */
{
tmp_731075 = genfunc_tmp_905039();
goto next_tmp_905121;
next_tmp_905121:
goto tmp_905120;
tmp_905120:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_905127;
fail_tmp_905118:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_905039();
goto next_tmp_905125;
next_tmp_905125:
goto tmp_905124;
tmp_905124:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_905127:
return tmp_731142;
}
reg_t genfunc_tmp_905092 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_905061 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_905061 >> 8) == 0)
field_imm = tmp_905061;
else goto fail_tmp_905060;
}
/* commit */
{
tmp_731858 = genfunc_tmp_905039();
goto next_tmp_905063;
next_tmp_905063:
goto tmp_905062;
tmp_905062:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_905091;
fail_tmp_905060:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_905083 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_905083))
field_imm = inv_maskmask(8, tmp_905083);
else goto fail_tmp_905082;
}
/* commit */
{
tmp_731075 = genfunc_tmp_905039();
goto next_tmp_905085;
next_tmp_905085:
goto tmp_905084;
tmp_905084:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_905091;
fail_tmp_905082:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_905039();
goto next_tmp_905089;
next_tmp_905089:
goto tmp_905088;
tmp_905088:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_905091:
return tmp_731862;
}
reg_t genfunc_tmp_905039 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_905030;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_905014();
goto next_tmp_905032;
next_tmp_905032:
goto tmp_905031;
tmp_905031:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_905038;
fail_tmp_905030:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_905034;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_905014();
goto next_tmp_905036;
next_tmp_905036:
goto tmp_905035;
tmp_905035:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_905038;
fail_tmp_905034:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_905014();
goto next_tmp_904992;
next_tmp_904992:
goto tmp_904991;
tmp_904991:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_905038:
return tmp_731876;
}
reg_t genfunc_tmp_905014 (void) {
reg_t tmp_731900;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + 5);
{
tmp_731900 = genfunc_tmp_899579();
goto next_tmp_904997;
next_tmp_904997:
goto tmp_904996;
tmp_904996:
}
tmp_731897 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_905013:
return tmp_731900;
}
void genfunc_tmp_904970 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_904546();
goto next_tmp_904716;
next_tmp_904716:
goto tmp_904715;
tmp_904715:
}
{
tmp_731146 = genfunc_tmp_904967();
goto next_tmp_904719;
next_tmp_904719:
goto tmp_904718;
tmp_904718:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_904969:
}
reg_t genfunc_tmp_904967 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_904890;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_904590();
goto next_tmp_904892;
next_tmp_904892:
goto tmp_904891;
tmp_904891:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 6 */
}
goto done_tmp_904966;
fail_tmp_904890:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_904895 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_904895 >> 8) == 0)
field_imm = tmp_904895;
else goto fail_tmp_904894;
}
/* commit */
{
tmp_731665 = genfunc_tmp_904590();
goto next_tmp_904897;
next_tmp_904897:
goto tmp_904896;
tmp_904896:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 6 */
}
goto done_tmp_904966;
fail_tmp_904894:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_904957;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_904590();
goto next_tmp_904959;
next_tmp_904959:
goto tmp_904958;
tmp_904958:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 6 */
}
goto done_tmp_904966;
fail_tmp_904957:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_904962 = tmp_731085;
if ((tmp_904962 >> 8) == 0)
field_imm = tmp_904962;
else goto fail_tmp_904961;
}
/* commit */
{
tmp_731083 = genfunc_tmp_904590();
goto next_tmp_904964;
next_tmp_904964:
goto tmp_904963;
tmp_904963:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 6 */
}
goto done_tmp_904966;
fail_tmp_904961:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_904590();
goto next_tmp_904955;
next_tmp_904955:
goto tmp_904954;
tmp_904954:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_904966:
return tmp_731146;
}
void genfunc_tmp_904710 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_904546();
goto next_tmp_904397;
next_tmp_904397:
goto tmp_904396;
tmp_904396:
}
{
tmp_731146 = genfunc_tmp_904707();
goto next_tmp_904549;
next_tmp_904549:
goto tmp_904548;
tmp_904548:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_904709:
}
reg_t genfunc_tmp_904707 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_904546();
goto next_tmp_904684;
next_tmp_904684:
goto tmp_904683;
tmp_904683:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_904706:
return tmp_731146;
}
reg_t genfunc_tmp_904659 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_904628 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_904628 >> 8) == 0)
field_imm = tmp_904628;
else goto fail_tmp_904627;
}
/* commit */
{
tmp_731858 = genfunc_tmp_904590();
goto next_tmp_904630;
next_tmp_904630:
goto tmp_904629;
tmp_904629:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 6 */
}
goto done_tmp_904658;
fail_tmp_904627:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_904650 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_904650))
field_imm = inv_maskmask(8, tmp_904650);
else goto fail_tmp_904649;
}
/* commit */
{
tmp_731075 = genfunc_tmp_904590();
goto next_tmp_904652;
next_tmp_904652:
goto tmp_904651;
tmp_904651:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 6 */
}
goto done_tmp_904658;
fail_tmp_904649:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_904590();
goto next_tmp_904656;
next_tmp_904656:
goto tmp_904655;
tmp_904655:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 6 */
}
done_tmp_904658:
return tmp_731862;
}
reg_t genfunc_tmp_904590 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_904546();
goto next_tmp_904587;
next_tmp_904587:
goto tmp_904586;
tmp_904586:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_904589:
return tmp_731898;
}
reg_t genfunc_tmp_904546 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_904513 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_904513 >> 8) == 0)
field_imm = tmp_904513;
else goto fail_tmp_904512;
}
/* commit */
{
tmp_731858 = genfunc_tmp_904457();
goto next_tmp_904515;
next_tmp_904515:
goto tmp_904514;
tmp_904514:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_904545;
fail_tmp_904512:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_904537 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_904537))
field_imm = inv_maskmask(8, tmp_904537);
else goto fail_tmp_904536;
}
/* commit */
{
tmp_731075 = genfunc_tmp_904457();
goto next_tmp_904539;
next_tmp_904539:
goto tmp_904538;
tmp_904538:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_904545;
fail_tmp_904536:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_904457();
goto next_tmp_904543;
next_tmp_904543:
goto tmp_904542;
tmp_904542:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_904545:
return tmp_731142;
}
reg_t genfunc_tmp_904510 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_904479 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_904479 >> 8) == 0)
field_imm = tmp_904479;
else goto fail_tmp_904478;
}
/* commit */
{
tmp_731858 = genfunc_tmp_904457();
goto next_tmp_904481;
next_tmp_904481:
goto tmp_904480;
tmp_904480:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_904509;
fail_tmp_904478:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_904501 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_904501))
field_imm = inv_maskmask(8, tmp_904501);
else goto fail_tmp_904500;
}
/* commit */
{
tmp_731075 = genfunc_tmp_904457();
goto next_tmp_904503;
next_tmp_904503:
goto tmp_904502;
tmp_904502:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_904509;
fail_tmp_904500:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_904457();
goto next_tmp_904507;
next_tmp_904507:
goto tmp_904506;
tmp_904506:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_904509:
return tmp_731862;
}
reg_t genfunc_tmp_904457 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_904448;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_904432();
goto next_tmp_904450;
next_tmp_904450:
goto tmp_904449;
tmp_904449:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_904456;
fail_tmp_904448:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_904452;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_904432();
goto next_tmp_904454;
next_tmp_904454:
goto tmp_904453;
tmp_904453:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_904456;
fail_tmp_904452:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_904432();
goto next_tmp_904413;
next_tmp_904413:
goto tmp_904412;
tmp_904412:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_904456:
return tmp_731876;
}
reg_t genfunc_tmp_904432 (void) {
reg_t tmp_731900;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + 5);
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_904431:
return tmp_731900;
}
void genfunc_tmp_904391 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_903967();
goto next_tmp_904137;
next_tmp_904137:
goto tmp_904136;
tmp_904136:
}
{
tmp_731146 = genfunc_tmp_904388();
goto next_tmp_904140;
next_tmp_904140:
goto tmp_904139;
tmp_904139:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_904390:
}
reg_t genfunc_tmp_904388 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_904311;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_904011();
goto next_tmp_904313;
next_tmp_904313:
goto tmp_904312;
tmp_904312:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_904387;
fail_tmp_904311:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_904316 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_904316 >> 8) == 0)
field_imm = tmp_904316;
else goto fail_tmp_904315;
}
/* commit */
{
tmp_731665 = genfunc_tmp_904011();
goto next_tmp_904318;
next_tmp_904318:
goto tmp_904317;
tmp_904317:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_904387;
fail_tmp_904315:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_904378;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_904011();
goto next_tmp_904380;
next_tmp_904380:
goto tmp_904379;
tmp_904379:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_904387;
fail_tmp_904378:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_904383 = tmp_731085;
if ((tmp_904383 >> 8) == 0)
field_imm = tmp_904383;
else goto fail_tmp_904382;
}
/* commit */
{
tmp_731083 = genfunc_tmp_904011();
goto next_tmp_904385;
next_tmp_904385:
goto tmp_904384;
tmp_904384:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_904387;
fail_tmp_904382:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_904011();
goto next_tmp_904376;
next_tmp_904376:
goto tmp_904375;
tmp_904375:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_904387:
return tmp_731146;
}
void genfunc_tmp_904131 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_903967();
goto next_tmp_903846;
next_tmp_903846:
goto tmp_903845;
tmp_903845:
}
{
tmp_731146 = genfunc_tmp_904128();
goto next_tmp_903970;
next_tmp_903970:
goto tmp_903969;
tmp_903969:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_904130:
}
reg_t genfunc_tmp_904128 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_903967();
goto next_tmp_904105;
next_tmp_904105:
goto tmp_904104;
tmp_904104:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_904127:
return tmp_731146;
}
reg_t genfunc_tmp_904080 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_904049 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_904049 >> 8) == 0)
field_imm = tmp_904049;
else goto fail_tmp_904048;
}
/* commit */
{
tmp_731858 = genfunc_tmp_904011();
goto next_tmp_904051;
next_tmp_904051:
goto tmp_904050;
tmp_904050:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_904079;
fail_tmp_904048:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_904071 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_904071))
field_imm = inv_maskmask(8, tmp_904071);
else goto fail_tmp_904070;
}
/* commit */
{
tmp_731075 = genfunc_tmp_904011();
goto next_tmp_904073;
next_tmp_904073:
goto tmp_904072;
tmp_904072:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_904079;
fail_tmp_904070:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_904011();
goto next_tmp_904077;
next_tmp_904077:
goto tmp_904076;
tmp_904076:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_904079:
return tmp_731862;
}
reg_t genfunc_tmp_904011 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_903967();
goto next_tmp_904008;
next_tmp_904008:
goto tmp_904007;
tmp_904007:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_904010:
return tmp_731898;
}
reg_t genfunc_tmp_903967 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_903934 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_903934 >> 8) == 0)
field_imm = tmp_903934;
else goto fail_tmp_903933;
}
/* commit */
{
tmp_731858 = genfunc_tmp_903878();
goto next_tmp_903936;
next_tmp_903936:
goto tmp_903935;
tmp_903935:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_903966;
fail_tmp_903933:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_903958 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_903958))
field_imm = inv_maskmask(8, tmp_903958);
else goto fail_tmp_903957;
}
/* commit */
{
tmp_731075 = genfunc_tmp_903878();
goto next_tmp_903960;
next_tmp_903960:
goto tmp_903959;
tmp_903959:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_903966;
fail_tmp_903957:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_903878();
goto next_tmp_903964;
next_tmp_903964:
goto tmp_903963;
tmp_903963:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_903966:
return tmp_731142;
}
reg_t genfunc_tmp_903931 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_903900 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_903900 >> 8) == 0)
field_imm = tmp_903900;
else goto fail_tmp_903899;
}
/* commit */
{
tmp_731858 = genfunc_tmp_903878();
goto next_tmp_903902;
next_tmp_903902:
goto tmp_903901;
tmp_903901:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_903930;
fail_tmp_903899:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_903922 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_903922))
field_imm = inv_maskmask(8, tmp_903922);
else goto fail_tmp_903921;
}
/* commit */
{
tmp_731075 = genfunc_tmp_903878();
goto next_tmp_903924;
next_tmp_903924:
goto tmp_903923;
tmp_903923:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_903930;
fail_tmp_903921:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_903878();
goto next_tmp_903928;
next_tmp_903928:
goto tmp_903927;
tmp_903927:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_903930:
return tmp_731862;
}
reg_t genfunc_tmp_903878 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_903875;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + base);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_903877;
fail_tmp_903875:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_903876;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + base);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_903877;
fail_tmp_903876:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731900 = ref_gpr_reg_for_reading(0 + base);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_903877:
return tmp_731876;
}
void genfunc_tmp_903840 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_903416();
goto next_tmp_903586;
next_tmp_903586:
goto tmp_903585;
tmp_903585:
}
{
tmp_731146 = genfunc_tmp_903837();
goto next_tmp_903589;
next_tmp_903589:
goto tmp_903588;
tmp_903588:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 14 */
}
done_tmp_903839:
}
reg_t genfunc_tmp_903837 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_903760;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_903460();
goto next_tmp_903762;
next_tmp_903762:
goto tmp_903761;
tmp_903761:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 7 */
}
goto done_tmp_903836;
fail_tmp_903760:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_903765 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_903765 >> 8) == 0)
field_imm = tmp_903765;
else goto fail_tmp_903764;
}
/* commit */
{
tmp_731665 = genfunc_tmp_903460();
goto next_tmp_903767;
next_tmp_903767:
goto tmp_903766;
tmp_903766:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 7 */
}
goto done_tmp_903836;
fail_tmp_903764:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_903827;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_903460();
goto next_tmp_903829;
next_tmp_903829:
goto tmp_903828;
tmp_903828:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 7 */
}
goto done_tmp_903836;
fail_tmp_903827:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_903832 = tmp_731085;
if ((tmp_903832 >> 8) == 0)
field_imm = tmp_903832;
else goto fail_tmp_903831;
}
/* commit */
{
tmp_731083 = genfunc_tmp_903460();
goto next_tmp_903834;
next_tmp_903834:
goto tmp_903833;
tmp_903833:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 7 */
}
goto done_tmp_903836;
fail_tmp_903831:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_903460();
goto next_tmp_903825;
next_tmp_903825:
goto tmp_903824;
tmp_903824:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 8 */
}
done_tmp_903836:
return tmp_731146;
}
void genfunc_tmp_903580 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_903416();
goto next_tmp_903286;
next_tmp_903286:
goto tmp_903285;
tmp_903285:
}
{
tmp_731146 = genfunc_tmp_903577();
goto next_tmp_903419;
next_tmp_903419:
goto tmp_903418;
tmp_903418:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_903579:
}
reg_t genfunc_tmp_903577 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_903416();
goto next_tmp_903554;
next_tmp_903554:
goto tmp_903553;
tmp_903553:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_903576:
return tmp_731146;
}
reg_t genfunc_tmp_903529 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_903498 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_903498 >> 8) == 0)
field_imm = tmp_903498;
else goto fail_tmp_903497;
}
/* commit */
{
tmp_731858 = genfunc_tmp_903460();
goto next_tmp_903500;
next_tmp_903500:
goto tmp_903499;
tmp_903499:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 7 */
}
goto done_tmp_903528;
fail_tmp_903497:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_903520 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_903520))
field_imm = inv_maskmask(8, tmp_903520);
else goto fail_tmp_903519;
}
/* commit */
{
tmp_731075 = genfunc_tmp_903460();
goto next_tmp_903522;
next_tmp_903522:
goto tmp_903521;
tmp_903521:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 7 */
}
goto done_tmp_903528;
fail_tmp_903519:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_903460();
goto next_tmp_903526;
next_tmp_903526:
goto tmp_903525;
tmp_903525:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 7 */
}
done_tmp_903528:
return tmp_731862;
}
reg_t genfunc_tmp_903460 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_903416();
goto next_tmp_903457;
next_tmp_903457:
goto tmp_903456;
tmp_903456:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_903459:
return tmp_731898;
}
reg_t genfunc_tmp_903416 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_903383 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_903383 >> 8) == 0)
field_imm = tmp_903383;
else goto fail_tmp_903382;
}
/* commit */
{
tmp_731858 = genfunc_tmp_903327();
goto next_tmp_903385;
next_tmp_903385:
goto tmp_903384;
tmp_903384:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_903415;
fail_tmp_903382:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_903407 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_903407))
field_imm = inv_maskmask(8, tmp_903407);
else goto fail_tmp_903406;
}
/* commit */
{
tmp_731075 = genfunc_tmp_903327();
goto next_tmp_903409;
next_tmp_903409:
goto tmp_903408;
tmp_903408:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_903415;
fail_tmp_903406:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_903327();
goto next_tmp_903413;
next_tmp_903413:
goto tmp_903412;
tmp_903412:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_903415:
return tmp_731142;
}
reg_t genfunc_tmp_903380 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_903349 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_903349 >> 8) == 0)
field_imm = tmp_903349;
else goto fail_tmp_903348;
}
/* commit */
{
tmp_731858 = genfunc_tmp_903327();
goto next_tmp_903351;
next_tmp_903351:
goto tmp_903350;
tmp_903350:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_903379;
fail_tmp_903348:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_903371 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_903371))
field_imm = inv_maskmask(8, tmp_903371);
else goto fail_tmp_903370;
}
/* commit */
{
tmp_731075 = genfunc_tmp_903327();
goto next_tmp_903373;
next_tmp_903373:
goto tmp_903372;
tmp_903372:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_903379;
fail_tmp_903370:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_903327();
goto next_tmp_903377;
next_tmp_903377:
goto tmp_903376;
tmp_903376:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_903379:
return tmp_731862;
}
reg_t genfunc_tmp_903327 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_903318;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_899596();
goto next_tmp_903320;
next_tmp_903320:
goto tmp_903319;
tmp_903319:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_903326;
fail_tmp_903318:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_903322;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_899596();
goto next_tmp_903324;
next_tmp_903324:
goto tmp_903323;
tmp_903323:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_903326;
fail_tmp_903322:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_899596();
goto next_tmp_903302;
next_tmp_903302:
goto tmp_903301;
tmp_903301:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_903326:
return tmp_731876;
}
void genfunc_tmp_903280 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_902856();
goto next_tmp_903026;
next_tmp_903026:
goto tmp_903025;
tmp_903025:
}
{
tmp_731146 = genfunc_tmp_903277();
goto next_tmp_903029;
next_tmp_903029:
goto tmp_903028;
tmp_903028:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_903279:
}
reg_t genfunc_tmp_903277 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_903200;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_902900();
goto next_tmp_903202;
next_tmp_903202:
goto tmp_903201;
tmp_903201:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 6 */
}
goto done_tmp_903276;
fail_tmp_903200:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_903205 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_903205 >> 8) == 0)
field_imm = tmp_903205;
else goto fail_tmp_903204;
}
/* commit */
{
tmp_731665 = genfunc_tmp_902900();
goto next_tmp_903207;
next_tmp_903207:
goto tmp_903206;
tmp_903206:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 6 */
}
goto done_tmp_903276;
fail_tmp_903204:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_903267;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_902900();
goto next_tmp_903269;
next_tmp_903269:
goto tmp_903268;
tmp_903268:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 6 */
}
goto done_tmp_903276;
fail_tmp_903267:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_903272 = tmp_731085;
if ((tmp_903272 >> 8) == 0)
field_imm = tmp_903272;
else goto fail_tmp_903271;
}
/* commit */
{
tmp_731083 = genfunc_tmp_902900();
goto next_tmp_903274;
next_tmp_903274:
goto tmp_903273;
tmp_903273:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 6 */
}
goto done_tmp_903276;
fail_tmp_903271:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_902900();
goto next_tmp_903265;
next_tmp_903265:
goto tmp_903264;
tmp_903264:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_903276:
return tmp_731146;
}
void genfunc_tmp_903020 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_902856();
goto next_tmp_902726;
next_tmp_902726:
goto tmp_902725;
tmp_902725:
}
{
tmp_731146 = genfunc_tmp_903017();
goto next_tmp_902859;
next_tmp_902859:
goto tmp_902858;
tmp_902858:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_903019:
}
reg_t genfunc_tmp_903017 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_902856();
goto next_tmp_902994;
next_tmp_902994:
goto tmp_902993;
tmp_902993:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_903016:
return tmp_731146;
}
reg_t genfunc_tmp_902969 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_902938 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_902938 >> 8) == 0)
field_imm = tmp_902938;
else goto fail_tmp_902937;
}
/* commit */
{
tmp_731858 = genfunc_tmp_902900();
goto next_tmp_902940;
next_tmp_902940:
goto tmp_902939;
tmp_902939:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 6 */
}
goto done_tmp_902968;
fail_tmp_902937:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_902960 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_902960))
field_imm = inv_maskmask(8, tmp_902960);
else goto fail_tmp_902959;
}
/* commit */
{
tmp_731075 = genfunc_tmp_902900();
goto next_tmp_902962;
next_tmp_902962:
goto tmp_902961;
tmp_902961:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 6 */
}
goto done_tmp_902968;
fail_tmp_902959:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_902900();
goto next_tmp_902966;
next_tmp_902966:
goto tmp_902965;
tmp_902965:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 6 */
}
done_tmp_902968:
return tmp_731862;
}
reg_t genfunc_tmp_902900 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_902856();
goto next_tmp_902897;
next_tmp_902897:
goto tmp_902896;
tmp_902896:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_902899:
return tmp_731898;
}
reg_t genfunc_tmp_902856 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_902823 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_902823 >> 8) == 0)
field_imm = tmp_902823;
else goto fail_tmp_902822;
}
/* commit */
{
tmp_731858 = genfunc_tmp_902767();
goto next_tmp_902825;
next_tmp_902825:
goto tmp_902824;
tmp_902824:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_902855;
fail_tmp_902822:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_902847 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_902847))
field_imm = inv_maskmask(8, tmp_902847);
else goto fail_tmp_902846;
}
/* commit */
{
tmp_731075 = genfunc_tmp_902767();
goto next_tmp_902849;
next_tmp_902849:
goto tmp_902848;
tmp_902848:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_902855;
fail_tmp_902846:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_902767();
goto next_tmp_902853;
next_tmp_902853:
goto tmp_902852;
tmp_902852:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_902855:
return tmp_731142;
}
reg_t genfunc_tmp_902820 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_902789 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_902789 >> 8) == 0)
field_imm = tmp_902789;
else goto fail_tmp_902788;
}
/* commit */
{
tmp_731858 = genfunc_tmp_902767();
goto next_tmp_902791;
next_tmp_902791:
goto tmp_902790;
tmp_902790:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_902819;
fail_tmp_902788:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_902811 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_902811))
field_imm = inv_maskmask(8, tmp_902811);
else goto fail_tmp_902810;
}
/* commit */
{
tmp_731075 = genfunc_tmp_902767();
goto next_tmp_902813;
next_tmp_902813:
goto tmp_902812;
tmp_902812:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_902819;
fail_tmp_902810:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_902767();
goto next_tmp_902817;
next_tmp_902817:
goto tmp_902816;
tmp_902816:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_902819:
return tmp_731862;
}
reg_t genfunc_tmp_902767 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_902758;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_899012();
goto next_tmp_902760;
next_tmp_902760:
goto tmp_902759;
tmp_902759:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_902766;
fail_tmp_902758:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_902762;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_899012();
goto next_tmp_902764;
next_tmp_902764:
goto tmp_902763;
tmp_902763:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_902766;
fail_tmp_902762:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_899012();
goto next_tmp_902742;
next_tmp_902742:
goto tmp_902741;
tmp_902741:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_902766:
return tmp_731876;
}
void genfunc_tmp_902720 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_902296();
goto next_tmp_902466;
next_tmp_902466:
goto tmp_902465;
tmp_902465:
}
{
tmp_731146 = genfunc_tmp_902717();
goto next_tmp_902469;
next_tmp_902469:
goto tmp_902468;
tmp_902468:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_902719:
}
reg_t genfunc_tmp_902717 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_902640;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_902340();
goto next_tmp_902642;
next_tmp_902642:
goto tmp_902641;
tmp_902641:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_902716;
fail_tmp_902640:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_902645 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_902645 >> 8) == 0)
field_imm = tmp_902645;
else goto fail_tmp_902644;
}
/* commit */
{
tmp_731665 = genfunc_tmp_902340();
goto next_tmp_902647;
next_tmp_902647:
goto tmp_902646;
tmp_902646:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_902716;
fail_tmp_902644:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_902707;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_902340();
goto next_tmp_902709;
next_tmp_902709:
goto tmp_902708;
tmp_902708:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_902716;
fail_tmp_902707:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_902712 = tmp_731085;
if ((tmp_902712 >> 8) == 0)
field_imm = tmp_902712;
else goto fail_tmp_902711;
}
/* commit */
{
tmp_731083 = genfunc_tmp_902340();
goto next_tmp_902714;
next_tmp_902714:
goto tmp_902713;
tmp_902713:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_902716;
fail_tmp_902711:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_902340();
goto next_tmp_902705;
next_tmp_902705:
goto tmp_902704;
tmp_902704:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_902716:
return tmp_731146;
}
void genfunc_tmp_902460 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_902296();
goto next_tmp_902170;
next_tmp_902170:
goto tmp_902169;
tmp_902169:
}
{
tmp_731146 = genfunc_tmp_902457();
goto next_tmp_902299;
next_tmp_902299:
goto tmp_902298;
tmp_902298:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_902459:
}
reg_t genfunc_tmp_902457 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_902296();
goto next_tmp_902434;
next_tmp_902434:
goto tmp_902433;
tmp_902433:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_902456:
return tmp_731146;
}
reg_t genfunc_tmp_902409 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_902378 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_902378 >> 8) == 0)
field_imm = tmp_902378;
else goto fail_tmp_902377;
}
/* commit */
{
tmp_731858 = genfunc_tmp_902340();
goto next_tmp_902380;
next_tmp_902380:
goto tmp_902379;
tmp_902379:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_902408;
fail_tmp_902377:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_902400 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_902400))
field_imm = inv_maskmask(8, tmp_902400);
else goto fail_tmp_902399;
}
/* commit */
{
tmp_731075 = genfunc_tmp_902340();
goto next_tmp_902402;
next_tmp_902402:
goto tmp_902401;
tmp_902401:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_902408;
fail_tmp_902399:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_902340();
goto next_tmp_902406;
next_tmp_902406:
goto tmp_902405;
tmp_902405:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_902408:
return tmp_731862;
}
reg_t genfunc_tmp_902340 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_902296();
goto next_tmp_902337;
next_tmp_902337:
goto tmp_902336;
tmp_902336:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_902339:
return tmp_731898;
}
reg_t genfunc_tmp_902296 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_902263 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_902263 >> 8) == 0)
field_imm = tmp_902263;
else goto fail_tmp_902262;
}
/* commit */
{
tmp_731858 = genfunc_tmp_902207();
goto next_tmp_902265;
next_tmp_902265:
goto tmp_902264;
tmp_902264:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_902295;
fail_tmp_902262:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_902287 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_902287))
field_imm = inv_maskmask(8, tmp_902287);
else goto fail_tmp_902286;
}
/* commit */
{
tmp_731075 = genfunc_tmp_902207();
goto next_tmp_902289;
next_tmp_902289:
goto tmp_902288;
tmp_902288:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_902295;
fail_tmp_902286:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_902207();
goto next_tmp_902293;
next_tmp_902293:
goto tmp_902292;
tmp_902292:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_902295:
return tmp_731142;
}
reg_t genfunc_tmp_902260 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_902229 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_902229 >> 8) == 0)
field_imm = tmp_902229;
else goto fail_tmp_902228;
}
/* commit */
{
tmp_731858 = genfunc_tmp_902207();
goto next_tmp_902231;
next_tmp_902231:
goto tmp_902230;
tmp_902230:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_902259;
fail_tmp_902228:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_902251 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_902251))
field_imm = inv_maskmask(8, tmp_902251);
else goto fail_tmp_902250;
}
/* commit */
{
tmp_731075 = genfunc_tmp_902207();
goto next_tmp_902253;
next_tmp_902253:
goto tmp_902252;
tmp_902252:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_902259;
fail_tmp_902250:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_902207();
goto next_tmp_902257;
next_tmp_902257:
goto tmp_902256;
tmp_902256:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_902259:
return tmp_731862;
}
reg_t genfunc_tmp_902207 (void) {
reg_t tmp_731876;
/* ADDQ_IMM */
{
word_5 tmp_731893;
word_5 field_rc;
word_5 tmp_731894;
word_5 field_ra;
word_64 tmp_731896;
word_8 field_imm;
tmp_731896 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_902192 = tmp_731896;
if ((tmp_902192 >> 8) == 0)
field_imm = tmp_902192;
else goto fail_tmp_902191;
}
/* commit */
tmp_731894 = ref_gpr_reg_for_reading(0 + rm);
tmp_731893 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731893;
field_ra = tmp_731894;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731894);
/* can fail: T   num insns: 1 */
}
goto done_tmp_902206;
fail_tmp_902191:
/* LDA */
{
word_5 tmp_731397;
word_5 field_ra;
word_5 tmp_731398;
word_5 field_rb;
word_64 tmp_731400;
word_16 field_memory_disp;
tmp_731400 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_902200 = tmp_731400;
if ((tmp_902200 >> 16) == 0xFFFFFFFFFFFF || (tmp_902200 >> 16) == 0)
field_memory_disp = (tmp_902200 & 0xFFFF);
else goto fail_tmp_902199;
}
/* commit */
tmp_731398 = ref_gpr_reg_for_reading(0 + rm);
tmp_731397 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731397;
field_rb = tmp_731398;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731398);
/* can fail: T   num insns: 1 */
}
goto done_tmp_902206;
fail_tmp_902199:
/* LDAH */
{
word_5 tmp_731393;
word_5 field_ra;
word_5 tmp_731394;
word_5 field_rb;
word_64 tmp_731396;
word_16 field_memory_disp;
tmp_731396 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_902204 = tmp_731396;
if ((tmp_902204 & 0xFFFF) == 0)
{
word_64 tmp_902205 = (tmp_902204 >> 16);
if ((tmp_902205 >> 16) == 0xFFFFFFFFFFFF || (tmp_902205 >> 16) == 0)
field_memory_disp = (tmp_902205 & 0xFFFF);
else goto fail_tmp_902203;
}
else goto fail_tmp_902203;
}
/* commit */
tmp_731394 = ref_gpr_reg_for_reading(0 + rm);
tmp_731393 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731393;
field_rb = tmp_731394;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731394);
/* can fail: T   num insns: 1 */
}
goto done_tmp_902206;
fail_tmp_902203:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731900 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731900, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_902206:
return tmp_731876;
}
void genfunc_tmp_902158 (void) {
/* STL */
{
word_5 field_rb;
word_64 tmp_731143;
word_16 field_memory_disp;
word_5 tmp_731145;
word_5 field_ra;
tmp_731143 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_902153 = tmp_731143;
if ((tmp_902153 >> 16) == 0xFFFFFFFFFFFF || (tmp_902153 >> 16) == 0)
field_memory_disp = (tmp_902153 & 0xFFFF);
else goto fail_tmp_902152;
}
/* commit */
{
tmp_731145 = genfunc_tmp_902150();
goto next_tmp_902155;
next_tmp_902155:
goto tmp_902154;
tmp_902154:
}
field_ra = tmp_731145;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731145);
/* can fail: T   num insns: 5 */
}
goto done_tmp_902157;
fail_tmp_902152:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
tmp_731142 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731142, ((word_64)disp32));
{
tmp_731146 = genfunc_tmp_902150();
goto next_tmp_901902;
next_tmp_901902:
goto tmp_901901;
tmp_901901:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_902157:
}
reg_t genfunc_tmp_902150 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_902073;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_901772();
goto next_tmp_902075;
next_tmp_902075:
goto tmp_902074;
tmp_902074:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 3 */
}
goto done_tmp_902149;
fail_tmp_902073:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_902078 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_902078 >> 8) == 0)
field_imm = tmp_902078;
else goto fail_tmp_902077;
}
/* commit */
{
tmp_731665 = genfunc_tmp_901772();
goto next_tmp_902080;
next_tmp_902080:
goto tmp_902079;
tmp_902079:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 3 */
}
goto done_tmp_902149;
fail_tmp_902077:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_902140;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_901772();
goto next_tmp_902142;
next_tmp_902142:
goto tmp_902141;
tmp_902141:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 3 */
}
goto done_tmp_902149;
fail_tmp_902140:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_902145 = tmp_731085;
if ((tmp_902145 >> 8) == 0)
field_imm = tmp_902145;
else goto fail_tmp_902144;
}
/* commit */
{
tmp_731083 = genfunc_tmp_901772();
goto next_tmp_902147;
next_tmp_902147:
goto tmp_902146;
tmp_902146:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 3 */
}
goto done_tmp_902149;
fail_tmp_902144:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_901772();
goto next_tmp_902138;
next_tmp_902138:
goto tmp_902137;
tmp_902137:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 4 */
}
done_tmp_902149:
return tmp_731146;
}
void genfunc_tmp_901896 (void) {
/* STL */
{
word_5 field_rb;
word_64 tmp_731143;
word_16 field_memory_disp;
word_5 tmp_731145;
word_5 field_ra;
tmp_731143 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_901891 = tmp_731143;
if ((tmp_901891 >> 16) == 0xFFFFFFFFFFFF || (tmp_901891 >> 16) == 0)
field_memory_disp = (tmp_901891 & 0xFFFF);
else goto fail_tmp_901890;
}
/* commit */
{
tmp_731145 = genfunc_tmp_901888();
goto next_tmp_901893;
next_tmp_901893:
goto tmp_901892;
tmp_901892:
}
field_ra = tmp_731145;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731145);
/* can fail: T   num insns: 3 */
}
goto done_tmp_901895;
fail_tmp_901890:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
tmp_731142 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731142, ((word_64)disp32));
{
tmp_731146 = genfunc_tmp_901888();
goto next_tmp_901732;
next_tmp_901732:
goto tmp_901731;
tmp_901731:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_901895:
}
reg_t genfunc_tmp_901888 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_731383;
word_16 field_memory_disp;
tmp_731383 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_901866 = tmp_731383;
if ((tmp_901866 >> 16) == 0xFFFFFFFFFFFF || (tmp_901866 >> 16) == 0)
field_memory_disp = (tmp_901866 & 0xFFFF);
else goto fail_tmp_901865;
}
/* commit */
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_901887;
fail_tmp_901865:
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
tmp_731382 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731382, ((word_64)disp32));
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_901887:
return tmp_731146;
}
reg_t genfunc_tmp_901841 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_901810 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_901810 >> 8) == 0)
field_imm = tmp_901810;
else goto fail_tmp_901809;
}
/* commit */
{
tmp_731858 = genfunc_tmp_901772();
goto next_tmp_901812;
next_tmp_901812:
goto tmp_901811;
tmp_901811:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_901840;
fail_tmp_901809:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_901832 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_901832))
field_imm = inv_maskmask(8, tmp_901832);
else goto fail_tmp_901831;
}
/* commit */
{
tmp_731075 = genfunc_tmp_901772();
goto next_tmp_901834;
next_tmp_901834:
goto tmp_901833;
tmp_901833:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_901840;
fail_tmp_901831:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_901772();
goto next_tmp_901838;
next_tmp_901838:
goto tmp_901837;
tmp_901837:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_901840:
return tmp_731862;
}
reg_t genfunc_tmp_901772 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_731383;
word_16 field_memory_disp;
tmp_731383 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_901770 = tmp_731383;
if ((tmp_901770 >> 16) == 0xFFFFFFFFFFFF || (tmp_901770 >> 16) == 0)
field_memory_disp = (tmp_901770 & 0xFFFF);
else goto fail_tmp_901769;
}
/* commit */
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_901771;
fail_tmp_901769:
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
tmp_731382 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731382, ((word_64)disp32));
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_901771:
return tmp_731898;
}
void genfunc_tmp_901726 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_901302();
goto next_tmp_901472;
next_tmp_901472:
goto tmp_901471;
tmp_901471:
}
{
tmp_731146 = genfunc_tmp_901723();
goto next_tmp_901475;
next_tmp_901475:
goto tmp_901474;
tmp_901474:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_901725:
}
reg_t genfunc_tmp_901723 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_901646;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_901346();
goto next_tmp_901648;
next_tmp_901648:
goto tmp_901647;
tmp_901647:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 6 */
}
goto done_tmp_901722;
fail_tmp_901646:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_901651 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_901651 >> 8) == 0)
field_imm = tmp_901651;
else goto fail_tmp_901650;
}
/* commit */
{
tmp_731665 = genfunc_tmp_901346();
goto next_tmp_901653;
next_tmp_901653:
goto tmp_901652;
tmp_901652:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 6 */
}
goto done_tmp_901722;
fail_tmp_901650:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_901713;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_901346();
goto next_tmp_901715;
next_tmp_901715:
goto tmp_901714;
tmp_901714:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 6 */
}
goto done_tmp_901722;
fail_tmp_901713:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_901718 = tmp_731085;
if ((tmp_901718 >> 8) == 0)
field_imm = tmp_901718;
else goto fail_tmp_901717;
}
/* commit */
{
tmp_731083 = genfunc_tmp_901346();
goto next_tmp_901720;
next_tmp_901720:
goto tmp_901719;
tmp_901719:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 6 */
}
goto done_tmp_901722;
fail_tmp_901717:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_901346();
goto next_tmp_901711;
next_tmp_901711:
goto tmp_901710;
tmp_901710:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_901722:
return tmp_731146;
}
void genfunc_tmp_901466 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_901302();
goto next_tmp_901172;
next_tmp_901172:
goto tmp_901171;
tmp_901171:
}
{
tmp_731146 = genfunc_tmp_901463();
goto next_tmp_901305;
next_tmp_901305:
goto tmp_901304;
tmp_901304:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_901465:
}
reg_t genfunc_tmp_901463 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_901302();
goto next_tmp_901440;
next_tmp_901440:
goto tmp_901439;
tmp_901439:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_901462:
return tmp_731146;
}
reg_t genfunc_tmp_901415 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_901384 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_901384 >> 8) == 0)
field_imm = tmp_901384;
else goto fail_tmp_901383;
}
/* commit */
{
tmp_731858 = genfunc_tmp_901346();
goto next_tmp_901386;
next_tmp_901386:
goto tmp_901385;
tmp_901385:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 6 */
}
goto done_tmp_901414;
fail_tmp_901383:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_901406 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_901406))
field_imm = inv_maskmask(8, tmp_901406);
else goto fail_tmp_901405;
}
/* commit */
{
tmp_731075 = genfunc_tmp_901346();
goto next_tmp_901408;
next_tmp_901408:
goto tmp_901407;
tmp_901407:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 6 */
}
goto done_tmp_901414;
fail_tmp_901405:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_901346();
goto next_tmp_901412;
next_tmp_901412:
goto tmp_901411;
tmp_901411:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 6 */
}
done_tmp_901414:
return tmp_731862;
}
reg_t genfunc_tmp_901346 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_901302();
goto next_tmp_901343;
next_tmp_901343:
goto tmp_901342;
tmp_901342:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_901345:
return tmp_731898;
}
reg_t genfunc_tmp_901302 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_901269 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_901269 >> 8) == 0)
field_imm = tmp_901269;
else goto fail_tmp_901268;
}
/* commit */
{
tmp_731858 = genfunc_tmp_901213();
goto next_tmp_901271;
next_tmp_901271:
goto tmp_901270;
tmp_901270:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_901301;
fail_tmp_901268:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_901293 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_901293))
field_imm = inv_maskmask(8, tmp_901293);
else goto fail_tmp_901292;
}
/* commit */
{
tmp_731075 = genfunc_tmp_901213();
goto next_tmp_901295;
next_tmp_901295:
goto tmp_901294;
tmp_901294:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_901301;
fail_tmp_901292:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_901213();
goto next_tmp_901299;
next_tmp_901299:
goto tmp_901298;
tmp_901298:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_901301:
return tmp_731142;
}
reg_t genfunc_tmp_901266 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_901235 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_901235 >> 8) == 0)
field_imm = tmp_901235;
else goto fail_tmp_901234;
}
/* commit */
{
tmp_731858 = genfunc_tmp_901213();
goto next_tmp_901237;
next_tmp_901237:
goto tmp_901236;
tmp_901236:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_901265;
fail_tmp_901234:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_901257 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_901257))
field_imm = inv_maskmask(8, tmp_901257);
else goto fail_tmp_901256;
}
/* commit */
{
tmp_731075 = genfunc_tmp_901213();
goto next_tmp_901259;
next_tmp_901259:
goto tmp_901258;
tmp_901258:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_901265;
fail_tmp_901256:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_901213();
goto next_tmp_901263;
next_tmp_901263:
goto tmp_901262;
tmp_901262:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_901265:
return tmp_731862;
}
reg_t genfunc_tmp_901213 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_901204;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_899579();
goto next_tmp_901206;
next_tmp_901206:
goto tmp_901205;
tmp_901205:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_901212;
fail_tmp_901204:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_901208;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_899579();
goto next_tmp_901210;
next_tmp_901210:
goto tmp_901209;
tmp_901209:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_901212;
fail_tmp_901208:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_899579();
goto next_tmp_901188;
next_tmp_901188:
goto tmp_901187;
tmp_901187:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_901212:
return tmp_731876;
}
void genfunc_tmp_901166 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_900742();
goto next_tmp_900912;
next_tmp_900912:
goto tmp_900911;
tmp_900911:
}
{
tmp_731146 = genfunc_tmp_901163();
goto next_tmp_900915;
next_tmp_900915:
goto tmp_900914;
tmp_900914:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_901165:
}
reg_t genfunc_tmp_901163 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_901086;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_900786();
goto next_tmp_901088;
next_tmp_901088:
goto tmp_901087;
tmp_901087:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_901162;
fail_tmp_901086:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_901091 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_901091 >> 8) == 0)
field_imm = tmp_901091;
else goto fail_tmp_901090;
}
/* commit */
{
tmp_731665 = genfunc_tmp_900786();
goto next_tmp_901093;
next_tmp_901093:
goto tmp_901092;
tmp_901092:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_901162;
fail_tmp_901090:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_901153;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_900786();
goto next_tmp_901155;
next_tmp_901155:
goto tmp_901154;
tmp_901154:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_901162;
fail_tmp_901153:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_901158 = tmp_731085;
if ((tmp_901158 >> 8) == 0)
field_imm = tmp_901158;
else goto fail_tmp_901157;
}
/* commit */
{
tmp_731083 = genfunc_tmp_900786();
goto next_tmp_901160;
next_tmp_901160:
goto tmp_901159;
tmp_901159:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_901162;
fail_tmp_901157:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_900786();
goto next_tmp_901151;
next_tmp_901151:
goto tmp_901150;
tmp_901150:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_901162:
return tmp_731146;
}
void genfunc_tmp_900906 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_900742();
goto next_tmp_900621;
next_tmp_900621:
goto tmp_900620;
tmp_900620:
}
{
tmp_731146 = genfunc_tmp_900903();
goto next_tmp_900745;
next_tmp_900745:
goto tmp_900744;
tmp_900744:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_900905:
}
reg_t genfunc_tmp_900903 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_900742();
goto next_tmp_900880;
next_tmp_900880:
goto tmp_900879;
tmp_900879:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_900902:
return tmp_731146;
}
reg_t genfunc_tmp_900855 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_900824 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_900824 >> 8) == 0)
field_imm = tmp_900824;
else goto fail_tmp_900823;
}
/* commit */
{
tmp_731858 = genfunc_tmp_900786();
goto next_tmp_900826;
next_tmp_900826:
goto tmp_900825;
tmp_900825:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_900854;
fail_tmp_900823:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_900846 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_900846))
field_imm = inv_maskmask(8, tmp_900846);
else goto fail_tmp_900845;
}
/* commit */
{
tmp_731075 = genfunc_tmp_900786();
goto next_tmp_900848;
next_tmp_900848:
goto tmp_900847;
tmp_900847:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_900854;
fail_tmp_900845:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_900786();
goto next_tmp_900852;
next_tmp_900852:
goto tmp_900851;
tmp_900851:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_900854:
return tmp_731862;
}
reg_t genfunc_tmp_900786 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_900742();
goto next_tmp_900783;
next_tmp_900783:
goto tmp_900782;
tmp_900782:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_900785:
return tmp_731898;
}
reg_t genfunc_tmp_900742 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_900709 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_900709 >> 8) == 0)
field_imm = tmp_900709;
else goto fail_tmp_900708;
}
/* commit */
{
tmp_731858 = genfunc_tmp_900653();
goto next_tmp_900711;
next_tmp_900711:
goto tmp_900710;
tmp_900710:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_900741;
fail_tmp_900708:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_900733 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_900733))
field_imm = inv_maskmask(8, tmp_900733);
else goto fail_tmp_900732;
}
/* commit */
{
tmp_731075 = genfunc_tmp_900653();
goto next_tmp_900735;
next_tmp_900735:
goto tmp_900734;
tmp_900734:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_900741;
fail_tmp_900732:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_900653();
goto next_tmp_900739;
next_tmp_900739:
goto tmp_900738;
tmp_900738:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_900741:
return tmp_731142;
}
reg_t genfunc_tmp_900706 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_900675 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_900675 >> 8) == 0)
field_imm = tmp_900675;
else goto fail_tmp_900674;
}
/* commit */
{
tmp_731858 = genfunc_tmp_900653();
goto next_tmp_900677;
next_tmp_900677:
goto tmp_900676;
tmp_900676:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_900705;
fail_tmp_900674:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_900697 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_900697))
field_imm = inv_maskmask(8, tmp_900697);
else goto fail_tmp_900696;
}
/* commit */
{
tmp_731075 = genfunc_tmp_900653();
goto next_tmp_900699;
next_tmp_900699:
goto tmp_900698;
tmp_900698:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_900705;
fail_tmp_900696:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_900653();
goto next_tmp_900703;
next_tmp_900703:
goto tmp_900702;
tmp_900702:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_900705:
return tmp_731862;
}
reg_t genfunc_tmp_900653 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_900650;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + index);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_900652;
fail_tmp_900650:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_900651;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + index);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_900652;
fail_tmp_900651:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_900652:
return tmp_731876;
}
void genfunc_tmp_900615 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_900191();
goto next_tmp_900361;
next_tmp_900361:
goto tmp_900360;
tmp_900360:
}
{
tmp_731146 = genfunc_tmp_900612();
goto next_tmp_900364;
next_tmp_900364:
goto tmp_900363;
tmp_900363:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_900614:
}
reg_t genfunc_tmp_900612 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_900535;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_900235();
goto next_tmp_900537;
next_tmp_900537:
goto tmp_900536;
tmp_900536:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 3 */
}
goto done_tmp_900611;
fail_tmp_900535:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_900540 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_900540 >> 8) == 0)
field_imm = tmp_900540;
else goto fail_tmp_900539;
}
/* commit */
{
tmp_731665 = genfunc_tmp_900235();
goto next_tmp_900542;
next_tmp_900542:
goto tmp_900541;
tmp_900541:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 3 */
}
goto done_tmp_900611;
fail_tmp_900539:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_900602;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_900235();
goto next_tmp_900604;
next_tmp_900604:
goto tmp_900603;
tmp_900603:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 3 */
}
goto done_tmp_900611;
fail_tmp_900602:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_900607 = tmp_731085;
if ((tmp_900607 >> 8) == 0)
field_imm = tmp_900607;
else goto fail_tmp_900606;
}
/* commit */
{
tmp_731083 = genfunc_tmp_900235();
goto next_tmp_900609;
next_tmp_900609:
goto tmp_900608;
tmp_900608:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 3 */
}
goto done_tmp_900611;
fail_tmp_900606:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_900235();
goto next_tmp_900600;
next_tmp_900600:
goto tmp_900599;
tmp_900599:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 4 */
}
done_tmp_900611:
return tmp_731146;
}
void genfunc_tmp_900355 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_900191();
goto next_tmp_900115;
next_tmp_900115:
goto tmp_900114;
tmp_900114:
}
{
tmp_731146 = genfunc_tmp_900352();
goto next_tmp_900194;
next_tmp_900194:
goto tmp_900193;
tmp_900193:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_900354:
}
reg_t genfunc_tmp_900352 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_900191();
goto next_tmp_900329;
next_tmp_900329:
goto tmp_900328;
tmp_900328:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_900351:
return tmp_731146;
}
reg_t genfunc_tmp_900304 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_900273 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_900273 >> 8) == 0)
field_imm = tmp_900273;
else goto fail_tmp_900272;
}
/* commit */
{
tmp_731858 = genfunc_tmp_900235();
goto next_tmp_900275;
next_tmp_900275:
goto tmp_900274;
tmp_900274:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_900303;
fail_tmp_900272:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_900295 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_900295))
field_imm = inv_maskmask(8, tmp_900295);
else goto fail_tmp_900294;
}
/* commit */
{
tmp_731075 = genfunc_tmp_900235();
goto next_tmp_900297;
next_tmp_900297:
goto tmp_900296;
tmp_900296:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_900303;
fail_tmp_900294:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_900235();
goto next_tmp_900301;
next_tmp_900301:
goto tmp_900300;
tmp_900300:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_900303:
return tmp_731862;
}
reg_t genfunc_tmp_900235 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_900191();
goto next_tmp_900232;
next_tmp_900232:
goto tmp_900231;
tmp_900231:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_900234:
return tmp_731898;
}
reg_t genfunc_tmp_900191 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_900167 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_900167 >> 8) == 0)
field_imm = tmp_900167;
else goto fail_tmp_900166;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + base);
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_900190;
fail_tmp_900166:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_900188 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_900188))
field_imm = inv_maskmask(8, tmp_900188);
else goto fail_tmp_900187;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + base);
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_900190;
fail_tmp_900187:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + base);
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_900190:
return tmp_731142;
}
reg_t genfunc_tmp_900164 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_900142 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_900142 >> 8) == 0)
field_imm = tmp_900142;
else goto fail_tmp_900141;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + base);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_900163;
fail_tmp_900141:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_900161 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_900161))
field_imm = inv_maskmask(8, tmp_900161);
else goto fail_tmp_900160;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + base);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_900163;
fail_tmp_900160:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + base);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_900163:
return tmp_731862;
}
void genfunc_tmp_900109 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_899685();
goto next_tmp_899855;
next_tmp_899855:
goto tmp_899854;
tmp_899854:
}
{
tmp_731146 = genfunc_tmp_900106();
goto next_tmp_899858;
next_tmp_899858:
goto tmp_899857;
tmp_899857:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_900108:
}
reg_t genfunc_tmp_900106 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_900029;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_899729();
goto next_tmp_900031;
next_tmp_900031:
goto tmp_900030;
tmp_900030:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_900105;
fail_tmp_900029:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_900034 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_900034 >> 8) == 0)
field_imm = tmp_900034;
else goto fail_tmp_900033;
}
/* commit */
{
tmp_731665 = genfunc_tmp_899729();
goto next_tmp_900036;
next_tmp_900036:
goto tmp_900035;
tmp_900035:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_900105;
fail_tmp_900033:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_900096;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_899729();
goto next_tmp_900098;
next_tmp_900098:
goto tmp_900097;
tmp_900097:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_900105;
fail_tmp_900096:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_900101 = tmp_731085;
if ((tmp_900101 >> 8) == 0)
field_imm = tmp_900101;
else goto fail_tmp_900100;
}
/* commit */
{
tmp_731083 = genfunc_tmp_899729();
goto next_tmp_900103;
next_tmp_900103:
goto tmp_900102;
tmp_900102:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_900105;
fail_tmp_900100:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_899729();
goto next_tmp_900094;
next_tmp_900094:
goto tmp_900093;
tmp_900093:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_900105:
return tmp_731146;
}
void genfunc_tmp_899849 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_899685();
goto next_tmp_899531;
next_tmp_899531:
goto tmp_899530;
tmp_899530:
}
{
tmp_731146 = genfunc_tmp_899846();
goto next_tmp_899688;
next_tmp_899688:
goto tmp_899687;
tmp_899687:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_899848:
}
reg_t genfunc_tmp_899846 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_899685();
goto next_tmp_899823;
next_tmp_899823:
goto tmp_899822;
tmp_899822:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_899845:
return tmp_731146;
}
reg_t genfunc_tmp_899798 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_899767 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_899767 >> 8) == 0)
field_imm = tmp_899767;
else goto fail_tmp_899766;
}
/* commit */
{
tmp_731858 = genfunc_tmp_899729();
goto next_tmp_899769;
next_tmp_899769:
goto tmp_899768;
tmp_899768:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_899797;
fail_tmp_899766:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_899789 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_899789))
field_imm = inv_maskmask(8, tmp_899789);
else goto fail_tmp_899788;
}
/* commit */
{
tmp_731075 = genfunc_tmp_899729();
goto next_tmp_899791;
next_tmp_899791:
goto tmp_899790;
tmp_899790:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_899797;
fail_tmp_899788:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_899729();
goto next_tmp_899795;
next_tmp_899795:
goto tmp_899794;
tmp_899794:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_899797:
return tmp_731862;
}
reg_t genfunc_tmp_899729 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_899685();
goto next_tmp_899726;
next_tmp_899726:
goto tmp_899725;
tmp_899725:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_899728:
return tmp_731898;
}
reg_t genfunc_tmp_899685 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_899652 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_899652 >> 8) == 0)
field_imm = tmp_899652;
else goto fail_tmp_899651;
}
/* commit */
{
tmp_731858 = genfunc_tmp_899596();
goto next_tmp_899654;
next_tmp_899654:
goto tmp_899653;
tmp_899653:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_899684;
fail_tmp_899651:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_899676 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_899676))
field_imm = inv_maskmask(8, tmp_899676);
else goto fail_tmp_899675;
}
/* commit */
{
tmp_731075 = genfunc_tmp_899596();
goto next_tmp_899678;
next_tmp_899678:
goto tmp_899677;
tmp_899677:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_899684;
fail_tmp_899675:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_899596();
goto next_tmp_899682;
next_tmp_899682:
goto tmp_899681;
tmp_899681:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_899684:
return tmp_731142;
}
reg_t genfunc_tmp_899649 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_899618 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_899618 >> 8) == 0)
field_imm = tmp_899618;
else goto fail_tmp_899617;
}
/* commit */
{
tmp_731858 = genfunc_tmp_899596();
goto next_tmp_899620;
next_tmp_899620:
goto tmp_899619;
tmp_899619:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_899648;
fail_tmp_899617:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_899640 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_899640))
field_imm = inv_maskmask(8, tmp_899640);
else goto fail_tmp_899639;
}
/* commit */
{
tmp_731075 = genfunc_tmp_899596();
goto next_tmp_899642;
next_tmp_899642:
goto tmp_899641;
tmp_899641:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_899648;
fail_tmp_899639:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_899596();
goto next_tmp_899646;
next_tmp_899646:
goto tmp_899645;
tmp_899645:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_899648:
return tmp_731862;
}
reg_t genfunc_tmp_899596 (void) {
reg_t tmp_731876;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + base);
{
tmp_731900 = genfunc_tmp_899579();
goto next_tmp_899547;
next_tmp_899547:
goto tmp_899546;
tmp_899546:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_899595:
return tmp_731876;
}
reg_t genfunc_tmp_899579 (void) {
reg_t tmp_731900;
/* EXTQH */
{
word_5 tmp_731618;
word_5 field_rc;
word_5 tmp_731619;
word_5 field_ra;
word_5 field_rb;
if (64 != ((word_64)scale)) goto fail_tmp_899560;
field_rb = 31;
/* commit */
tmp_731619 = ref_gpr_reg_for_reading(0 + index);
tmp_731618 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731618;
field_ra = tmp_731619;
emit(COMPOSE_EXTQH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731619);
/* can fail: T   num insns: 1 */
}
goto done_tmp_899578;
fail_tmp_899560:
/* EXTQH_IMM */
{
word_5 tmp_731614;
word_5 field_rc;
word_5 tmp_731615;
word_5 field_ra;
word_64 tmp_731617;
word_8 field_imm;
tmp_731617 = ((word_64)scale);
{
word_64 tmp_899562 = ((64 - tmp_731617) & 0xFFFFFFFFFFFFFFFF);
if (tmp_899562 % 8 == 0)
{
word_64 tmp_899563 = (tmp_899562 / 8);
if ((tmp_899563 & 7) == tmp_899563)
{
word_64 tmp_899564 = tmp_899563;
if ((tmp_899564 >> 8) == 0)
field_imm = tmp_899564;
else goto fail_tmp_899561;
}
else goto fail_tmp_899561;
}
else goto fail_tmp_899561;
}
/* commit */
tmp_731615 = ref_gpr_reg_for_reading(0 + index);
tmp_731614 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731614;
field_ra = tmp_731615;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731615);
/* can fail: T   num insns: 1 */
}
goto done_tmp_899578;
fail_tmp_899561:
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 tmp_731241;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_899570;
field_rb = 31;
/* commit */
tmp_731241 = ref_gpr_reg_for_reading(0 + index);
tmp_731240 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_ra = tmp_731241;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731241);
/* can fail: T   num insns: 1 */
}
goto done_tmp_899578;
fail_tmp_899570:
/* S4ADDQ_IMM */
{
word_5 tmp_731236;
word_5 field_rc;
word_5 tmp_731237;
word_5 field_ra;
word_64 tmp_731239;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_899571;
tmp_731239 = 0;
field_imm = 0;
/* commit */
tmp_731237 = ref_gpr_reg_for_reading(0 + index);
tmp_731236 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731236;
field_ra = tmp_731237;
emit(COMPOSE_S4ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731237);
/* can fail: T   num insns: 1 */
}
goto done_tmp_899578;
fail_tmp_899571:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 tmp_731209;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_899573;
field_rb = 31;
/* commit */
tmp_731209 = ref_gpr_reg_for_reading(0 + index);
tmp_731208 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_ra = tmp_731209;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731209);
/* can fail: T   num insns: 1 */
}
goto done_tmp_899578;
fail_tmp_899573:
/* S8ADDQ_IMM */
{
word_5 tmp_731204;
word_5 field_rc;
word_5 tmp_731205;
word_5 field_ra;
word_64 tmp_731207;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_899574;
tmp_731207 = 0;
field_imm = 0;
/* commit */
tmp_731205 = ref_gpr_reg_for_reading(0 + index);
tmp_731204 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731204;
field_ra = tmp_731205;
emit(COMPOSE_S8ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731205);
/* can fail: T   num insns: 1 */
}
goto done_tmp_899578;
fail_tmp_899574:
/* SLL */
{
word_5 tmp_731176;
word_5 field_rc;
word_5 tmp_731177;
word_5 field_ra;
word_5 field_rb;
if (0 != ((word_64)scale)) goto fail_tmp_899575;
field_rb = 31;
/* commit */
tmp_731177 = ref_gpr_reg_for_reading(0 + index);
tmp_731176 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731176;
field_ra = tmp_731177;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731177);
/* can fail: T   num insns: 1 */
}
goto done_tmp_899578;
fail_tmp_899575:
/* SLL_IMM */
{
word_5 tmp_731172;
word_5 field_rc;
word_5 tmp_731173;
word_5 field_ra;
word_64 tmp_731175;
word_8 field_imm;
tmp_731175 = ((word_64)scale);
field_imm = tmp_731175;
/* commit */
tmp_731173 = ref_gpr_reg_for_reading(0 + index);
tmp_731172 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731172;
field_ra = tmp_731173;
emit(COMPOSE_SLL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731173);
/* can fail: NIL   num insns: 1 */
}
done_tmp_899578:
return tmp_731900;
}
void genfunc_tmp_899525 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_899101();
goto next_tmp_899271;
next_tmp_899271:
goto tmp_899270;
tmp_899270:
}
{
tmp_731146 = genfunc_tmp_899522();
goto next_tmp_899274;
next_tmp_899274:
goto tmp_899273;
tmp_899273:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_899524:
}
reg_t genfunc_tmp_899522 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_899445;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_899145();
goto next_tmp_899447;
next_tmp_899447:
goto tmp_899446;
tmp_899446:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 4 */
}
goto done_tmp_899521;
fail_tmp_899445:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_899450 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_899450 >> 8) == 0)
field_imm = tmp_899450;
else goto fail_tmp_899449;
}
/* commit */
{
tmp_731665 = genfunc_tmp_899145();
goto next_tmp_899452;
next_tmp_899452:
goto tmp_899451;
tmp_899451:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 4 */
}
goto done_tmp_899521;
fail_tmp_899449:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_899512;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_899145();
goto next_tmp_899514;
next_tmp_899514:
goto tmp_899513;
tmp_899513:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 4 */
}
goto done_tmp_899521;
fail_tmp_899512:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_899517 = tmp_731085;
if ((tmp_899517 >> 8) == 0)
field_imm = tmp_899517;
else goto fail_tmp_899516;
}
/* commit */
{
tmp_731083 = genfunc_tmp_899145();
goto next_tmp_899519;
next_tmp_899519:
goto tmp_899518;
tmp_899518:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 4 */
}
goto done_tmp_899521;
fail_tmp_899516:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_899145();
goto next_tmp_899510;
next_tmp_899510:
goto tmp_899509;
tmp_899509:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_899521:
return tmp_731146;
}
void genfunc_tmp_899265 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_899101();
goto next_tmp_898982;
next_tmp_898982:
goto tmp_898981;
tmp_898981:
}
{
tmp_731146 = genfunc_tmp_899262();
goto next_tmp_899104;
next_tmp_899104:
goto tmp_899103;
tmp_899103:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_899264:
}
reg_t genfunc_tmp_899262 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_899101();
goto next_tmp_899239;
next_tmp_899239:
goto tmp_899238;
tmp_899238:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 3 */
}
done_tmp_899261:
return tmp_731146;
}
reg_t genfunc_tmp_899214 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_899183 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_899183 >> 8) == 0)
field_imm = tmp_899183;
else goto fail_tmp_899182;
}
/* commit */
{
tmp_731858 = genfunc_tmp_899145();
goto next_tmp_899185;
next_tmp_899185:
goto tmp_899184;
tmp_899184:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_899213;
fail_tmp_899182:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_899205 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_899205))
field_imm = inv_maskmask(8, tmp_899205);
else goto fail_tmp_899204;
}
/* commit */
{
tmp_731075 = genfunc_tmp_899145();
goto next_tmp_899207;
next_tmp_899207:
goto tmp_899206;
tmp_899206:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_899213;
fail_tmp_899204:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_899145();
goto next_tmp_899211;
next_tmp_899211:
goto tmp_899210;
tmp_899210:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_899213:
return tmp_731862;
}
reg_t genfunc_tmp_899145 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_899101();
goto next_tmp_899142;
next_tmp_899142:
goto tmp_899141;
tmp_899141:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 3 */
}
done_tmp_899144:
return tmp_731898;
}
reg_t genfunc_tmp_899101 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_899068 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_899068 >> 8) == 0)
field_imm = tmp_899068;
else goto fail_tmp_899067;
}
/* commit */
{
tmp_731858 = genfunc_tmp_899012();
goto next_tmp_899070;
next_tmp_899070:
goto tmp_899069;
tmp_899069:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_899100;
fail_tmp_899067:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_899092 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_899092))
field_imm = inv_maskmask(8, tmp_899092);
else goto fail_tmp_899091;
}
/* commit */
{
tmp_731075 = genfunc_tmp_899012();
goto next_tmp_899094;
next_tmp_899094:
goto tmp_899093;
tmp_899093:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_899100;
fail_tmp_899091:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_899012();
goto next_tmp_899098;
next_tmp_899098:
goto tmp_899097;
tmp_899097:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_899100:
return tmp_731142;
}
reg_t genfunc_tmp_899065 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_899034 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_899034 >> 8) == 0)
field_imm = tmp_899034;
else goto fail_tmp_899033;
}
/* commit */
{
tmp_731858 = genfunc_tmp_899012();
goto next_tmp_899036;
next_tmp_899036:
goto tmp_899035;
tmp_899035:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_899064;
fail_tmp_899033:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_899056 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_899056))
field_imm = inv_maskmask(8, tmp_899056);
else goto fail_tmp_899055;
}
/* commit */
{
tmp_731075 = genfunc_tmp_899012();
goto next_tmp_899058;
next_tmp_899058:
goto tmp_899057;
tmp_899057:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_899064;
fail_tmp_899055:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_899012();
goto next_tmp_899062;
next_tmp_899062:
goto tmp_899061;
tmp_899061:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_899064:
return tmp_731862;
}
reg_t genfunc_tmp_899012 (void) {
reg_t tmp_731876;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + base);
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_899011:
return tmp_731876;
}
void genfunc_tmp_898976 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_898552();
goto next_tmp_898722;
next_tmp_898722:
goto tmp_898721;
tmp_898721:
}
{
tmp_731146 = genfunc_tmp_898973();
goto next_tmp_898725;
next_tmp_898725:
goto tmp_898724;
tmp_898724:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_898975:
}
reg_t genfunc_tmp_898973 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_898896;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_898596();
goto next_tmp_898898;
next_tmp_898898:
goto tmp_898897;
tmp_898897:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 3 */
}
goto done_tmp_898972;
fail_tmp_898896:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_898901 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_898901 >> 8) == 0)
field_imm = tmp_898901;
else goto fail_tmp_898900;
}
/* commit */
{
tmp_731665 = genfunc_tmp_898596();
goto next_tmp_898903;
next_tmp_898903:
goto tmp_898902;
tmp_898902:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 3 */
}
goto done_tmp_898972;
fail_tmp_898900:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_898963;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_898596();
goto next_tmp_898965;
next_tmp_898965:
goto tmp_898964;
tmp_898964:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 3 */
}
goto done_tmp_898972;
fail_tmp_898963:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_898968 = tmp_731085;
if ((tmp_898968 >> 8) == 0)
field_imm = tmp_898968;
else goto fail_tmp_898967;
}
/* commit */
{
tmp_731083 = genfunc_tmp_898596();
goto next_tmp_898970;
next_tmp_898970:
goto tmp_898969;
tmp_898969:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 3 */
}
goto done_tmp_898972;
fail_tmp_898967:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_898596();
goto next_tmp_898961;
next_tmp_898961:
goto tmp_898960;
tmp_898960:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 4 */
}
done_tmp_898972:
return tmp_731146;
}
void genfunc_tmp_898716 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_898552();
goto next_tmp_898476;
next_tmp_898476:
goto tmp_898475;
tmp_898475:
}
{
tmp_731146 = genfunc_tmp_898713();
goto next_tmp_898555;
next_tmp_898555:
goto tmp_898554;
tmp_898554:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_898715:
}
reg_t genfunc_tmp_898713 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_898552();
goto next_tmp_898690;
next_tmp_898690:
goto tmp_898689;
tmp_898689:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_898712:
return tmp_731146;
}
reg_t genfunc_tmp_898665 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_898634 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_898634 >> 8) == 0)
field_imm = tmp_898634;
else goto fail_tmp_898633;
}
/* commit */
{
tmp_731858 = genfunc_tmp_898596();
goto next_tmp_898636;
next_tmp_898636:
goto tmp_898635;
tmp_898635:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_898664;
fail_tmp_898633:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_898656 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_898656))
field_imm = inv_maskmask(8, tmp_898656);
else goto fail_tmp_898655;
}
/* commit */
{
tmp_731075 = genfunc_tmp_898596();
goto next_tmp_898658;
next_tmp_898658:
goto tmp_898657;
tmp_898657:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_898664;
fail_tmp_898655:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_898596();
goto next_tmp_898662;
next_tmp_898662:
goto tmp_898661;
tmp_898661:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_898664:
return tmp_731862;
}
reg_t genfunc_tmp_898596 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_898552();
goto next_tmp_898593;
next_tmp_898593:
goto tmp_898592;
tmp_898592:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_898595:
return tmp_731898;
}
reg_t genfunc_tmp_898552 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_898528 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_898528 >> 8) == 0)
field_imm = tmp_898528;
else goto fail_tmp_898527;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + rm);
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898551;
fail_tmp_898527:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_898549 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_898549))
field_imm = inv_maskmask(8, tmp_898549);
else goto fail_tmp_898548;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + rm);
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898551;
fail_tmp_898548:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + rm);
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_898551:
return tmp_731142;
}
reg_t genfunc_tmp_898525 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_898503 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_898503 >> 8) == 0)
field_imm = tmp_898503;
else goto fail_tmp_898502;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + rm);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898524;
fail_tmp_898502:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_898522 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_898522))
field_imm = inv_maskmask(8, tmp_898522);
else goto fail_tmp_898521;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + rm);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898524;
fail_tmp_898521:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + rm);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_898524:
return tmp_731862;
}
