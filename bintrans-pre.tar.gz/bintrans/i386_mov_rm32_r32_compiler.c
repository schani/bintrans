#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compile_mov_rm32_r32_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_876888();
goto next_tmp_876806;
next_tmp_876806:
goto finish_tmp_876805;
finish_tmp_876805:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_877016();
goto next_tmp_876891;
next_tmp_876891:
goto finish_tmp_876890;
finish_tmp_876890:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_877179();
goto next_tmp_877019;
next_tmp_877019:
goto finish_tmp_877018;
finish_tmp_877018:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_877264();
goto next_tmp_877182;
next_tmp_877182:
goto finish_tmp_877181;
finish_tmp_877181:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_877394();
goto next_tmp_877267;
next_tmp_877267:
goto finish_tmp_877266;
finish_tmp_877266:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_877533();
goto next_tmp_877397;
next_tmp_877397:
goto finish_tmp_877396;
finish_tmp_877396:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_877541();
goto next_tmp_877536;
next_tmp_877536:
goto finish_tmp_877535;
finish_tmp_877535:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; }))
{
genfunc_tmp_877541();
goto next_tmp_877544;
next_tmp_877544:
goto finish_tmp_877543;
finish_tmp_877543:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_877679();
goto next_tmp_877547;
next_tmp_877547:
goto finish_tmp_877546;
finish_tmp_877546:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_877818();
goto next_tmp_877682;
next_tmp_877682:
goto finish_tmp_877681;
finish_tmp_877681:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_877957();
goto next_tmp_877821;
next_tmp_877821:
goto finish_tmp_877820;
finish_tmp_877820:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_878087();
goto next_tmp_877960;
next_tmp_877960:
goto finish_tmp_877959;
finish_tmp_877959:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_878245();
goto next_tmp_878090;
next_tmp_878090:
goto finish_tmp_878089;
finish_tmp_878089:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_878406();
goto next_tmp_878248;
next_tmp_878248:
goto finish_tmp_878247;
finish_tmp_878247:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_878536();
goto next_tmp_878409;
next_tmp_878409:
goto finish_tmp_878408;
finish_tmp_878408:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_878671();
goto next_tmp_878539;
next_tmp_878539:
goto finish_tmp_878538;
finish_tmp_878538:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_878810();
goto next_tmp_878674;
next_tmp_878674:
goto finish_tmp_878673;
finish_tmp_878673:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_878949();
goto next_tmp_878813;
next_tmp_878813:
goto finish_tmp_878812;
finish_tmp_878812:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_879079();
goto next_tmp_878952;
next_tmp_878952:
goto finish_tmp_878951;
finish_tmp_878951:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_879218();
goto next_tmp_879082;
next_tmp_879082:
goto finish_tmp_879081;
finish_tmp_879081:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_879357();
goto next_tmp_879221;
next_tmp_879221:
goto finish_tmp_879220;
finish_tmp_879220:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_879487();
goto next_tmp_879360;
next_tmp_879360:
goto finish_tmp_879359;
finish_tmp_879359:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 3; }))
{
genfunc_tmp_879500();
goto next_tmp_879490;
next_tmp_879490:
goto finish_tmp_879489;
finish_tmp_879489:
}
}
void genfunc_tmp_879500 (void) {
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 field_rb;
field_rb = 31;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + reg);
tmp_731897 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731897;
field_ra = tmp_731898;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731897);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_879499:
}
void genfunc_tmp_879487 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_879484();
goto next_tmp_879363;
next_tmp_879363:
goto tmp_879362;
tmp_879362:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_879486:
}
reg_t genfunc_tmp_879484 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_879451 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_879451 >> 8) == 0)
field_imm = tmp_879451;
else goto fail_tmp_879450;
}
/* commit */
{
tmp_731858 = genfunc_tmp_879395();
goto next_tmp_879453;
next_tmp_879453:
goto tmp_879452;
tmp_879452:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_879483;
fail_tmp_879450:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_879475 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_879475))
field_imm = inv_maskmask(8, tmp_879475);
else goto fail_tmp_879474;
}
/* commit */
{
tmp_731075 = genfunc_tmp_879395();
goto next_tmp_879477;
next_tmp_879477:
goto tmp_879476;
tmp_879476:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_879483;
fail_tmp_879474:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_879395();
goto next_tmp_879481;
next_tmp_879481:
goto tmp_879480;
tmp_879480:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_879483:
return tmp_731142;
}
reg_t genfunc_tmp_879448 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_879417 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_879417 >> 8) == 0)
field_imm = tmp_879417;
else goto fail_tmp_879416;
}
/* commit */
{
tmp_731858 = genfunc_tmp_879395();
goto next_tmp_879419;
next_tmp_879419:
goto tmp_879418;
tmp_879418:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_879447;
fail_tmp_879416:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_879439 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_879439))
field_imm = inv_maskmask(8, tmp_879439);
else goto fail_tmp_879438;
}
/* commit */
{
tmp_731075 = genfunc_tmp_879395();
goto next_tmp_879441;
next_tmp_879441:
goto tmp_879440;
tmp_879440:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_879447;
fail_tmp_879438:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_879395();
goto next_tmp_879445;
next_tmp_879445:
goto tmp_879444;
tmp_879444:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_879447:
return tmp_731862;
}
reg_t genfunc_tmp_879395 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_879392;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + 5);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_879394;
fail_tmp_879392:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_879393;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + 5);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_879394;
fail_tmp_879393:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + 5);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_879394:
return tmp_731876;
}
void genfunc_tmp_879357 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_879354();
goto next_tmp_879224;
next_tmp_879224:
goto tmp_879223;
tmp_879223:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_879356:
}
reg_t genfunc_tmp_879354 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_879321 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_879321 >> 8) == 0)
field_imm = tmp_879321;
else goto fail_tmp_879320;
}
/* commit */
{
tmp_731858 = genfunc_tmp_879265();
goto next_tmp_879323;
next_tmp_879323:
goto tmp_879322;
tmp_879322:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_879353;
fail_tmp_879320:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_879345 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_879345))
field_imm = inv_maskmask(8, tmp_879345);
else goto fail_tmp_879344;
}
/* commit */
{
tmp_731075 = genfunc_tmp_879265();
goto next_tmp_879347;
next_tmp_879347:
goto tmp_879346;
tmp_879346:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_879353;
fail_tmp_879344:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_879265();
goto next_tmp_879351;
next_tmp_879351:
goto tmp_879350;
tmp_879350:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_879353:
return tmp_731142;
}
reg_t genfunc_tmp_879318 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_879287 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_879287 >> 8) == 0)
field_imm = tmp_879287;
else goto fail_tmp_879286;
}
/* commit */
{
tmp_731858 = genfunc_tmp_879265();
goto next_tmp_879289;
next_tmp_879289:
goto tmp_879288;
tmp_879288:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_879317;
fail_tmp_879286:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_879309 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_879309))
field_imm = inv_maskmask(8, tmp_879309);
else goto fail_tmp_879308;
}
/* commit */
{
tmp_731075 = genfunc_tmp_879265();
goto next_tmp_879311;
next_tmp_879311:
goto tmp_879310;
tmp_879310:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_879317;
fail_tmp_879308:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_879265();
goto next_tmp_879315;
next_tmp_879315:
goto tmp_879314;
tmp_879314:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_879317:
return tmp_731862;
}
reg_t genfunc_tmp_879265 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_879256;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_878289();
goto next_tmp_879258;
next_tmp_879258:
goto tmp_879257;
tmp_879257:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_879264;
fail_tmp_879256:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_879260;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_878289();
goto next_tmp_879262;
next_tmp_879262:
goto tmp_879261;
tmp_879261:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_879264;
fail_tmp_879260:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_878289();
goto next_tmp_879240;
next_tmp_879240:
goto tmp_879239;
tmp_879239:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_879264:
return tmp_731876;
}
void genfunc_tmp_879218 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_879215();
goto next_tmp_879085;
next_tmp_879085:
goto tmp_879084;
tmp_879084:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_879217:
}
reg_t genfunc_tmp_879215 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_879182 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_879182 >> 8) == 0)
field_imm = tmp_879182;
else goto fail_tmp_879181;
}
/* commit */
{
tmp_731858 = genfunc_tmp_879126();
goto next_tmp_879184;
next_tmp_879184:
goto tmp_879183;
tmp_879183:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_879214;
fail_tmp_879181:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_879206 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_879206))
field_imm = inv_maskmask(8, tmp_879206);
else goto fail_tmp_879205;
}
/* commit */
{
tmp_731075 = genfunc_tmp_879126();
goto next_tmp_879208;
next_tmp_879208:
goto tmp_879207;
tmp_879207:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_879214;
fail_tmp_879205:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_879126();
goto next_tmp_879212;
next_tmp_879212:
goto tmp_879211;
tmp_879211:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_879214:
return tmp_731142;
}
reg_t genfunc_tmp_879179 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_879148 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_879148 >> 8) == 0)
field_imm = tmp_879148;
else goto fail_tmp_879147;
}
/* commit */
{
tmp_731858 = genfunc_tmp_879126();
goto next_tmp_879150;
next_tmp_879150:
goto tmp_879149;
tmp_879149:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_879178;
fail_tmp_879147:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_879170 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_879170))
field_imm = inv_maskmask(8, tmp_879170);
else goto fail_tmp_879169;
}
/* commit */
{
tmp_731075 = genfunc_tmp_879126();
goto next_tmp_879172;
next_tmp_879172:
goto tmp_879171;
tmp_879171:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_879178;
fail_tmp_879169:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_879126();
goto next_tmp_879176;
next_tmp_879176:
goto tmp_879175;
tmp_879175:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_879178:
return tmp_731862;
}
reg_t genfunc_tmp_879126 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_879117;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_878128();
goto next_tmp_879119;
next_tmp_879119:
goto tmp_879118;
tmp_879118:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_879125;
fail_tmp_879117:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_879121;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_878128();
goto next_tmp_879123;
next_tmp_879123:
goto tmp_879122;
tmp_879122:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_879125;
fail_tmp_879121:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_878128();
goto next_tmp_879101;
next_tmp_879101:
goto tmp_879100;
tmp_879100:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_879125:
return tmp_731876;
}
void genfunc_tmp_879079 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_879076();
goto next_tmp_878955;
next_tmp_878955:
goto tmp_878954;
tmp_878954:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_879078:
}
reg_t genfunc_tmp_879076 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_879043 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_879043 >> 8) == 0)
field_imm = tmp_879043;
else goto fail_tmp_879042;
}
/* commit */
{
tmp_731858 = genfunc_tmp_878987();
goto next_tmp_879045;
next_tmp_879045:
goto tmp_879044;
tmp_879044:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_879075;
fail_tmp_879042:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_879067 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_879067))
field_imm = inv_maskmask(8, tmp_879067);
else goto fail_tmp_879066;
}
/* commit */
{
tmp_731075 = genfunc_tmp_878987();
goto next_tmp_879069;
next_tmp_879069:
goto tmp_879068;
tmp_879068:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_879075;
fail_tmp_879066:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_878987();
goto next_tmp_879073;
next_tmp_879073:
goto tmp_879072;
tmp_879072:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_879075:
return tmp_731142;
}
reg_t genfunc_tmp_879040 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_879009 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_879009 >> 8) == 0)
field_imm = tmp_879009;
else goto fail_tmp_879008;
}
/* commit */
{
tmp_731858 = genfunc_tmp_878987();
goto next_tmp_879011;
next_tmp_879011:
goto tmp_879010;
tmp_879010:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_879039;
fail_tmp_879008:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_879031 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_879031))
field_imm = inv_maskmask(8, tmp_879031);
else goto fail_tmp_879030;
}
/* commit */
{
tmp_731075 = genfunc_tmp_878987();
goto next_tmp_879033;
next_tmp_879033:
goto tmp_879032;
tmp_879032:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_879039;
fail_tmp_879030:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_878987();
goto next_tmp_879037;
next_tmp_879037:
goto tmp_879036;
tmp_879036:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_879039:
return tmp_731862;
}
reg_t genfunc_tmp_878987 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_878984;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + base);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_878986;
fail_tmp_878984:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_878985;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + base);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_878986;
fail_tmp_878985:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + base);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_878986:
return tmp_731876;
}
void genfunc_tmp_878949 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_878946();
goto next_tmp_878816;
next_tmp_878816:
goto tmp_878815;
tmp_878815:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_878948:
}
reg_t genfunc_tmp_878946 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_878913 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_878913 >> 8) == 0)
field_imm = tmp_878913;
else goto fail_tmp_878912;
}
/* commit */
{
tmp_731858 = genfunc_tmp_878857();
goto next_tmp_878915;
next_tmp_878915:
goto tmp_878914;
tmp_878914:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_878945;
fail_tmp_878912:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_878937 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_878937))
field_imm = inv_maskmask(8, tmp_878937);
else goto fail_tmp_878936;
}
/* commit */
{
tmp_731075 = genfunc_tmp_878857();
goto next_tmp_878939;
next_tmp_878939:
goto tmp_878938;
tmp_878938:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_878945;
fail_tmp_878936:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_878857();
goto next_tmp_878943;
next_tmp_878943:
goto tmp_878942;
tmp_878942:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_878945:
return tmp_731142;
}
reg_t genfunc_tmp_878910 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_878879 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_878879 >> 8) == 0)
field_imm = tmp_878879;
else goto fail_tmp_878878;
}
/* commit */
{
tmp_731858 = genfunc_tmp_878857();
goto next_tmp_878881;
next_tmp_878881:
goto tmp_878880;
tmp_878880:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_878909;
fail_tmp_878878:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_878901 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_878901))
field_imm = inv_maskmask(8, tmp_878901);
else goto fail_tmp_878900;
}
/* commit */
{
tmp_731075 = genfunc_tmp_878857();
goto next_tmp_878903;
next_tmp_878903:
goto tmp_878902;
tmp_878902:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_878909;
fail_tmp_878900:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_878857();
goto next_tmp_878907;
next_tmp_878907:
goto tmp_878906;
tmp_878906:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_878909:
return tmp_731862;
}
reg_t genfunc_tmp_878857 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_878848;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_877087();
goto next_tmp_878850;
next_tmp_878850:
goto tmp_878849;
tmp_878849:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878856;
fail_tmp_878848:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_878852;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_877087();
goto next_tmp_878854;
next_tmp_878854:
goto tmp_878853;
tmp_878853:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878856;
fail_tmp_878852:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_877087();
goto next_tmp_878832;
next_tmp_878832:
goto tmp_878831;
tmp_878831:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_878856:
return tmp_731876;
}
void genfunc_tmp_878810 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_878807();
goto next_tmp_878677;
next_tmp_878677:
goto tmp_878676;
tmp_878676:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_878809:
}
reg_t genfunc_tmp_878807 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_878774 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_878774 >> 8) == 0)
field_imm = tmp_878774;
else goto fail_tmp_878773;
}
/* commit */
{
tmp_731858 = genfunc_tmp_878718();
goto next_tmp_878776;
next_tmp_878776:
goto tmp_878775;
tmp_878775:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_878806;
fail_tmp_878773:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_878798 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_878798))
field_imm = inv_maskmask(8, tmp_878798);
else goto fail_tmp_878797;
}
/* commit */
{
tmp_731075 = genfunc_tmp_878718();
goto next_tmp_878800;
next_tmp_878800:
goto tmp_878799;
tmp_878799:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_878806;
fail_tmp_878797:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_878718();
goto next_tmp_878804;
next_tmp_878804:
goto tmp_878803;
tmp_878803:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_878806:
return tmp_731142;
}
reg_t genfunc_tmp_878771 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_878740 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_878740 >> 8) == 0)
field_imm = tmp_878740;
else goto fail_tmp_878739;
}
/* commit */
{
tmp_731858 = genfunc_tmp_878718();
goto next_tmp_878742;
next_tmp_878742:
goto tmp_878741;
tmp_878741:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_878770;
fail_tmp_878739:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_878762 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_878762))
field_imm = inv_maskmask(8, tmp_878762);
else goto fail_tmp_878761;
}
/* commit */
{
tmp_731075 = genfunc_tmp_878718();
goto next_tmp_878764;
next_tmp_878764:
goto tmp_878763;
tmp_878763:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_878770;
fail_tmp_878761:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_878718();
goto next_tmp_878768;
next_tmp_878768:
goto tmp_878767;
tmp_878767:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_878770:
return tmp_731862;
}
reg_t genfunc_tmp_878718 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_878709;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_876924();
goto next_tmp_878711;
next_tmp_878711:
goto tmp_878710;
tmp_878710:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_878717;
fail_tmp_878709:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_878713;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_876924();
goto next_tmp_878715;
next_tmp_878715:
goto tmp_878714;
tmp_878714:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_878717;
fail_tmp_878713:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_876924();
goto next_tmp_878693;
next_tmp_878693:
goto tmp_878692;
tmp_878692:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_878717:
return tmp_731876;
}
void genfunc_tmp_878671 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_878668();
goto next_tmp_878542;
next_tmp_878542:
goto tmp_878541;
tmp_878541:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_878670:
}
reg_t genfunc_tmp_878668 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_878635 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_878635 >> 8) == 0)
field_imm = tmp_878635;
else goto fail_tmp_878634;
}
/* commit */
{
tmp_731858 = genfunc_tmp_878579();
goto next_tmp_878637;
next_tmp_878637:
goto tmp_878636;
tmp_878636:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878667;
fail_tmp_878634:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_878659 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_878659))
field_imm = inv_maskmask(8, tmp_878659);
else goto fail_tmp_878658;
}
/* commit */
{
tmp_731075 = genfunc_tmp_878579();
goto next_tmp_878661;
next_tmp_878661:
goto tmp_878660;
tmp_878660:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878667;
fail_tmp_878658:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_878579();
goto next_tmp_878665;
next_tmp_878665:
goto tmp_878664;
tmp_878664:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_878667:
return tmp_731142;
}
reg_t genfunc_tmp_878632 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_878601 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_878601 >> 8) == 0)
field_imm = tmp_878601;
else goto fail_tmp_878600;
}
/* commit */
{
tmp_731858 = genfunc_tmp_878579();
goto next_tmp_878603;
next_tmp_878603:
goto tmp_878602;
tmp_878602:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878631;
fail_tmp_878600:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_878623 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_878623))
field_imm = inv_maskmask(8, tmp_878623);
else goto fail_tmp_878622;
}
/* commit */
{
tmp_731075 = genfunc_tmp_878579();
goto next_tmp_878625;
next_tmp_878625:
goto tmp_878624;
tmp_878624:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878631;
fail_tmp_878622:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_878579();
goto next_tmp_878629;
next_tmp_878629:
goto tmp_878628;
tmp_878628:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_878631:
return tmp_731862;
}
reg_t genfunc_tmp_878579 (void) {
reg_t tmp_731876;
/* ADDQ_IMM */
{
word_5 tmp_731893;
word_5 field_rc;
word_5 tmp_731894;
word_5 field_ra;
word_64 tmp_731896;
word_8 field_imm;
tmp_731896 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_878564 = tmp_731896;
if ((tmp_878564 >> 8) == 0)
field_imm = tmp_878564;
else goto fail_tmp_878563;
}
/* commit */
tmp_731894 = ref_gpr_reg_for_reading(0 + rm);
tmp_731893 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731893;
field_ra = tmp_731894;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731894);
/* can fail: T   num insns: 1 */
}
goto done_tmp_878578;
fail_tmp_878563:
/* LDA */
{
word_5 tmp_731397;
word_5 field_ra;
word_5 tmp_731398;
word_5 field_rb;
word_64 tmp_731400;
word_16 field_memory_disp;
tmp_731400 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_878572 = tmp_731400;
if ((tmp_878572 >> 16) == 0xFFFFFFFFFFFF || (tmp_878572 >> 16) == 0)
field_memory_disp = (tmp_878572 & 0xFFFF);
else goto fail_tmp_878571;
}
/* commit */
tmp_731398 = ref_gpr_reg_for_reading(0 + rm);
tmp_731397 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731397;
field_rb = tmp_731398;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731398);
/* can fail: T   num insns: 1 */
}
goto done_tmp_878578;
fail_tmp_878571:
/* LDAH */
{
word_5 tmp_731393;
word_5 field_ra;
word_5 tmp_731394;
word_5 field_rb;
word_64 tmp_731396;
word_16 field_memory_disp;
tmp_731396 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_878576 = tmp_731396;
if ((tmp_878576 & 0xFFFF) == 0)
{
word_64 tmp_878577 = (tmp_878576 >> 16);
if ((tmp_878577 >> 16) == 0xFFFFFFFFFFFF || (tmp_878577 >> 16) == 0)
field_memory_disp = (tmp_878577 & 0xFFFF);
else goto fail_tmp_878575;
}
else goto fail_tmp_878575;
}
/* commit */
tmp_731394 = ref_gpr_reg_for_reading(0 + rm);
tmp_731393 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731393;
field_rb = tmp_731394;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731394);
/* can fail: T   num insns: 1 */
}
goto done_tmp_878578;
fail_tmp_878575:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731900 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731900, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_878578:
return tmp_731876;
}
void genfunc_tmp_878536 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_878533();
goto next_tmp_878412;
next_tmp_878412:
goto tmp_878411;
tmp_878411:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_878535:
}
reg_t genfunc_tmp_878533 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_878500 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_878500 >> 8) == 0)
field_imm = tmp_878500;
else goto fail_tmp_878499;
}
/* commit */
{
tmp_731858 = genfunc_tmp_878444();
goto next_tmp_878502;
next_tmp_878502:
goto tmp_878501;
tmp_878501:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878532;
fail_tmp_878499:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_878524 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_878524))
field_imm = inv_maskmask(8, tmp_878524);
else goto fail_tmp_878523;
}
/* commit */
{
tmp_731075 = genfunc_tmp_878444();
goto next_tmp_878526;
next_tmp_878526:
goto tmp_878525;
tmp_878525:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878532;
fail_tmp_878523:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_878444();
goto next_tmp_878530;
next_tmp_878530:
goto tmp_878529;
tmp_878529:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_878532:
return tmp_731142;
}
reg_t genfunc_tmp_878497 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_878466 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_878466 >> 8) == 0)
field_imm = tmp_878466;
else goto fail_tmp_878465;
}
/* commit */
{
tmp_731858 = genfunc_tmp_878444();
goto next_tmp_878468;
next_tmp_878468:
goto tmp_878467;
tmp_878467:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878496;
fail_tmp_878465:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_878488 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_878488))
field_imm = inv_maskmask(8, tmp_878488);
else goto fail_tmp_878487;
}
/* commit */
{
tmp_731075 = genfunc_tmp_878444();
goto next_tmp_878490;
next_tmp_878490:
goto tmp_878489;
tmp_878489:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878496;
fail_tmp_878487:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_878444();
goto next_tmp_878494;
next_tmp_878494:
goto tmp_878493;
tmp_878493:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_878496:
return tmp_731862;
}
reg_t genfunc_tmp_878444 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_878441;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + 5);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_878443;
fail_tmp_878441:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_878442;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + 5);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_878443;
fail_tmp_878442:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731900 = ref_gpr_reg_for_reading(0 + 5);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_878443:
return tmp_731876;
}
void genfunc_tmp_878406 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_878403();
goto next_tmp_878251;
next_tmp_878251:
goto tmp_878250;
tmp_878250:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_878405:
}
reg_t genfunc_tmp_878403 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_878370 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_878370 >> 8) == 0)
field_imm = tmp_878370;
else goto fail_tmp_878369;
}
/* commit */
{
tmp_731858 = genfunc_tmp_878314();
goto next_tmp_878372;
next_tmp_878372:
goto tmp_878371;
tmp_878371:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_878402;
fail_tmp_878369:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_878394 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_878394))
field_imm = inv_maskmask(8, tmp_878394);
else goto fail_tmp_878393;
}
/* commit */
{
tmp_731075 = genfunc_tmp_878314();
goto next_tmp_878396;
next_tmp_878396:
goto tmp_878395;
tmp_878395:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_878402;
fail_tmp_878393:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_878314();
goto next_tmp_878400;
next_tmp_878400:
goto tmp_878399;
tmp_878399:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_878402:
return tmp_731142;
}
reg_t genfunc_tmp_878367 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_878336 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_878336 >> 8) == 0)
field_imm = tmp_878336;
else goto fail_tmp_878335;
}
/* commit */
{
tmp_731858 = genfunc_tmp_878314();
goto next_tmp_878338;
next_tmp_878338:
goto tmp_878337;
tmp_878337:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_878366;
fail_tmp_878335:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_878358 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_878358))
field_imm = inv_maskmask(8, tmp_878358);
else goto fail_tmp_878357;
}
/* commit */
{
tmp_731075 = genfunc_tmp_878314();
goto next_tmp_878360;
next_tmp_878360:
goto tmp_878359;
tmp_878359:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_878366;
fail_tmp_878357:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_878314();
goto next_tmp_878364;
next_tmp_878364:
goto tmp_878363;
tmp_878363:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_878366:
return tmp_731862;
}
reg_t genfunc_tmp_878314 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_878305;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_878289();
goto next_tmp_878307;
next_tmp_878307:
goto tmp_878306;
tmp_878306:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878313;
fail_tmp_878305:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_878309;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_878289();
goto next_tmp_878311;
next_tmp_878311:
goto tmp_878310;
tmp_878310:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878313;
fail_tmp_878309:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_878289();
goto next_tmp_878267;
next_tmp_878267:
goto tmp_878266;
tmp_878266:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_878313:
return tmp_731876;
}
reg_t genfunc_tmp_878289 (void) {
reg_t tmp_731900;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + 5);
{
tmp_731900 = genfunc_tmp_877070();
goto next_tmp_878272;
next_tmp_878272:
goto tmp_878271;
tmp_878271:
}
tmp_731897 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_878288:
return tmp_731900;
}
void genfunc_tmp_878245 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_878242();
goto next_tmp_878093;
next_tmp_878093:
goto tmp_878092;
tmp_878092:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_878244:
}
reg_t genfunc_tmp_878242 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_878209 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_878209 >> 8) == 0)
field_imm = tmp_878209;
else goto fail_tmp_878208;
}
/* commit */
{
tmp_731858 = genfunc_tmp_878153();
goto next_tmp_878211;
next_tmp_878211:
goto tmp_878210;
tmp_878210:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_878241;
fail_tmp_878208:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_878233 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_878233))
field_imm = inv_maskmask(8, tmp_878233);
else goto fail_tmp_878232;
}
/* commit */
{
tmp_731075 = genfunc_tmp_878153();
goto next_tmp_878235;
next_tmp_878235:
goto tmp_878234;
tmp_878234:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_878241;
fail_tmp_878232:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_878153();
goto next_tmp_878239;
next_tmp_878239:
goto tmp_878238;
tmp_878238:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_878241:
return tmp_731142;
}
reg_t genfunc_tmp_878206 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_878175 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_878175 >> 8) == 0)
field_imm = tmp_878175;
else goto fail_tmp_878174;
}
/* commit */
{
tmp_731858 = genfunc_tmp_878153();
goto next_tmp_878177;
next_tmp_878177:
goto tmp_878176;
tmp_878176:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_878205;
fail_tmp_878174:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_878197 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_878197))
field_imm = inv_maskmask(8, tmp_878197);
else goto fail_tmp_878196;
}
/* commit */
{
tmp_731075 = genfunc_tmp_878153();
goto next_tmp_878199;
next_tmp_878199:
goto tmp_878198;
tmp_878198:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_878205;
fail_tmp_878196:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_878153();
goto next_tmp_878203;
next_tmp_878203:
goto tmp_878202;
tmp_878202:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_878205:
return tmp_731862;
}
reg_t genfunc_tmp_878153 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_878144;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_878128();
goto next_tmp_878146;
next_tmp_878146:
goto tmp_878145;
tmp_878145:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_878152;
fail_tmp_878144:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_878148;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_878128();
goto next_tmp_878150;
next_tmp_878150:
goto tmp_878149;
tmp_878149:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_878152;
fail_tmp_878148:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_878128();
goto next_tmp_878109;
next_tmp_878109:
goto tmp_878108;
tmp_878108:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_878152:
return tmp_731876;
}
reg_t genfunc_tmp_878128 (void) {
reg_t tmp_731900;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + 5);
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_878127:
return tmp_731900;
}
void genfunc_tmp_878087 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_878084();
goto next_tmp_877963;
next_tmp_877963:
goto tmp_877962;
tmp_877962:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_878086:
}
reg_t genfunc_tmp_878084 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_878051 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_878051 >> 8) == 0)
field_imm = tmp_878051;
else goto fail_tmp_878050;
}
/* commit */
{
tmp_731858 = genfunc_tmp_877995();
goto next_tmp_878053;
next_tmp_878053:
goto tmp_878052;
tmp_878052:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878083;
fail_tmp_878050:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_878075 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_878075))
field_imm = inv_maskmask(8, tmp_878075);
else goto fail_tmp_878074;
}
/* commit */
{
tmp_731075 = genfunc_tmp_877995();
goto next_tmp_878077;
next_tmp_878077:
goto tmp_878076;
tmp_878076:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878083;
fail_tmp_878074:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_877995();
goto next_tmp_878081;
next_tmp_878081:
goto tmp_878080;
tmp_878080:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_878083:
return tmp_731142;
}
reg_t genfunc_tmp_878048 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_878017 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_878017 >> 8) == 0)
field_imm = tmp_878017;
else goto fail_tmp_878016;
}
/* commit */
{
tmp_731858 = genfunc_tmp_877995();
goto next_tmp_878019;
next_tmp_878019:
goto tmp_878018;
tmp_878018:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878047;
fail_tmp_878016:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_878039 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_878039))
field_imm = inv_maskmask(8, tmp_878039);
else goto fail_tmp_878038;
}
/* commit */
{
tmp_731075 = genfunc_tmp_877995();
goto next_tmp_878041;
next_tmp_878041:
goto tmp_878040;
tmp_878040:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_878047;
fail_tmp_878038:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_877995();
goto next_tmp_878045;
next_tmp_878045:
goto tmp_878044;
tmp_878044:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_878047:
return tmp_731862;
}
reg_t genfunc_tmp_877995 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_877992;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + base);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877994;
fail_tmp_877992:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_877993;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + base);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877994;
fail_tmp_877993:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731900 = ref_gpr_reg_for_reading(0 + base);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_877994:
return tmp_731876;
}
void genfunc_tmp_877957 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_877954();
goto next_tmp_877824;
next_tmp_877824:
goto tmp_877823;
tmp_877823:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_877956:
}
reg_t genfunc_tmp_877954 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_877921 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_877921 >> 8) == 0)
field_imm = tmp_877921;
else goto fail_tmp_877920;
}
/* commit */
{
tmp_731858 = genfunc_tmp_877865();
goto next_tmp_877923;
next_tmp_877923:
goto tmp_877922;
tmp_877922:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_877953;
fail_tmp_877920:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_877945 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_877945))
field_imm = inv_maskmask(8, tmp_877945);
else goto fail_tmp_877944;
}
/* commit */
{
tmp_731075 = genfunc_tmp_877865();
goto next_tmp_877947;
next_tmp_877947:
goto tmp_877946;
tmp_877946:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_877953;
fail_tmp_877944:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_877865();
goto next_tmp_877951;
next_tmp_877951:
goto tmp_877950;
tmp_877950:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_877953:
return tmp_731142;
}
reg_t genfunc_tmp_877918 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_877887 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_877887 >> 8) == 0)
field_imm = tmp_877887;
else goto fail_tmp_877886;
}
/* commit */
{
tmp_731858 = genfunc_tmp_877865();
goto next_tmp_877889;
next_tmp_877889:
goto tmp_877888;
tmp_877888:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_877917;
fail_tmp_877886:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_877909 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_877909))
field_imm = inv_maskmask(8, tmp_877909);
else goto fail_tmp_877908;
}
/* commit */
{
tmp_731075 = genfunc_tmp_877865();
goto next_tmp_877911;
next_tmp_877911:
goto tmp_877910;
tmp_877910:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_877917;
fail_tmp_877908:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_877865();
goto next_tmp_877915;
next_tmp_877915:
goto tmp_877914;
tmp_877914:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_877917:
return tmp_731862;
}
reg_t genfunc_tmp_877865 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_877856;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_877087();
goto next_tmp_877858;
next_tmp_877858:
goto tmp_877857;
tmp_877857:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_877864;
fail_tmp_877856:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_877860;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_877087();
goto next_tmp_877862;
next_tmp_877862:
goto tmp_877861;
tmp_877861:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_877864;
fail_tmp_877860:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_877087();
goto next_tmp_877840;
next_tmp_877840:
goto tmp_877839;
tmp_877839:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_877864:
return tmp_731876;
}
void genfunc_tmp_877818 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_877815();
goto next_tmp_877685;
next_tmp_877685:
goto tmp_877684;
tmp_877684:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_877817:
}
reg_t genfunc_tmp_877815 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_877782 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_877782 >> 8) == 0)
field_imm = tmp_877782;
else goto fail_tmp_877781;
}
/* commit */
{
tmp_731858 = genfunc_tmp_877726();
goto next_tmp_877784;
next_tmp_877784:
goto tmp_877783;
tmp_877783:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_877814;
fail_tmp_877781:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_877806 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_877806))
field_imm = inv_maskmask(8, tmp_877806);
else goto fail_tmp_877805;
}
/* commit */
{
tmp_731075 = genfunc_tmp_877726();
goto next_tmp_877808;
next_tmp_877808:
goto tmp_877807;
tmp_877807:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_877814;
fail_tmp_877805:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_877726();
goto next_tmp_877812;
next_tmp_877812:
goto tmp_877811;
tmp_877811:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_877814:
return tmp_731142;
}
reg_t genfunc_tmp_877779 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_877748 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_877748 >> 8) == 0)
field_imm = tmp_877748;
else goto fail_tmp_877747;
}
/* commit */
{
tmp_731858 = genfunc_tmp_877726();
goto next_tmp_877750;
next_tmp_877750:
goto tmp_877749;
tmp_877749:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_877778;
fail_tmp_877747:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_877770 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_877770))
field_imm = inv_maskmask(8, tmp_877770);
else goto fail_tmp_877769;
}
/* commit */
{
tmp_731075 = genfunc_tmp_877726();
goto next_tmp_877772;
next_tmp_877772:
goto tmp_877771;
tmp_877771:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_877778;
fail_tmp_877769:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_877726();
goto next_tmp_877776;
next_tmp_877776:
goto tmp_877775;
tmp_877775:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_877778:
return tmp_731862;
}
reg_t genfunc_tmp_877726 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_877717;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_876924();
goto next_tmp_877719;
next_tmp_877719:
goto tmp_877718;
tmp_877718:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_877725;
fail_tmp_877717:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_877721;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_876924();
goto next_tmp_877723;
next_tmp_877723:
goto tmp_877722;
tmp_877722:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_877725;
fail_tmp_877721:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_876924();
goto next_tmp_877701;
next_tmp_877701:
goto tmp_877700;
tmp_877700:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_877725:
return tmp_731876;
}
void genfunc_tmp_877679 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_877676();
goto next_tmp_877550;
next_tmp_877550:
goto tmp_877549;
tmp_877549:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_877678:
}
reg_t genfunc_tmp_877676 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_877643 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_877643 >> 8) == 0)
field_imm = tmp_877643;
else goto fail_tmp_877642;
}
/* commit */
{
tmp_731858 = genfunc_tmp_877587();
goto next_tmp_877645;
next_tmp_877645:
goto tmp_877644;
tmp_877644:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_877675;
fail_tmp_877642:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_877667 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_877667))
field_imm = inv_maskmask(8, tmp_877667);
else goto fail_tmp_877666;
}
/* commit */
{
tmp_731075 = genfunc_tmp_877587();
goto next_tmp_877669;
next_tmp_877669:
goto tmp_877668;
tmp_877668:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_877675;
fail_tmp_877666:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_877587();
goto next_tmp_877673;
next_tmp_877673:
goto tmp_877672;
tmp_877672:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_877675:
return tmp_731142;
}
reg_t genfunc_tmp_877640 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_877609 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_877609 >> 8) == 0)
field_imm = tmp_877609;
else goto fail_tmp_877608;
}
/* commit */
{
tmp_731858 = genfunc_tmp_877587();
goto next_tmp_877611;
next_tmp_877611:
goto tmp_877610;
tmp_877610:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_877639;
fail_tmp_877608:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_877631 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_877631))
field_imm = inv_maskmask(8, tmp_877631);
else goto fail_tmp_877630;
}
/* commit */
{
tmp_731075 = genfunc_tmp_877587();
goto next_tmp_877633;
next_tmp_877633:
goto tmp_877632;
tmp_877632:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_877639;
fail_tmp_877630:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_877587();
goto next_tmp_877637;
next_tmp_877637:
goto tmp_877636;
tmp_877636:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_877639:
return tmp_731862;
}
reg_t genfunc_tmp_877587 (void) {
reg_t tmp_731876;
/* ADDQ_IMM */
{
word_5 tmp_731893;
word_5 field_rc;
word_5 tmp_731894;
word_5 field_ra;
word_64 tmp_731896;
word_8 field_imm;
tmp_731896 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_877572 = tmp_731896;
if ((tmp_877572 >> 8) == 0)
field_imm = tmp_877572;
else goto fail_tmp_877571;
}
/* commit */
tmp_731894 = ref_gpr_reg_for_reading(0 + rm);
tmp_731893 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731893;
field_ra = tmp_731894;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731894);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877586;
fail_tmp_877571:
/* LDA */
{
word_5 tmp_731397;
word_5 field_ra;
word_5 tmp_731398;
word_5 field_rb;
word_64 tmp_731400;
word_16 field_memory_disp;
tmp_731400 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_877580 = tmp_731400;
if ((tmp_877580 >> 16) == 0xFFFFFFFFFFFF || (tmp_877580 >> 16) == 0)
field_memory_disp = (tmp_877580 & 0xFFFF);
else goto fail_tmp_877579;
}
/* commit */
tmp_731398 = ref_gpr_reg_for_reading(0 + rm);
tmp_731397 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731397;
field_rb = tmp_731398;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731398);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877586;
fail_tmp_877579:
/* LDAH */
{
word_5 tmp_731393;
word_5 field_ra;
word_5 tmp_731394;
word_5 field_rb;
word_64 tmp_731396;
word_16 field_memory_disp;
tmp_731396 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_877584 = tmp_731396;
if ((tmp_877584 & 0xFFFF) == 0)
{
word_64 tmp_877585 = (tmp_877584 >> 16);
if ((tmp_877585 >> 16) == 0xFFFFFFFFFFFF || (tmp_877585 >> 16) == 0)
field_memory_disp = (tmp_877585 & 0xFFFF);
else goto fail_tmp_877583;
}
else goto fail_tmp_877583;
}
/* commit */
tmp_731394 = ref_gpr_reg_for_reading(0 + rm);
tmp_731393 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731393;
field_rb = tmp_731394;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731394);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877586;
fail_tmp_877583:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731900 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731900, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_877586:
return tmp_731876;
}
void genfunc_tmp_877541 (void) {
/* STL */
{
word_5 field_rb;
word_64 tmp_731143;
word_16 field_memory_disp;
word_5 tmp_731145;
word_5 field_ra;
tmp_731143 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_877539 = tmp_731143;
if ((tmp_877539 >> 16) == 0xFFFFFFFFFFFF || (tmp_877539 >> 16) == 0)
field_memory_disp = (tmp_877539 & 0xFFFF);
else goto fail_tmp_877538;
}
/* commit */
tmp_731145 = ref_gpr_reg_for_reading(0 + reg);
field_ra = tmp_731145;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731145);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877540;
fail_tmp_877538:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
tmp_731142 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731142, ((word_64)disp32));
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 2 */
}
done_tmp_877540:
}
void genfunc_tmp_877533 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_877530();
goto next_tmp_877400;
next_tmp_877400:
goto tmp_877399;
tmp_877399:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_877532:
}
reg_t genfunc_tmp_877530 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_877497 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_877497 >> 8) == 0)
field_imm = tmp_877497;
else goto fail_tmp_877496;
}
/* commit */
{
tmp_731858 = genfunc_tmp_877441();
goto next_tmp_877499;
next_tmp_877499:
goto tmp_877498;
tmp_877498:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_877529;
fail_tmp_877496:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_877521 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_877521))
field_imm = inv_maskmask(8, tmp_877521);
else goto fail_tmp_877520;
}
/* commit */
{
tmp_731075 = genfunc_tmp_877441();
goto next_tmp_877523;
next_tmp_877523:
goto tmp_877522;
tmp_877522:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_877529;
fail_tmp_877520:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_877441();
goto next_tmp_877527;
next_tmp_877527:
goto tmp_877526;
tmp_877526:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_877529:
return tmp_731142;
}
reg_t genfunc_tmp_877494 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_877463 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_877463 >> 8) == 0)
field_imm = tmp_877463;
else goto fail_tmp_877462;
}
/* commit */
{
tmp_731858 = genfunc_tmp_877441();
goto next_tmp_877465;
next_tmp_877465:
goto tmp_877464;
tmp_877464:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_877493;
fail_tmp_877462:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_877485 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_877485))
field_imm = inv_maskmask(8, tmp_877485);
else goto fail_tmp_877484;
}
/* commit */
{
tmp_731075 = genfunc_tmp_877441();
goto next_tmp_877487;
next_tmp_877487:
goto tmp_877486;
tmp_877486:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_877493;
fail_tmp_877484:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_877441();
goto next_tmp_877491;
next_tmp_877491:
goto tmp_877490;
tmp_877490:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_877493:
return tmp_731862;
}
reg_t genfunc_tmp_877441 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_877432;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_877070();
goto next_tmp_877434;
next_tmp_877434:
goto tmp_877433;
tmp_877433:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_877440;
fail_tmp_877432:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_877436;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_877070();
goto next_tmp_877438;
next_tmp_877438:
goto tmp_877437;
tmp_877437:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_877440;
fail_tmp_877436:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_877070();
goto next_tmp_877416;
next_tmp_877416:
goto tmp_877415;
tmp_877415:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_877440:
return tmp_731876;
}
void genfunc_tmp_877394 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_877391();
goto next_tmp_877270;
next_tmp_877270:
goto tmp_877269;
tmp_877269:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_877393:
}
reg_t genfunc_tmp_877391 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_877358 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_877358 >> 8) == 0)
field_imm = tmp_877358;
else goto fail_tmp_877357;
}
/* commit */
{
tmp_731858 = genfunc_tmp_877302();
goto next_tmp_877360;
next_tmp_877360:
goto tmp_877359;
tmp_877359:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_877390;
fail_tmp_877357:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_877382 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_877382))
field_imm = inv_maskmask(8, tmp_877382);
else goto fail_tmp_877381;
}
/* commit */
{
tmp_731075 = genfunc_tmp_877302();
goto next_tmp_877384;
next_tmp_877384:
goto tmp_877383;
tmp_877383:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_877390;
fail_tmp_877381:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_877302();
goto next_tmp_877388;
next_tmp_877388:
goto tmp_877387;
tmp_877387:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_877390:
return tmp_731142;
}
reg_t genfunc_tmp_877355 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_877324 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_877324 >> 8) == 0)
field_imm = tmp_877324;
else goto fail_tmp_877323;
}
/* commit */
{
tmp_731858 = genfunc_tmp_877302();
goto next_tmp_877326;
next_tmp_877326:
goto tmp_877325;
tmp_877325:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_877354;
fail_tmp_877323:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_877346 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_877346))
field_imm = inv_maskmask(8, tmp_877346);
else goto fail_tmp_877345;
}
/* commit */
{
tmp_731075 = genfunc_tmp_877302();
goto next_tmp_877348;
next_tmp_877348:
goto tmp_877347;
tmp_877347:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_877354;
fail_tmp_877345:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_877302();
goto next_tmp_877352;
next_tmp_877352:
goto tmp_877351;
tmp_877351:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_877354:
return tmp_731862;
}
reg_t genfunc_tmp_877302 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_877299;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + index);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877301;
fail_tmp_877299:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_877300;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + index);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877301;
fail_tmp_877300:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_877301:
return tmp_731876;
}
void genfunc_tmp_877264 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_877261();
goto next_tmp_877185;
next_tmp_877185:
goto tmp_877184;
tmp_877184:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 2 */
}
done_tmp_877263:
}
reg_t genfunc_tmp_877261 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_877237 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_877237 >> 8) == 0)
field_imm = tmp_877237;
else goto fail_tmp_877236;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + base);
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877260;
fail_tmp_877236:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_877258 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_877258))
field_imm = inv_maskmask(8, tmp_877258);
else goto fail_tmp_877257;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + base);
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877260;
fail_tmp_877257:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + base);
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_877260:
return tmp_731142;
}
reg_t genfunc_tmp_877234 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_877212 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_877212 >> 8) == 0)
field_imm = tmp_877212;
else goto fail_tmp_877211;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + base);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877233;
fail_tmp_877211:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_877231 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_877231))
field_imm = inv_maskmask(8, tmp_877231);
else goto fail_tmp_877230;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + base);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877233;
fail_tmp_877230:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + base);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_877233:
return tmp_731862;
}
void genfunc_tmp_877179 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_877176();
goto next_tmp_877022;
next_tmp_877022:
goto tmp_877021;
tmp_877021:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_877178:
}
reg_t genfunc_tmp_877176 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_877143 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_877143 >> 8) == 0)
field_imm = tmp_877143;
else goto fail_tmp_877142;
}
/* commit */
{
tmp_731858 = genfunc_tmp_877087();
goto next_tmp_877145;
next_tmp_877145:
goto tmp_877144;
tmp_877144:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_877175;
fail_tmp_877142:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_877167 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_877167))
field_imm = inv_maskmask(8, tmp_877167);
else goto fail_tmp_877166;
}
/* commit */
{
tmp_731075 = genfunc_tmp_877087();
goto next_tmp_877169;
next_tmp_877169:
goto tmp_877168;
tmp_877168:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_877175;
fail_tmp_877166:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_877087();
goto next_tmp_877173;
next_tmp_877173:
goto tmp_877172;
tmp_877172:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_877175:
return tmp_731142;
}
reg_t genfunc_tmp_877140 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_877109 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_877109 >> 8) == 0)
field_imm = tmp_877109;
else goto fail_tmp_877108;
}
/* commit */
{
tmp_731858 = genfunc_tmp_877087();
goto next_tmp_877111;
next_tmp_877111:
goto tmp_877110;
tmp_877110:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_877139;
fail_tmp_877108:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_877131 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_877131))
field_imm = inv_maskmask(8, tmp_877131);
else goto fail_tmp_877130;
}
/* commit */
{
tmp_731075 = genfunc_tmp_877087();
goto next_tmp_877133;
next_tmp_877133:
goto tmp_877132;
tmp_877132:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_877139;
fail_tmp_877130:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_877087();
goto next_tmp_877137;
next_tmp_877137:
goto tmp_877136;
tmp_877136:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_877139:
return tmp_731862;
}
reg_t genfunc_tmp_877087 (void) {
reg_t tmp_731876;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + base);
{
tmp_731900 = genfunc_tmp_877070();
goto next_tmp_877038;
next_tmp_877038:
goto tmp_877037;
tmp_877037:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_877086:
return tmp_731876;
}
reg_t genfunc_tmp_877070 (void) {
reg_t tmp_731900;
/* EXTQH */
{
word_5 tmp_731618;
word_5 field_rc;
word_5 tmp_731619;
word_5 field_ra;
word_5 field_rb;
if (64 != ((word_64)scale)) goto fail_tmp_877051;
field_rb = 31;
/* commit */
tmp_731619 = ref_gpr_reg_for_reading(0 + index);
tmp_731618 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731618;
field_ra = tmp_731619;
emit(COMPOSE_EXTQH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731619);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877069;
fail_tmp_877051:
/* EXTQH_IMM */
{
word_5 tmp_731614;
word_5 field_rc;
word_5 tmp_731615;
word_5 field_ra;
word_64 tmp_731617;
word_8 field_imm;
tmp_731617 = ((word_64)scale);
{
word_64 tmp_877053 = ((64 - tmp_731617) & 0xFFFFFFFFFFFFFFFF);
if (tmp_877053 % 8 == 0)
{
word_64 tmp_877054 = (tmp_877053 / 8);
if ((tmp_877054 & 7) == tmp_877054)
{
word_64 tmp_877055 = tmp_877054;
if ((tmp_877055 >> 8) == 0)
field_imm = tmp_877055;
else goto fail_tmp_877052;
}
else goto fail_tmp_877052;
}
else goto fail_tmp_877052;
}
/* commit */
tmp_731615 = ref_gpr_reg_for_reading(0 + index);
tmp_731614 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731614;
field_ra = tmp_731615;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731615);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877069;
fail_tmp_877052:
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 tmp_731241;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_877061;
field_rb = 31;
/* commit */
tmp_731241 = ref_gpr_reg_for_reading(0 + index);
tmp_731240 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_ra = tmp_731241;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731241);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877069;
fail_tmp_877061:
/* S4ADDQ_IMM */
{
word_5 tmp_731236;
word_5 field_rc;
word_5 tmp_731237;
word_5 field_ra;
word_64 tmp_731239;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_877062;
tmp_731239 = 0;
field_imm = 0;
/* commit */
tmp_731237 = ref_gpr_reg_for_reading(0 + index);
tmp_731236 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731236;
field_ra = tmp_731237;
emit(COMPOSE_S4ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731237);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877069;
fail_tmp_877062:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 tmp_731209;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_877064;
field_rb = 31;
/* commit */
tmp_731209 = ref_gpr_reg_for_reading(0 + index);
tmp_731208 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_ra = tmp_731209;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731209);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877069;
fail_tmp_877064:
/* S8ADDQ_IMM */
{
word_5 tmp_731204;
word_5 field_rc;
word_5 tmp_731205;
word_5 field_ra;
word_64 tmp_731207;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_877065;
tmp_731207 = 0;
field_imm = 0;
/* commit */
tmp_731205 = ref_gpr_reg_for_reading(0 + index);
tmp_731204 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731204;
field_ra = tmp_731205;
emit(COMPOSE_S8ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731205);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877069;
fail_tmp_877065:
/* SLL */
{
word_5 tmp_731176;
word_5 field_rc;
word_5 tmp_731177;
word_5 field_ra;
word_5 field_rb;
if (0 != ((word_64)scale)) goto fail_tmp_877066;
field_rb = 31;
/* commit */
tmp_731177 = ref_gpr_reg_for_reading(0 + index);
tmp_731176 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731176;
field_ra = tmp_731177;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731177);
/* can fail: T   num insns: 1 */
}
goto done_tmp_877069;
fail_tmp_877066:
/* SLL_IMM */
{
word_5 tmp_731172;
word_5 field_rc;
word_5 tmp_731173;
word_5 field_ra;
word_64 tmp_731175;
word_8 field_imm;
tmp_731175 = ((word_64)scale);
field_imm = tmp_731175;
/* commit */
tmp_731173 = ref_gpr_reg_for_reading(0 + index);
tmp_731172 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731172;
field_ra = tmp_731173;
emit(COMPOSE_SLL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731173);
/* can fail: NIL   num insns: 1 */
}
done_tmp_877069:
return tmp_731900;
}
void genfunc_tmp_877016 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_877013();
goto next_tmp_876894;
next_tmp_876894:
goto tmp_876893;
tmp_876893:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 3 */
}
done_tmp_877015:
}
reg_t genfunc_tmp_877013 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_876980 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_876980 >> 8) == 0)
field_imm = tmp_876980;
else goto fail_tmp_876979;
}
/* commit */
{
tmp_731858 = genfunc_tmp_876924();
goto next_tmp_876982;
next_tmp_876982:
goto tmp_876981;
tmp_876981:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_877012;
fail_tmp_876979:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_877004 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_877004))
field_imm = inv_maskmask(8, tmp_877004);
else goto fail_tmp_877003;
}
/* commit */
{
tmp_731075 = genfunc_tmp_876924();
goto next_tmp_877006;
next_tmp_877006:
goto tmp_877005;
tmp_877005:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_877012;
fail_tmp_877003:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_876924();
goto next_tmp_877010;
next_tmp_877010:
goto tmp_877009;
tmp_877009:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_877012:
return tmp_731142;
}
reg_t genfunc_tmp_876977 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_876946 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_876946 >> 8) == 0)
field_imm = tmp_876946;
else goto fail_tmp_876945;
}
/* commit */
{
tmp_731858 = genfunc_tmp_876924();
goto next_tmp_876948;
next_tmp_876948:
goto tmp_876947;
tmp_876947:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_876976;
fail_tmp_876945:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_876968 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_876968))
field_imm = inv_maskmask(8, tmp_876968);
else goto fail_tmp_876967;
}
/* commit */
{
tmp_731075 = genfunc_tmp_876924();
goto next_tmp_876970;
next_tmp_876970:
goto tmp_876969;
tmp_876969:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_876976;
fail_tmp_876967:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_876924();
goto next_tmp_876974;
next_tmp_876974:
goto tmp_876973;
tmp_876973:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_876976:
return tmp_731862;
}
reg_t genfunc_tmp_876924 (void) {
reg_t tmp_731876;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + base);
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_876923:
return tmp_731876;
}
void genfunc_tmp_876888 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_876885();
goto next_tmp_876809;
next_tmp_876809:
goto tmp_876808;
tmp_876808:
}
tmp_731146 = ref_gpr_reg_for_reading(0 + reg);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 2 */
}
done_tmp_876887:
}
reg_t genfunc_tmp_876885 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_876861 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_876861 >> 8) == 0)
field_imm = tmp_876861;
else goto fail_tmp_876860;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + rm);
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876884;
fail_tmp_876860:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_876882 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_876882))
field_imm = inv_maskmask(8, tmp_876882);
else goto fail_tmp_876881;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + rm);
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876884;
fail_tmp_876881:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + rm);
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_876884:
return tmp_731142;
}
reg_t genfunc_tmp_876858 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_876836 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_876836 >> 8) == 0)
field_imm = tmp_876836;
else goto fail_tmp_876835;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + rm);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876857;
fail_tmp_876835:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_876855 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_876855))
field_imm = inv_maskmask(8, tmp_876855);
else goto fail_tmp_876854;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + rm);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876857;
fail_tmp_876854:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + rm);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_876857:
return tmp_731862;
}
