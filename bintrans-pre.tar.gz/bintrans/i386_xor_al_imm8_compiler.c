#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compiler_tmp_897795 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_897785 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_897790 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_897794 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_897781 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_897770 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_897780 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_897775 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_897778 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_897766 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_897762 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_897761 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_897795 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 6 6 T)
*/
{
{
reg_t tmp_897797, tmp_897798, tmp_897796;
rhs_func(&tmp_897797, -1, env);
emit(COMPOSE_SLL_IMM(tmp_897797, 63, tmp_897797));
emit(COMPOSE_SRL_IMM(tmp_897797, 57, tmp_897797));
tmp_897798 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_897798, -1);
emit(COMPOSE_SLL_IMM(tmp_897798, 63, tmp_897798));
emit(COMPOSE_SRL_IMM(tmp_897798, 57, tmp_897798));
tmp_897796 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_897796, tmp_897798, tmp_897796));
unref_integer_reg(tmp_897798);
emit(COMPOSE_BIS(tmp_897796, tmp_897797, tmp_897796));
unref_integer_reg(tmp_897797);
unref_integer_reg(tmp_897796);
}
}

void compiler_tmp_897785 (reg_t *target, int foreign_target, void **env)
/*
(IF (= (SUBREGISTER EAX GPR (INTEGER 0) 0 7 T) (INTEGER 0)) (INTEGER 1)
 (INTEGER 0))
*/
{
{
label_t tmp_897787 = alloc_label(), tmp_897788 = alloc_label(), tmp_897789 = alloc_label();
reg_t tmp_897786;
compiler_tmp_897790(tmp_897787, tmp_897788, env);

tmp_897786 = ref_integer_reg_for_writing(-1);
emit_label(tmp_897787);
push_alloc();
compiler_tmp_897780(&tmp_897786, tmp_897786 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_897789);
emit_label(tmp_897788);
push_alloc();
compiler_tmp_897761(&tmp_897786, tmp_897786 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_897789);
free_label(tmp_897787);
free_label(tmp_897788);
free_label(tmp_897789);
if (foreign_target == -1)
*target = tmp_897786;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_897786, *target));
unref_integer_reg(tmp_897786);
}

}
}

void compiler_tmp_897790 (label_t true_label, label_t false_label, void **env)
/*
(= (SUBREGISTER EAX GPR (INTEGER 0) 0 7 T) (INTEGER 0))
*/
{
{
reg_t tmp_897791, tmp_897792, tmp_897793;
compiler_tmp_897778(&tmp_897791, -1, env);
compiler_tmp_897794(&tmp_897792, -1, env);
tmp_897793 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_CMPEQ(tmp_897791, tmp_897792, tmp_897793));
unref_integer_reg(tmp_897791);
unref_integer_reg(tmp_897792);
emit_branch(COMPOSE_BEQ(tmp_897793, 0), false_label);
unref_integer_reg(tmp_897793);
emit_branch(COMPOSE_BR(31, 0), true_label);
}
}

void compiler_tmp_897794 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_897781 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 7 7 T)
*/
{
{
reg_t tmp_897783, tmp_897784, tmp_897782;
rhs_func(&tmp_897783, -1, env);
emit(COMPOSE_SLL_IMM(tmp_897783, 63, tmp_897783));
emit(COMPOSE_SRL_IMM(tmp_897783, 56, tmp_897783));
tmp_897784 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_897784, -1);
emit(COMPOSE_SLL_IMM(tmp_897784, 63, tmp_897784));
emit(COMPOSE_SRL_IMM(tmp_897784, 56, tmp_897784));
tmp_897782 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_897782, tmp_897784, tmp_897782));
unref_integer_reg(tmp_897784);
emit(COMPOSE_BIS(tmp_897782, tmp_897783, tmp_897782));
unref_integer_reg(tmp_897783);
unref_integer_reg(tmp_897782);
}
}

void compiler_tmp_897770 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (BIT-SET-P (SUBREGISTER EAX GPR (INTEGER 0) 0 7 T)
  (- (INTEGER 8) (INTEGER 1)))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_897772 = alloc_label(), tmp_897773 = alloc_label(), tmp_897774 = alloc_label();
reg_t tmp_897771;
compiler_tmp_897775(tmp_897772, tmp_897773, env);

tmp_897771 = ref_integer_reg_for_writing(-1);
emit_label(tmp_897772);
push_alloc();
compiler_tmp_897780(&tmp_897771, tmp_897771 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_897774);
emit_label(tmp_897773);
push_alloc();
compiler_tmp_897761(&tmp_897771, tmp_897771 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_897774);
free_label(tmp_897772);
free_label(tmp_897773);
free_label(tmp_897774);
if (foreign_target == -1)
*target = tmp_897771;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_897771, *target));
unref_integer_reg(tmp_897771);
}

}
}

void compiler_tmp_897780 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 1)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 1);
}

void compiler_tmp_897775 (label_t true_label, label_t false_label, void **env)
/*
(BIT-SET-P (SUBREGISTER EAX GPR (INTEGER 0) 0 7 T) (- (INTEGER 8) (INTEGER 1)))
*/
{
{
reg_t tmp_897776, tmp_897777;
compiler_tmp_897778(&tmp_897776, -1, env);
tmp_897777 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_SRL_IMM(tmp_897776, (8 - 1), tmp_897777));
unref_integer_reg(tmp_897776);
emit_branch(COMPOSE_BLBS(tmp_897777, 0), true_label);
unref_integer_reg(tmp_897777);
emit_branch(COMPOSE_BR(31, 0), false_label);
}
}

void compiler_tmp_897778 (reg_t *target, int foreign_target, void **env)
/*
(SUBREGISTER EAX GPR (INTEGER 0) 0 7 T)
*/
{
{
reg_t tmp_897779 = ref_integer_reg_for_reading(0);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_SLL_IMM(tmp_897779, 56, *target));
unref_integer_reg(tmp_897779);
emit(COMPOSE_SRL_IMM(*target, 56, *target));
}
}

void compiler_tmp_897766 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 11 11 T)
*/
{
{
reg_t tmp_897768, tmp_897769, tmp_897767;
rhs_func(&tmp_897768, -1, env);
emit(COMPOSE_SLL_IMM(tmp_897768, 63, tmp_897768));
emit(COMPOSE_SRL_IMM(tmp_897768, 52, tmp_897768));
tmp_897769 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_897769, -1);
emit(COMPOSE_SLL_IMM(tmp_897769, 63, tmp_897769));
emit(COMPOSE_SRL_IMM(tmp_897769, 52, tmp_897769));
tmp_897767 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_897767, tmp_897769, tmp_897767));
unref_integer_reg(tmp_897769);
emit(COMPOSE_BIS(tmp_897767, tmp_897768, tmp_897767));
unref_integer_reg(tmp_897768);
unref_integer_reg(tmp_897767);
}
}

void compiler_tmp_897762 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 0 0 T)
*/
{
{
reg_t tmp_897764, tmp_897765, tmp_897763;
rhs_func(&tmp_897764, -1, env);
emit(COMPOSE_SLL_IMM(tmp_897764, 63, tmp_897764));
emit(COMPOSE_SRL_IMM(tmp_897764, 63, tmp_897764));
tmp_897765 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_897765, -1);
emit(COMPOSE_SLL_IMM(tmp_897765, 63, tmp_897765));
emit(COMPOSE_SRL_IMM(tmp_897765, 63, tmp_897765));
tmp_897763 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_897763, tmp_897765, tmp_897763));
unref_integer_reg(tmp_897765);
emit(COMPOSE_BIS(tmp_897763, tmp_897764, tmp_897763));
unref_integer_reg(tmp_897764);
unref_integer_reg(tmp_897763);
}
}

void compiler_tmp_897761 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compile_xor_al_imm8_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 && (imm8 == 0))
{
genfunc_tmp_897461();
goto next_tmp_897242;
next_tmp_897242:
goto finish_tmp_897241;
finish_tmp_897241:
}
if (1 && (!(imm8 == 0)))
{
genfunc_tmp_897759();
goto next_tmp_897464;
next_tmp_897464:
goto finish_tmp_897463;
finish_tmp_897463:
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_897761;
killed |= 0x1;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_897762(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_897761;
killed |= 0x800;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_897766(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_897770;
killed |= 0x80;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_897781(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_897785;
killed |= 0x40;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_897795(rhs_func, env);
}
}
}
void genfunc_tmp_897759 (void) {
/* BIS */
{
word_5 tmp_731853;
word_5 field_rc;
word_5 tmp_731854;
word_5 field_ra;
word_5 tmp_731856;
word_5 field_rb;
/* commit */
{
tmp_731854 = genfunc_tmp_897514();
goto next_tmp_897737;
next_tmp_897737:
goto tmp_897736;
tmp_897736:
}
{
tmp_731856 = genfunc_tmp_897710();
goto next_tmp_897740;
next_tmp_897740:
goto tmp_897739;
tmp_897739:
}
tmp_731853 = ref_gpr_reg_for_writing(0 + 0);
field_rc = tmp_731853;
field_ra = tmp_731854;
field_rb = tmp_731856;
emit(COMPOSE_BIS(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731853);
unref_gpr_reg(tmp_731856);
unref_gpr_reg(tmp_731854);
/* can fail: NIL   num insns: 5 */
}
done_tmp_897758:
}
reg_t genfunc_tmp_897721 (void) {
reg_t tmp_731898;
/* BIS */
{
word_5 tmp_731853;
word_5 field_rc;
word_5 tmp_731854;
word_5 field_ra;
word_5 tmp_731856;
word_5 field_rb;
/* commit */
{
tmp_731854 = genfunc_tmp_897514();
goto next_tmp_897478;
next_tmp_897478:
goto tmp_897477;
tmp_897477:
}
{
tmp_731856 = genfunc_tmp_897710();
goto next_tmp_897517;
next_tmp_897517:
goto tmp_897516;
tmp_897516:
}
tmp_731853 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731853;
field_ra = tmp_731854;
field_rb = tmp_731856;
emit(COMPOSE_BIS(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731856);
unref_gpr_reg(tmp_731854);
/* can fail: NIL   num insns: 5 */
}
done_tmp_897720:
return tmp_731898;
}
reg_t genfunc_tmp_897710 (void) {
reg_t tmp_731856;
/* EXTQH_IMM */
{
word_5 tmp_731614;
word_5 field_rc;
word_5 tmp_731615;
word_5 field_ra;
word_64 tmp_731617;
word_8 field_imm;
tmp_731617 = 0;
{
word_64 tmp_897532 = ((64 - tmp_731617) & 0xFFFFFFFFFFFFFFFF);
if (tmp_897532 % 8 == 0)
{
word_64 tmp_897533 = (tmp_897532 / 8);
if ((tmp_897533 & 7) == tmp_897533)
{
word_64 tmp_897534 = tmp_897533;
if ((tmp_897534 >> 8) == 0)
field_imm = tmp_897534;
else goto fail_tmp_897531;
}
else goto fail_tmp_897531;
}
else goto fail_tmp_897531;
}
/* commit */
{
tmp_731615 = genfunc_tmp_897688();
goto next_tmp_897536;
next_tmp_897536:
goto tmp_897535;
tmp_897535:
}
tmp_731614 = tmp_731856 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731614;
field_ra = tmp_731615;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731615);
/* can fail: T   num insns: 3 */
}
goto done_tmp_897709;
fail_tmp_897531:
/* SLL */
{
word_5 tmp_731176;
word_5 field_rc;
word_5 tmp_731177;
word_5 field_ra;
word_5 field_rb;
field_rb = 31;
/* commit */
{
tmp_731177 = genfunc_tmp_897688();
goto next_tmp_897702;
next_tmp_897702:
goto tmp_897701;
tmp_897701:
}
tmp_731176 = tmp_731856 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731176;
field_ra = tmp_731177;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731177);
/* can fail: NIL   num insns: 3 */
}
done_tmp_897709:
return tmp_731856;
}
reg_t genfunc_tmp_897688 (void) {
reg_t tmp_731615;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((word_64)imm8)) goto fail_tmp_897642;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_897390();
goto next_tmp_897644;
next_tmp_897644:
goto tmp_897643;
tmp_897643:
}
tmp_731668 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 2 */
}
goto done_tmp_897687;
fail_tmp_897642:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((word_64)imm8);
{
word_64 tmp_897647 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_897647 >> 8) == 0)
field_imm = tmp_897647;
else goto fail_tmp_897646;
}
/* commit */
{
tmp_731665 = genfunc_tmp_897390();
goto next_tmp_897649;
next_tmp_897649:
goto tmp_897648;
tmp_897648:
}
tmp_731664 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 2 */
}
goto done_tmp_897687;
fail_tmp_897646:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((word_64)imm8)) goto fail_tmp_897666;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_897390();
goto next_tmp_897668;
next_tmp_897668:
goto tmp_897667;
tmp_897667:
}
tmp_731086 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 2 */
}
goto done_tmp_897687;
fail_tmp_897666:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((word_64)imm8);
field_imm = tmp_731085;
/* commit */
{
tmp_731083 = genfunc_tmp_897390();
goto next_tmp_897672;
next_tmp_897672:
goto tmp_897671;
tmp_897671:
}
tmp_731082 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: NIL   num insns: 2 */
}
done_tmp_897687:
return tmp_731615;
}
reg_t genfunc_tmp_897631 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 255;
{
word_64 tmp_897600 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_897600 >> 8) == 0)
field_imm = tmp_897600;
else goto fail_tmp_897599;
}
/* commit */
{
tmp_731858 = genfunc_tmp_897572();
goto next_tmp_897602;
next_tmp_897602:
goto tmp_897601;
tmp_897601:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_897630;
fail_tmp_897599:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 255;
{
word_64 tmp_897622 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_897622))
field_imm = inv_maskmask(8, tmp_897622);
else goto fail_tmp_897621;
}
/* commit */
{
tmp_731075 = genfunc_tmp_897572();
goto next_tmp_897624;
next_tmp_897624:
goto tmp_897623;
tmp_897623:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_897630;
fail_tmp_897621:
/* AND_IMM */
{
word_5 tmp_731871;
word_5 field_rc;
word_5 tmp_731872;
word_5 field_ra;
word_64 tmp_731874;
word_8 field_imm;
tmp_731874 = 255;
field_imm = 255;
/* commit */
{
tmp_731872 = genfunc_tmp_897572();
goto next_tmp_897595;
next_tmp_897595:
goto tmp_897594;
tmp_897594:
}
tmp_731871 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731871;
field_ra = tmp_731872;
emit(COMPOSE_AND_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731872);
/* can fail: NIL   num insns: 3 */
}
done_tmp_897630:
return tmp_731862;
}
reg_t genfunc_tmp_897572 (void) {
reg_t tmp_731876;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_897560;
field_rb = 31;
/* commit */
tmp_731669 = ref_gpr_reg_for_reading(0 + 0);
tmp_731668 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897571;
fail_tmp_897560:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_897562 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_897562 >> 8) == 0)
field_imm = tmp_897562;
else goto fail_tmp_897561;
}
/* commit */
tmp_731665 = ref_gpr_reg_for_reading(0 + 0);
tmp_731664 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897571;
fail_tmp_897561:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_897568;
field_rb = 31;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + 0);
tmp_731086 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897571;
fail_tmp_897568:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_897570 = tmp_731085;
if ((tmp_897570 >> 8) == 0)
field_imm = tmp_897570;
else goto fail_tmp_897569;
}
/* commit */
tmp_731083 = ref_gpr_reg_for_reading(0 + 0);
tmp_731082 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897571;
fail_tmp_897569:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + 0);
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 2 */
}
done_tmp_897571:
return tmp_731876;
}
reg_t genfunc_tmp_897514 (void) {
reg_t tmp_731854;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 18446744073709551360;
{
word_64 tmp_897492 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_897492 >> 8) == 0)
field_imm = tmp_897492;
else goto fail_tmp_897491;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + 0);
tmp_731857 = tmp_731854 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897513;
fail_tmp_897491:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 18446744073709551360;
{
word_64 tmp_897511 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_897511))
field_imm = inv_maskmask(8, tmp_897511);
else goto fail_tmp_897510;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + 0);
tmp_731074 = tmp_731854 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897513;
fail_tmp_897510:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 18446744073709551360;
field_imm = 254;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + 0);
tmp_731066 = tmp_731854 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_897513:
return tmp_731854;
}
void genfunc_tmp_897461 (void) {
/* BIS */
{
word_5 tmp_731853;
word_5 field_rc;
word_5 tmp_731854;
word_5 field_ra;
word_5 tmp_731856;
word_5 field_rb;
/* commit */
{
tmp_731854 = genfunc_tmp_897292();
goto next_tmp_897439;
next_tmp_897439:
goto tmp_897438;
tmp_897438:
}
{
tmp_731856 = genfunc_tmp_897412();
goto next_tmp_897442;
next_tmp_897442:
goto tmp_897441;
tmp_897441:
}
tmp_731853 = ref_gpr_reg_for_writing(0 + 0);
field_rc = tmp_731853;
field_ra = tmp_731854;
field_rb = tmp_731856;
emit(COMPOSE_BIS(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731853);
unref_gpr_reg(tmp_731856);
unref_gpr_reg(tmp_731854);
/* can fail: NIL   num insns: 4 */
}
done_tmp_897460:
}
reg_t genfunc_tmp_897423 (void) {
reg_t tmp_731898;
/* BIS */
{
word_5 tmp_731853;
word_5 field_rc;
word_5 tmp_731854;
word_5 field_ra;
word_5 tmp_731856;
word_5 field_rb;
/* commit */
{
tmp_731854 = genfunc_tmp_897292();
goto next_tmp_897256;
next_tmp_897256:
goto tmp_897255;
tmp_897255:
}
{
tmp_731856 = genfunc_tmp_897412();
goto next_tmp_897295;
next_tmp_897295:
goto tmp_897294;
tmp_897294:
}
tmp_731853 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731853;
field_ra = tmp_731854;
field_rb = tmp_731856;
emit(COMPOSE_BIS(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731856);
unref_gpr_reg(tmp_731854);
/* can fail: NIL   num insns: 4 */
}
done_tmp_897422:
return tmp_731898;
}
reg_t genfunc_tmp_897412 (void) {
reg_t tmp_731856;
/* EXTQH_IMM */
{
word_5 tmp_731614;
word_5 field_rc;
word_5 tmp_731615;
word_5 field_ra;
word_64 tmp_731617;
word_8 field_imm;
tmp_731617 = 0;
{
word_64 tmp_897310 = ((64 - tmp_731617) & 0xFFFFFFFFFFFFFFFF);
if (tmp_897310 % 8 == 0)
{
word_64 tmp_897311 = (tmp_897310 / 8);
if ((tmp_897311 & 7) == tmp_897311)
{
word_64 tmp_897312 = tmp_897311;
if ((tmp_897312 >> 8) == 0)
field_imm = tmp_897312;
else goto fail_tmp_897309;
}
else goto fail_tmp_897309;
}
else goto fail_tmp_897309;
}
/* commit */
{
tmp_731615 = genfunc_tmp_897390();
goto next_tmp_897314;
next_tmp_897314:
goto tmp_897313;
tmp_897313:
}
tmp_731614 = tmp_731856 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731614;
field_ra = tmp_731615;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731615);
/* can fail: T   num insns: 2 */
}
goto done_tmp_897411;
fail_tmp_897309:
/* SLL */
{
word_5 tmp_731176;
word_5 field_rc;
word_5 tmp_731177;
word_5 field_ra;
word_5 field_rb;
field_rb = 31;
/* commit */
{
tmp_731177 = genfunc_tmp_897390();
goto next_tmp_897404;
next_tmp_897404:
goto tmp_897403;
tmp_897403:
}
tmp_731176 = tmp_731856 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731176;
field_ra = tmp_731177;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731177);
/* can fail: NIL   num insns: 2 */
}
done_tmp_897411:
return tmp_731856;
}
reg_t genfunc_tmp_897390 (void) {
reg_t tmp_731615;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 255;
{
word_64 tmp_897366 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_897366 >> 8) == 0)
field_imm = tmp_897366;
else goto fail_tmp_897365;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + 0);
tmp_731857 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897389;
fail_tmp_897365:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 255;
{
word_64 tmp_897387 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_897387))
field_imm = inv_maskmask(8, tmp_897387);
else goto fail_tmp_897386;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + 0);
tmp_731074 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897389;
fail_tmp_897386:
/* AND_IMM */
{
word_5 tmp_731871;
word_5 field_rc;
word_5 tmp_731872;
word_5 field_ra;
word_64 tmp_731874;
word_8 field_imm;
tmp_731874 = 255;
field_imm = 255;
/* commit */
tmp_731872 = ref_gpr_reg_for_reading(0 + 0);
tmp_731871 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731871;
field_ra = tmp_731872;
emit(COMPOSE_AND_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731872);
/* can fail: NIL   num insns: 1 */
}
done_tmp_897389:
return tmp_731615;
}
reg_t genfunc_tmp_897363 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 255;
{
word_64 tmp_897341 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_897341 >> 8) == 0)
field_imm = tmp_897341;
else goto fail_tmp_897340;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + 0);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897362;
fail_tmp_897340:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 255;
{
word_64 tmp_897360 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_897360))
field_imm = inv_maskmask(8, tmp_897360);
else goto fail_tmp_897359;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + 0);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897362;
fail_tmp_897359:
/* AND_IMM */
{
word_5 tmp_731871;
word_5 field_rc;
word_5 tmp_731872;
word_5 field_ra;
word_64 tmp_731874;
word_8 field_imm;
tmp_731874 = 255;
field_imm = 255;
/* commit */
tmp_731872 = ref_gpr_reg_for_reading(0 + 0);
tmp_731871 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731871;
field_ra = tmp_731872;
emit(COMPOSE_AND_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731872);
/* can fail: NIL   num insns: 1 */
}
done_tmp_897362:
return tmp_731862;
}
reg_t genfunc_tmp_897292 (void) {
reg_t tmp_731854;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 18446744073709551360;
{
word_64 tmp_897270 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_897270 >> 8) == 0)
field_imm = tmp_897270;
else goto fail_tmp_897269;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + 0);
tmp_731857 = tmp_731854 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897291;
fail_tmp_897269:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 18446744073709551360;
{
word_64 tmp_897289 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_897289))
field_imm = inv_maskmask(8, tmp_897289);
else goto fail_tmp_897288;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + 0);
tmp_731074 = tmp_731854 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897291;
fail_tmp_897288:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 18446744073709551360;
field_imm = 254;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + 0);
tmp_731066 = tmp_731854 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_897291:
return tmp_731854;
}
