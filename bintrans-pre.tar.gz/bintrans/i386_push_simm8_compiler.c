#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compile_push_simm8_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 )
{
genfunc_tmp_887193();
goto next_tmp_887058;
next_tmp_887058:
goto finish_tmp_887057;
finish_tmp_887057:
}
if (1 )
{
genfunc_tmp_887326();
goto next_tmp_887196;
next_tmp_887196:
goto finish_tmp_887195;
finish_tmp_887195:
}
}
void genfunc_tmp_887326 (void) {
/* SUBL_IMM */
{
word_5 tmp_731114;
word_5 field_rc;
word_5 tmp_731115;
word_5 field_ra;
word_32 tmp_731117;
word_8 field_imm;
tmp_731117 = 4;
field_imm = 4;
/* commit */
tmp_731115 = ref_gpr_reg_for_reading(0 + 4);
tmp_731114 = ref_gpr_reg_for_writing(0 + 4);
field_rc = tmp_731114;
field_ra = tmp_731115;
emit(COMPOSE_SUBL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731114);
unref_gpr_reg(tmp_731115);
/* can fail: NIL   num insns: 1 */
}
done_tmp_887325:
}
reg_t genfunc_tmp_887276 (void) {
reg_t tmp_731906;
/* SUBL_IMM */
{
word_5 tmp_731114;
word_5 field_rc;
word_5 tmp_731115;
word_5 field_ra;
word_32 tmp_731117;
word_8 field_imm;
tmp_731117 = 4;
field_imm = 4;
/* commit */
tmp_731115 = ref_gpr_reg_for_reading(0 + 4);
tmp_731114 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731114;
field_ra = tmp_731115;
emit(COMPOSE_SUBL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731115);
/* can fail: NIL   num insns: 1 */
}
done_tmp_887275:
return tmp_731906;
}
reg_t genfunc_tmp_887239 (void) {
reg_t tmp_731898;
/* SUBL_IMM */
{
word_5 tmp_731114;
word_5 field_rc;
word_5 tmp_731115;
word_5 field_ra;
word_32 tmp_731117;
word_8 field_imm;
tmp_731117 = 4;
field_imm = 4;
/* commit */
tmp_731115 = ref_gpr_reg_for_reading(0 + 4);
tmp_731114 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731114;
field_ra = tmp_731115;
emit(COMPOSE_SUBL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731115);
/* can fail: NIL   num insns: 1 */
}
done_tmp_887238:
return tmp_731898;
}
void genfunc_tmp_887193 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)) goto fail_tmp_887184;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_887182();
goto next_tmp_887186;
next_tmp_887186:
goto tmp_887185;
tmp_887185:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 3 */
}
goto done_tmp_887192;
fail_tmp_887184:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8)) goto fail_tmp_887188;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_887182();
goto next_tmp_887190;
next_tmp_887190:
goto tmp_887189;
tmp_887189:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 3 */
}
goto done_tmp_887192;
fail_tmp_887188:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_887182();
goto next_tmp_887061;
next_tmp_887061:
goto tmp_887060;
tmp_887060:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_887192:
}
reg_t genfunc_tmp_887182 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_887149 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_887149 >> 8) == 0)
field_imm = tmp_887149;
else goto fail_tmp_887148;
}
/* commit */
{
tmp_731858 = genfunc_tmp_887093();
goto next_tmp_887151;
next_tmp_887151:
goto tmp_887150;
tmp_887150:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_887181;
fail_tmp_887148:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_887173 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_887173))
field_imm = inv_maskmask(8, tmp_887173);
else goto fail_tmp_887172;
}
/* commit */
{
tmp_731075 = genfunc_tmp_887093();
goto next_tmp_887175;
next_tmp_887175:
goto tmp_887174;
tmp_887174:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_887181;
fail_tmp_887172:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_887093();
goto next_tmp_887179;
next_tmp_887179:
goto tmp_887178;
tmp_887178:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_887181:
return tmp_731142;
}
reg_t genfunc_tmp_887146 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_887115 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_887115 >> 8) == 0)
field_imm = tmp_887115;
else goto fail_tmp_887114;
}
/* commit */
{
tmp_731858 = genfunc_tmp_887093();
goto next_tmp_887117;
next_tmp_887117:
goto tmp_887116;
tmp_887116:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_887145;
fail_tmp_887114:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_887137 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_887137))
field_imm = inv_maskmask(8, tmp_887137);
else goto fail_tmp_887136;
}
/* commit */
{
tmp_731075 = genfunc_tmp_887093();
goto next_tmp_887139;
next_tmp_887139:
goto tmp_887138;
tmp_887138:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_887145;
fail_tmp_887136:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_887093();
goto next_tmp_887143;
next_tmp_887143:
goto tmp_887142;
tmp_887142:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_887145:
return tmp_731862;
}
reg_t genfunc_tmp_887093 (void) {
reg_t tmp_731876;
/* SUBQ_IMM */
{
word_5 tmp_731106;
word_5 field_rc;
word_5 tmp_731107;
word_5 field_ra;
word_64 tmp_731109;
word_8 field_imm;
tmp_731109 = 4;
field_imm = 4;
/* commit */
tmp_731107 = ref_gpr_reg_for_reading(0 + 4);
tmp_731106 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731106;
field_ra = tmp_731107;
emit(COMPOSE_SUBQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731107);
/* can fail: NIL   num insns: 1 */
}
done_tmp_887092:
return tmp_731876;
}
