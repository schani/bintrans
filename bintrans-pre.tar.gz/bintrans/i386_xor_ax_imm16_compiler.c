#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compiler_tmp_898348 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_898338 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_898343 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_898347 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_898334 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_898323 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_898333 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_898328 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_898331 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_898319 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_898315 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_898314 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_898348 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 6 6 T)
*/
{
{
reg_t tmp_898350, tmp_898351, tmp_898349;
rhs_func(&tmp_898350, -1, env);
emit(COMPOSE_SLL_IMM(tmp_898350, 63, tmp_898350));
emit(COMPOSE_SRL_IMM(tmp_898350, 57, tmp_898350));
tmp_898351 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_898351, -1);
emit(COMPOSE_SLL_IMM(tmp_898351, 63, tmp_898351));
emit(COMPOSE_SRL_IMM(tmp_898351, 57, tmp_898351));
tmp_898349 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_898349, tmp_898351, tmp_898349));
unref_integer_reg(tmp_898351);
emit(COMPOSE_BIS(tmp_898349, tmp_898350, tmp_898349));
unref_integer_reg(tmp_898350);
unref_integer_reg(tmp_898349);
}
}

void compiler_tmp_898338 (reg_t *target, int foreign_target, void **env)
/*
(IF (= (SUBREGISTER EAX GPR (INTEGER 0) 0 15 T) (INTEGER 0)) (INTEGER 1)
 (INTEGER 0))
*/
{
{
label_t tmp_898340 = alloc_label(), tmp_898341 = alloc_label(), tmp_898342 = alloc_label();
reg_t tmp_898339;
compiler_tmp_898343(tmp_898340, tmp_898341, env);

tmp_898339 = ref_integer_reg_for_writing(-1);
emit_label(tmp_898340);
push_alloc();
compiler_tmp_898333(&tmp_898339, tmp_898339 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_898342);
emit_label(tmp_898341);
push_alloc();
compiler_tmp_898314(&tmp_898339, tmp_898339 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_898342);
free_label(tmp_898340);
free_label(tmp_898341);
free_label(tmp_898342);
if (foreign_target == -1)
*target = tmp_898339;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_898339, *target));
unref_integer_reg(tmp_898339);
}

}
}

void compiler_tmp_898343 (label_t true_label, label_t false_label, void **env)
/*
(= (SUBREGISTER EAX GPR (INTEGER 0) 0 15 T) (INTEGER 0))
*/
{
{
reg_t tmp_898344, tmp_898345, tmp_898346;
compiler_tmp_898331(&tmp_898344, -1, env);
compiler_tmp_898347(&tmp_898345, -1, env);
tmp_898346 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_CMPEQ(tmp_898344, tmp_898345, tmp_898346));
unref_integer_reg(tmp_898344);
unref_integer_reg(tmp_898345);
emit_branch(COMPOSE_BEQ(tmp_898346, 0), false_label);
unref_integer_reg(tmp_898346);
emit_branch(COMPOSE_BR(31, 0), true_label);
}
}

void compiler_tmp_898347 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_898334 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 7 7 T)
*/
{
{
reg_t tmp_898336, tmp_898337, tmp_898335;
rhs_func(&tmp_898336, -1, env);
emit(COMPOSE_SLL_IMM(tmp_898336, 63, tmp_898336));
emit(COMPOSE_SRL_IMM(tmp_898336, 56, tmp_898336));
tmp_898337 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_898337, -1);
emit(COMPOSE_SLL_IMM(tmp_898337, 63, tmp_898337));
emit(COMPOSE_SRL_IMM(tmp_898337, 56, tmp_898337));
tmp_898335 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_898335, tmp_898337, tmp_898335));
unref_integer_reg(tmp_898337);
emit(COMPOSE_BIS(tmp_898335, tmp_898336, tmp_898335));
unref_integer_reg(tmp_898336);
unref_integer_reg(tmp_898335);
}
}

void compiler_tmp_898323 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (BIT-SET-P (SUBREGISTER EAX GPR (INTEGER 0) 0 15 T)
  (- (INTEGER 16) (INTEGER 1)))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_898325 = alloc_label(), tmp_898326 = alloc_label(), tmp_898327 = alloc_label();
reg_t tmp_898324;
compiler_tmp_898328(tmp_898325, tmp_898326, env);

tmp_898324 = ref_integer_reg_for_writing(-1);
emit_label(tmp_898325);
push_alloc();
compiler_tmp_898333(&tmp_898324, tmp_898324 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_898327);
emit_label(tmp_898326);
push_alloc();
compiler_tmp_898314(&tmp_898324, tmp_898324 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_898327);
free_label(tmp_898325);
free_label(tmp_898326);
free_label(tmp_898327);
if (foreign_target == -1)
*target = tmp_898324;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_898324, *target));
unref_integer_reg(tmp_898324);
}

}
}

void compiler_tmp_898333 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 1)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 1);
}

void compiler_tmp_898328 (label_t true_label, label_t false_label, void **env)
/*
(BIT-SET-P (SUBREGISTER EAX GPR (INTEGER 0) 0 15 T)
 (- (INTEGER 16) (INTEGER 1)))
*/
{
{
reg_t tmp_898329, tmp_898330;
compiler_tmp_898331(&tmp_898329, -1, env);
tmp_898330 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_SRL_IMM(tmp_898329, (16 - 1), tmp_898330));
unref_integer_reg(tmp_898329);
emit_branch(COMPOSE_BLBS(tmp_898330, 0), true_label);
unref_integer_reg(tmp_898330);
emit_branch(COMPOSE_BR(31, 0), false_label);
}
}

void compiler_tmp_898331 (reg_t *target, int foreign_target, void **env)
/*
(SUBREGISTER EAX GPR (INTEGER 0) 0 15 T)
*/
{
{
reg_t tmp_898332 = ref_integer_reg_for_reading(0);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_SLL_IMM(tmp_898332, 48, *target));
unref_integer_reg(tmp_898332);
emit(COMPOSE_SRL_IMM(*target, 48, *target));
}
}

void compiler_tmp_898319 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 11 11 T)
*/
{
{
reg_t tmp_898321, tmp_898322, tmp_898320;
rhs_func(&tmp_898321, -1, env);
emit(COMPOSE_SLL_IMM(tmp_898321, 63, tmp_898321));
emit(COMPOSE_SRL_IMM(tmp_898321, 52, tmp_898321));
tmp_898322 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_898322, -1);
emit(COMPOSE_SLL_IMM(tmp_898322, 63, tmp_898322));
emit(COMPOSE_SRL_IMM(tmp_898322, 52, tmp_898322));
tmp_898320 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_898320, tmp_898322, tmp_898320));
unref_integer_reg(tmp_898322);
emit(COMPOSE_BIS(tmp_898320, tmp_898321, tmp_898320));
unref_integer_reg(tmp_898321);
unref_integer_reg(tmp_898320);
}
}

void compiler_tmp_898315 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 0 0 T)
*/
{
{
reg_t tmp_898317, tmp_898318, tmp_898316;
rhs_func(&tmp_898317, -1, env);
emit(COMPOSE_SLL_IMM(tmp_898317, 63, tmp_898317));
emit(COMPOSE_SRL_IMM(tmp_898317, 63, tmp_898317));
tmp_898318 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_898318, -1);
emit(COMPOSE_SLL_IMM(tmp_898318, 63, tmp_898318));
emit(COMPOSE_SRL_IMM(tmp_898318, 63, tmp_898318));
tmp_898316 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_898316, tmp_898318, tmp_898316));
unref_integer_reg(tmp_898318);
emit(COMPOSE_BIS(tmp_898316, tmp_898317, tmp_898316));
unref_integer_reg(tmp_898317);
unref_integer_reg(tmp_898316);
}
}

void compiler_tmp_898314 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compile_xor_ax_imm16_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 && (imm16 == 0))
{
genfunc_tmp_898019();
goto next_tmp_897800;
next_tmp_897800:
goto finish_tmp_897799;
finish_tmp_897799:
}
if (1 && (!(imm16 == 0)))
{
genfunc_tmp_898312();
goto next_tmp_898022;
next_tmp_898022:
goto finish_tmp_898021;
finish_tmp_898021:
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_898314;
killed |= 0x1;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_898315(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_898314;
killed |= 0x800;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_898319(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_898323;
killed |= 0x80;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_898334(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_898338;
killed |= 0x40;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_898348(rhs_func, env);
}
}
}
void genfunc_tmp_898312 (void) {
/* BIS */
{
word_5 tmp_731853;
word_5 field_rc;
word_5 tmp_731854;
word_5 field_ra;
word_5 tmp_731856;
word_5 field_rb;
/* commit */
{
tmp_731854 = genfunc_tmp_898072();
goto next_tmp_898290;
next_tmp_898290:
goto tmp_898289;
tmp_898289:
}
{
tmp_731856 = genfunc_tmp_898263();
goto next_tmp_898293;
next_tmp_898293:
goto tmp_898292;
tmp_898292:
}
tmp_731853 = ref_gpr_reg_for_writing(0 + 0);
field_rc = tmp_731853;
field_ra = tmp_731854;
field_rb = tmp_731856;
emit(COMPOSE_BIS(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731853);
unref_gpr_reg(tmp_731856);
unref_gpr_reg(tmp_731854);
/* can fail: NIL   num insns: 6 */
}
done_tmp_898311:
}
reg_t genfunc_tmp_898274 (void) {
reg_t tmp_731898;
/* BIS */
{
word_5 tmp_731853;
word_5 field_rc;
word_5 tmp_731854;
word_5 field_ra;
word_5 tmp_731856;
word_5 field_rb;
/* commit */
{
tmp_731854 = genfunc_tmp_898072();
goto next_tmp_898036;
next_tmp_898036:
goto tmp_898035;
tmp_898035:
}
{
tmp_731856 = genfunc_tmp_898263();
goto next_tmp_898075;
next_tmp_898075:
goto tmp_898074;
tmp_898074:
}
tmp_731853 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731853;
field_ra = tmp_731854;
field_rb = tmp_731856;
emit(COMPOSE_BIS(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731856);
unref_gpr_reg(tmp_731854);
/* can fail: NIL   num insns: 6 */
}
done_tmp_898273:
return tmp_731898;
}
reg_t genfunc_tmp_898263 (void) {
reg_t tmp_731856;
/* EXTQH_IMM */
{
word_5 tmp_731614;
word_5 field_rc;
word_5 tmp_731615;
word_5 field_ra;
word_64 tmp_731617;
word_8 field_imm;
tmp_731617 = 0;
{
word_64 tmp_898090 = ((64 - tmp_731617) & 0xFFFFFFFFFFFFFFFF);
if (tmp_898090 % 8 == 0)
{
word_64 tmp_898091 = (tmp_898090 / 8);
if ((tmp_898091 & 7) == tmp_898091)
{
word_64 tmp_898092 = tmp_898091;
if ((tmp_898092 >> 8) == 0)
field_imm = tmp_898092;
else goto fail_tmp_898089;
}
else goto fail_tmp_898089;
}
else goto fail_tmp_898089;
}
/* commit */
{
tmp_731615 = genfunc_tmp_898241();
goto next_tmp_898094;
next_tmp_898094:
goto tmp_898093;
tmp_898093:
}
tmp_731614 = tmp_731856 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731614;
field_ra = tmp_731615;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731615);
/* can fail: T   num insns: 4 */
}
goto done_tmp_898262;
fail_tmp_898089:
/* SLL */
{
word_5 tmp_731176;
word_5 field_rc;
word_5 tmp_731177;
word_5 field_ra;
word_5 field_rb;
field_rb = 31;
/* commit */
{
tmp_731177 = genfunc_tmp_898241();
goto next_tmp_898255;
next_tmp_898255:
goto tmp_898254;
tmp_898254:
}
tmp_731176 = tmp_731856 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731176;
field_ra = tmp_731177;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731177);
/* can fail: NIL   num insns: 4 */
}
done_tmp_898262:
return tmp_731856;
}
reg_t genfunc_tmp_898241 (void) {
reg_t tmp_731615;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((word_64)imm16)) goto fail_tmp_898194;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_897948();
goto next_tmp_898196;
next_tmp_898196:
goto tmp_898195;
tmp_898195:
}
tmp_731668 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 2 */
}
goto done_tmp_898240;
fail_tmp_898194:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((word_64)imm16);
{
word_64 tmp_898199 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_898199 >> 8) == 0)
field_imm = tmp_898199;
else goto fail_tmp_898198;
}
/* commit */
{
tmp_731665 = genfunc_tmp_897948();
goto next_tmp_898201;
next_tmp_898201:
goto tmp_898200;
tmp_898200:
}
tmp_731664 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 2 */
}
goto done_tmp_898240;
fail_tmp_898198:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((word_64)imm16)) goto fail_tmp_898218;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_897948();
goto next_tmp_898220;
next_tmp_898220:
goto tmp_898219;
tmp_898219:
}
tmp_731086 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 2 */
}
goto done_tmp_898240;
fail_tmp_898218:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((word_64)imm16);
{
word_64 tmp_898223 = tmp_731085;
if ((tmp_898223 >> 8) == 0)
field_imm = tmp_898223;
else goto fail_tmp_898222;
}
/* commit */
{
tmp_731083 = genfunc_tmp_897948();
goto next_tmp_898225;
next_tmp_898225:
goto tmp_898224;
tmp_898224:
}
tmp_731082 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 2 */
}
goto done_tmp_898240;
fail_tmp_898222:
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 65535;
{
word_64 tmp_898186 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_898186 >> 8) == 0)
field_imm = tmp_898186;
else goto fail_tmp_898185;
}
/* commit */
{
tmp_731858 = genfunc_tmp_898130();
goto next_tmp_898188;
next_tmp_898188:
goto tmp_898187;
tmp_898187:
}
tmp_731857 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_898240;
fail_tmp_898185:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 65535;
{
word_64 tmp_898232 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_898232))
field_imm = inv_maskmask(8, tmp_898232);
else goto fail_tmp_898231;
}
/* commit */
{
tmp_731075 = genfunc_tmp_898130();
goto next_tmp_898234;
next_tmp_898234:
goto tmp_898233;
tmp_898233:
}
tmp_731074 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_898240;
fail_tmp_898231:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_897948();
goto next_tmp_898216;
next_tmp_898216:
goto tmp_898215;
tmp_898215:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((word_64)imm16));
tmp_731086 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 3 */
}
done_tmp_898240:
return tmp_731615;
}
reg_t genfunc_tmp_898183 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 65535;
{
word_64 tmp_898152 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_898152 >> 8) == 0)
field_imm = tmp_898152;
else goto fail_tmp_898151;
}
/* commit */
{
tmp_731858 = genfunc_tmp_898130();
goto next_tmp_898154;
next_tmp_898154:
goto tmp_898153;
tmp_898153:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_898182;
fail_tmp_898151:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 65535;
{
word_64 tmp_898174 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_898174))
field_imm = inv_maskmask(8, tmp_898174);
else goto fail_tmp_898173;
}
/* commit */
{
tmp_731075 = genfunc_tmp_898130();
goto next_tmp_898176;
next_tmp_898176:
goto tmp_898175;
tmp_898175:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_898182;
fail_tmp_898173:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 65535;
field_imm = 3;
/* commit */
{
tmp_731067 = genfunc_tmp_898130();
goto next_tmp_898180;
next_tmp_898180:
goto tmp_898179;
tmp_898179:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_898182:
return tmp_731862;
}
reg_t genfunc_tmp_898130 (void) {
reg_t tmp_731876;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm16 & 0x8000) ? ((word_64)imm16 | 0xFFFFFFFFFFFF0000) : (word_64)imm16)) goto fail_tmp_898118;
field_rb = 31;
/* commit */
tmp_731669 = ref_gpr_reg_for_reading(0 + 0);
tmp_731668 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898129;
fail_tmp_898118:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm16 & 0x8000) ? ((word_64)imm16 | 0xFFFFFFFFFFFF0000) : (word_64)imm16);
{
word_64 tmp_898120 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_898120 >> 8) == 0)
field_imm = tmp_898120;
else goto fail_tmp_898119;
}
/* commit */
tmp_731665 = ref_gpr_reg_for_reading(0 + 0);
tmp_731664 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898129;
fail_tmp_898119:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm16 & 0x8000) ? ((word_64)imm16 | 0xFFFFFFFFFFFF0000) : (word_64)imm16)) goto fail_tmp_898126;
field_rb = 31;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + 0);
tmp_731086 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898129;
fail_tmp_898126:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm16 & 0x8000) ? ((word_64)imm16 | 0xFFFFFFFFFFFF0000) : (word_64)imm16);
{
word_64 tmp_898128 = tmp_731085;
if ((tmp_898128 >> 8) == 0)
field_imm = tmp_898128;
else goto fail_tmp_898127;
}
/* commit */
tmp_731083 = ref_gpr_reg_for_reading(0 + 0);
tmp_731082 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898129;
fail_tmp_898127:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + 0);
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm16 & 0x8000) ? ((word_64)imm16 | 0xFFFFFFFFFFFF0000) : (word_64)imm16));
tmp_731086 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 2 */
}
done_tmp_898129:
return tmp_731876;
}
reg_t genfunc_tmp_898072 (void) {
reg_t tmp_731854;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 18446744073709486080;
{
word_64 tmp_898050 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_898050 >> 8) == 0)
field_imm = tmp_898050;
else goto fail_tmp_898049;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + 0);
tmp_731857 = tmp_731854 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898071;
fail_tmp_898049:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 18446744073709486080;
{
word_64 tmp_898069 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_898069))
field_imm = inv_maskmask(8, tmp_898069);
else goto fail_tmp_898068;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + 0);
tmp_731074 = tmp_731854 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898071;
fail_tmp_898068:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 18446744073709486080;
field_imm = 252;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + 0);
tmp_731066 = tmp_731854 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_898071:
return tmp_731854;
}
void genfunc_tmp_898019 (void) {
/* BIS */
{
word_5 tmp_731853;
word_5 field_rc;
word_5 tmp_731854;
word_5 field_ra;
word_5 tmp_731856;
word_5 field_rb;
/* commit */
{
tmp_731854 = genfunc_tmp_897850();
goto next_tmp_897997;
next_tmp_897997:
goto tmp_897996;
tmp_897996:
}
{
tmp_731856 = genfunc_tmp_897970();
goto next_tmp_898000;
next_tmp_898000:
goto tmp_897999;
tmp_897999:
}
tmp_731853 = ref_gpr_reg_for_writing(0 + 0);
field_rc = tmp_731853;
field_ra = tmp_731854;
field_rb = tmp_731856;
emit(COMPOSE_BIS(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731853);
unref_gpr_reg(tmp_731856);
unref_gpr_reg(tmp_731854);
/* can fail: NIL   num insns: 4 */
}
done_tmp_898018:
}
reg_t genfunc_tmp_897981 (void) {
reg_t tmp_731898;
/* BIS */
{
word_5 tmp_731853;
word_5 field_rc;
word_5 tmp_731854;
word_5 field_ra;
word_5 tmp_731856;
word_5 field_rb;
/* commit */
{
tmp_731854 = genfunc_tmp_897850();
goto next_tmp_897814;
next_tmp_897814:
goto tmp_897813;
tmp_897813:
}
{
tmp_731856 = genfunc_tmp_897970();
goto next_tmp_897853;
next_tmp_897853:
goto tmp_897852;
tmp_897852:
}
tmp_731853 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731853;
field_ra = tmp_731854;
field_rb = tmp_731856;
emit(COMPOSE_BIS(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731856);
unref_gpr_reg(tmp_731854);
/* can fail: NIL   num insns: 4 */
}
done_tmp_897980:
return tmp_731898;
}
reg_t genfunc_tmp_897970 (void) {
reg_t tmp_731856;
/* EXTQH_IMM */
{
word_5 tmp_731614;
word_5 field_rc;
word_5 tmp_731615;
word_5 field_ra;
word_64 tmp_731617;
word_8 field_imm;
tmp_731617 = 0;
{
word_64 tmp_897868 = ((64 - tmp_731617) & 0xFFFFFFFFFFFFFFFF);
if (tmp_897868 % 8 == 0)
{
word_64 tmp_897869 = (tmp_897868 / 8);
if ((tmp_897869 & 7) == tmp_897869)
{
word_64 tmp_897870 = tmp_897869;
if ((tmp_897870 >> 8) == 0)
field_imm = tmp_897870;
else goto fail_tmp_897867;
}
else goto fail_tmp_897867;
}
else goto fail_tmp_897867;
}
/* commit */
{
tmp_731615 = genfunc_tmp_897948();
goto next_tmp_897872;
next_tmp_897872:
goto tmp_897871;
tmp_897871:
}
tmp_731614 = tmp_731856 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731614;
field_ra = tmp_731615;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731615);
/* can fail: T   num insns: 2 */
}
goto done_tmp_897969;
fail_tmp_897867:
/* SLL */
{
word_5 tmp_731176;
word_5 field_rc;
word_5 tmp_731177;
word_5 field_ra;
word_5 field_rb;
field_rb = 31;
/* commit */
{
tmp_731177 = genfunc_tmp_897948();
goto next_tmp_897962;
next_tmp_897962:
goto tmp_897961;
tmp_897961:
}
tmp_731176 = tmp_731856 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731176;
field_ra = tmp_731177;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731177);
/* can fail: NIL   num insns: 2 */
}
done_tmp_897969:
return tmp_731856;
}
reg_t genfunc_tmp_897948 (void) {
reg_t tmp_731615;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 65535;
{
word_64 tmp_897924 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_897924 >> 8) == 0)
field_imm = tmp_897924;
else goto fail_tmp_897923;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + 0);
tmp_731857 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897947;
fail_tmp_897923:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 65535;
{
word_64 tmp_897945 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_897945))
field_imm = inv_maskmask(8, tmp_897945);
else goto fail_tmp_897944;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + 0);
tmp_731074 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897947;
fail_tmp_897944:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 65535;
field_imm = 3;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + 0);
tmp_731066 = tmp_731615 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_897947:
return tmp_731615;
}
reg_t genfunc_tmp_897921 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 65535;
{
word_64 tmp_897899 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_897899 >> 8) == 0)
field_imm = tmp_897899;
else goto fail_tmp_897898;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + 0);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897920;
fail_tmp_897898:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 65535;
{
word_64 tmp_897918 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_897918))
field_imm = inv_maskmask(8, tmp_897918);
else goto fail_tmp_897917;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + 0);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897920;
fail_tmp_897917:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 65535;
field_imm = 3;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + 0);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_897920:
return tmp_731862;
}
reg_t genfunc_tmp_897850 (void) {
reg_t tmp_731854;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 18446744073709486080;
{
word_64 tmp_897828 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_897828 >> 8) == 0)
field_imm = tmp_897828;
else goto fail_tmp_897827;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + 0);
tmp_731857 = tmp_731854 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897849;
fail_tmp_897827:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 18446744073709486080;
{
word_64 tmp_897847 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_897847))
field_imm = inv_maskmask(8, tmp_897847);
else goto fail_tmp_897846;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + 0);
tmp_731074 = tmp_731854 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_897849;
fail_tmp_897846:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 18446744073709486080;
field_imm = 252;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + 0);
tmp_731066 = tmp_731854 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_897849:
return tmp_731854;
}
