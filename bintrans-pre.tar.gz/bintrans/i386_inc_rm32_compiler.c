#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compiler_tmp_971195 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_971186 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_971191 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_971184 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_971174 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_971183 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_971182 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_971179 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_963215 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_963169 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963214 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963173 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963174 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963177 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963207 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963211 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963208 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963199 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963204 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963200 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963203 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963178 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963181 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963191 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963198 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963192 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963197 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963195 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963184 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963187 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963189 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963188 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963185 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963179 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_971195 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 6 6 T)
*/
{
{
reg_t tmp_971196;
rhs_func(&tmp_971196, 11, env);
emit(COMPOSE_AND_IMM(tmp_971196, 1, tmp_971196));
unref_integer_reg(tmp_971196);
}
}

void compiler_tmp_971186 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (=
  (CASE
   ((0 1 2)
    (MEM
     (CASE
      ((0)
       (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
        ((4)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))
        ((5) (FIELD DISP32 NIL NIL))))
      ((1)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
        ((4)
         (+ (SEX (FIELD DISP8 NIL NIL))
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0))))))))
      ((2)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
        ((4)
         (+ (FIELD DISP32 NIL NIL)
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0)))))))))))
   ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
  (INTEGER 0))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_971188 = alloc_label(), tmp_971189 = alloc_label(), tmp_971190 = alloc_label();
reg_t tmp_971187;
compiler_tmp_971191(tmp_971188, tmp_971189, env);

tmp_971187 = ref_integer_reg_for_writing(-1);
emit_label(tmp_971188);
push_alloc();
compiler_tmp_971182(&tmp_971187, tmp_971187 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_971190);
emit_label(tmp_971189);
push_alloc();
compiler_tmp_971183(&tmp_971187, tmp_971187 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_971190);
free_label(tmp_971188);
free_label(tmp_971189);
free_label(tmp_971190);
if (foreign_target == -1)
*target = tmp_971187;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_971187, *target));
unref_integer_reg(tmp_971187);
}

}
}

void compiler_tmp_971191 (label_t true_label, label_t false_label, void **env)
/*
(=
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (INTEGER 0))
*/
{
{
reg_t tmp_971192, tmp_971193, tmp_971194;
compiler_tmp_963173(&tmp_971192, -1, env);
compiler_tmp_963198(&tmp_971193, -1, env);
tmp_971194 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_CMPEQ(tmp_971192, tmp_971193, tmp_971194));
unref_integer_reg(tmp_971192);
unref_integer_reg(tmp_971193);
emit_branch(COMPOSE_BEQ(tmp_971194, 0), false_label);
unref_integer_reg(tmp_971194);
emit_branch(COMPOSE_BR(31, 0), true_label);
}
}

void compiler_tmp_971184 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 7 7 T)
*/
{
{
reg_t tmp_971185;
rhs_func(&tmp_971185, 12, env);
emit(COMPOSE_AND_IMM(tmp_971185, 1, tmp_971185));
unref_integer_reg(tmp_971185);
}
}

void compiler_tmp_971174 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (BIT-SET-P
  (CASE
   ((0 1 2)
    (MEM
     (CASE
      ((0)
       (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
        ((4)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))
        ((5) (FIELD DISP32 NIL NIL))))
      ((1)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
        ((4)
         (+ (SEX (FIELD DISP8 NIL NIL))
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0))))))))
      ((2)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
        ((4)
         (+ (FIELD DISP32 NIL NIL)
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0)))))))))))
   ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
  (- (INTEGER 32) (INTEGER 1)))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_971176 = alloc_label(), tmp_971177 = alloc_label(), tmp_971178 = alloc_label();
reg_t tmp_971175;
compiler_tmp_971179(tmp_971176, tmp_971177, env);

tmp_971175 = ref_integer_reg_for_writing(-1);
emit_label(tmp_971176);
push_alloc();
compiler_tmp_971182(&tmp_971175, tmp_971175 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_971178);
emit_label(tmp_971177);
push_alloc();
compiler_tmp_971183(&tmp_971175, tmp_971175 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_971178);
free_label(tmp_971176);
free_label(tmp_971177);
free_label(tmp_971178);
if (foreign_target == -1)
*target = tmp_971175;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_971175, *target));
unref_integer_reg(tmp_971175);
}

}
}

void compiler_tmp_971183 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_971182 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 1)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 1);
}

void compiler_tmp_971179 (label_t true_label, label_t false_label, void **env)
/*
(BIT-SET-P
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (- (INTEGER 32) (INTEGER 1)))
*/
{
{
reg_t tmp_971180, tmp_971181;
compiler_tmp_963173(&tmp_971180, -1, env);
tmp_971181 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_SRL_IMM(tmp_971180, (32 - 1), tmp_971181));
unref_integer_reg(tmp_971180);
emit_branch(COMPOSE_BLBS(tmp_971181, 0), true_label);
unref_integer_reg(tmp_971181);
emit_branch(COMPOSE_BR(31, 0), false_label);
}
}

void compiler_tmp_963215 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 11 11 T)
*/
{
{
reg_t tmp_963216;
rhs_func(&tmp_963216, 13, env);
emit(COMPOSE_AND_IMM(tmp_963216, 1, tmp_963216));
unref_integer_reg(tmp_963216);
}
}

void compiler_tmp_963169 (reg_t *target, int foreign_target, void **env)
/*
(+OVERFLOW
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (INTEGER 1))
*/
{
{
reg_t tmp_963170, tmp_963171, tmp_963172;
compiler_tmp_963173(&tmp_963170, -1, env);
compiler_tmp_963214(&tmp_963171, -1, env);
tmp_963172 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ADDQ(tmp_963170, tmp_963171, tmp_963172));
unref_integer_reg(tmp_963170);
unref_integer_reg(tmp_963171);
emit(COMPOSE_SRA_IMM(tmp_963172, 32, tmp_963172));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDQ_IMM(31, 1, *target));
emit(COMPOSE_CMOVEQ_IMM(tmp_963172, 0, *target));
emit(COMPOSE_NOT(tmp_963172, tmp_963172));
emit(COMPOSE_CMOVEQ_IMM(tmp_963172, 0, *target));
unref_integer_reg(tmp_963172);
}
}

void compiler_tmp_963214 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 1)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 1);
}

void compiler_tmp_963173 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2)
  (MEM
   (CASE
    ((0)
     (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
      ((4)
       (+
        (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
         ((5)
          (CASE ((0) (FIELD DISP32 NIL NIL))
           ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
        (CASE
         ((0 1 2 3 5 6 7)
          (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
           (ZEX (FIELD SCALE NIL NIL))))
         ((4) (INTEGER 0)))))
      ((5) (FIELD DISP32 NIL NIL))))
    ((1)
     (CASE
      ((0 1 2 3 5 6 7)
       (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
      ((4)
       (+ (SEX (FIELD DISP8 NIL NIL))
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0))))))))
    ((2)
     (CASE
      ((0 1 2 3 5 6 7)
       (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
      ((4)
       (+ (FIELD DISP32 NIL NIL)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))))))))
 ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
*/
{
switch (mod) {
case 0:
case 1:
case 2:
compiler_tmp_963174(&(*target), foreign_target, env);
break;
case 3:
compiler_tmp_963179(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_963174 (reg_t *target, int foreign_target, void **env)
/*
(MEM
 (CASE
  ((0)
   (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
    ((4)
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0)))))
    ((5) (FIELD DISP32 NIL NIL))))
  ((1)
   (CASE
    ((0 1 2 3 5 6 7)
     (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
    ((4)
     (+ (SEX (FIELD DISP8 NIL NIL))
      (+
       (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
        ((5)
         (CASE ((0) (FIELD DISP32 NIL NIL))
          ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
       (CASE
        ((0 1 2 3 5 6 7)
         (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
          (ZEX (FIELD SCALE NIL NIL))))
        ((4) (INTEGER 0))))))))
  ((2)
   (CASE
    ((0 1 2 3 5 6 7)
     (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
    ((4)
     (+ (FIELD DISP32 NIL NIL)
      (+
       (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
        ((5)
         (CASE ((0) (FIELD DISP32 NIL NIL))
          ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
       (CASE
        ((0 1 2 3 5 6 7)
         (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
          (ZEX (FIELD SCALE NIL NIL))))
        ((4) (INTEGER 0))))))))))
*/
{
{
reg_t tmp_963175, tmp_963176;
compiler_tmp_963177(&tmp_963175, -1, env);
#ifdef EMU_I386
tmp_963176 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ZAPNOT_IMM(tmp_963175, 15, tmp_963176));
unref_integer_reg(tmp_963175);
#else
tmp_963176 = tmp_963175;
#endif
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_mem_32(*target, tmp_963176);
unref_integer_reg(tmp_963176);
}
}

void compiler_tmp_963177 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0)
  (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
   ((4)
    (+
     (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
      ((5)
       (CASE ((0) (FIELD DISP32 NIL NIL))
        ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
     (CASE
      ((0 1 2 3 5 6 7)
       (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
        (ZEX (FIELD SCALE NIL NIL))))
      ((4) (INTEGER 0)))))
   ((5) (FIELD DISP32 NIL NIL))))
 ((1)
  (CASE
   ((0 1 2 3 5 6 7)
    (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
   ((4)
    (+ (SEX (FIELD DISP8 NIL NIL))
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0))))))))
 ((2)
  (CASE
   ((0 1 2 3 5 6 7)
    (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
   ((4)
    (+ (FIELD DISP32 NIL NIL)
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0)))))))))
*/
{
switch (mod) {
case 0:
compiler_tmp_963178(&(*target), foreign_target, env);
break;
case 1:
compiler_tmp_963199(&(*target), foreign_target, env);
break;
case 2:
compiler_tmp_963207(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_963207 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
 ((4)
  (+ (FIELD DISP32 NIL NIL)
   (+
    (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
     ((5)
      (CASE ((0) (FIELD DISP32 NIL NIL))
       ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
    (CASE
     ((0 1 2 3 5 6 7)
      (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
       (ZEX (FIELD SCALE NIL NIL))))
     ((4) (INTEGER 0)))))))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_963208(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_963211(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_963211 (reg_t *target, int foreign_target, void **env)
/*
(+ (FIELD DISP32 NIL NIL)
 (+
  (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
   ((5)
    (CASE ((0) (FIELD DISP32 NIL NIL))
     ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
  (CASE
   ((0 1 2 3 5 6 7)
    (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
     (ZEX (FIELD SCALE NIL NIL))))
   ((4) (INTEGER 0)))))
*/
{
{
reg_t tmp_963212, tmp_963213;
compiler_tmp_963188(&tmp_963212, -1, env);
compiler_tmp_963181(&tmp_963213, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_963212, tmp_963213, *target));
unref_integer_reg(tmp_963212);
unref_integer_reg(tmp_963213);
}
}

void compiler_tmp_963208 (reg_t *target, int foreign_target, void **env)
/*
(+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL))
*/
{
{
reg_t tmp_963209, tmp_963210;
compiler_tmp_963179(&tmp_963209, -1, env);
compiler_tmp_963188(&tmp_963210, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_963209, tmp_963210, *target));
unref_integer_reg(tmp_963209);
unref_integer_reg(tmp_963210);
}
}

void compiler_tmp_963199 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
 ((4)
  (+ (SEX (FIELD DISP8 NIL NIL))
   (+
    (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
     ((5)
      (CASE ((0) (FIELD DISP32 NIL NIL))
       ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
    (CASE
     ((0 1 2 3 5 6 7)
      (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
       (ZEX (FIELD SCALE NIL NIL))))
     ((4) (INTEGER 0)))))))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_963200(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_963204(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_963204 (reg_t *target, int foreign_target, void **env)
/*
(+ (SEX (FIELD DISP8 NIL NIL))
 (+
  (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
   ((5)
    (CASE ((0) (FIELD DISP32 NIL NIL))
     ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
  (CASE
   ((0 1 2 3 5 6 7)
    (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
     (ZEX (FIELD SCALE NIL NIL))))
   ((4) (INTEGER 0)))))
*/
{
{
reg_t tmp_963205, tmp_963206;
compiler_tmp_963203(&tmp_963205, -1, env);
compiler_tmp_963181(&tmp_963206, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_963205, tmp_963206, *target));
unref_integer_reg(tmp_963205);
unref_integer_reg(tmp_963206);
}
}

void compiler_tmp_963200 (reg_t *target, int foreign_target, void **env)
/*
(+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL)))
*/
{
{
reg_t tmp_963201, tmp_963202;
compiler_tmp_963179(&tmp_963201, -1, env);
compiler_tmp_963203(&tmp_963202, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_963201, tmp_963202, *target));
unref_integer_reg(tmp_963201);
unref_integer_reg(tmp_963202);
}
}

void compiler_tmp_963203 (reg_t *target, int foreign_target, void **env)
/*
(SEX (FIELD DISP8 NIL NIL))
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
}

void compiler_tmp_963178 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
 ((4)
  (+
   (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
    ((5)
     (CASE ((0) (FIELD DISP32 NIL NIL))
      ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
   (CASE
    ((0 1 2 3 5 6 7)
     (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
      (ZEX (FIELD SCALE NIL NIL))))
    ((4) (INTEGER 0)))))
 ((5) (FIELD DISP32 NIL NIL)))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 6:
case 7:
compiler_tmp_963179(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_963181(&(*target), foreign_target, env);
break;
case 5:
compiler_tmp_963188(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_963181 (reg_t *target, int foreign_target, void **env)
/*
(+
 (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
  ((5)
   (CASE ((0) (FIELD DISP32 NIL NIL))
    ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
 (CASE
  ((0 1 2 3 5 6 7)
   (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
    (ZEX (FIELD SCALE NIL NIL))))
  ((4) (INTEGER 0))))
*/
{
{
reg_t tmp_963182, tmp_963183;
compiler_tmp_963184(&tmp_963182, -1, env);
compiler_tmp_963191(&tmp_963183, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_963182, tmp_963183, *target));
unref_integer_reg(tmp_963182);
unref_integer_reg(tmp_963183);
}
}

void compiler_tmp_963191 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
   (ZEX (FIELD SCALE NIL NIL))))
 ((4) (INTEGER 0)))
*/
{
switch (index) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_963192(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_963198(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_963198 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_963192 (reg_t *target, int foreign_target, void **env)
/*
(SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL)) (ZEX (FIELD SCALE NIL NIL)))
*/
{
{
reg_t tmp_963193, tmp_963194;
compiler_tmp_963195(&tmp_963193, -1, env);
compiler_tmp_963197(&tmp_963194, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_SLL(tmp_963193, tmp_963194, *target));
unref_integer_reg(tmp_963193);
unref_integer_reg(tmp_963194);
emit(COMPOSE_ADDL((*target), 31, (*target)));
}
}

void compiler_tmp_963197 (reg_t *target, int foreign_target, void **env)
/*
(ZEX (FIELD SCALE NIL NIL))
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, scale);
}

void compiler_tmp_963195 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD INDEX NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + index));
else {
reg_t tmp_963196 = ref_integer_reg_for_reading((0 + index));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_963196, *target));
unref_integer_reg(tmp_963196);
}
}

void compiler_tmp_963184 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
 ((5)
  (CASE ((0) (FIELD DISP32 NIL NIL))
   ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
*/
{
switch (base) {
case 0:
case 1:
case 2:
case 3:
case 4:
case 6:
case 7:
compiler_tmp_963185(&(*target), foreign_target, env);
break;
case 5:
compiler_tmp_963187(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_963187 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0) (FIELD DISP32 NIL NIL)) ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))
*/
{
switch (mod) {
case 0:
compiler_tmp_963188(&(*target), foreign_target, env);
break;
case 1:
case 2:
case 3:
compiler_tmp_963189(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_963189 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER EBP GPR (INTEGER 5))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading(5);
else {
reg_t tmp_963190 = ref_integer_reg_for_reading(5);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_963190, *target));
unref_integer_reg(tmp_963190);
}
}

void compiler_tmp_963188 (reg_t *target, int foreign_target, void **env)
/*
(FIELD DISP32 NIL NIL)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, disp32);
}

void compiler_tmp_963185 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD BASE NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + base));
else {
reg_t tmp_963186 = ref_integer_reg_for_reading((0 + base));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_963186, *target));
unref_integer_reg(tmp_963186);
}
}

void compiler_tmp_963179 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD RM NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + rm));
else {
reg_t tmp_963180 = ref_integer_reg_for_reading((0 + rm));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_963180, *target));
unref_integer_reg(tmp_963180);
}
}

void compile_inc_rm32_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_963169;
killed |= 0x800;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_963215(rhs_func, env);
}
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_963545();
goto next_tmp_963218;
next_tmp_963218:
goto finish_tmp_963217;
finish_tmp_963217:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_963918();
goto next_tmp_963548;
next_tmp_963548:
goto finish_tmp_963547;
finish_tmp_963547:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_964326();
goto next_tmp_963921;
next_tmp_963921:
goto finish_tmp_963920;
finish_tmp_963920:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_964656();
goto next_tmp_964329;
next_tmp_964329:
goto finish_tmp_964328;
finish_tmp_964328:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_965031();
goto next_tmp_964659;
next_tmp_964659:
goto finish_tmp_964658;
finish_tmp_964658:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_965415();
goto next_tmp_965034;
next_tmp_965034:
goto finish_tmp_965033;
finish_tmp_965033:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_965669();
goto next_tmp_965418;
next_tmp_965418:
goto finish_tmp_965417;
finish_tmp_965417:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; }))
{
genfunc_tmp_965669();
goto next_tmp_965672;
next_tmp_965672:
goto finish_tmp_965671;
finish_tmp_965671:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_966052();
goto next_tmp_965675;
next_tmp_965675:
goto finish_tmp_965674;
finish_tmp_965674:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_966436();
goto next_tmp_966055;
next_tmp_966055:
goto finish_tmp_966054;
finish_tmp_966054:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_966820();
goto next_tmp_966439;
next_tmp_966439:
goto finish_tmp_966438;
finish_tmp_966438:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_967195();
goto next_tmp_966823;
next_tmp_966823:
goto finish_tmp_966822;
finish_tmp_966822:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_967598();
goto next_tmp_967198;
next_tmp_967198:
goto finish_tmp_967197;
finish_tmp_967197:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_968004();
goto next_tmp_967601;
next_tmp_967601:
goto finish_tmp_967600;
finish_tmp_967600:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_968379();
goto next_tmp_968007;
next_tmp_968007:
goto finish_tmp_968006;
finish_tmp_968006:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_968759();
goto next_tmp_968382;
next_tmp_968382:
goto finish_tmp_968381;
finish_tmp_968381:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_969143();
goto next_tmp_968762;
next_tmp_968762:
goto finish_tmp_968761;
finish_tmp_968761:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_969527();
goto next_tmp_969146;
next_tmp_969146:
goto finish_tmp_969145;
finish_tmp_969145:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_969902();
goto next_tmp_969530;
next_tmp_969530:
goto finish_tmp_969529;
finish_tmp_969529:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_970286();
goto next_tmp_969905;
next_tmp_969905:
goto finish_tmp_969904;
finish_tmp_969904:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_970670();
goto next_tmp_970289;
next_tmp_970289:
goto finish_tmp_970288;
finish_tmp_970288:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_971045();
goto next_tmp_970673;
next_tmp_970673:
goto finish_tmp_970672;
finish_tmp_970672:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 3; })&& ({ word_2 tmp = mod; 0 || tmp == 3; }))
{
genfunc_tmp_971172();
goto next_tmp_971048;
next_tmp_971048:
goto finish_tmp_971047;
finish_tmp_971047:
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_971174;
killed |= 0x80;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_971184(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_971186;
killed |= 0x40;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_971195(rhs_func, env);
}
}
}
void genfunc_tmp_971172 (void) {
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
tmp_952084 = ref_gpr_reg_for_reading(0 + rm);
tmp_952083 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952083);
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 1 */
}
done_tmp_971171:
}
reg_t genfunc_tmp_971123 (void) {
reg_t tmp_952088;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
tmp_952084 = ref_gpr_reg_for_reading(0 + rm);
tmp_952083 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 1 */
}
done_tmp_971122:
return tmp_952088;
}
reg_t genfunc_tmp_971092 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
tmp_952084 = ref_gpr_reg_for_reading(0 + rm);
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 1 */
}
done_tmp_971091:
return tmp_952080;
}
void genfunc_tmp_971045 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_970797();
goto next_tmp_970676;
next_tmp_970676:
goto tmp_970675;
tmp_970675:
}
{
tmp_951328 = genfunc_tmp_971042();
goto next_tmp_970800;
next_tmp_970800:
goto tmp_970799;
tmp_970799:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 9 */
}
done_tmp_971044:
}
reg_t genfunc_tmp_971042 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_970963();
goto next_tmp_970973;
next_tmp_970973:
goto tmp_970972;
tmp_970972:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_971041:
return tmp_951328;
}
reg_t genfunc_tmp_971011 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_970963();
goto next_tmp_970992;
next_tmp_970992:
goto tmp_970991;
tmp_970991:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_971010:
return tmp_952080;
}
reg_t genfunc_tmp_970963 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_970797();
goto next_tmp_970940;
next_tmp_970940:
goto tmp_970939;
tmp_970939:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_970962:
return tmp_952088;
}
reg_t genfunc_tmp_970915 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_970884 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_970884 >> 8) == 0)
field_imm = tmp_970884;
else goto fail_tmp_970883;
}
/* commit */
{
tmp_952040 = genfunc_tmp_970846();
goto next_tmp_970886;
next_tmp_970886:
goto tmp_970885;
tmp_970885:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_970914;
fail_tmp_970883:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_970906 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_970906))
field_imm = inv_maskmask(8, tmp_970906);
else goto fail_tmp_970905;
}
/* commit */
{
tmp_951257 = genfunc_tmp_970846();
goto next_tmp_970908;
next_tmp_970908:
goto tmp_970907;
tmp_970907:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_970914;
fail_tmp_970905:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_970846();
goto next_tmp_970912;
next_tmp_970912:
goto tmp_970911;
tmp_970911:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_970914:
return tmp_952044;
}
reg_t genfunc_tmp_970846 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_970797();
goto next_tmp_970843;
next_tmp_970843:
goto tmp_970842;
tmp_970842:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_970845:
return tmp_952080;
}
reg_t genfunc_tmp_970797 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_970764 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_970764 >> 8) == 0)
field_imm = tmp_970764;
else goto fail_tmp_970763;
}
/* commit */
{
tmp_952040 = genfunc_tmp_970708();
goto next_tmp_970766;
next_tmp_970766:
goto tmp_970765;
tmp_970765:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_970796;
fail_tmp_970763:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_970788 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_970788))
field_imm = inv_maskmask(8, tmp_970788);
else goto fail_tmp_970787;
}
/* commit */
{
tmp_951257 = genfunc_tmp_970708();
goto next_tmp_970790;
next_tmp_970790:
goto tmp_970789;
tmp_970789:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_970796;
fail_tmp_970787:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_970708();
goto next_tmp_970794;
next_tmp_970794:
goto tmp_970793;
tmp_970793:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_970796:
return tmp_951324;
}
reg_t genfunc_tmp_970761 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_970730 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_970730 >> 8) == 0)
field_imm = tmp_970730;
else goto fail_tmp_970729;
}
/* commit */
{
tmp_952040 = genfunc_tmp_970708();
goto next_tmp_970732;
next_tmp_970732:
goto tmp_970731;
tmp_970731:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_970760;
fail_tmp_970729:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_970752 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_970752))
field_imm = inv_maskmask(8, tmp_970752);
else goto fail_tmp_970751;
}
/* commit */
{
tmp_951257 = genfunc_tmp_970708();
goto next_tmp_970754;
next_tmp_970754:
goto tmp_970753;
tmp_970753:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_970760;
fail_tmp_970751:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_970708();
goto next_tmp_970758;
next_tmp_970758:
goto tmp_970757;
tmp_970757:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_970760:
return tmp_952044;
}
reg_t genfunc_tmp_970708 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_970705;
field_ra = 31;
/* commit */
tmp_951424 = ref_gpr_reg_for_reading(0 + 5);
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 1 */
}
goto done_tmp_970707;
fail_tmp_970705:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_970706;
field_ra = 31;
/* commit */
tmp_951392 = ref_gpr_reg_for_reading(0 + 5);
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 1 */
}
goto done_tmp_970707;
fail_tmp_970706:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_952082 = ref_gpr_reg_for_reading(0 + 5);
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_970707:
return tmp_952058;
}
void genfunc_tmp_970670 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_970422();
goto next_tmp_970292;
next_tmp_970292:
goto tmp_970291;
tmp_970291:
}
{
tmp_951328 = genfunc_tmp_970667();
goto next_tmp_970425;
next_tmp_970425:
goto tmp_970424;
tmp_970424:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 13 */
}
done_tmp_970669:
}
reg_t genfunc_tmp_970667 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_970588();
goto next_tmp_970598;
next_tmp_970598:
goto tmp_970597;
tmp_970597:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 7 */
}
done_tmp_970666:
return tmp_951328;
}
reg_t genfunc_tmp_970636 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_970588();
goto next_tmp_970617;
next_tmp_970617:
goto tmp_970616;
tmp_970616:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 7 */
}
done_tmp_970635:
return tmp_952080;
}
reg_t genfunc_tmp_970588 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_970422();
goto next_tmp_970565;
next_tmp_970565:
goto tmp_970564;
tmp_970564:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_970587:
return tmp_952088;
}
reg_t genfunc_tmp_970540 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_970509 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_970509 >> 8) == 0)
field_imm = tmp_970509;
else goto fail_tmp_970508;
}
/* commit */
{
tmp_952040 = genfunc_tmp_970471();
goto next_tmp_970511;
next_tmp_970511:
goto tmp_970510;
tmp_970510:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 7 */
}
goto done_tmp_970539;
fail_tmp_970508:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_970531 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_970531))
field_imm = inv_maskmask(8, tmp_970531);
else goto fail_tmp_970530;
}
/* commit */
{
tmp_951257 = genfunc_tmp_970471();
goto next_tmp_970533;
next_tmp_970533:
goto tmp_970532;
tmp_970532:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 7 */
}
goto done_tmp_970539;
fail_tmp_970530:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_970471();
goto next_tmp_970537;
next_tmp_970537:
goto tmp_970536;
tmp_970536:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 7 */
}
done_tmp_970539:
return tmp_952044;
}
reg_t genfunc_tmp_970471 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_970422();
goto next_tmp_970468;
next_tmp_970468:
goto tmp_970467;
tmp_970467:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_970470:
return tmp_952080;
}
reg_t genfunc_tmp_970422 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_970389 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_970389 >> 8) == 0)
field_imm = tmp_970389;
else goto fail_tmp_970388;
}
/* commit */
{
tmp_952040 = genfunc_tmp_970333();
goto next_tmp_970391;
next_tmp_970391:
goto tmp_970390;
tmp_970390:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_970421;
fail_tmp_970388:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_970413 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_970413))
field_imm = inv_maskmask(8, tmp_970413);
else goto fail_tmp_970412;
}
/* commit */
{
tmp_951257 = genfunc_tmp_970333();
goto next_tmp_970415;
next_tmp_970415:
goto tmp_970414;
tmp_970414:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_970421;
fail_tmp_970412:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_970333();
goto next_tmp_970419;
next_tmp_970419:
goto tmp_970418;
tmp_970418:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_970421:
return tmp_951324;
}
reg_t genfunc_tmp_970386 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_970355 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_970355 >> 8) == 0)
field_imm = tmp_970355;
else goto fail_tmp_970354;
}
/* commit */
{
tmp_952040 = genfunc_tmp_970333();
goto next_tmp_970357;
next_tmp_970357:
goto tmp_970356;
tmp_970356:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_970385;
fail_tmp_970354:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_970377 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_970377))
field_imm = inv_maskmask(8, tmp_970377);
else goto fail_tmp_970376;
}
/* commit */
{
tmp_951257 = genfunc_tmp_970333();
goto next_tmp_970379;
next_tmp_970379:
goto tmp_970378;
tmp_970378:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_970385;
fail_tmp_970376:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_970333();
goto next_tmp_970383;
next_tmp_970383:
goto tmp_970382;
tmp_970382:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_970385:
return tmp_952044;
}
reg_t genfunc_tmp_970333 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_970324;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_967642();
goto next_tmp_970326;
next_tmp_970326:
goto tmp_970325;
tmp_970325:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 3 */
}
goto done_tmp_970332;
fail_tmp_970324:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_970328;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_967642();
goto next_tmp_970330;
next_tmp_970330:
goto tmp_970329;
tmp_970329:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 3 */
}
goto done_tmp_970332;
fail_tmp_970328:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_952082 = genfunc_tmp_967642();
goto next_tmp_970308;
next_tmp_970308:
goto tmp_970307;
tmp_970307:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 4 */
}
done_tmp_970332:
return tmp_952058;
}
void genfunc_tmp_970286 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_970038();
goto next_tmp_969908;
next_tmp_969908:
goto tmp_969907;
tmp_969907:
}
{
tmp_951328 = genfunc_tmp_970283();
goto next_tmp_970041;
next_tmp_970041:
goto tmp_970040;
tmp_970040:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 11 */
}
done_tmp_970285:
}
reg_t genfunc_tmp_970283 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_970204();
goto next_tmp_970214;
next_tmp_970214:
goto tmp_970213;
tmp_970213:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 6 */
}
done_tmp_970282:
return tmp_951328;
}
reg_t genfunc_tmp_970252 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_970204();
goto next_tmp_970233;
next_tmp_970233:
goto tmp_970232;
tmp_970232:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 6 */
}
done_tmp_970251:
return tmp_952080;
}
reg_t genfunc_tmp_970204 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_970038();
goto next_tmp_970181;
next_tmp_970181:
goto tmp_970180;
tmp_970180:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_970203:
return tmp_952088;
}
reg_t genfunc_tmp_970156 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_970125 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_970125 >> 8) == 0)
field_imm = tmp_970125;
else goto fail_tmp_970124;
}
/* commit */
{
tmp_952040 = genfunc_tmp_970087();
goto next_tmp_970127;
next_tmp_970127:
goto tmp_970126;
tmp_970126:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 6 */
}
goto done_tmp_970155;
fail_tmp_970124:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_970147 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_970147))
field_imm = inv_maskmask(8, tmp_970147);
else goto fail_tmp_970146;
}
/* commit */
{
tmp_951257 = genfunc_tmp_970087();
goto next_tmp_970149;
next_tmp_970149:
goto tmp_970148;
tmp_970148:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 6 */
}
goto done_tmp_970155;
fail_tmp_970146:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_970087();
goto next_tmp_970153;
next_tmp_970153:
goto tmp_970152;
tmp_970152:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 6 */
}
done_tmp_970155:
return tmp_952044;
}
reg_t genfunc_tmp_970087 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_970038();
goto next_tmp_970084;
next_tmp_970084:
goto tmp_970083;
tmp_970083:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_970086:
return tmp_952080;
}
reg_t genfunc_tmp_970038 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_970005 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_970005 >> 8) == 0)
field_imm = tmp_970005;
else goto fail_tmp_970004;
}
/* commit */
{
tmp_952040 = genfunc_tmp_969949();
goto next_tmp_970007;
next_tmp_970007:
goto tmp_970006;
tmp_970006:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_970037;
fail_tmp_970004:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_970029 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_970029))
field_imm = inv_maskmask(8, tmp_970029);
else goto fail_tmp_970028;
}
/* commit */
{
tmp_951257 = genfunc_tmp_969949();
goto next_tmp_970031;
next_tmp_970031:
goto tmp_970030;
tmp_970030:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_970037;
fail_tmp_970028:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_969949();
goto next_tmp_970035;
next_tmp_970035:
goto tmp_970034;
tmp_970034:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_970037:
return tmp_951324;
}
reg_t genfunc_tmp_970002 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_969971 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_969971 >> 8) == 0)
field_imm = tmp_969971;
else goto fail_tmp_969970;
}
/* commit */
{
tmp_952040 = genfunc_tmp_969949();
goto next_tmp_969973;
next_tmp_969973:
goto tmp_969972;
tmp_969972:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_970001;
fail_tmp_969970:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_969993 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_969993))
field_imm = inv_maskmask(8, tmp_969993);
else goto fail_tmp_969992;
}
/* commit */
{
tmp_951257 = genfunc_tmp_969949();
goto next_tmp_969995;
next_tmp_969995:
goto tmp_969994;
tmp_969994:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_970001;
fail_tmp_969992:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_969949();
goto next_tmp_969999;
next_tmp_969999:
goto tmp_969998;
tmp_969998:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_970001:
return tmp_952044;
}
reg_t genfunc_tmp_969949 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_969940;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_967236();
goto next_tmp_969942;
next_tmp_969942:
goto tmp_969941;
tmp_969941:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 2 */
}
goto done_tmp_969948;
fail_tmp_969940:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_969944;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_967236();
goto next_tmp_969946;
next_tmp_969946:
goto tmp_969945;
tmp_969945:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 2 */
}
goto done_tmp_969948;
fail_tmp_969944:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_952082 = genfunc_tmp_967236();
goto next_tmp_969924;
next_tmp_969924:
goto tmp_969923;
tmp_969923:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 3 */
}
done_tmp_969948:
return tmp_952058;
}
void genfunc_tmp_969902 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_969654();
goto next_tmp_969533;
next_tmp_969533:
goto tmp_969532;
tmp_969532:
}
{
tmp_951328 = genfunc_tmp_969899();
goto next_tmp_969657;
next_tmp_969657:
goto tmp_969656;
tmp_969656:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 9 */
}
done_tmp_969901:
}
reg_t genfunc_tmp_969899 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_969820();
goto next_tmp_969830;
next_tmp_969830:
goto tmp_969829;
tmp_969829:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_969898:
return tmp_951328;
}
reg_t genfunc_tmp_969868 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_969820();
goto next_tmp_969849;
next_tmp_969849:
goto tmp_969848;
tmp_969848:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_969867:
return tmp_952080;
}
reg_t genfunc_tmp_969820 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_969654();
goto next_tmp_969797;
next_tmp_969797:
goto tmp_969796;
tmp_969796:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_969819:
return tmp_952088;
}
reg_t genfunc_tmp_969772 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_969741 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_969741 >> 8) == 0)
field_imm = tmp_969741;
else goto fail_tmp_969740;
}
/* commit */
{
tmp_952040 = genfunc_tmp_969703();
goto next_tmp_969743;
next_tmp_969743:
goto tmp_969742;
tmp_969742:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_969771;
fail_tmp_969740:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_969763 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_969763))
field_imm = inv_maskmask(8, tmp_969763);
else goto fail_tmp_969762;
}
/* commit */
{
tmp_951257 = genfunc_tmp_969703();
goto next_tmp_969765;
next_tmp_969765:
goto tmp_969764;
tmp_969764:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_969771;
fail_tmp_969762:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_969703();
goto next_tmp_969769;
next_tmp_969769:
goto tmp_969768;
tmp_969768:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_969771:
return tmp_952044;
}
reg_t genfunc_tmp_969703 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_969654();
goto next_tmp_969700;
next_tmp_969700:
goto tmp_969699;
tmp_969699:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_969702:
return tmp_952080;
}
reg_t genfunc_tmp_969654 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_969621 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_969621 >> 8) == 0)
field_imm = tmp_969621;
else goto fail_tmp_969620;
}
/* commit */
{
tmp_952040 = genfunc_tmp_969565();
goto next_tmp_969623;
next_tmp_969623:
goto tmp_969622;
tmp_969622:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_969653;
fail_tmp_969620:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_969645 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_969645))
field_imm = inv_maskmask(8, tmp_969645);
else goto fail_tmp_969644;
}
/* commit */
{
tmp_951257 = genfunc_tmp_969565();
goto next_tmp_969647;
next_tmp_969647:
goto tmp_969646;
tmp_969646:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_969653;
fail_tmp_969644:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_969565();
goto next_tmp_969651;
next_tmp_969651:
goto tmp_969650;
tmp_969650:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_969653:
return tmp_951324;
}
reg_t genfunc_tmp_969618 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_969587 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_969587 >> 8) == 0)
field_imm = tmp_969587;
else goto fail_tmp_969586;
}
/* commit */
{
tmp_952040 = genfunc_tmp_969565();
goto next_tmp_969589;
next_tmp_969589:
goto tmp_969588;
tmp_969588:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_969617;
fail_tmp_969586:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_969609 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_969609))
field_imm = inv_maskmask(8, tmp_969609);
else goto fail_tmp_969608;
}
/* commit */
{
tmp_951257 = genfunc_tmp_969565();
goto next_tmp_969611;
next_tmp_969611:
goto tmp_969610;
tmp_969610:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_969617;
fail_tmp_969608:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_969565();
goto next_tmp_969615;
next_tmp_969615:
goto tmp_969614;
tmp_969614:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_969617:
return tmp_952044;
}
reg_t genfunc_tmp_969565 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_969562;
field_ra = 31;
/* commit */
tmp_951424 = ref_gpr_reg_for_reading(0 + base);
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 1 */
}
goto done_tmp_969564;
fail_tmp_969562:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_969563;
field_ra = 31;
/* commit */
tmp_951392 = ref_gpr_reg_for_reading(0 + base);
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 1 */
}
goto done_tmp_969564;
fail_tmp_969563:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_952082 = ref_gpr_reg_for_reading(0 + base);
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_969564:
return tmp_952058;
}
void genfunc_tmp_969527 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_969279();
goto next_tmp_969149;
next_tmp_969149:
goto tmp_969148;
tmp_969148:
}
{
tmp_951328 = genfunc_tmp_969524();
goto next_tmp_969282;
next_tmp_969282:
goto tmp_969281;
tmp_969281:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 13 */
}
done_tmp_969526:
}
reg_t genfunc_tmp_969524 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_969445();
goto next_tmp_969455;
next_tmp_969455:
goto tmp_969454;
tmp_969454:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 7 */
}
done_tmp_969523:
return tmp_951328;
}
reg_t genfunc_tmp_969493 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_969445();
goto next_tmp_969474;
next_tmp_969474:
goto tmp_969473;
tmp_969473:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 7 */
}
done_tmp_969492:
return tmp_952080;
}
reg_t genfunc_tmp_969445 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_969279();
goto next_tmp_969422;
next_tmp_969422:
goto tmp_969421;
tmp_969421:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_969444:
return tmp_952088;
}
reg_t genfunc_tmp_969397 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_969366 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_969366 >> 8) == 0)
field_imm = tmp_969366;
else goto fail_tmp_969365;
}
/* commit */
{
tmp_952040 = genfunc_tmp_969328();
goto next_tmp_969368;
next_tmp_969368:
goto tmp_969367;
tmp_969367:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 7 */
}
goto done_tmp_969396;
fail_tmp_969365:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_969388 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_969388))
field_imm = inv_maskmask(8, tmp_969388);
else goto fail_tmp_969387;
}
/* commit */
{
tmp_951257 = genfunc_tmp_969328();
goto next_tmp_969390;
next_tmp_969390:
goto tmp_969389;
tmp_969389:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 7 */
}
goto done_tmp_969396;
fail_tmp_969387:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_969328();
goto next_tmp_969394;
next_tmp_969394:
goto tmp_969393;
tmp_969393:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 7 */
}
done_tmp_969396:
return tmp_952044;
}
reg_t genfunc_tmp_969328 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_969279();
goto next_tmp_969325;
next_tmp_969325:
goto tmp_969324;
tmp_969324:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_969327:
return tmp_952080;
}
reg_t genfunc_tmp_969279 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_969246 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_969246 >> 8) == 0)
field_imm = tmp_969246;
else goto fail_tmp_969245;
}
/* commit */
{
tmp_952040 = genfunc_tmp_969190();
goto next_tmp_969248;
next_tmp_969248:
goto tmp_969247;
tmp_969247:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_969278;
fail_tmp_969245:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_969270 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_969270))
field_imm = inv_maskmask(8, tmp_969270);
else goto fail_tmp_969269;
}
/* commit */
{
tmp_951257 = genfunc_tmp_969190();
goto next_tmp_969272;
next_tmp_969272:
goto tmp_969271;
tmp_969271:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_969278;
fail_tmp_969269:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_969190();
goto next_tmp_969276;
next_tmp_969276:
goto tmp_969275;
tmp_969275:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_969278:
return tmp_951324;
}
reg_t genfunc_tmp_969243 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_969212 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_969212 >> 8) == 0)
field_imm = tmp_969212;
else goto fail_tmp_969211;
}
/* commit */
{
tmp_952040 = genfunc_tmp_969190();
goto next_tmp_969214;
next_tmp_969214:
goto tmp_969213;
tmp_969213:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_969242;
fail_tmp_969211:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_969234 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_969234))
field_imm = inv_maskmask(8, tmp_969234);
else goto fail_tmp_969233;
}
/* commit */
{
tmp_951257 = genfunc_tmp_969190();
goto next_tmp_969236;
next_tmp_969236:
goto tmp_969235;
tmp_969235:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_969242;
fail_tmp_969233:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_969190();
goto next_tmp_969240;
next_tmp_969240:
goto tmp_969239;
tmp_969239:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_969242:
return tmp_952044;
}
reg_t genfunc_tmp_969190 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_969181;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_963989();
goto next_tmp_969183;
next_tmp_969183:
goto tmp_969182;
tmp_969182:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 3 */
}
goto done_tmp_969189;
fail_tmp_969181:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_969185;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_963989();
goto next_tmp_969187;
next_tmp_969187:
goto tmp_969186;
tmp_969186:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 3 */
}
goto done_tmp_969189;
fail_tmp_969185:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_952082 = genfunc_tmp_963989();
goto next_tmp_969165;
next_tmp_969165:
goto tmp_969164;
tmp_969164:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 4 */
}
done_tmp_969189:
return tmp_952058;
}
void genfunc_tmp_969143 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_968895();
goto next_tmp_968765;
next_tmp_968765:
goto tmp_968764;
tmp_968764:
}
{
tmp_951328 = genfunc_tmp_969140();
goto next_tmp_968898;
next_tmp_968898:
goto tmp_968897;
tmp_968897:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 11 */
}
done_tmp_969142:
}
reg_t genfunc_tmp_969140 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_969061();
goto next_tmp_969071;
next_tmp_969071:
goto tmp_969070;
tmp_969070:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 6 */
}
done_tmp_969139:
return tmp_951328;
}
reg_t genfunc_tmp_969109 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_969061();
goto next_tmp_969090;
next_tmp_969090:
goto tmp_969089;
tmp_969089:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 6 */
}
done_tmp_969108:
return tmp_952080;
}
reg_t genfunc_tmp_969061 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_968895();
goto next_tmp_969038;
next_tmp_969038:
goto tmp_969037;
tmp_969037:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_969060:
return tmp_952088;
}
reg_t genfunc_tmp_969013 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_968982 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_968982 >> 8) == 0)
field_imm = tmp_968982;
else goto fail_tmp_968981;
}
/* commit */
{
tmp_952040 = genfunc_tmp_968944();
goto next_tmp_968984;
next_tmp_968984:
goto tmp_968983;
tmp_968983:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 6 */
}
goto done_tmp_969012;
fail_tmp_968981:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_969004 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_969004))
field_imm = inv_maskmask(8, tmp_969004);
else goto fail_tmp_969003;
}
/* commit */
{
tmp_951257 = genfunc_tmp_968944();
goto next_tmp_969006;
next_tmp_969006:
goto tmp_969005;
tmp_969005:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 6 */
}
goto done_tmp_969012;
fail_tmp_969003:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_968944();
goto next_tmp_969010;
next_tmp_969010:
goto tmp_969009;
tmp_969009:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 6 */
}
done_tmp_969012:
return tmp_952044;
}
reg_t genfunc_tmp_968944 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_968895();
goto next_tmp_968941;
next_tmp_968941:
goto tmp_968940;
tmp_968940:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_968943:
return tmp_952080;
}
reg_t genfunc_tmp_968895 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_968862 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_968862 >> 8) == 0)
field_imm = tmp_968862;
else goto fail_tmp_968861;
}
/* commit */
{
tmp_952040 = genfunc_tmp_968806();
goto next_tmp_968864;
next_tmp_968864:
goto tmp_968863;
tmp_968863:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_968894;
fail_tmp_968861:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_968886 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_968886))
field_imm = inv_maskmask(8, tmp_968886);
else goto fail_tmp_968885;
}
/* commit */
{
tmp_951257 = genfunc_tmp_968806();
goto next_tmp_968888;
next_tmp_968888:
goto tmp_968887;
tmp_968887:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_968894;
fail_tmp_968885:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_968806();
goto next_tmp_968892;
next_tmp_968892:
goto tmp_968891;
tmp_968891:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_968894:
return tmp_951324;
}
reg_t genfunc_tmp_968859 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_968828 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_968828 >> 8) == 0)
field_imm = tmp_968828;
else goto fail_tmp_968827;
}
/* commit */
{
tmp_952040 = genfunc_tmp_968806();
goto next_tmp_968830;
next_tmp_968830:
goto tmp_968829;
tmp_968829:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_968858;
fail_tmp_968827:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_968850 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_968850))
field_imm = inv_maskmask(8, tmp_968850);
else goto fail_tmp_968849;
}
/* commit */
{
tmp_951257 = genfunc_tmp_968806();
goto next_tmp_968852;
next_tmp_968852:
goto tmp_968851;
tmp_968851:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_968858;
fail_tmp_968849:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_968806();
goto next_tmp_968856;
next_tmp_968856:
goto tmp_968855;
tmp_968855:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_968858:
return tmp_952044;
}
reg_t genfunc_tmp_968806 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_968797;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_963581();
goto next_tmp_968799;
next_tmp_968799:
goto tmp_968798;
tmp_968798:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 2 */
}
goto done_tmp_968805;
fail_tmp_968797:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_968801;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_963581();
goto next_tmp_968803;
next_tmp_968803:
goto tmp_968802;
tmp_968802:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 2 */
}
goto done_tmp_968805;
fail_tmp_968801:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_952082 = genfunc_tmp_963581();
goto next_tmp_968781;
next_tmp_968781:
goto tmp_968780;
tmp_968780:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 3 */
}
done_tmp_968805:
return tmp_952058;
}
void genfunc_tmp_968759 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_968511();
goto next_tmp_968385;
next_tmp_968385:
goto tmp_968384;
tmp_968384:
}
{
tmp_951328 = genfunc_tmp_968756();
goto next_tmp_968514;
next_tmp_968514:
goto tmp_968513;
tmp_968513:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 9 */
}
done_tmp_968758:
}
reg_t genfunc_tmp_968756 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_968677();
goto next_tmp_968687;
next_tmp_968687:
goto tmp_968686;
tmp_968686:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_968755:
return tmp_951328;
}
reg_t genfunc_tmp_968725 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_968677();
goto next_tmp_968706;
next_tmp_968706:
goto tmp_968705;
tmp_968705:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_968724:
return tmp_952080;
}
reg_t genfunc_tmp_968677 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_968511();
goto next_tmp_968654;
next_tmp_968654:
goto tmp_968653;
tmp_968653:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_968676:
return tmp_952088;
}
reg_t genfunc_tmp_968629 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_968598 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_968598 >> 8) == 0)
field_imm = tmp_968598;
else goto fail_tmp_968597;
}
/* commit */
{
tmp_952040 = genfunc_tmp_968560();
goto next_tmp_968600;
next_tmp_968600:
goto tmp_968599;
tmp_968599:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_968628;
fail_tmp_968597:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_968620 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_968620))
field_imm = inv_maskmask(8, tmp_968620);
else goto fail_tmp_968619;
}
/* commit */
{
tmp_951257 = genfunc_tmp_968560();
goto next_tmp_968622;
next_tmp_968622:
goto tmp_968621;
tmp_968621:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_968628;
fail_tmp_968619:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_968560();
goto next_tmp_968626;
next_tmp_968626:
goto tmp_968625;
tmp_968625:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_968628:
return tmp_952044;
}
reg_t genfunc_tmp_968560 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_968511();
goto next_tmp_968557;
next_tmp_968557:
goto tmp_968556;
tmp_968556:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_968559:
return tmp_952080;
}
reg_t genfunc_tmp_968511 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_968478 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_968478 >> 8) == 0)
field_imm = tmp_968478;
else goto fail_tmp_968477;
}
/* commit */
{
tmp_952040 = genfunc_tmp_968422();
goto next_tmp_968480;
next_tmp_968480:
goto tmp_968479;
tmp_968479:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_968510;
fail_tmp_968477:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_968502 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_968502))
field_imm = inv_maskmask(8, tmp_968502);
else goto fail_tmp_968501;
}
/* commit */
{
tmp_951257 = genfunc_tmp_968422();
goto next_tmp_968504;
next_tmp_968504:
goto tmp_968503;
tmp_968503:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_968510;
fail_tmp_968501:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_968422();
goto next_tmp_968508;
next_tmp_968508:
goto tmp_968507;
tmp_968507:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_968510:
return tmp_951324;
}
reg_t genfunc_tmp_968475 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_968444 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_968444 >> 8) == 0)
field_imm = tmp_968444;
else goto fail_tmp_968443;
}
/* commit */
{
tmp_952040 = genfunc_tmp_968422();
goto next_tmp_968446;
next_tmp_968446:
goto tmp_968445;
tmp_968445:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_968474;
fail_tmp_968443:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_968466 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_968466))
field_imm = inv_maskmask(8, tmp_968466);
else goto fail_tmp_968465;
}
/* commit */
{
tmp_951257 = genfunc_tmp_968422();
goto next_tmp_968468;
next_tmp_968468:
goto tmp_968467;
tmp_968467:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_968474;
fail_tmp_968465:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_968422();
goto next_tmp_968472;
next_tmp_968472:
goto tmp_968471;
tmp_968471:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_968474:
return tmp_952044;
}
reg_t genfunc_tmp_968422 (void) {
reg_t tmp_952058;
/* ADDQ_IMM */
{
word_5 tmp_952075;
word_5 field_rc;
word_5 tmp_952076;
word_5 field_ra;
word_64 tmp_952078;
word_8 field_imm;
tmp_952078 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_968407 = tmp_952078;
if ((tmp_968407 >> 8) == 0)
field_imm = tmp_968407;
else goto fail_tmp_968406;
}
/* commit */
tmp_952076 = ref_gpr_reg_for_reading(0 + rm);
tmp_952075 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952075;
field_ra = tmp_952076;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952076);
/* can fail: T   num insns: 1 */
}
goto done_tmp_968421;
fail_tmp_968406:
/* LDA */
{
word_5 tmp_951579;
word_5 field_ra;
word_5 tmp_951580;
word_5 field_rb;
word_64 tmp_951582;
word_16 field_memory_disp;
tmp_951582 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_968415 = tmp_951582;
if ((tmp_968415 >> 16) == 0xFFFFFFFFFFFF || (tmp_968415 >> 16) == 0)
field_memory_disp = (tmp_968415 & 0xFFFF);
else goto fail_tmp_968414;
}
/* commit */
tmp_951580 = ref_gpr_reg_for_reading(0 + rm);
tmp_951579 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951579;
field_rb = tmp_951580;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951580);
/* can fail: T   num insns: 1 */
}
goto done_tmp_968421;
fail_tmp_968414:
/* LDAH */
{
word_5 tmp_951575;
word_5 field_ra;
word_5 tmp_951576;
word_5 field_rb;
word_64 tmp_951578;
word_16 field_memory_disp;
tmp_951578 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_968419 = tmp_951578;
if ((tmp_968419 & 0xFFFF) == 0)
{
word_64 tmp_968420 = (tmp_968419 >> 16);
if ((tmp_968420 >> 16) == 0xFFFFFFFFFFFF || (tmp_968420 >> 16) == 0)
field_memory_disp = (tmp_968420 & 0xFFFF);
else goto fail_tmp_968418;
}
else goto fail_tmp_968418;
}
/* commit */
tmp_951576 = ref_gpr_reg_for_reading(0 + rm);
tmp_951575 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951575;
field_rb = tmp_951576;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951576);
/* can fail: T   num insns: 1 */
}
goto done_tmp_968421;
fail_tmp_968418:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_reading(0 + rm);
tmp_952082 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952082, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_968421:
return tmp_952058;
}
void genfunc_tmp_968379 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_968131();
goto next_tmp_968010;
next_tmp_968010:
goto tmp_968009;
tmp_968009:
}
{
tmp_951328 = genfunc_tmp_968376();
goto next_tmp_968134;
next_tmp_968134:
goto tmp_968133;
tmp_968133:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 9 */
}
done_tmp_968378:
}
reg_t genfunc_tmp_968376 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_968297();
goto next_tmp_968307;
next_tmp_968307:
goto tmp_968306;
tmp_968306:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_968375:
return tmp_951328;
}
reg_t genfunc_tmp_968345 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_968297();
goto next_tmp_968326;
next_tmp_968326:
goto tmp_968325;
tmp_968325:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_968344:
return tmp_952080;
}
reg_t genfunc_tmp_968297 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_968131();
goto next_tmp_968274;
next_tmp_968274:
goto tmp_968273;
tmp_968273:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_968296:
return tmp_952088;
}
reg_t genfunc_tmp_968249 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_968218 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_968218 >> 8) == 0)
field_imm = tmp_968218;
else goto fail_tmp_968217;
}
/* commit */
{
tmp_952040 = genfunc_tmp_968180();
goto next_tmp_968220;
next_tmp_968220:
goto tmp_968219;
tmp_968219:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_968248;
fail_tmp_968217:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_968240 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_968240))
field_imm = inv_maskmask(8, tmp_968240);
else goto fail_tmp_968239;
}
/* commit */
{
tmp_951257 = genfunc_tmp_968180();
goto next_tmp_968242;
next_tmp_968242:
goto tmp_968241;
tmp_968241:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_968248;
fail_tmp_968239:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_968180();
goto next_tmp_968246;
next_tmp_968246:
goto tmp_968245;
tmp_968245:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_968248:
return tmp_952044;
}
reg_t genfunc_tmp_968180 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_968131();
goto next_tmp_968177;
next_tmp_968177:
goto tmp_968176;
tmp_968176:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_968179:
return tmp_952080;
}
reg_t genfunc_tmp_968131 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_968098 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_968098 >> 8) == 0)
field_imm = tmp_968098;
else goto fail_tmp_968097;
}
/* commit */
{
tmp_952040 = genfunc_tmp_968042();
goto next_tmp_968100;
next_tmp_968100:
goto tmp_968099;
tmp_968099:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_968130;
fail_tmp_968097:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_968122 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_968122))
field_imm = inv_maskmask(8, tmp_968122);
else goto fail_tmp_968121;
}
/* commit */
{
tmp_951257 = genfunc_tmp_968042();
goto next_tmp_968124;
next_tmp_968124:
goto tmp_968123;
tmp_968123:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_968130;
fail_tmp_968121:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_968042();
goto next_tmp_968128;
next_tmp_968128:
goto tmp_968127;
tmp_968127:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_968130:
return tmp_951324;
}
reg_t genfunc_tmp_968095 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_968064 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_968064 >> 8) == 0)
field_imm = tmp_968064;
else goto fail_tmp_968063;
}
/* commit */
{
tmp_952040 = genfunc_tmp_968042();
goto next_tmp_968066;
next_tmp_968066:
goto tmp_968065;
tmp_968065:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_968094;
fail_tmp_968063:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_968086 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_968086))
field_imm = inv_maskmask(8, tmp_968086);
else goto fail_tmp_968085;
}
/* commit */
{
tmp_951257 = genfunc_tmp_968042();
goto next_tmp_968088;
next_tmp_968088:
goto tmp_968087;
tmp_968087:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_968094;
fail_tmp_968085:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_968042();
goto next_tmp_968092;
next_tmp_968092:
goto tmp_968091;
tmp_968091:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_968094:
return tmp_952044;
}
reg_t genfunc_tmp_968042 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_968039;
field_ra = 31;
/* commit */
tmp_951424 = ref_gpr_reg_for_reading(0 + 5);
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 1 */
}
goto done_tmp_968041;
fail_tmp_968039:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_968040;
field_ra = 31;
/* commit */
tmp_951392 = ref_gpr_reg_for_reading(0 + 5);
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 1 */
}
goto done_tmp_968041;
fail_tmp_968040:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_952082 = ref_gpr_reg_for_reading(0 + 5);
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_968041:
return tmp_952058;
}
void genfunc_tmp_968004 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_967756();
goto next_tmp_967604;
next_tmp_967604:
goto tmp_967603;
tmp_967603:
}
{
tmp_951328 = genfunc_tmp_968001();
goto next_tmp_967759;
next_tmp_967759:
goto tmp_967758;
tmp_967758:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 13 */
}
done_tmp_968003:
}
reg_t genfunc_tmp_968001 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_967922();
goto next_tmp_967932;
next_tmp_967932:
goto tmp_967931;
tmp_967931:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 7 */
}
done_tmp_968000:
return tmp_951328;
}
reg_t genfunc_tmp_967970 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_967922();
goto next_tmp_967951;
next_tmp_967951:
goto tmp_967950;
tmp_967950:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 7 */
}
done_tmp_967969:
return tmp_952080;
}
reg_t genfunc_tmp_967922 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_967756();
goto next_tmp_967899;
next_tmp_967899:
goto tmp_967898;
tmp_967898:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_967921:
return tmp_952088;
}
reg_t genfunc_tmp_967874 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_967843 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_967843 >> 8) == 0)
field_imm = tmp_967843;
else goto fail_tmp_967842;
}
/* commit */
{
tmp_952040 = genfunc_tmp_967805();
goto next_tmp_967845;
next_tmp_967845:
goto tmp_967844;
tmp_967844:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 7 */
}
goto done_tmp_967873;
fail_tmp_967842:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_967865 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_967865))
field_imm = inv_maskmask(8, tmp_967865);
else goto fail_tmp_967864;
}
/* commit */
{
tmp_951257 = genfunc_tmp_967805();
goto next_tmp_967867;
next_tmp_967867:
goto tmp_967866;
tmp_967866:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 7 */
}
goto done_tmp_967873;
fail_tmp_967864:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_967805();
goto next_tmp_967871;
next_tmp_967871:
goto tmp_967870;
tmp_967870:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 7 */
}
done_tmp_967873:
return tmp_952044;
}
reg_t genfunc_tmp_967805 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_967756();
goto next_tmp_967802;
next_tmp_967802:
goto tmp_967801;
tmp_967801:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_967804:
return tmp_952080;
}
reg_t genfunc_tmp_967756 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_967723 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_967723 >> 8) == 0)
field_imm = tmp_967723;
else goto fail_tmp_967722;
}
/* commit */
{
tmp_952040 = genfunc_tmp_967667();
goto next_tmp_967725;
next_tmp_967725:
goto tmp_967724;
tmp_967724:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_967755;
fail_tmp_967722:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_967747 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_967747))
field_imm = inv_maskmask(8, tmp_967747);
else goto fail_tmp_967746;
}
/* commit */
{
tmp_951257 = genfunc_tmp_967667();
goto next_tmp_967749;
next_tmp_967749:
goto tmp_967748;
tmp_967748:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_967755;
fail_tmp_967746:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_967667();
goto next_tmp_967753;
next_tmp_967753:
goto tmp_967752;
tmp_967752:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_967755:
return tmp_951324;
}
reg_t genfunc_tmp_967720 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_967689 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_967689 >> 8) == 0)
field_imm = tmp_967689;
else goto fail_tmp_967688;
}
/* commit */
{
tmp_952040 = genfunc_tmp_967667();
goto next_tmp_967691;
next_tmp_967691:
goto tmp_967690;
tmp_967690:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_967719;
fail_tmp_967688:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_967711 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_967711))
field_imm = inv_maskmask(8, tmp_967711);
else goto fail_tmp_967710;
}
/* commit */
{
tmp_951257 = genfunc_tmp_967667();
goto next_tmp_967713;
next_tmp_967713:
goto tmp_967712;
tmp_967712:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_967719;
fail_tmp_967710:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_967667();
goto next_tmp_967717;
next_tmp_967717:
goto tmp_967716;
tmp_967716:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_967719:
return tmp_952044;
}
reg_t genfunc_tmp_967667 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_967658;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_967642();
goto next_tmp_967660;
next_tmp_967660:
goto tmp_967659;
tmp_967659:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 3 */
}
goto done_tmp_967666;
fail_tmp_967658:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_967662;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_967642();
goto next_tmp_967664;
next_tmp_967664:
goto tmp_967663;
tmp_967663:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 3 */
}
goto done_tmp_967666;
fail_tmp_967662:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_952082 = genfunc_tmp_967642();
goto next_tmp_967620;
next_tmp_967620:
goto tmp_967619;
tmp_967619:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 4 */
}
done_tmp_967666:
return tmp_952058;
}
reg_t genfunc_tmp_967642 (void) {
reg_t tmp_952082;
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_reading(0 + 5);
{
tmp_952082 = genfunc_tmp_963972();
goto next_tmp_967625;
next_tmp_967625:
goto tmp_967624;
tmp_967624:
}
tmp_952079 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_967641:
return tmp_952082;
}
void genfunc_tmp_967598 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_967350();
goto next_tmp_967201;
next_tmp_967201:
goto tmp_967200;
tmp_967200:
}
{
tmp_951328 = genfunc_tmp_967595();
goto next_tmp_967353;
next_tmp_967353:
goto tmp_967352;
tmp_967352:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 11 */
}
done_tmp_967597:
}
reg_t genfunc_tmp_967595 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_967516();
goto next_tmp_967526;
next_tmp_967526:
goto tmp_967525;
tmp_967525:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 6 */
}
done_tmp_967594:
return tmp_951328;
}
reg_t genfunc_tmp_967564 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_967516();
goto next_tmp_967545;
next_tmp_967545:
goto tmp_967544;
tmp_967544:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 6 */
}
done_tmp_967563:
return tmp_952080;
}
reg_t genfunc_tmp_967516 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_967350();
goto next_tmp_967493;
next_tmp_967493:
goto tmp_967492;
tmp_967492:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_967515:
return tmp_952088;
}
reg_t genfunc_tmp_967468 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_967437 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_967437 >> 8) == 0)
field_imm = tmp_967437;
else goto fail_tmp_967436;
}
/* commit */
{
tmp_952040 = genfunc_tmp_967399();
goto next_tmp_967439;
next_tmp_967439:
goto tmp_967438;
tmp_967438:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 6 */
}
goto done_tmp_967467;
fail_tmp_967436:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_967459 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_967459))
field_imm = inv_maskmask(8, tmp_967459);
else goto fail_tmp_967458;
}
/* commit */
{
tmp_951257 = genfunc_tmp_967399();
goto next_tmp_967461;
next_tmp_967461:
goto tmp_967460;
tmp_967460:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 6 */
}
goto done_tmp_967467;
fail_tmp_967458:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_967399();
goto next_tmp_967465;
next_tmp_967465:
goto tmp_967464;
tmp_967464:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 6 */
}
done_tmp_967467:
return tmp_952044;
}
reg_t genfunc_tmp_967399 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_967350();
goto next_tmp_967396;
next_tmp_967396:
goto tmp_967395;
tmp_967395:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_967398:
return tmp_952080;
}
reg_t genfunc_tmp_967350 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_967317 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_967317 >> 8) == 0)
field_imm = tmp_967317;
else goto fail_tmp_967316;
}
/* commit */
{
tmp_952040 = genfunc_tmp_967261();
goto next_tmp_967319;
next_tmp_967319:
goto tmp_967318;
tmp_967318:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_967349;
fail_tmp_967316:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_967341 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_967341))
field_imm = inv_maskmask(8, tmp_967341);
else goto fail_tmp_967340;
}
/* commit */
{
tmp_951257 = genfunc_tmp_967261();
goto next_tmp_967343;
next_tmp_967343:
goto tmp_967342;
tmp_967342:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_967349;
fail_tmp_967340:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_967261();
goto next_tmp_967347;
next_tmp_967347:
goto tmp_967346;
tmp_967346:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_967349:
return tmp_951324;
}
reg_t genfunc_tmp_967314 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_967283 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_967283 >> 8) == 0)
field_imm = tmp_967283;
else goto fail_tmp_967282;
}
/* commit */
{
tmp_952040 = genfunc_tmp_967261();
goto next_tmp_967285;
next_tmp_967285:
goto tmp_967284;
tmp_967284:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_967313;
fail_tmp_967282:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_967305 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_967305))
field_imm = inv_maskmask(8, tmp_967305);
else goto fail_tmp_967304;
}
/* commit */
{
tmp_951257 = genfunc_tmp_967261();
goto next_tmp_967307;
next_tmp_967307:
goto tmp_967306;
tmp_967306:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_967313;
fail_tmp_967304:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_967261();
goto next_tmp_967311;
next_tmp_967311:
goto tmp_967310;
tmp_967310:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_967313:
return tmp_952044;
}
reg_t genfunc_tmp_967261 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_967252;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_967236();
goto next_tmp_967254;
next_tmp_967254:
goto tmp_967253;
tmp_967253:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 2 */
}
goto done_tmp_967260;
fail_tmp_967252:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_967256;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_967236();
goto next_tmp_967258;
next_tmp_967258:
goto tmp_967257;
tmp_967257:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 2 */
}
goto done_tmp_967260;
fail_tmp_967256:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_952082 = genfunc_tmp_967236();
goto next_tmp_967217;
next_tmp_967217:
goto tmp_967216;
tmp_967216:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 3 */
}
done_tmp_967260:
return tmp_952058;
}
reg_t genfunc_tmp_967236 (void) {
reg_t tmp_952082;
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_reading(0 + 5);
tmp_952082 = ref_gpr_reg_for_reading(0 + index);
tmp_952079 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 1 */
}
done_tmp_967235:
return tmp_952082;
}
void genfunc_tmp_967195 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_966947();
goto next_tmp_966826;
next_tmp_966826:
goto tmp_966825;
tmp_966825:
}
{
tmp_951328 = genfunc_tmp_967192();
goto next_tmp_966950;
next_tmp_966950:
goto tmp_966949;
tmp_966949:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 9 */
}
done_tmp_967194:
}
reg_t genfunc_tmp_967192 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_967113();
goto next_tmp_967123;
next_tmp_967123:
goto tmp_967122;
tmp_967122:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_967191:
return tmp_951328;
}
reg_t genfunc_tmp_967161 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_967113();
goto next_tmp_967142;
next_tmp_967142:
goto tmp_967141;
tmp_967141:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_967160:
return tmp_952080;
}
reg_t genfunc_tmp_967113 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_966947();
goto next_tmp_967090;
next_tmp_967090:
goto tmp_967089;
tmp_967089:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_967112:
return tmp_952088;
}
reg_t genfunc_tmp_967065 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_967034 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_967034 >> 8) == 0)
field_imm = tmp_967034;
else goto fail_tmp_967033;
}
/* commit */
{
tmp_952040 = genfunc_tmp_966996();
goto next_tmp_967036;
next_tmp_967036:
goto tmp_967035;
tmp_967035:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_967064;
fail_tmp_967033:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_967056 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_967056))
field_imm = inv_maskmask(8, tmp_967056);
else goto fail_tmp_967055;
}
/* commit */
{
tmp_951257 = genfunc_tmp_966996();
goto next_tmp_967058;
next_tmp_967058:
goto tmp_967057;
tmp_967057:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_967064;
fail_tmp_967055:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_966996();
goto next_tmp_967062;
next_tmp_967062:
goto tmp_967061;
tmp_967061:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_967064:
return tmp_952044;
}
reg_t genfunc_tmp_966996 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_966947();
goto next_tmp_966993;
next_tmp_966993:
goto tmp_966992;
tmp_966992:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_966995:
return tmp_952080;
}
reg_t genfunc_tmp_966947 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_966914 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_966914 >> 8) == 0)
field_imm = tmp_966914;
else goto fail_tmp_966913;
}
/* commit */
{
tmp_952040 = genfunc_tmp_966858();
goto next_tmp_966916;
next_tmp_966916:
goto tmp_966915;
tmp_966915:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_966946;
fail_tmp_966913:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_966938 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_966938))
field_imm = inv_maskmask(8, tmp_966938);
else goto fail_tmp_966937;
}
/* commit */
{
tmp_951257 = genfunc_tmp_966858();
goto next_tmp_966940;
next_tmp_966940:
goto tmp_966939;
tmp_966939:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_966946;
fail_tmp_966937:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_966858();
goto next_tmp_966944;
next_tmp_966944:
goto tmp_966943;
tmp_966943:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_966946:
return tmp_951324;
}
reg_t genfunc_tmp_966911 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_966880 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_966880 >> 8) == 0)
field_imm = tmp_966880;
else goto fail_tmp_966879;
}
/* commit */
{
tmp_952040 = genfunc_tmp_966858();
goto next_tmp_966882;
next_tmp_966882:
goto tmp_966881;
tmp_966881:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_966910;
fail_tmp_966879:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_966902 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_966902))
field_imm = inv_maskmask(8, tmp_966902);
else goto fail_tmp_966901;
}
/* commit */
{
tmp_951257 = genfunc_tmp_966858();
goto next_tmp_966904;
next_tmp_966904:
goto tmp_966903;
tmp_966903:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_966910;
fail_tmp_966901:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_966858();
goto next_tmp_966908;
next_tmp_966908:
goto tmp_966907;
tmp_966907:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_966910:
return tmp_952044;
}
reg_t genfunc_tmp_966858 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_966855;
field_ra = 31;
/* commit */
tmp_951424 = ref_gpr_reg_for_reading(0 + base);
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 1 */
}
goto done_tmp_966857;
fail_tmp_966855:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_966856;
field_ra = 31;
/* commit */
tmp_951392 = ref_gpr_reg_for_reading(0 + base);
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 1 */
}
goto done_tmp_966857;
fail_tmp_966856:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_952082 = ref_gpr_reg_for_reading(0 + base);
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_966857:
return tmp_952058;
}
void genfunc_tmp_966820 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_966572();
goto next_tmp_966442;
next_tmp_966442:
goto tmp_966441;
tmp_966441:
}
{
tmp_951328 = genfunc_tmp_966817();
goto next_tmp_966575;
next_tmp_966575:
goto tmp_966574;
tmp_966574:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 13 */
}
done_tmp_966819:
}
reg_t genfunc_tmp_966817 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_966738();
goto next_tmp_966748;
next_tmp_966748:
goto tmp_966747;
tmp_966747:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 7 */
}
done_tmp_966816:
return tmp_951328;
}
reg_t genfunc_tmp_966786 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_966738();
goto next_tmp_966767;
next_tmp_966767:
goto tmp_966766;
tmp_966766:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 7 */
}
done_tmp_966785:
return tmp_952080;
}
reg_t genfunc_tmp_966738 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_966572();
goto next_tmp_966715;
next_tmp_966715:
goto tmp_966714;
tmp_966714:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_966737:
return tmp_952088;
}
reg_t genfunc_tmp_966690 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_966659 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_966659 >> 8) == 0)
field_imm = tmp_966659;
else goto fail_tmp_966658;
}
/* commit */
{
tmp_952040 = genfunc_tmp_966621();
goto next_tmp_966661;
next_tmp_966661:
goto tmp_966660;
tmp_966660:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 7 */
}
goto done_tmp_966689;
fail_tmp_966658:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_966681 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_966681))
field_imm = inv_maskmask(8, tmp_966681);
else goto fail_tmp_966680;
}
/* commit */
{
tmp_951257 = genfunc_tmp_966621();
goto next_tmp_966683;
next_tmp_966683:
goto tmp_966682;
tmp_966682:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 7 */
}
goto done_tmp_966689;
fail_tmp_966680:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_966621();
goto next_tmp_966687;
next_tmp_966687:
goto tmp_966686;
tmp_966686:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 7 */
}
done_tmp_966689:
return tmp_952044;
}
reg_t genfunc_tmp_966621 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_966572();
goto next_tmp_966618;
next_tmp_966618:
goto tmp_966617;
tmp_966617:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_966620:
return tmp_952080;
}
reg_t genfunc_tmp_966572 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_966539 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_966539 >> 8) == 0)
field_imm = tmp_966539;
else goto fail_tmp_966538;
}
/* commit */
{
tmp_952040 = genfunc_tmp_966483();
goto next_tmp_966541;
next_tmp_966541:
goto tmp_966540;
tmp_966540:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_966571;
fail_tmp_966538:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_966563 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_966563))
field_imm = inv_maskmask(8, tmp_966563);
else goto fail_tmp_966562;
}
/* commit */
{
tmp_951257 = genfunc_tmp_966483();
goto next_tmp_966565;
next_tmp_966565:
goto tmp_966564;
tmp_966564:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_966571;
fail_tmp_966562:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_966483();
goto next_tmp_966569;
next_tmp_966569:
goto tmp_966568;
tmp_966568:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_966571:
return tmp_951324;
}
reg_t genfunc_tmp_966536 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_966505 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_966505 >> 8) == 0)
field_imm = tmp_966505;
else goto fail_tmp_966504;
}
/* commit */
{
tmp_952040 = genfunc_tmp_966483();
goto next_tmp_966507;
next_tmp_966507:
goto tmp_966506;
tmp_966506:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_966535;
fail_tmp_966504:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_966527 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_966527))
field_imm = inv_maskmask(8, tmp_966527);
else goto fail_tmp_966526;
}
/* commit */
{
tmp_951257 = genfunc_tmp_966483();
goto next_tmp_966529;
next_tmp_966529:
goto tmp_966528;
tmp_966528:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_966535;
fail_tmp_966526:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_966483();
goto next_tmp_966533;
next_tmp_966533:
goto tmp_966532;
tmp_966532:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_966535:
return tmp_952044;
}
reg_t genfunc_tmp_966483 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_966474;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_963989();
goto next_tmp_966476;
next_tmp_966476:
goto tmp_966475;
tmp_966475:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 3 */
}
goto done_tmp_966482;
fail_tmp_966474:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_966478;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_963989();
goto next_tmp_966480;
next_tmp_966480:
goto tmp_966479;
tmp_966479:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 3 */
}
goto done_tmp_966482;
fail_tmp_966478:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_952082 = genfunc_tmp_963989();
goto next_tmp_966458;
next_tmp_966458:
goto tmp_966457;
tmp_966457:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 4 */
}
done_tmp_966482:
return tmp_952058;
}
void genfunc_tmp_966436 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_966188();
goto next_tmp_966058;
next_tmp_966058:
goto tmp_966057;
tmp_966057:
}
{
tmp_951328 = genfunc_tmp_966433();
goto next_tmp_966191;
next_tmp_966191:
goto tmp_966190;
tmp_966190:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 11 */
}
done_tmp_966435:
}
reg_t genfunc_tmp_966433 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_966354();
goto next_tmp_966364;
next_tmp_966364:
goto tmp_966363;
tmp_966363:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 6 */
}
done_tmp_966432:
return tmp_951328;
}
reg_t genfunc_tmp_966402 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_966354();
goto next_tmp_966383;
next_tmp_966383:
goto tmp_966382;
tmp_966382:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 6 */
}
done_tmp_966401:
return tmp_952080;
}
reg_t genfunc_tmp_966354 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_966188();
goto next_tmp_966331;
next_tmp_966331:
goto tmp_966330;
tmp_966330:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_966353:
return tmp_952088;
}
reg_t genfunc_tmp_966306 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_966275 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_966275 >> 8) == 0)
field_imm = tmp_966275;
else goto fail_tmp_966274;
}
/* commit */
{
tmp_952040 = genfunc_tmp_966237();
goto next_tmp_966277;
next_tmp_966277:
goto tmp_966276;
tmp_966276:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 6 */
}
goto done_tmp_966305;
fail_tmp_966274:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_966297 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_966297))
field_imm = inv_maskmask(8, tmp_966297);
else goto fail_tmp_966296;
}
/* commit */
{
tmp_951257 = genfunc_tmp_966237();
goto next_tmp_966299;
next_tmp_966299:
goto tmp_966298;
tmp_966298:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 6 */
}
goto done_tmp_966305;
fail_tmp_966296:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_966237();
goto next_tmp_966303;
next_tmp_966303:
goto tmp_966302;
tmp_966302:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 6 */
}
done_tmp_966305:
return tmp_952044;
}
reg_t genfunc_tmp_966237 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_966188();
goto next_tmp_966234;
next_tmp_966234:
goto tmp_966233;
tmp_966233:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_966236:
return tmp_952080;
}
reg_t genfunc_tmp_966188 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_966155 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_966155 >> 8) == 0)
field_imm = tmp_966155;
else goto fail_tmp_966154;
}
/* commit */
{
tmp_952040 = genfunc_tmp_966099();
goto next_tmp_966157;
next_tmp_966157:
goto tmp_966156;
tmp_966156:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_966187;
fail_tmp_966154:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_966179 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_966179))
field_imm = inv_maskmask(8, tmp_966179);
else goto fail_tmp_966178;
}
/* commit */
{
tmp_951257 = genfunc_tmp_966099();
goto next_tmp_966181;
next_tmp_966181:
goto tmp_966180;
tmp_966180:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_966187;
fail_tmp_966178:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_966099();
goto next_tmp_966185;
next_tmp_966185:
goto tmp_966184;
tmp_966184:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_966187:
return tmp_951324;
}
reg_t genfunc_tmp_966152 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_966121 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_966121 >> 8) == 0)
field_imm = tmp_966121;
else goto fail_tmp_966120;
}
/* commit */
{
tmp_952040 = genfunc_tmp_966099();
goto next_tmp_966123;
next_tmp_966123:
goto tmp_966122;
tmp_966122:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_966151;
fail_tmp_966120:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_966143 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_966143))
field_imm = inv_maskmask(8, tmp_966143);
else goto fail_tmp_966142;
}
/* commit */
{
tmp_951257 = genfunc_tmp_966099();
goto next_tmp_966145;
next_tmp_966145:
goto tmp_966144;
tmp_966144:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_966151;
fail_tmp_966142:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_966099();
goto next_tmp_966149;
next_tmp_966149:
goto tmp_966148;
tmp_966148:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_966151:
return tmp_952044;
}
reg_t genfunc_tmp_966099 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_966090;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_963581();
goto next_tmp_966092;
next_tmp_966092:
goto tmp_966091;
tmp_966091:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 2 */
}
goto done_tmp_966098;
fail_tmp_966090:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_966094;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_963581();
goto next_tmp_966096;
next_tmp_966096:
goto tmp_966095;
tmp_966095:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 2 */
}
goto done_tmp_966098;
fail_tmp_966094:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_952082 = genfunc_tmp_963581();
goto next_tmp_966074;
next_tmp_966074:
goto tmp_966073;
tmp_966073:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 3 */
}
done_tmp_966098:
return tmp_952058;
}
void genfunc_tmp_966052 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_965804();
goto next_tmp_965678;
next_tmp_965678:
goto tmp_965677;
tmp_965677:
}
{
tmp_951328 = genfunc_tmp_966049();
goto next_tmp_965807;
next_tmp_965807:
goto tmp_965806;
tmp_965806:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 9 */
}
done_tmp_966051:
}
reg_t genfunc_tmp_966049 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_965970();
goto next_tmp_965980;
next_tmp_965980:
goto tmp_965979;
tmp_965979:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_966048:
return tmp_951328;
}
reg_t genfunc_tmp_966018 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_965970();
goto next_tmp_965999;
next_tmp_965999:
goto tmp_965998;
tmp_965998:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_966017:
return tmp_952080;
}
reg_t genfunc_tmp_965970 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_965804();
goto next_tmp_965947;
next_tmp_965947:
goto tmp_965946;
tmp_965946:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_965969:
return tmp_952088;
}
reg_t genfunc_tmp_965922 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_965891 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_965891 >> 8) == 0)
field_imm = tmp_965891;
else goto fail_tmp_965890;
}
/* commit */
{
tmp_952040 = genfunc_tmp_965853();
goto next_tmp_965893;
next_tmp_965893:
goto tmp_965892;
tmp_965892:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_965921;
fail_tmp_965890:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_965913 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_965913))
field_imm = inv_maskmask(8, tmp_965913);
else goto fail_tmp_965912;
}
/* commit */
{
tmp_951257 = genfunc_tmp_965853();
goto next_tmp_965915;
next_tmp_965915:
goto tmp_965914;
tmp_965914:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_965921;
fail_tmp_965912:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_965853();
goto next_tmp_965919;
next_tmp_965919:
goto tmp_965918;
tmp_965918:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_965921:
return tmp_952044;
}
reg_t genfunc_tmp_965853 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_965804();
goto next_tmp_965850;
next_tmp_965850:
goto tmp_965849;
tmp_965849:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_965852:
return tmp_952080;
}
reg_t genfunc_tmp_965804 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_965771 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_965771 >> 8) == 0)
field_imm = tmp_965771;
else goto fail_tmp_965770;
}
/* commit */
{
tmp_952040 = genfunc_tmp_965715();
goto next_tmp_965773;
next_tmp_965773:
goto tmp_965772;
tmp_965772:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_965803;
fail_tmp_965770:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_965795 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_965795))
field_imm = inv_maskmask(8, tmp_965795);
else goto fail_tmp_965794;
}
/* commit */
{
tmp_951257 = genfunc_tmp_965715();
goto next_tmp_965797;
next_tmp_965797:
goto tmp_965796;
tmp_965796:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_965803;
fail_tmp_965794:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_965715();
goto next_tmp_965801;
next_tmp_965801:
goto tmp_965800;
tmp_965800:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_965803:
return tmp_951324;
}
reg_t genfunc_tmp_965768 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_965737 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_965737 >> 8) == 0)
field_imm = tmp_965737;
else goto fail_tmp_965736;
}
/* commit */
{
tmp_952040 = genfunc_tmp_965715();
goto next_tmp_965739;
next_tmp_965739:
goto tmp_965738;
tmp_965738:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_965767;
fail_tmp_965736:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_965759 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_965759))
field_imm = inv_maskmask(8, tmp_965759);
else goto fail_tmp_965758;
}
/* commit */
{
tmp_951257 = genfunc_tmp_965715();
goto next_tmp_965761;
next_tmp_965761:
goto tmp_965760;
tmp_965760:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_965767;
fail_tmp_965758:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_965715();
goto next_tmp_965765;
next_tmp_965765:
goto tmp_965764;
tmp_965764:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_965767:
return tmp_952044;
}
reg_t genfunc_tmp_965715 (void) {
reg_t tmp_952058;
/* ADDQ_IMM */
{
word_5 tmp_952075;
word_5 field_rc;
word_5 tmp_952076;
word_5 field_ra;
word_64 tmp_952078;
word_8 field_imm;
tmp_952078 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_965700 = tmp_952078;
if ((tmp_965700 >> 8) == 0)
field_imm = tmp_965700;
else goto fail_tmp_965699;
}
/* commit */
tmp_952076 = ref_gpr_reg_for_reading(0 + rm);
tmp_952075 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952075;
field_ra = tmp_952076;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952076);
/* can fail: T   num insns: 1 */
}
goto done_tmp_965714;
fail_tmp_965699:
/* LDA */
{
word_5 tmp_951579;
word_5 field_ra;
word_5 tmp_951580;
word_5 field_rb;
word_64 tmp_951582;
word_16 field_memory_disp;
tmp_951582 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_965708 = tmp_951582;
if ((tmp_965708 >> 16) == 0xFFFFFFFFFFFF || (tmp_965708 >> 16) == 0)
field_memory_disp = (tmp_965708 & 0xFFFF);
else goto fail_tmp_965707;
}
/* commit */
tmp_951580 = ref_gpr_reg_for_reading(0 + rm);
tmp_951579 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951579;
field_rb = tmp_951580;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951580);
/* can fail: T   num insns: 1 */
}
goto done_tmp_965714;
fail_tmp_965707:
/* LDAH */
{
word_5 tmp_951575;
word_5 field_ra;
word_5 tmp_951576;
word_5 field_rb;
word_64 tmp_951578;
word_16 field_memory_disp;
tmp_951578 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_965712 = tmp_951578;
if ((tmp_965712 & 0xFFFF) == 0)
{
word_64 tmp_965713 = (tmp_965712 >> 16);
if ((tmp_965713 >> 16) == 0xFFFFFFFFFFFF || (tmp_965713 >> 16) == 0)
field_memory_disp = (tmp_965713 & 0xFFFF);
else goto fail_tmp_965711;
}
else goto fail_tmp_965711;
}
/* commit */
tmp_951576 = ref_gpr_reg_for_reading(0 + rm);
tmp_951575 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951575;
field_rb = tmp_951576;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951576);
/* can fail: T   num insns: 1 */
}
goto done_tmp_965714;
fail_tmp_965711:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_reading(0 + rm);
tmp_952082 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952082, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_965714:
return tmp_952058;
}
void genfunc_tmp_965669 (void) {
/* STL */
{
word_5 field_rb;
word_64 tmp_951325;
word_16 field_memory_disp;
word_5 tmp_951327;
word_5 field_ra;
tmp_951325 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_965664 = tmp_951325;
if ((tmp_965664 >> 16) == 0xFFFFFFFFFFFF || (tmp_965664 >> 16) == 0)
field_memory_disp = (tmp_965664 & 0xFFFF);
else goto fail_tmp_965663;
}
/* commit */
{
tmp_951327 = genfunc_tmp_965661();
goto next_tmp_965666;
next_tmp_965666:
goto tmp_965665;
tmp_965665:
}
field_ra = tmp_951327;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951327);
/* can fail: T   num insns: 4 */
}
goto done_tmp_965668;
fail_tmp_965663:
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
tmp_951324 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_951324, ((word_64)disp32));
{
tmp_951328 = genfunc_tmp_965661();
goto next_tmp_965421;
next_tmp_965421:
goto tmp_965420;
tmp_965420:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 5 */
}
done_tmp_965668:
}
reg_t genfunc_tmp_965661 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_965582();
goto next_tmp_965592;
next_tmp_965592:
goto tmp_965591;
tmp_965591:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 3 */
}
done_tmp_965660:
return tmp_951328;
}
reg_t genfunc_tmp_965630 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_965582();
goto next_tmp_965611;
next_tmp_965611:
goto tmp_965610;
tmp_965610:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 3 */
}
done_tmp_965629:
return tmp_952080;
}
reg_t genfunc_tmp_965582 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_951565;
word_16 field_memory_disp;
tmp_951565 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_965560 = tmp_951565;
if ((tmp_965560 >> 16) == 0xFFFFFFFFFFFF || (tmp_965560 >> 16) == 0)
field_memory_disp = (tmp_965560 & 0xFFFF);
else goto fail_tmp_965559;
}
/* commit */
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_965581;
fail_tmp_965559:
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
tmp_951564 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_951564, ((word_64)disp32));
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 2 */
}
done_tmp_965581:
return tmp_952088;
}
reg_t genfunc_tmp_965535 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_965504 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_965504 >> 8) == 0)
field_imm = tmp_965504;
else goto fail_tmp_965503;
}
/* commit */
{
tmp_952040 = genfunc_tmp_965466();
goto next_tmp_965506;
next_tmp_965506:
goto tmp_965505;
tmp_965505:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_965534;
fail_tmp_965503:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_965526 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_965526))
field_imm = inv_maskmask(8, tmp_965526);
else goto fail_tmp_965525;
}
/* commit */
{
tmp_951257 = genfunc_tmp_965466();
goto next_tmp_965528;
next_tmp_965528:
goto tmp_965527;
tmp_965527:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_965534;
fail_tmp_965525:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_965466();
goto next_tmp_965532;
next_tmp_965532:
goto tmp_965531;
tmp_965531:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_965534:
return tmp_952044;
}
reg_t genfunc_tmp_965466 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_951565;
word_16 field_memory_disp;
tmp_951565 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_965464 = tmp_951565;
if ((tmp_965464 >> 16) == 0xFFFFFFFFFFFF || (tmp_965464 >> 16) == 0)
field_memory_disp = (tmp_965464 & 0xFFFF);
else goto fail_tmp_965463;
}
/* commit */
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_965465;
fail_tmp_965463:
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
tmp_951564 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_951564, ((word_64)disp32));
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 2 */
}
done_tmp_965465:
return tmp_952080;
}
void genfunc_tmp_965415 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_965167();
goto next_tmp_965037;
next_tmp_965037:
goto tmp_965036;
tmp_965036:
}
{
tmp_951328 = genfunc_tmp_965412();
goto next_tmp_965170;
next_tmp_965170:
goto tmp_965169;
tmp_965169:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 11 */
}
done_tmp_965414:
}
reg_t genfunc_tmp_965412 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_965333();
goto next_tmp_965343;
next_tmp_965343:
goto tmp_965342;
tmp_965342:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 6 */
}
done_tmp_965411:
return tmp_951328;
}
reg_t genfunc_tmp_965381 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_965333();
goto next_tmp_965362;
next_tmp_965362:
goto tmp_965361;
tmp_965361:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 6 */
}
done_tmp_965380:
return tmp_952080;
}
reg_t genfunc_tmp_965333 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_965167();
goto next_tmp_965310;
next_tmp_965310:
goto tmp_965309;
tmp_965309:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_965332:
return tmp_952088;
}
reg_t genfunc_tmp_965285 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_965254 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_965254 >> 8) == 0)
field_imm = tmp_965254;
else goto fail_tmp_965253;
}
/* commit */
{
tmp_952040 = genfunc_tmp_965216();
goto next_tmp_965256;
next_tmp_965256:
goto tmp_965255;
tmp_965255:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 6 */
}
goto done_tmp_965284;
fail_tmp_965253:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_965276 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_965276))
field_imm = inv_maskmask(8, tmp_965276);
else goto fail_tmp_965275;
}
/* commit */
{
tmp_951257 = genfunc_tmp_965216();
goto next_tmp_965278;
next_tmp_965278:
goto tmp_965277;
tmp_965277:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 6 */
}
goto done_tmp_965284;
fail_tmp_965275:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_965216();
goto next_tmp_965282;
next_tmp_965282:
goto tmp_965281;
tmp_965281:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 6 */
}
done_tmp_965284:
return tmp_952044;
}
reg_t genfunc_tmp_965216 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_965167();
goto next_tmp_965213;
next_tmp_965213:
goto tmp_965212;
tmp_965212:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_965215:
return tmp_952080;
}
reg_t genfunc_tmp_965167 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_965134 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_965134 >> 8) == 0)
field_imm = tmp_965134;
else goto fail_tmp_965133;
}
/* commit */
{
tmp_952040 = genfunc_tmp_965078();
goto next_tmp_965136;
next_tmp_965136:
goto tmp_965135;
tmp_965135:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_965166;
fail_tmp_965133:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_965158 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_965158))
field_imm = inv_maskmask(8, tmp_965158);
else goto fail_tmp_965157;
}
/* commit */
{
tmp_951257 = genfunc_tmp_965078();
goto next_tmp_965160;
next_tmp_965160:
goto tmp_965159;
tmp_965159:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_965166;
fail_tmp_965157:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_965078();
goto next_tmp_965164;
next_tmp_965164:
goto tmp_965163;
tmp_965163:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_965166:
return tmp_951324;
}
reg_t genfunc_tmp_965131 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_965100 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_965100 >> 8) == 0)
field_imm = tmp_965100;
else goto fail_tmp_965099;
}
/* commit */
{
tmp_952040 = genfunc_tmp_965078();
goto next_tmp_965102;
next_tmp_965102:
goto tmp_965101;
tmp_965101:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_965130;
fail_tmp_965099:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_965122 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_965122))
field_imm = inv_maskmask(8, tmp_965122);
else goto fail_tmp_965121;
}
/* commit */
{
tmp_951257 = genfunc_tmp_965078();
goto next_tmp_965124;
next_tmp_965124:
goto tmp_965123;
tmp_965123:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_965130;
fail_tmp_965121:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_965078();
goto next_tmp_965128;
next_tmp_965128:
goto tmp_965127;
tmp_965127:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_965130:
return tmp_952044;
}
reg_t genfunc_tmp_965078 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_965069;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_963972();
goto next_tmp_965071;
next_tmp_965071:
goto tmp_965070;
tmp_965070:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 2 */
}
goto done_tmp_965077;
fail_tmp_965069:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_965073;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_963972();
goto next_tmp_965075;
next_tmp_965075:
goto tmp_965074;
tmp_965074:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 2 */
}
goto done_tmp_965077;
fail_tmp_965073:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_952082 = genfunc_tmp_963972();
goto next_tmp_965053;
next_tmp_965053:
goto tmp_965052;
tmp_965052:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 3 */
}
done_tmp_965077:
return tmp_952058;
}
void genfunc_tmp_965031 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_964783();
goto next_tmp_964662;
next_tmp_964662:
goto tmp_964661;
tmp_964661:
}
{
tmp_951328 = genfunc_tmp_965028();
goto next_tmp_964786;
next_tmp_964786:
goto tmp_964785;
tmp_964785:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 9 */
}
done_tmp_965030:
}
reg_t genfunc_tmp_965028 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_964949();
goto next_tmp_964959;
next_tmp_964959:
goto tmp_964958;
tmp_964958:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_965027:
return tmp_951328;
}
reg_t genfunc_tmp_964997 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_964949();
goto next_tmp_964978;
next_tmp_964978:
goto tmp_964977;
tmp_964977:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_964996:
return tmp_952080;
}
reg_t genfunc_tmp_964949 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_964783();
goto next_tmp_964926;
next_tmp_964926:
goto tmp_964925;
tmp_964925:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_964948:
return tmp_952088;
}
reg_t genfunc_tmp_964901 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_964870 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_964870 >> 8) == 0)
field_imm = tmp_964870;
else goto fail_tmp_964869;
}
/* commit */
{
tmp_952040 = genfunc_tmp_964832();
goto next_tmp_964872;
next_tmp_964872:
goto tmp_964871;
tmp_964871:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_964900;
fail_tmp_964869:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_964892 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_964892))
field_imm = inv_maskmask(8, tmp_964892);
else goto fail_tmp_964891;
}
/* commit */
{
tmp_951257 = genfunc_tmp_964832();
goto next_tmp_964894;
next_tmp_964894:
goto tmp_964893;
tmp_964893:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_964900;
fail_tmp_964891:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_964832();
goto next_tmp_964898;
next_tmp_964898:
goto tmp_964897;
tmp_964897:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_964900:
return tmp_952044;
}
reg_t genfunc_tmp_964832 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_964783();
goto next_tmp_964829;
next_tmp_964829:
goto tmp_964828;
tmp_964828:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_964831:
return tmp_952080;
}
reg_t genfunc_tmp_964783 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_964750 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_964750 >> 8) == 0)
field_imm = tmp_964750;
else goto fail_tmp_964749;
}
/* commit */
{
tmp_952040 = genfunc_tmp_964694();
goto next_tmp_964752;
next_tmp_964752:
goto tmp_964751;
tmp_964751:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_964782;
fail_tmp_964749:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_964774 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_964774))
field_imm = inv_maskmask(8, tmp_964774);
else goto fail_tmp_964773;
}
/* commit */
{
tmp_951257 = genfunc_tmp_964694();
goto next_tmp_964776;
next_tmp_964776:
goto tmp_964775;
tmp_964775:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_964782;
fail_tmp_964773:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_964694();
goto next_tmp_964780;
next_tmp_964780:
goto tmp_964779;
tmp_964779:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_964782:
return tmp_951324;
}
reg_t genfunc_tmp_964747 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_964716 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_964716 >> 8) == 0)
field_imm = tmp_964716;
else goto fail_tmp_964715;
}
/* commit */
{
tmp_952040 = genfunc_tmp_964694();
goto next_tmp_964718;
next_tmp_964718:
goto tmp_964717;
tmp_964717:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_964746;
fail_tmp_964715:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_964738 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_964738))
field_imm = inv_maskmask(8, tmp_964738);
else goto fail_tmp_964737;
}
/* commit */
{
tmp_951257 = genfunc_tmp_964694();
goto next_tmp_964740;
next_tmp_964740:
goto tmp_964739;
tmp_964739:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_964746;
fail_tmp_964737:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_964694();
goto next_tmp_964744;
next_tmp_964744:
goto tmp_964743;
tmp_964743:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_964746:
return tmp_952044;
}
reg_t genfunc_tmp_964694 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_964691;
field_ra = 31;
/* commit */
tmp_951424 = ref_gpr_reg_for_reading(0 + index);
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 1 */
}
goto done_tmp_964693;
fail_tmp_964691:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_964692;
field_ra = 31;
/* commit */
tmp_951392 = ref_gpr_reg_for_reading(0 + index);
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 1 */
}
goto done_tmp_964693;
fail_tmp_964692:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_952082 = ref_gpr_reg_for_reading(0 + index);
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_964693:
return tmp_952058;
}
void genfunc_tmp_964656 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_964408();
goto next_tmp_964332;
next_tmp_964332:
goto tmp_964331;
tmp_964331:
}
{
tmp_951328 = genfunc_tmp_964653();
goto next_tmp_964411;
next_tmp_964411:
goto tmp_964410;
tmp_964410:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 5 */
}
done_tmp_964655:
}
reg_t genfunc_tmp_964653 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_964574();
goto next_tmp_964584;
next_tmp_964584:
goto tmp_964583;
tmp_964583:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 3 */
}
done_tmp_964652:
return tmp_951328;
}
reg_t genfunc_tmp_964622 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_964574();
goto next_tmp_964603;
next_tmp_964603:
goto tmp_964602;
tmp_964602:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 3 */
}
done_tmp_964621:
return tmp_952080;
}
reg_t genfunc_tmp_964574 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_964408();
goto next_tmp_964551;
next_tmp_964551:
goto tmp_964550;
tmp_964550:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 2 */
}
done_tmp_964573:
return tmp_952088;
}
reg_t genfunc_tmp_964526 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_964495 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_964495 >> 8) == 0)
field_imm = tmp_964495;
else goto fail_tmp_964494;
}
/* commit */
{
tmp_952040 = genfunc_tmp_964457();
goto next_tmp_964497;
next_tmp_964497:
goto tmp_964496;
tmp_964496:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_964525;
fail_tmp_964494:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_964517 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_964517))
field_imm = inv_maskmask(8, tmp_964517);
else goto fail_tmp_964516;
}
/* commit */
{
tmp_951257 = genfunc_tmp_964457();
goto next_tmp_964519;
next_tmp_964519:
goto tmp_964518;
tmp_964518:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_964525;
fail_tmp_964516:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_964457();
goto next_tmp_964523;
next_tmp_964523:
goto tmp_964522;
tmp_964522:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_964525:
return tmp_952044;
}
reg_t genfunc_tmp_964457 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_964408();
goto next_tmp_964454;
next_tmp_964454:
goto tmp_964453;
tmp_964453:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 2 */
}
done_tmp_964456:
return tmp_952080;
}
reg_t genfunc_tmp_964408 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_964384 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_964384 >> 8) == 0)
field_imm = tmp_964384;
else goto fail_tmp_964383;
}
/* commit */
tmp_952040 = ref_gpr_reg_for_reading(0 + base);
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 1 */
}
goto done_tmp_964407;
fail_tmp_964383:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_964405 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_964405))
field_imm = inv_maskmask(8, tmp_964405);
else goto fail_tmp_964404;
}
/* commit */
tmp_951257 = ref_gpr_reg_for_reading(0 + base);
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 1 */
}
goto done_tmp_964407;
fail_tmp_964404:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
tmp_951249 = ref_gpr_reg_for_reading(0 + base);
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 1 */
}
done_tmp_964407:
return tmp_951324;
}
reg_t genfunc_tmp_964381 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_964359 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_964359 >> 8) == 0)
field_imm = tmp_964359;
else goto fail_tmp_964358;
}
/* commit */
tmp_952040 = ref_gpr_reg_for_reading(0 + base);
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 1 */
}
goto done_tmp_964380;
fail_tmp_964358:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_964378 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_964378))
field_imm = inv_maskmask(8, tmp_964378);
else goto fail_tmp_964377;
}
/* commit */
tmp_951257 = ref_gpr_reg_for_reading(0 + base);
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 1 */
}
goto done_tmp_964380;
fail_tmp_964377:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
tmp_951249 = ref_gpr_reg_for_reading(0 + base);
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 1 */
}
done_tmp_964380:
return tmp_952044;
}
void genfunc_tmp_964326 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_964078();
goto next_tmp_963924;
next_tmp_963924:
goto tmp_963923;
tmp_963923:
}
{
tmp_951328 = genfunc_tmp_964323();
goto next_tmp_964081;
next_tmp_964081:
goto tmp_964080;
tmp_964080:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 9 */
}
done_tmp_964325:
}
reg_t genfunc_tmp_964323 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_964244();
goto next_tmp_964254;
next_tmp_964254:
goto tmp_964253;
tmp_964253:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_964322:
return tmp_951328;
}
reg_t genfunc_tmp_964292 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_964244();
goto next_tmp_964273;
next_tmp_964273:
goto tmp_964272;
tmp_964272:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 5 */
}
done_tmp_964291:
return tmp_952080;
}
reg_t genfunc_tmp_964244 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_964078();
goto next_tmp_964221;
next_tmp_964221:
goto tmp_964220;
tmp_964220:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_964243:
return tmp_952088;
}
reg_t genfunc_tmp_964196 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_964165 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_964165 >> 8) == 0)
field_imm = tmp_964165;
else goto fail_tmp_964164;
}
/* commit */
{
tmp_952040 = genfunc_tmp_964127();
goto next_tmp_964167;
next_tmp_964167:
goto tmp_964166;
tmp_964166:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_964195;
fail_tmp_964164:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_964187 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_964187))
field_imm = inv_maskmask(8, tmp_964187);
else goto fail_tmp_964186;
}
/* commit */
{
tmp_951257 = genfunc_tmp_964127();
goto next_tmp_964189;
next_tmp_964189:
goto tmp_964188;
tmp_964188:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_964195;
fail_tmp_964186:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_964127();
goto next_tmp_964193;
next_tmp_964193:
goto tmp_964192;
tmp_964192:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_964195:
return tmp_952044;
}
reg_t genfunc_tmp_964127 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_964078();
goto next_tmp_964124;
next_tmp_964124:
goto tmp_964123;
tmp_964123:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_964126:
return tmp_952080;
}
reg_t genfunc_tmp_964078 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_964045 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_964045 >> 8) == 0)
field_imm = tmp_964045;
else goto fail_tmp_964044;
}
/* commit */
{
tmp_952040 = genfunc_tmp_963989();
goto next_tmp_964047;
next_tmp_964047:
goto tmp_964046;
tmp_964046:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_964077;
fail_tmp_964044:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_964069 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_964069))
field_imm = inv_maskmask(8, tmp_964069);
else goto fail_tmp_964068;
}
/* commit */
{
tmp_951257 = genfunc_tmp_963989();
goto next_tmp_964071;
next_tmp_964071:
goto tmp_964070;
tmp_964070:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_964077;
fail_tmp_964068:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_963989();
goto next_tmp_964075;
next_tmp_964075:
goto tmp_964074;
tmp_964074:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_964077:
return tmp_951324;
}
reg_t genfunc_tmp_964042 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_964011 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_964011 >> 8) == 0)
field_imm = tmp_964011;
else goto fail_tmp_964010;
}
/* commit */
{
tmp_952040 = genfunc_tmp_963989();
goto next_tmp_964013;
next_tmp_964013:
goto tmp_964012;
tmp_964012:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_964041;
fail_tmp_964010:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_964033 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_964033))
field_imm = inv_maskmask(8, tmp_964033);
else goto fail_tmp_964032;
}
/* commit */
{
tmp_951257 = genfunc_tmp_963989();
goto next_tmp_964035;
next_tmp_964035:
goto tmp_964034;
tmp_964034:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_964041;
fail_tmp_964032:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_963989();
goto next_tmp_964039;
next_tmp_964039:
goto tmp_964038;
tmp_964038:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_964041:
return tmp_952044;
}
reg_t genfunc_tmp_963989 (void) {
reg_t tmp_952058;
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_reading(0 + base);
{
tmp_952082 = genfunc_tmp_963972();
goto next_tmp_963940;
next_tmp_963940:
goto tmp_963939;
tmp_963939:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_963988:
return tmp_952058;
}
reg_t genfunc_tmp_963972 (void) {
reg_t tmp_952082;
/* EXTQH */
{
word_5 tmp_951800;
word_5 field_rc;
word_5 tmp_951801;
word_5 field_ra;
word_5 field_rb;
if (64 != ((word_64)scale)) goto fail_tmp_963953;
field_rb = 31;
/* commit */
tmp_951801 = ref_gpr_reg_for_reading(0 + index);
tmp_951800 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951800;
field_ra = tmp_951801;
emit(COMPOSE_EXTQH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951801);
/* can fail: T   num insns: 1 */
}
goto done_tmp_963971;
fail_tmp_963953:
/* EXTQH_IMM */
{
word_5 tmp_951796;
word_5 field_rc;
word_5 tmp_951797;
word_5 field_ra;
word_64 tmp_951799;
word_8 field_imm;
tmp_951799 = ((word_64)scale);
{
word_64 tmp_963955 = ((64 - tmp_951799) & 0xFFFFFFFFFFFFFFFF);
if (tmp_963955 % 8 == 0)
{
word_64 tmp_963956 = (tmp_963955 / 8);
if ((tmp_963956 & 7) == tmp_963956)
{
word_64 tmp_963957 = tmp_963956;
if ((tmp_963957 >> 8) == 0)
field_imm = tmp_963957;
else goto fail_tmp_963954;
}
else goto fail_tmp_963954;
}
else goto fail_tmp_963954;
}
/* commit */
tmp_951797 = ref_gpr_reg_for_reading(0 + index);
tmp_951796 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951796;
field_ra = tmp_951797;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951797);
/* can fail: T   num insns: 1 */
}
goto done_tmp_963971;
fail_tmp_963954:
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 tmp_951423;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_963963;
field_rb = 31;
/* commit */
tmp_951423 = ref_gpr_reg_for_reading(0 + index);
tmp_951422 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_ra = tmp_951423;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951423);
/* can fail: T   num insns: 1 */
}
goto done_tmp_963971;
fail_tmp_963963:
/* S4ADDQ_IMM */
{
word_5 tmp_951418;
word_5 field_rc;
word_5 tmp_951419;
word_5 field_ra;
word_64 tmp_951421;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_963964;
tmp_951421 = 0;
field_imm = 0;
/* commit */
tmp_951419 = ref_gpr_reg_for_reading(0 + index);
tmp_951418 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951418;
field_ra = tmp_951419;
emit(COMPOSE_S4ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951419);
/* can fail: T   num insns: 1 */
}
goto done_tmp_963971;
fail_tmp_963964:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 tmp_951391;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_963966;
field_rb = 31;
/* commit */
tmp_951391 = ref_gpr_reg_for_reading(0 + index);
tmp_951390 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_ra = tmp_951391;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951391);
/* can fail: T   num insns: 1 */
}
goto done_tmp_963971;
fail_tmp_963966:
/* S8ADDQ_IMM */
{
word_5 tmp_951386;
word_5 field_rc;
word_5 tmp_951387;
word_5 field_ra;
word_64 tmp_951389;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_963967;
tmp_951389 = 0;
field_imm = 0;
/* commit */
tmp_951387 = ref_gpr_reg_for_reading(0 + index);
tmp_951386 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951386;
field_ra = tmp_951387;
emit(COMPOSE_S8ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951387);
/* can fail: T   num insns: 1 */
}
goto done_tmp_963971;
fail_tmp_963967:
/* SLL */
{
word_5 tmp_951358;
word_5 field_rc;
word_5 tmp_951359;
word_5 field_ra;
word_5 field_rb;
if (0 != ((word_64)scale)) goto fail_tmp_963968;
field_rb = 31;
/* commit */
tmp_951359 = ref_gpr_reg_for_reading(0 + index);
tmp_951358 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951358;
field_ra = tmp_951359;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951359);
/* can fail: T   num insns: 1 */
}
goto done_tmp_963971;
fail_tmp_963968:
/* SLL_IMM */
{
word_5 tmp_951354;
word_5 field_rc;
word_5 tmp_951355;
word_5 field_ra;
word_64 tmp_951357;
word_8 field_imm;
tmp_951357 = ((word_64)scale);
field_imm = tmp_951357;
/* commit */
tmp_951355 = ref_gpr_reg_for_reading(0 + index);
tmp_951354 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951354;
field_ra = tmp_951355;
emit(COMPOSE_SLL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951355);
/* can fail: NIL   num insns: 1 */
}
done_tmp_963971:
return tmp_952082;
}
void genfunc_tmp_963918 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_963670();
goto next_tmp_963551;
next_tmp_963551:
goto tmp_963550;
tmp_963550:
}
{
tmp_951328 = genfunc_tmp_963915();
goto next_tmp_963673;
next_tmp_963673:
goto tmp_963672;
tmp_963672:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 7 */
}
done_tmp_963917:
}
reg_t genfunc_tmp_963915 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_963836();
goto next_tmp_963846;
next_tmp_963846:
goto tmp_963845;
tmp_963845:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 4 */
}
done_tmp_963914:
return tmp_951328;
}
reg_t genfunc_tmp_963884 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_963836();
goto next_tmp_963865;
next_tmp_963865:
goto tmp_963864;
tmp_963864:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 4 */
}
done_tmp_963883:
return tmp_952080;
}
reg_t genfunc_tmp_963836 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_963670();
goto next_tmp_963813;
next_tmp_963813:
goto tmp_963812;
tmp_963812:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 3 */
}
done_tmp_963835:
return tmp_952088;
}
reg_t genfunc_tmp_963788 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_963757 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_963757 >> 8) == 0)
field_imm = tmp_963757;
else goto fail_tmp_963756;
}
/* commit */
{
tmp_952040 = genfunc_tmp_963719();
goto next_tmp_963759;
next_tmp_963759:
goto tmp_963758;
tmp_963758:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_963787;
fail_tmp_963756:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_963779 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_963779))
field_imm = inv_maskmask(8, tmp_963779);
else goto fail_tmp_963778;
}
/* commit */
{
tmp_951257 = genfunc_tmp_963719();
goto next_tmp_963781;
next_tmp_963781:
goto tmp_963780;
tmp_963780:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_963787;
fail_tmp_963778:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_963719();
goto next_tmp_963785;
next_tmp_963785:
goto tmp_963784;
tmp_963784:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_963787:
return tmp_952044;
}
reg_t genfunc_tmp_963719 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_963670();
goto next_tmp_963716;
next_tmp_963716:
goto tmp_963715;
tmp_963715:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 3 */
}
done_tmp_963718:
return tmp_952080;
}
reg_t genfunc_tmp_963670 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_963637 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_963637 >> 8) == 0)
field_imm = tmp_963637;
else goto fail_tmp_963636;
}
/* commit */
{
tmp_952040 = genfunc_tmp_963581();
goto next_tmp_963639;
next_tmp_963639:
goto tmp_963638;
tmp_963638:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 2 */
}
goto done_tmp_963669;
fail_tmp_963636:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_963661 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_963661))
field_imm = inv_maskmask(8, tmp_963661);
else goto fail_tmp_963660;
}
/* commit */
{
tmp_951257 = genfunc_tmp_963581();
goto next_tmp_963663;
next_tmp_963663:
goto tmp_963662;
tmp_963662:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 2 */
}
goto done_tmp_963669;
fail_tmp_963660:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_963581();
goto next_tmp_963667;
next_tmp_963667:
goto tmp_963666;
tmp_963666:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 2 */
}
done_tmp_963669:
return tmp_951324;
}
reg_t genfunc_tmp_963634 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_963603 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_963603 >> 8) == 0)
field_imm = tmp_963603;
else goto fail_tmp_963602;
}
/* commit */
{
tmp_952040 = genfunc_tmp_963581();
goto next_tmp_963605;
next_tmp_963605:
goto tmp_963604;
tmp_963604:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 2 */
}
goto done_tmp_963633;
fail_tmp_963602:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_963625 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_963625))
field_imm = inv_maskmask(8, tmp_963625);
else goto fail_tmp_963624;
}
/* commit */
{
tmp_951257 = genfunc_tmp_963581();
goto next_tmp_963627;
next_tmp_963627:
goto tmp_963626;
tmp_963626:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 2 */
}
goto done_tmp_963633;
fail_tmp_963624:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_963581();
goto next_tmp_963631;
next_tmp_963631:
goto tmp_963630;
tmp_963630:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 2 */
}
done_tmp_963633:
return tmp_952044;
}
reg_t genfunc_tmp_963581 (void) {
reg_t tmp_952058;
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_reading(0 + base);
tmp_952082 = ref_gpr_reg_for_reading(0 + index);
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 1 */
}
done_tmp_963580:
return tmp_952058;
}
void genfunc_tmp_963545 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_963297();
goto next_tmp_963221;
next_tmp_963221:
goto tmp_963220;
tmp_963220:
}
{
tmp_951328 = genfunc_tmp_963542();
goto next_tmp_963300;
next_tmp_963300:
goto tmp_963299;
tmp_963299:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 5 */
}
done_tmp_963544:
}
reg_t genfunc_tmp_963542 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_963463();
goto next_tmp_963473;
next_tmp_963473:
goto tmp_963472;
tmp_963472:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 3 */
}
done_tmp_963541:
return tmp_951328;
}
reg_t genfunc_tmp_963511 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = 1;
field_imm = 1;
/* commit */
{
tmp_952084 = genfunc_tmp_963463();
goto next_tmp_963492;
next_tmp_963492:
goto tmp_963491;
tmp_963491:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: NIL   num insns: 3 */
}
done_tmp_963510:
return tmp_952080;
}
reg_t genfunc_tmp_963463 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_963297();
goto next_tmp_963440;
next_tmp_963440:
goto tmp_963439;
tmp_963439:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 2 */
}
done_tmp_963462:
return tmp_952088;
}
reg_t genfunc_tmp_963415 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_963384 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_963384 >> 8) == 0)
field_imm = tmp_963384;
else goto fail_tmp_963383;
}
/* commit */
{
tmp_952040 = genfunc_tmp_963346();
goto next_tmp_963386;
next_tmp_963386:
goto tmp_963385;
tmp_963385:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_963414;
fail_tmp_963383:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_963406 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_963406))
field_imm = inv_maskmask(8, tmp_963406);
else goto fail_tmp_963405;
}
/* commit */
{
tmp_951257 = genfunc_tmp_963346();
goto next_tmp_963408;
next_tmp_963408:
goto tmp_963407;
tmp_963407:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_963414;
fail_tmp_963405:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_963346();
goto next_tmp_963412;
next_tmp_963412:
goto tmp_963411;
tmp_963411:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_963414:
return tmp_952044;
}
reg_t genfunc_tmp_963346 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_963297();
goto next_tmp_963343;
next_tmp_963343:
goto tmp_963342;
tmp_963342:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 2 */
}
done_tmp_963345:
return tmp_952080;
}
reg_t genfunc_tmp_963297 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_963273 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_963273 >> 8) == 0)
field_imm = tmp_963273;
else goto fail_tmp_963272;
}
/* commit */
tmp_952040 = ref_gpr_reg_for_reading(0 + rm);
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 1 */
}
goto done_tmp_963296;
fail_tmp_963272:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_963294 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_963294))
field_imm = inv_maskmask(8, tmp_963294);
else goto fail_tmp_963293;
}
/* commit */
tmp_951257 = ref_gpr_reg_for_reading(0 + rm);
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 1 */
}
goto done_tmp_963296;
fail_tmp_963293:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
tmp_951249 = ref_gpr_reg_for_reading(0 + rm);
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 1 */
}
done_tmp_963296:
return tmp_951324;
}
reg_t genfunc_tmp_963270 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_963248 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_963248 >> 8) == 0)
field_imm = tmp_963248;
else goto fail_tmp_963247;
}
/* commit */
tmp_952040 = ref_gpr_reg_for_reading(0 + rm);
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 1 */
}
goto done_tmp_963269;
fail_tmp_963247:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_963267 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_963267))
field_imm = inv_maskmask(8, tmp_963267);
else goto fail_tmp_963266;
}
/* commit */
tmp_951257 = ref_gpr_reg_for_reading(0 + rm);
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 1 */
}
goto done_tmp_963269;
fail_tmp_963266:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
tmp_951249 = ref_gpr_reg_for_reading(0 + rm);
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 1 */
}
done_tmp_963269:
return tmp_952044;
}
