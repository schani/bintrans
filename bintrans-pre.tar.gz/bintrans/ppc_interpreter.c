void interpret_ppc_insn (interpreter_t *intp) {
word_32 insn = mem_get_32(intp, intp->pc);
word_32 pc = intp->pc, next_pc = pc + 4;
switch (((insn >> 26) & 0x3F)) {
case 27:
/* XORIS */
assert((insn & 0xFC000000) == 0x6C000000);
({ word_32 tmp_966 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) ^ (((insn >> 0) & 0xFFFF) << 16)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_966); });
break;
case 26:
/* XORI */
assert((insn & 0xFC000000) == 0x68000000);
({ word_32 tmp_967 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) ^ ((insn >> 0) & 0xFFFF)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_967); });
break;
case 31:
switch (((insn >> 0) & 0x7FF)) {
case 633:
/* XOR. */
assert((insn & 0xFC0007FF) == 0x7C000279);
({ word_32 tmp_968 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) ^ (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_968); });
({ word_1 tmp_969 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_969 << (1 * 31))); });
({ word_1 tmp_970 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_970 << (1 * 30))); });
({ word_1 tmp_971 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_971 << (1 * 29))); });
({ word_1 tmp_972 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_972 << (1 * 28))); });
break;
case 632:
/* XOR */
assert((insn & 0xFC0007FF) == 0x7C000278);
({ word_32 tmp_973 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) ^ (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_973); });
break;
case 1196:
/* SYNC */
assert((insn & 0xFFFFFFFF) == 0x7C0004AC);
0 /* nop */;
break;
case 1425:
/* SUBFZEO. */
assert((insn & 0xFC00FFFF) == 0x7C000591);
{
word_32 tmp_974 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_975 = (((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_975); });
({ word_1 tmp_976 = addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_976 << 29)); });
}
;
({ assert(0); 0; }) /* not implemented */;
({ word_1 tmp_977 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_977 << (1 * 31))); });
({ word_1 tmp_978 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_978 << (1 * 30))); });
({ word_1 tmp_979 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_979 << (1 * 29))); });
({ word_1 tmp_980 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_980 << (1 * 28))); });
break;
case 1424:
/* SUBFZEO */
assert((insn & 0xFC00FFFF) == 0x7C000590);
{
word_32 tmp_981 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_982 = (((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_982); });
({ word_1 tmp_983 = addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_983 << 29)); });
}
;
({ assert(0); 0; }) /* not implemented */;
break;
case 401:
/* SUBFZE. */
assert((insn & 0xFC00FFFF) == 0x7C000191);
{
word_32 tmp_984 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_985 = (((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_985); });
({ word_1 tmp_986 = addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_986 << 29)); });
}
;
({ word_1 tmp_987 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_987 << (1 * 31))); });
({ word_1 tmp_988 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_988 << (1 * 30))); });
({ word_1 tmp_989 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_989 << (1 * 29))); });
({ word_1 tmp_990 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_990 << (1 * 28))); });
break;
case 400:
/* SUBFZE */
assert((insn & 0xFC00FFFF) == 0x7C000190);
{
word_32 tmp_991 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_992 = (((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_992); });
({ word_1 tmp_993 = addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_993 << 29)); });
}
;
break;
case 1489:
/* SUBFMEO. */
assert((insn & 0xFC00FFFF) == 0x7C0005D1);
{
word_32 tmp_994 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_995 = ((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)) - 1); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_995); });
({ word_1 tmp_996 = ((addcarry_32(((word_32)~tmp_994), ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((((word_32)~tmp_994) + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_996 << 29)); });
}
;
({ assert(0); 0; }) /* not implemented */;
({ word_1 tmp_997 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_997 << (1 * 31))); });
({ word_1 tmp_998 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_998 << (1 * 30))); });
({ word_1 tmp_999 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_999 << (1 * 29))); });
({ word_1 tmp_1000 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1000 << (1 * 28))); });
break;
case 1488:
/* SUBFMEO */
assert((insn & 0xFC00FFFF) == 0x7C0005D0);
{
word_32 tmp_1001 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_1002 = ((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)) - 1); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1002); });
({ word_1 tmp_1003 = ((addcarry_32(((word_32)~tmp_1001), ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((((word_32)~tmp_1001) + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1003 << 29)); });
}
;
({ assert(0); 0; }) /* not implemented */;
break;
case 465:
/* SUBFME. */
assert((insn & 0xFC00FFFF) == 0x7C0001D1);
{
word_32 tmp_1004 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_1005 = ((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)) - 1); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1005); });
({ word_1 tmp_1006 = ((addcarry_32(((word_32)~tmp_1004), ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((((word_32)~tmp_1004) + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1006 << 29)); });
}
;
({ word_1 tmp_1007 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1007 << (1 * 31))); });
({ word_1 tmp_1008 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1008 << (1 * 30))); });
({ word_1 tmp_1009 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1009 << (1 * 29))); });
({ word_1 tmp_1010 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1010 << (1 * 28))); });
break;
case 464:
/* SUBFME */
assert((insn & 0xFC00FFFF) == 0x7C0001D0);
{
word_32 tmp_1011 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_1012 = ((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((intp->regs_SPR[2] >> 29) & 0x1)) - 1); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1012); });
({ word_1 tmp_1013 = ((addcarry_32(((word_32)~tmp_1011), ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((((word_32)~tmp_1011) + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1013 << 29)); });
}
;
break;
case 1297:
/* SUBFEO. */
assert((insn & 0xFC0007FF) == 0x7C000511);
{
word_32 tmp_1014 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
word_32 tmp_1015 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_1016 = (tmp_1014 - (tmp_1015 + (((intp->regs_SPR[2] >> 29) & 0x1) ^ 1))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1016); });
({ word_1 tmp_1017 = ((addcarry_32(((word_32)~tmp_1015), tmp_1014) | addcarry_32((((word_32)~tmp_1015) + tmp_1014), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1017 << 29)); });
}
;
({ assert(0); 0; }) /* not implemented */;
({ word_1 tmp_1018 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1018 << (1 * 31))); });
({ word_1 tmp_1019 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1019 << (1 * 30))); });
({ word_1 tmp_1020 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1020 << (1 * 29))); });
({ word_1 tmp_1021 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1021 << (1 * 28))); });
break;
case 1296:
/* SUBFEO */
assert((insn & 0xFC0007FF) == 0x7C000510);
{
word_32 tmp_1022 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
word_32 tmp_1023 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_1024 = (tmp_1022 - (tmp_1023 + (((intp->regs_SPR[2] >> 29) & 0x1) ^ 1))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1024); });
({ word_1 tmp_1025 = ((addcarry_32(((word_32)~tmp_1023), tmp_1022) | addcarry_32((((word_32)~tmp_1023) + tmp_1022), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1025 << 29)); });
}
;
({ assert(0); 0; }) /* not implemented */;
break;
case 273:
/* SUBFE. */
assert((insn & 0xFC0007FF) == 0x7C000111);
{
word_32 tmp_1026 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
word_32 tmp_1027 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_1028 = (tmp_1026 - (tmp_1027 + (((intp->regs_SPR[2] >> 29) & 0x1) ^ 1))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1028); });
({ word_1 tmp_1029 = ((addcarry_32(((word_32)~tmp_1027), tmp_1026) | addcarry_32((((word_32)~tmp_1027) + tmp_1026), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1029 << 29)); });
}
;
({ word_1 tmp_1030 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1030 << (1 * 31))); });
({ word_1 tmp_1031 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1031 << (1 * 30))); });
({ word_1 tmp_1032 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1032 << (1 * 29))); });
({ word_1 tmp_1033 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1033 << (1 * 28))); });
break;
case 272:
/* SUBFE */
assert((insn & 0xFC0007FF) == 0x7C000110);
{
word_32 tmp_1034 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
word_32 tmp_1035 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_1036 = (tmp_1034 - (tmp_1035 + (((intp->regs_SPR[2] >> 29) & 0x1) ^ 1))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1036); });
({ word_1 tmp_1037 = ((addcarry_32(((word_32)~tmp_1035), tmp_1034) | addcarry_32((((word_32)~tmp_1035) + tmp_1034), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1037 << 29)); });
}
;
break;
case 1041:
/* SUBFCO. */
assert((insn & 0xFC0007FF) == 0x7C000411);
({ word_1 tmp_1038 = ((addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), (intp->regs_GPR[((insn >> 11) & 0x1F)])) | addcarry_32((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), 1)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1038 << 29)); });
({ word_32 tmp_1039 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1039); });
({ assert(0); 0; }) /* not implemented */;
({ word_1 tmp_1040 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1040 << (1 * 31))); });
({ word_1 tmp_1041 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1041 << (1 * 30))); });
({ word_1 tmp_1042 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1042 << (1 * 29))); });
({ word_1 tmp_1043 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1043 << (1 * 28))); });
break;
case 1040:
/* SUBFCO */
assert((insn & 0xFC0007FF) == 0x7C000410);
({ word_1 tmp_1044 = ((addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), (intp->regs_GPR[((insn >> 11) & 0x1F)])) | addcarry_32((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), 1)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1044 << 29)); });
({ word_32 tmp_1045 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1045); });
({ assert(0); 0; }) /* not implemented */;
break;
case 17:
/* SUBFC. */
assert((insn & 0xFC0007FF) == 0x7C000011);
({ word_1 tmp_1046 = ((addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), (intp->regs_GPR[((insn >> 11) & 0x1F)])) | addcarry_32((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), 1)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1046 << 29)); });
({ word_32 tmp_1047 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1047); });
({ word_1 tmp_1048 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1048 << (1 * 31))); });
({ word_1 tmp_1049 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1049 << (1 * 30))); });
({ word_1 tmp_1050 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1050 << (1 * 29))); });
({ word_1 tmp_1051 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1051 << (1 * 28))); });
break;
case 16:
/* SUBFC */
assert((insn & 0xFC0007FF) == 0x7C000010);
({ word_1 tmp_1052 = ((addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), (intp->regs_GPR[((insn >> 11) & 0x1F)])) | addcarry_32((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), 1)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1052 << 29)); });
({ word_32 tmp_1053 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1053); });
break;
case 1105:
/* SUBFO. */
assert((insn & 0xFC0007FF) == 0x7C000451);
({ word_32 tmp_1054 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1054); });
({ assert(0); 0; }) /* not implemented */;
({ word_1 tmp_1055 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1055 << (1 * 31))); });
({ word_1 tmp_1056 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1056 << (1 * 30))); });
({ word_1 tmp_1057 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1057 << (1 * 29))); });
({ word_1 tmp_1058 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1058 << (1 * 28))); });
break;
case 1104:
/* SUBFO */
assert((insn & 0xFC0007FF) == 0x7C000450);
({ word_32 tmp_1059 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1059); });
({ assert(0); 0; }) /* not implemented */;
break;
case 81:
/* SUBF. */
assert((insn & 0xFC0007FF) == 0x7C000051);
({ word_32 tmp_1060 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1060); });
({ word_1 tmp_1061 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1061 << (1 * 31))); });
({ word_1 tmp_1062 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1062 << (1 * 30))); });
({ word_1 tmp_1063 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1063 << (1 * 29))); });
({ word_1 tmp_1064 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1064 << (1 * 28))); });
break;
case 80:
/* SUBF */
assert((insn & 0xFC0007FF) == 0x7C000050);
({ word_32 tmp_1065 = ((intp->regs_GPR[((insn >> 11) & 0x1F)]) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1065); });
break;
case 302:
/* STWX */
assert((insn & 0xFC0007FF) == 0x7C00012E);
({ word_32 tmp_1066 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); mem_set_32(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_1066); });
break;
case 366:
/* STWUX */
assert((insn & 0xFC0007FF) == 0x7C00016E);
({ word_32 tmp_1067 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); mem_set_32(intp, ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_1067); });
({ word_32 tmp_1068 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1068); });
break;
case 1324:
/* STWBRX */
assert((insn & 0xFC0007FF) == 0x7C00052C);
({ word_32 tmp_1069 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); mem_set_32(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_1069); });
break;
case 814:
/* STHX */
assert((insn & 0xFC0007FF) == 0x7C00032E);
({ word_16 tmp_1070 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF); mem_set_16(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_1070); });
break;
case 1836:
/* STHBRX */
assert((insn & 0xFC0007FF) == 0x7C00072C);
({ word_16 tmp_1071 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF); mem_set_16(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_1071); });
break;
case 1326:
/* STFSX */
assert((insn & 0xFC0007FF) == 0x7C00052E);
({ word_32 tmp_1072 = ({ float tmp = ((float)(intp->regs_FPR[((insn >> 21) & 0x1F)])); *(word_32*)&tmp; }); mem_set_32(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_1072); });
break;
case 1454:
/* STFDX */
assert((insn & 0xFC0007FF) == 0x7C0005AE);
({ word_64 tmp_1073 = ({ double tmp = (intp->regs_FPR[((insn >> 21) & 0x1F)]); *(word_64*)&tmp; }); mem_set_64(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_1073); });
break;
case 430:
/* STBX */
assert((insn & 0xFC0007FF) == 0x7C0001AE);
({ word_8 tmp_1074 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFF); mem_set_8(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])), tmp_1074); });
break;
case 1073:
/* SRW. */
assert((insn & 0xFC0007FF) == 0x7C000431);
({ word_32 tmp_1075 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1075); });
({ word_1 tmp_1076 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1076 << (1 * 31))); });
({ word_1 tmp_1077 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1077 << (1 * 30))); });
({ word_1 tmp_1078 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1078 << (1 * 29))); });
({ word_1 tmp_1079 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1079 << (1 * 28))); });
break;
case 1072:
/* SRW */
assert((insn & 0xFC0007FF) == 0x7C000430);
({ word_32 tmp_1080 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1080); });
break;
case 1649:
/* SRAWI. */
assert((insn & 0xFC0007FF) == 0x7C000671);
({ word_1 tmp_1081 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? (((((1 << ((insn >> 11) & 0x1F)) - 1) & (intp->regs_GPR[((insn >> 21) & 0x1F)])) == 0) ? 0 : 1) : 0); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1081 << 29)); });
({ word_32 tmp_1082 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> ((insn >> 11) & 0x1F)) | (((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (1 << 31)) ? ~((1 << (32 - ((insn >> 11) & 0x1F))) - 1) : 0)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1082); });
({ word_1 tmp_1083 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1083 << (1 * 31))); });
({ word_1 tmp_1084 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1084 << (1 * 30))); });
({ word_1 tmp_1085 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1085 << (1 * 29))); });
({ word_1 tmp_1086 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1086 << (1 * 28))); });
break;
case 1648:
/* SRAWI */
assert((insn & 0xFC0007FF) == 0x7C000670);
({ word_1 tmp_1087 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? (((((1 << ((insn >> 11) & 0x1F)) - 1) & (intp->regs_GPR[((insn >> 21) & 0x1F)])) == 0) ? 0 : 1) : 0); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1087 << 29)); });
({ word_32 tmp_1088 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> ((insn >> 11) & 0x1F)) | (((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (1 << 31)) ? ~((1 << (32 - ((insn >> 11) & 0x1F))) - 1) : 0)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1088); });
break;
case 1585:
/* SRAW. */
assert((insn & 0xFC0007FF) == 0x7C000631);
({ word_1 tmp_1089 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? (((((1 << ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)) - 1) & (intp->regs_GPR[((insn >> 21) & 0x1F)])) == 0) ? 0 : 1) : 0); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1089 << 29)); });
({ word_32 tmp_1090 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)) | (((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (1 << 31)) ? ~((1 << (32 - ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31))) - 1) : 0)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1090); });
({ word_1 tmp_1091 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1091 << (1 * 31))); });
({ word_1 tmp_1092 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1092 << (1 * 30))); });
({ word_1 tmp_1093 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1093 << (1 * 29))); });
({ word_1 tmp_1094 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1094 << (1 * 28))); });
break;
case 1584:
/* SRAW */
assert((insn & 0xFC0007FF) == 0x7C000630);
({ word_1 tmp_1095 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? (((((1 << ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)) - 1) & (intp->regs_GPR[((insn >> 21) & 0x1F)])) == 0) ? 0 : 1) : 0); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1095 << 29)); });
({ word_32 tmp_1096 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)) | (((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (1 << 31)) ? ~((1 << (32 - ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31))) - 1) : 0)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1096); });
break;
case 49:
/* SLW. */
assert((insn & 0xFC0007FF) == 0x7C000031);
({ word_32 tmp_1097 = (((intp->regs_GPR[((insn >> 11) & 0x1F)]) & (1 << 5)) ? 0 : ((intp->regs_GPR[((insn >> 21) & 0x1F)]) << (((intp->regs_GPR[((insn >> 11) & 0x1F)]) >> 0) & 0x1F))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1097); });
({ word_1 tmp_1098 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1098 << (1 * 31))); });
({ word_1 tmp_1099 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1099 << (1 * 30))); });
({ word_1 tmp_1100 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1100 << (1 * 29))); });
({ word_1 tmp_1101 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1101 << (1 * 28))); });
break;
case 48:
/* SLW */
assert((insn & 0xFC0007FF) == 0x7C000030);
({ word_32 tmp_1102 = (((intp->regs_GPR[((insn >> 11) & 0x1F)]) & (1 << 5)) ? 0 : ((intp->regs_GPR[((insn >> 21) & 0x1F)]) << (((intp->regs_GPR[((insn >> 11) & 0x1F)]) >> 0) & 0x1F))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1102); });
break;
case 825:
/* ORC. */
assert((insn & 0xFC0007FF) == 0x7C000339);
({ word_32 tmp_1103 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) | ((word_32)~(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1103); });
({ word_1 tmp_1104 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1104 << (1 * 31))); });
({ word_1 tmp_1105 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1105 << (1 * 30))); });
({ word_1 tmp_1106 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1106 << (1 * 29))); });
({ word_1 tmp_1107 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1107 << (1 * 28))); });
break;
case 824:
/* ORC */
assert((insn & 0xFC0007FF) == 0x7C000338);
({ word_32 tmp_1108 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) | ((word_32)~(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1108); });
break;
case 889:
/* OR. */
assert((insn & 0xFC0007FF) == 0x7C000379);
({ word_32 tmp_1109 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) | (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1109); });
({ word_1 tmp_1110 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1110 << (1 * 31))); });
({ word_1 tmp_1111 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1111 << (1 * 30))); });
({ word_1 tmp_1112 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1112 << (1 * 29))); });
({ word_1 tmp_1113 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1113 << (1 * 28))); });
break;
case 888:
/* OR */
assert((insn & 0xFC0007FF) == 0x7C000378);
({ word_32 tmp_1114 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) | (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1114); });
break;
case 249:
/* NOR. */
assert((insn & 0xFC0007FF) == 0x7C0000F9);
({ word_32 tmp_1115 = ((word_32)~((intp->regs_GPR[((insn >> 21) & 0x1F)]) | (intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1115); });
({ word_1 tmp_1116 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1116 << (1 * 31))); });
({ word_1 tmp_1117 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1117 << (1 * 30))); });
({ word_1 tmp_1118 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1118 << (1 * 29))); });
({ word_1 tmp_1119 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1119 << (1 * 28))); });
break;
case 248:
/* NOR */
assert((insn & 0xFC0007FF) == 0x7C0000F8);
({ word_32 tmp_1120 = ((word_32)~((intp->regs_GPR[((insn >> 21) & 0x1F)]) | (intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1120); });
break;
case 1233:
/* NEGO. */
assert((insn & 0xFC00FFFF) == 0x7C0004D1);
({ word_32 tmp_1121 = ((word_32)-(intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1121); });
({ assert(0); 0; }) /* not implemented */;
({ word_1 tmp_1122 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1122 << (1 * 31))); });
({ word_1 tmp_1123 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1123 << (1 * 30))); });
({ word_1 tmp_1124 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1124 << (1 * 29))); });
({ word_1 tmp_1125 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1125 << (1 * 28))); });
break;
case 1232:
/* NEGO */
assert((insn & 0xFC00FFFF) == 0x7C0004D0);
({ word_32 tmp_1126 = ((word_32)-(intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1126); });
({ assert(0); 0; }) /* not implemented */;
break;
case 209:
/* NEG. */
assert((insn & 0xFC00FFFF) == 0x7C0000D1);
({ word_32 tmp_1127 = ((word_32)-(intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1127); });
({ word_1 tmp_1128 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1128 << (1 * 31))); });
({ word_1 tmp_1129 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1129 << (1 * 30))); });
({ word_1 tmp_1130 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1130 << (1 * 29))); });
({ word_1 tmp_1131 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1131 << (1 * 28))); });
break;
case 208:
/* NEG */
assert((insn & 0xFC00FFFF) == 0x7C0000D0);
({ word_32 tmp_1132 = ((word_32)-(intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1132); });
break;
case 953:
/* NAND. */
assert((insn & 0xFC0007FF) == 0x7C0003B9);
({ word_32 tmp_1133 = ((word_32)~((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1133); });
({ word_1 tmp_1134 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1134 << (1 * 31))); });
({ word_1 tmp_1135 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1135 << (1 * 30))); });
({ word_1 tmp_1136 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1136 << (1 * 29))); });
({ word_1 tmp_1137 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1137 << (1 * 28))); });
break;
case 952:
/* NAND */
assert((insn & 0xFC0007FF) == 0x7C0003B8);
({ word_32 tmp_1138 = ((word_32)~((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1138); });
break;
case 1495:
/* MULLWO. */
assert((insn & 0xFC0007FF) == 0x7C0005D7);
({ word_32 tmp_1139 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) * (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1139); });
({ assert(0); 0; }) /* not implemented */;
({ word_1 tmp_1140 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1140 << (1 * 31))); });
({ word_1 tmp_1141 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1141 << (1 * 30))); });
({ word_1 tmp_1142 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1142 << (1 * 29))); });
({ word_1 tmp_1143 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1143 << (1 * 28))); });
break;
case 1494:
/* MULLWO */
assert((insn & 0xFC0007FF) == 0x7C0005D6);
({ word_32 tmp_1144 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) * (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1144); });
({ assert(0); 0; }) /* not implemented */;
break;
case 471:
/* MULLW. */
assert((insn & 0xFC0007FF) == 0x7C0001D7);
({ word_32 tmp_1145 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) * (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1145); });
({ word_1 tmp_1146 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1146 << (1 * 31))); });
({ word_1 tmp_1147 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1147 << (1 * 30))); });
({ word_1 tmp_1148 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1148 << (1 * 29))); });
({ word_1 tmp_1149 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1149 << (1 * 28))); });
break;
case 470:
/* MULLW */
assert((insn & 0xFC0007FF) == 0x7C0001D6);
({ word_32 tmp_1150 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) * (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1150); });
break;
case 22:
/* MULHWU */
assert((insn & 0xFC0007FF) == 0x7C000016);
({ word_32 tmp_1151 = ((word_32)((((word_64)(intp->regs_GPR[((insn >> 16) & 0x1F)])) * ((word_64)(intp->regs_GPR[((insn >> 11) & 0x1F)]))) >> 32)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1151); });
break;
case 150:
/* MULHW */
assert((insn & 0xFC0007FF) == 0x7C000096);
({ word_32 tmp_1152 = ((word_32)(((((intp->regs_GPR[((insn >> 16) & 0x1F)]) & 0x80000000) ? ((word_64)(intp->regs_GPR[((insn >> 16) & 0x1F)]) | 0xFFFFFFFF00000000) : (word_64)(intp->regs_GPR[((insn >> 16) & 0x1F)])) * (((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 0x80000000) ? ((word_64)(intp->regs_GPR[((insn >> 11) & 0x1F)]) | 0xFFFFFFFF00000000) : (word_64)(intp->regs_GPR[((insn >> 11) & 0x1F)]))) >> 32)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1152); });
break;
case 934:
switch (((insn >> 11) & 0x3FF)) {
case 32:
/* MTXER */
assert((insn & 0xFC1FFFFF) == 0x7C0103A6);
({ word_32 tmp_1153 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); ((intp->regs_SPR[2]) = tmp_1153); });
break;
case 256:
/* MTLR */
assert((insn & 0xFC1FFFFF) == 0x7C0803A6);
({ word_32 tmp_1154 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); ((intp->regs_SPR[0]) = tmp_1154); });
break;
case 288:
/* MTCTR */
assert((insn & 0xFC1FFFFF) == 0x7C0903A6);
({ word_32 tmp_1155 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); ((intp->regs_SPR[3]) = tmp_1155); });
break;
default:
assert(0);
}
break;
case 288:
/* MTCRF */
assert((insn & 0xFC100FFF) == 0x7C000120);
({ word_32 tmp_1156 = (((intp->regs_SPR[1]) & ((word_32)~maskmask(4, 8, ((insn >> 12) & 0xFF)))) | ((intp->regs_GPR[((insn >> 21) & 0x1F)]) & maskmask(4, 8, ((insn >> 12) & 0xFF)))); ((intp->regs_SPR[1]) = tmp_1156); });
break;
case 678:
switch (((insn >> 11) & 0x3FF)) {
case 32:
/* MFXER */
assert((insn & 0xFC1FFFFF) == 0x7C0102A6);
({ word_32 tmp_1157 = (intp->regs_SPR[2]); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1157); });
break;
case 256:
/* MFLR */
assert((insn & 0xFC1FFFFF) == 0x7C0802A6);
({ word_32 tmp_1158 = (intp->regs_SPR[0]); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1158); });
break;
case 288:
/* MFCTR */
assert((insn & 0xFC1FFFFF) == 0x7C0902A6);
({ word_32 tmp_1159 = (intp->regs_SPR[3]); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1159); });
break;
default:
assert(0);
}
break;
case 38:
/* MFCR */
assert((insn & 0xFC1FFFFF) == 0x7C000026);
({ word_32 tmp_1160 = (intp->regs_SPR[1]); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1160); });
break;
case 1024:
/* MCRXR */
assert((insn & 0xFC7FFFFF) == 0x7C000400);
({ word_4 tmp_1161 = (((intp->regs_SPR[2]) >> (4 * 7)) & ((1 << 4) - 1)); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(4 * ((7 - ((insn >> 23) & 0x7)) & 0x7), 4 * ((7 - ((insn >> 23) & 0x7)) & 0x7) + 4 - 1)) | (tmp_1161 << (4 * ((7 - ((insn >> 23) & 0x7)) & 0x7)))); });
break;
case 46:
/* LWZX */
assert((insn & 0xFC0007FF) == 0x7C00002E);
({ word_32 tmp_1162 = mem_get_32(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1162); });
break;
case 110:
/* LWZUX */
assert((insn & 0xFC0007FF) == 0x7C00006E);
{
word_32 tmp_1163 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)]));
({ word_32 tmp_1164 = mem_get_32(intp, tmp_1163); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1164); });
({ word_32 tmp_1165 = tmp_1163; ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1165); });
}
;
break;
case 1068:
/* LWBRX */
assert((insn & 0xFC0007FF) == 0x7C00042C);
({ word_32 tmp_1166 = mem_get_32(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1166); });
break;
case 558:
/* LHZX */
assert((insn & 0xFC0007FF) == 0x7C00022E);
({ word_32 tmp_1167 = mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1167); });
break;
case 1580:
/* LHBRX */
assert((insn & 0xFC0007FF) == 0x7C00062C);
({ word_32 tmp_1168 = mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1168); });
break;
case 686:
/* LHAX */
assert((insn & 0xFC0007FF) == 0x7C0002AE);
({ word_32 tmp_1169 = ((mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))) & 0x8000) ? ((word_32)mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))) | 0xFFFF0000) : (word_32)mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)]))))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1169); });
break;
case 1070:
/* LFSX */
assert((insn & 0xFC0007FF) == 0x7C00042E);
({ double tmp_1170 = ((double)({ word_32 tmp = mem_get_32(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))); *(float*)&tmp; })); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1170); });
break;
case 1198:
/* LFDX */
assert((insn & 0xFC0007FF) == 0x7C0004AE);
({ double tmp_1171 = ({ word_64 tmp = mem_get_64(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))); *(double*)&tmp; }); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1171); });
break;
case 174:
/* LBZX */
assert((insn & 0xFC0007FF) == 0x7C0000AE);
({ word_32 tmp_1172 = mem_get_8(intp, ((((insn >> 16) & 0x1F) == 0) ? (intp->regs_GPR[((insn >> 11) & 0x1F)]) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1172); });
break;
case 238:
/* LBZUX */
assert((insn & 0xFC0007FF) == 0x7C0000EE);
{
word_32 tmp_1173 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)]));
({ word_32 tmp_1174 = mem_get_8(intp, tmp_1173); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1174); });
({ word_32 tmp_1175 = tmp_1173; ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1175); });
}
;
break;
case 1964:
/* ICBI */
assert((insn & 0xFFE007FF) == 0x7C0007AC);
0 /* ignore */;
break;
case 1845:
/* EXTSH. */
assert((insn & 0xFC00FFFF) == 0x7C000735);
({ word_32 tmp_1176 = (((((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF) & 0x8000) ? ((word_32)(((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)(((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1176); });
({ word_1 tmp_1177 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1177 << (1 * 31))); });
({ word_1 tmp_1178 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1178 << (1 * 30))); });
({ word_1 tmp_1179 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1179 << (1 * 29))); });
({ word_1 tmp_1180 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1180 << (1 * 28))); });
break;
case 1844:
/* EXTSH */
assert((insn & 0xFC00FFFF) == 0x7C000734);
({ word_32 tmp_1181 = (((((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF) & 0x8000) ? ((word_32)(((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)(((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1181); });
break;
case 1908:
/* EXTSB */
assert((insn & 0xFC00FFFF) == 0x7C000774);
({ word_32 tmp_1182 = (((((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFF) & 0x80) ? ((word_32)(((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFF) | 0xFFFFFF00) : (word_32)(((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFF)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1182); });
break;
case 569:
/* EQV. */
assert((insn & 0xFC0007FF) == 0x7C000239);
({ word_32 tmp_1183 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) ^ ((word_32)~(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1183); });
({ word_1 tmp_1184 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1184 << (1 * 31))); });
({ word_1 tmp_1185 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1185 << (1 * 30))); });
({ word_1 tmp_1186 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1186 << (1 * 29))); });
({ word_1 tmp_1187 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1187 << (1 * 28))); });
break;
case 568:
/* EQV */
assert((insn & 0xFC0007FF) == 0x7C000238);
({ word_32 tmp_1188 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) ^ ((word_32)~(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1188); });
break;
case 1943:
/* DIVWUO. */
assert((insn & 0xFC0007FF) == 0x7C000797);
({ word_32 tmp_1189 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) / (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1189); });
({ assert(0); 0; }) /* not implemented */;
({ word_1 tmp_1190 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1190 << (1 * 31))); });
({ word_1 tmp_1191 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1191 << (1 * 30))); });
({ word_1 tmp_1192 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1192 << (1 * 29))); });
({ word_1 tmp_1193 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1193 << (1 * 28))); });
break;
case 1942:
/* DIVWUO */
assert((insn & 0xFC0007FF) == 0x7C000796);
({ word_32 tmp_1194 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) / (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1194); });
({ assert(0); 0; }) /* not implemented */;
break;
case 919:
/* DIVWU. */
assert((insn & 0xFC0007FF) == 0x7C000397);
({ word_32 tmp_1195 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) / (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1195); });
({ word_1 tmp_1196 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1196 << (1 * 31))); });
({ word_1 tmp_1197 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1197 << (1 * 30))); });
({ word_1 tmp_1198 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1198 << (1 * 29))); });
({ word_1 tmp_1199 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1199 << (1 * 28))); });
break;
case 918:
/* DIVWU */
assert((insn & 0xFC0007FF) == 0x7C000396);
({ word_32 tmp_1200 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) / (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1200); });
break;
case 2007:
/* DIVWO. */
assert((insn & 0xFC0007FF) == 0x7C0007D7);
({ word_32 tmp_1201 = ((word_32)((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) / (sword_32)(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1201); });
({ assert(0); 0; }) /* not implemented */;
({ word_1 tmp_1202 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1202 << (1 * 31))); });
({ word_1 tmp_1203 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1203 << (1 * 30))); });
({ word_1 tmp_1204 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1204 << (1 * 29))); });
({ word_1 tmp_1205 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1205 << (1 * 28))); });
break;
case 2006:
/* DIVWO */
assert((insn & 0xFC0007FF) == 0x7C0007D6);
({ word_32 tmp_1206 = ((word_32)((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) / (sword_32)(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1206); });
({ assert(0); 0; }) /* not implemented */;
break;
case 983:
/* DIVW. */
assert((insn & 0xFC0007FF) == 0x7C0003D7);
({ word_32 tmp_1207 = ((word_32)((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) / (sword_32)(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1207); });
({ word_1 tmp_1208 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1208 << (1 * 31))); });
({ word_1 tmp_1209 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1209 << (1 * 30))); });
({ word_1 tmp_1210 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1210 << (1 * 29))); });
({ word_1 tmp_1211 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1211 << (1 * 28))); });
break;
case 982:
/* DIVW */
assert((insn & 0xFC0007FF) == 0x7C0003D6);
({ word_32 tmp_1212 = ((word_32)((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) / (sword_32)(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1212); });
break;
case 2028:
/* DCBZ */
assert((insn & 0xFFE007FF) == 0x7C0007EC);
{
word_32 tmp_1213 = ((((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + (intp->regs_GPR[((insn >> 11) & 0x1F)])) & 4294967264);
({ word_32 tmp_1214 = 0; mem_set_32(intp, tmp_1213, tmp_1214); });
({ word_32 tmp_1215 = 0; mem_set_32(intp, (tmp_1213 + 4), tmp_1215); });
({ word_32 tmp_1216 = 0; mem_set_32(intp, (tmp_1213 + 8), tmp_1216); });
({ word_32 tmp_1217 = 0; mem_set_32(intp, (tmp_1213 + 12), tmp_1217); });
({ word_32 tmp_1218 = 0; mem_set_32(intp, (tmp_1213 + 16), tmp_1218); });
({ word_32 tmp_1219 = 0; mem_set_32(intp, (tmp_1213 + 20), tmp_1219); });
({ word_32 tmp_1220 = 0; mem_set_32(intp, (tmp_1213 + 24), tmp_1220); });
({ word_32 tmp_1221 = 0; mem_set_32(intp, (tmp_1213 + 28), tmp_1221); });
}
;
break;
case 108:
/* DCBST */
assert((insn & 0xFFE007FF) == 0x7C00006C);
0 /* ignore */;
break;
case 52:
/* CNTLZW */
assert((insn & 0xFC00FFFF) == 0x7C000034);
({ word_32 tmp_1222 = leading_zeros((intp->regs_GPR[((insn >> 21) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1222); });
break;
case 0:
/* CMPW */
assert((insn & 0xFC6007FF) == 0x7C000000);
({ word_1 tmp_1223 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)(intp->regs_GPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F) + 1 - 1)) | (tmp_1223 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F)))); });
({ word_1 tmp_1224 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)(intp->regs_GPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F) + 1 - 1)) | (tmp_1224 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F)))); });
({ word_1 tmp_1225 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == (intp->regs_GPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F) + 1 - 1)) | (tmp_1225 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F)))); });
({ word_1 tmp_1226 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F), 1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1 - 1)) | (tmp_1226 << (1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F)))); });
break;
case 64:
/* CMPLW */
assert((insn & 0xFC6007FF) == 0x7C000040);
({ word_1 tmp_1227 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) < (intp->regs_GPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F) + 1 - 1)) | (tmp_1227 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F)))); });
({ word_1 tmp_1228 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) > (intp->regs_GPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F) + 1 - 1)) | (tmp_1228 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F)))); });
({ word_1 tmp_1229 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == (intp->regs_GPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F) + 1 - 1)) | (tmp_1229 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F)))); });
({ word_1 tmp_1230 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F), 1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1 - 1)) | (tmp_1230 << (1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F)))); });
break;
case 121:
/* ANDC. */
assert((insn & 0xFC0007FF) == 0x7C000079);
({ word_32 tmp_1231 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) & ((word_32)~(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1231); });
({ word_1 tmp_1232 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1232 << (1 * 31))); });
({ word_1 tmp_1233 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1233 << (1 * 30))); });
({ word_1 tmp_1234 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1234 << (1 * 29))); });
({ word_1 tmp_1235 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1235 << (1 * 28))); });
break;
case 120:
/* ANDC */
assert((insn & 0xFC0007FF) == 0x7C000078);
({ word_32 tmp_1236 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) & ((word_32)~(intp->regs_GPR[((insn >> 11) & 0x1F)]))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1236); });
break;
case 57:
/* AND. */
assert((insn & 0xFC0007FF) == 0x7C000039);
({ word_32 tmp_1237 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1237); });
({ word_1 tmp_1238 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1238 << (1 * 31))); });
({ word_1 tmp_1239 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1239 << (1 * 30))); });
({ word_1 tmp_1240 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1240 << (1 * 29))); });
({ word_1 tmp_1241 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1241 << (1 * 28))); });
break;
case 56:
/* AND */
assert((insn & 0xFC0007FF) == 0x7C000038);
({ word_32 tmp_1242 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1242); });
break;
case 1429:
/* ADDZEO. */
assert((insn & 0xFC00FFFF) == 0x7C000595);
{
word_32 tmp_1243 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_1244 = (tmp_1243 + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1244); });
({ word_1 tmp_1245 = addcarry_32(tmp_1243, ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1245 << 29)); });
}
;
({ assert(0); 0; }) /* not implemented */;
({ word_1 tmp_1246 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1246 << (1 * 31))); });
({ word_1 tmp_1247 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1247 << (1 * 30))); });
({ word_1 tmp_1248 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1248 << (1 * 29))); });
({ word_1 tmp_1249 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1249 << (1 * 28))); });
break;
case 1428:
/* ADDZEO */
assert((insn & 0xFC00FFFF) == 0x7C000594);
{
word_32 tmp_1250 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_1251 = (tmp_1250 + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1251); });
({ word_1 tmp_1252 = addcarry_32(tmp_1250, ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1252 << 29)); });
}
;
({ assert(0); 0; }) /* not implemented */;
break;
case 405:
/* ADDZE. */
assert((insn & 0xFC00FFFF) == 0x7C000195);
{
word_32 tmp_1253 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_1254 = (tmp_1253 + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1254); });
({ word_1 tmp_1255 = addcarry_32(tmp_1253, ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1255 << 29)); });
}
;
({ word_1 tmp_1256 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1256 << (1 * 31))); });
({ word_1 tmp_1257 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1257 << (1 * 30))); });
({ word_1 tmp_1258 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1258 << (1 * 29))); });
({ word_1 tmp_1259 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1259 << (1 * 28))); });
break;
case 404:
/* ADDZE */
assert((insn & 0xFC00FFFF) == 0x7C000194);
{
word_32 tmp_1260 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_1261 = (tmp_1260 + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1261); });
({ word_1 tmp_1262 = addcarry_32(tmp_1260, ((intp->regs_SPR[2] >> 29) & 0x1)); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1262 << 29)); });
}
;
break;
case 1493:
/* ADDMEO. */
assert((insn & 0xFC00FFFF) == 0x7C0005D5);
{
word_32 tmp_1263 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_1264 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((intp->regs_SPR[2] >> 29) & 0x1)) + 4294967295); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1264); });
({ word_1 tmp_1265 = ((addcarry_32(tmp_1263, ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((tmp_1263 + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1265 << 29)); });
}
;
({ assert(0); 0; }) /* not implemented */;
({ word_1 tmp_1266 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1266 << (1 * 31))); });
({ word_1 tmp_1267 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1267 << (1 * 30))); });
({ word_1 tmp_1268 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1268 << (1 * 29))); });
({ word_1 tmp_1269 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1269 << (1 * 28))); });
break;
case 1492:
/* ADDMEO */
assert((insn & 0xFC00FFFF) == 0x7C0005D4);
{
word_32 tmp_1270 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_1271 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((intp->regs_SPR[2] >> 29) & 0x1)) + 4294967295); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1271); });
({ word_1 tmp_1272 = ((addcarry_32(tmp_1270, ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((tmp_1270 + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1272 << 29)); });
}
;
({ assert(0); 0; }) /* not implemented */;
break;
case 469:
/* ADDME. */
assert((insn & 0xFC00FFFF) == 0x7C0001D5);
{
word_32 tmp_1273 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_1274 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((intp->regs_SPR[2] >> 29) & 0x1)) + 4294967295); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1274); });
({ word_1 tmp_1275 = ((addcarry_32(tmp_1273, ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((tmp_1273 + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1275 << 29)); });
}
;
({ word_1 tmp_1276 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1276 << (1 * 31))); });
({ word_1 tmp_1277 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1277 << (1 * 30))); });
({ word_1 tmp_1278 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1278 << (1 * 29))); });
({ word_1 tmp_1279 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1279 << (1 * 28))); });
break;
case 468:
/* ADDME */
assert((insn & 0xFC00FFFF) == 0x7C0001D4);
{
word_32 tmp_1280 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
({ word_32 tmp_1281 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((intp->regs_SPR[2] >> 29) & 0x1)) + 4294967295); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1281); });
({ word_1 tmp_1282 = ((addcarry_32(tmp_1280, ((intp->regs_SPR[2] >> 29) & 0x1)) | addcarry_32((tmp_1280 + ((intp->regs_SPR[2] >> 29) & 0x1)), 4294967295)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1282 << 29)); });
}
;
break;
case 1301:
/* ADDEO. */
assert((insn & 0xFC0007FF) == 0x7C000515);
{
word_32 tmp_1283 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
word_32 tmp_1284 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
({ word_32 tmp_1285 = ((tmp_1283 + tmp_1284) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1285); });
({ word_1 tmp_1286 = ((addcarry_32(tmp_1283, tmp_1284) | addcarry_32((tmp_1283 + tmp_1284), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1286 << 29)); });
}
;
({ assert(0); 0; }) /* not implemented */;
({ word_1 tmp_1287 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1287 << (1 * 31))); });
({ word_1 tmp_1288 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1288 << (1 * 30))); });
({ word_1 tmp_1289 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1289 << (1 * 29))); });
({ word_1 tmp_1290 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1290 << (1 * 28))); });
break;
case 1300:
/* ADDEO */
assert((insn & 0xFC0007FF) == 0x7C000514);
{
word_32 tmp_1291 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
word_32 tmp_1292 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
({ word_32 tmp_1293 = ((tmp_1291 + tmp_1292) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1293); });
({ word_1 tmp_1294 = ((addcarry_32(tmp_1291, tmp_1292) | addcarry_32((tmp_1291 + tmp_1292), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1294 << 29)); });
}
;
({ assert(0); 0; }) /* not implemented */;
break;
case 277:
/* ADDE. */
assert((insn & 0xFC0007FF) == 0x7C000115);
{
word_32 tmp_1295 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
word_32 tmp_1296 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
({ word_32 tmp_1297 = ((tmp_1295 + tmp_1296) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1297); });
({ word_1 tmp_1298 = ((addcarry_32(tmp_1295, tmp_1296) | addcarry_32((tmp_1295 + tmp_1296), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1298 << 29)); });
}
;
({ word_1 tmp_1299 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1299 << (1 * 31))); });
({ word_1 tmp_1300 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1300 << (1 * 30))); });
({ word_1 tmp_1301 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1301 << (1 * 29))); });
({ word_1 tmp_1302 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1302 << (1 * 28))); });
break;
case 276:
/* ADDE */
assert((insn & 0xFC0007FF) == 0x7C000114);
{
word_32 tmp_1303 = (intp->regs_GPR[((insn >> 16) & 0x1F)]);
word_32 tmp_1304 = (intp->regs_GPR[((insn >> 11) & 0x1F)]);
({ word_32 tmp_1305 = ((tmp_1303 + tmp_1304) + ((intp->regs_SPR[2] >> 29) & 0x1)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1305); });
({ word_1 tmp_1306 = ((addcarry_32(tmp_1303, tmp_1304) | addcarry_32((tmp_1303 + tmp_1304), ((intp->regs_SPR[2] >> 29) & 0x1))) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1306 << 29)); });
}
;
break;
case 1045:
/* ADDCO. */
assert((insn & 0xFC0007FF) == 0x7C000415);
({ word_1 tmp_1307 = addcarry_32((intp->regs_GPR[((insn >> 16) & 0x1F)]), (intp->regs_GPR[((insn >> 11) & 0x1F)])); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1307 << 29)); });
({ word_32 tmp_1308 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1308); });
({ assert(0); 0; }) /* not implemented */;
({ word_1 tmp_1309 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1309 << (1 * 31))); });
({ word_1 tmp_1310 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1310 << (1 * 30))); });
({ word_1 tmp_1311 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1311 << (1 * 29))); });
({ word_1 tmp_1312 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1312 << (1 * 28))); });
break;
case 1044:
/* ADDCO */
assert((insn & 0xFC0007FF) == 0x7C000414);
({ word_1 tmp_1313 = addcarry_32((intp->regs_GPR[((insn >> 16) & 0x1F)]), (intp->regs_GPR[((insn >> 11) & 0x1F)])); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1313 << 29)); });
({ word_32 tmp_1314 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1314); });
({ assert(0); 0; }) /* not implemented */;
break;
case 21:
/* ADDC. */
assert((insn & 0xFC0007FF) == 0x7C000015);
({ word_1 tmp_1315 = addcarry_32((intp->regs_GPR[((insn >> 16) & 0x1F)]), (intp->regs_GPR[((insn >> 11) & 0x1F)])); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1315 << 29)); });
({ word_32 tmp_1316 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1316); });
({ word_1 tmp_1317 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1317 << (1 * 31))); });
({ word_1 tmp_1318 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1318 << (1 * 30))); });
({ word_1 tmp_1319 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1319 << (1 * 29))); });
({ word_1 tmp_1320 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1320 << (1 * 28))); });
break;
case 20:
/* ADDC */
assert((insn & 0xFC0007FF) == 0x7C000014);
({ word_1 tmp_1321 = addcarry_32((intp->regs_GPR[((insn >> 16) & 0x1F)]), (intp->regs_GPR[((insn >> 11) & 0x1F)])); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1321 << 29)); });
({ word_32 tmp_1322 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1322); });
break;
case 1557:
/* ADDO. */
assert((insn & 0xFC0007FF) == 0x7C000615);
({ word_32 tmp_1323 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1323); });
({ assert(0); 0; }) /* not implemented */;
({ word_1 tmp_1324 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1324 << (1 * 31))); });
({ word_1 tmp_1325 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1325 << (1 * 30))); });
({ word_1 tmp_1326 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1326 << (1 * 29))); });
({ word_1 tmp_1327 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1327 << (1 * 28))); });
break;
case 1556:
/* ADDO */
assert((insn & 0xFC0007FF) == 0x7C000614);
({ word_32 tmp_1328 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1328); });
({ assert(0); 0; }) /* not implemented */;
break;
case 533:
/* ADD. */
assert((insn & 0xFC0007FF) == 0x7C000215);
({ word_32 tmp_1329 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1329); });
({ word_1 tmp_1330 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1330 << (1 * 31))); });
({ word_1 tmp_1331 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1331 << (1 * 30))); });
({ word_1 tmp_1332 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1332 << (1 * 29))); });
({ word_1 tmp_1333 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1333 << (1 * 28))); });
break;
case 532:
/* ADD */
assert((insn & 0xFC0007FF) == 0x7C000214);
({ word_32 tmp_1334 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (intp->regs_GPR[((insn >> 11) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1334); });
break;
default:
assert(0);
}
break;
case 8:
/* SUBFIC */
assert((insn & 0xFC000000) == 0x20000000);
({ word_1 tmp_1335 = ((addcarry_32(((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])), ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))) | addcarry_32((((word_32)~(intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), 1)) & 0x1); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1335 << 29)); });
({ word_32 tmp_1336 = (((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) - (intp->regs_GPR[((insn >> 16) & 0x1F)])); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1336); });
break;
case 37:
/* STWU */
assert((insn & 0xFC000000) == 0x94000000);
({ word_32 tmp_1337 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); mem_set_32(intp, ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), tmp_1337); });
({ word_32 tmp_1338 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1338); });
break;
case 36:
/* STW */
assert((insn & 0xFC000000) == 0x90000000);
({ word_32 tmp_1339 = (intp->regs_GPR[((insn >> 21) & 0x1F)]); mem_set_32(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), tmp_1339); });
break;
case 45:
/* STHU */
assert((insn & 0xFC000000) == 0xB4000000);
({ word_16 tmp_1340 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF); mem_set_16(intp, ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), tmp_1340); });
({ word_32 tmp_1341 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1341); });
break;
case 44:
/* STH */
assert((insn & 0xFC000000) == 0xB0000000);
({ word_16 tmp_1342 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFFFF); mem_set_16(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)))), tmp_1342); });
break;
case 52:
/* STFS */
assert((insn & 0xFC000000) == 0xD0000000);
({ word_32 tmp_1343 = ({ float tmp = ((float)(intp->regs_FPR[((insn >> 21) & 0x1F)])); *(word_32*)&tmp; }); mem_set_32(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), tmp_1343); });
break;
case 55:
/* STFDU */
assert((insn & 0xFC000000) == 0xDC000000);
({ word_64 tmp_1344 = ({ double tmp = (intp->regs_FPR[((insn >> 21) & 0x1F)]); *(word_64*)&tmp; }); mem_set_64(intp, ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), tmp_1344); });
({ word_32 tmp_1345 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1345); });
break;
case 54:
/* STFD */
assert((insn & 0xFC000000) == 0xD8000000);
({ word_64 tmp_1346 = ({ double tmp = (intp->regs_FPR[((insn >> 21) & 0x1F)]); *(word_64*)&tmp; }); mem_set_64(intp, (((((insn >> 16) & 0x1F) == 0) ? 0 : (intp->regs_GPR[((insn >> 16) & 0x1F)])) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), tmp_1346); });
break;
case 39:
/* STBU */
assert((insn & 0xFC000000) == 0x9C000000);
({ word_8 tmp_1347 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFF); mem_set_8(intp, ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))), tmp_1347); });
({ word_32 tmp_1348 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1348); });
break;
case 38:
/* STB */
assert((insn & 0xFC000000) == 0x98000000);
({ word_8 tmp_1349 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) >> 0) & 0xFF); mem_set_8(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)))), tmp_1349); });
break;
case 17:
/* SC */
assert((insn & 0xFFFFFFFF) == 0x44000002);
handle_system_call(intp);
break;
case 23:
switch (((insn >> 0) & 0x1)) {
case 1:
/* RLWNM. */
assert((insn & 0xFC000001) == 0x5C000001);
({ word_32 tmp_1350 = (rotl_32((intp->regs_GPR[((insn >> 21) & 0x1F)]), ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)) & mask_32((31 - ((insn >> 1) & 0x1F)), (31 - ((insn >> 6) & 0x1F)))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1350); });
({ word_1 tmp_1351 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1351 << (1 * 31))); });
({ word_1 tmp_1352 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1352 << (1 * 30))); });
({ word_1 tmp_1353 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1353 << (1 * 29))); });
({ word_1 tmp_1354 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1354 << (1 * 28))); });
break;
case 0:
/* RLWNM */
assert((insn & 0xFC000001) == 0x5C000000);
({ word_32 tmp_1355 = (rotl_32((intp->regs_GPR[((insn >> 21) & 0x1F)]), ((intp->regs_GPR[((insn >> 11) & 0x1F)]) & 31)) & mask_32((31 - ((insn >> 1) & 0x1F)), (31 - ((insn >> 6) & 0x1F)))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1355); });
break;
default:
assert(0);
}
break;
case 21:
switch (((insn >> 0) & 0x1)) {
case 1:
/* RLWINM. */
assert((insn & 0xFC000001) == 0x54000001);
({ word_32 tmp_1356 = (rotl_32((intp->regs_GPR[((insn >> 21) & 0x1F)]), ((insn >> 11) & 0x1F)) & mask_32((31 - ((insn >> 1) & 0x1F)), (31 - ((insn >> 6) & 0x1F)))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1356); });
({ word_1 tmp_1357 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1357 << (1 * 31))); });
({ word_1 tmp_1358 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1358 << (1 * 30))); });
({ word_1 tmp_1359 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1359 << (1 * 29))); });
({ word_1 tmp_1360 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1360 << (1 * 28))); });
break;
case 0:
/* RLWINM */
assert((insn & 0xFC000001) == 0x54000000);
({ word_32 tmp_1361 = (rotl_32((intp->regs_GPR[((insn >> 21) & 0x1F)]), ((insn >> 11) & 0x1F)) & mask_32((31 - ((insn >> 1) & 0x1F)), (31 - ((insn >> 6) & 0x1F)))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1361); });
break;
default:
assert(0);
}
break;
case 20:
/* RLWIMI */
assert((insn & 0xFC000001) == 0x50000000);
({ word_32 tmp_1362 = ((rotl_32((intp->regs_GPR[((insn >> 21) & 0x1F)]), ((insn >> 11) & 0x1F)) & mask_32((31 - ((insn >> 1) & 0x1F)), (31 - ((insn >> 6) & 0x1F)))) | ((intp->regs_GPR[((insn >> 16) & 0x1F)]) & ((word_32)~mask_32((31 - ((insn >> 1) & 0x1F)), (31 - ((insn >> 6) & 0x1F)))))); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1362); });
break;
case 25:
/* ORIS */
assert((insn & 0xFC000000) == 0x64000000);
({ word_32 tmp_1363 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) | (((insn >> 0) & 0xFFFF) << 16)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1363); });
break;
case 24:
/* ORI */
assert((insn & 0xFC000000) == 0x60000000);
({ word_32 tmp_1364 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) | ((insn >> 0) & 0xFFFF)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1364); });
break;
case 7:
/* MULLI */
assert((insn & 0xFC000000) == 0x1C000000);
({ word_32 tmp_1365 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) * ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1365); });
break;
case 63:
switch (((insn >> 0) & 0x3F)) {
case 12:
switch (((insn >> 6) & 0x3F)) {
case 4:
/* MTFSFI */
assert((insn & 0xFC7F0FFF) == 0xFC00010C);
({ word_4 tmp_1366 = ((insn >> 12) & 0xF); ((intp->regs_SPR[4]) = ((intp->regs_SPR[4]) & ~mask_32(4 * ((7 - ((insn >> 23) & 0x7)) & 0x7), 4 * ((7 - ((insn >> 23) & 0x7)) & 0x7) + 4 - 1)) | (tmp_1366 << (4 * ((7 - ((insn >> 23) & 0x7)) & 0x7)))); });
break;
case 2:
/* MTFSB0 */
assert((insn & 0xFC1FFFFF) == 0xFC00008C);
({ word_1 tmp_1367 = 0; ((intp->regs_SPR[4]) = ((intp->regs_SPR[4]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_1367 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
default:
assert(0);
}
break;
case 14:
switch (((insn >> 6) & 0x1F)) {
case 22:
/* MTFSF */
assert((insn & 0xFFFF07FF) == 0xFDFE058E);
({ word_32 tmp_1368 = ((word_32)(({ double tmp = (intp->regs_FPR[((insn >> 11) & 0x1F)]); *(word_64*)&tmp; }) & 4294967295)); ((intp->regs_SPR[4]) = tmp_1368); });
break;
case 18:
/* MFFS */
assert((insn & 0xFC1FFFFF) == 0xFC00048E);
({ double tmp_1369 = ({ word_64 tmp = ((word_64)(intp->regs_SPR[4])); *(double*)&tmp; }); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1369); });
break;
default:
assert(0);
}
break;
case 40:
/* FSUB */
assert((insn & 0xFC0007FF) == 0xFC000028);
({ double tmp_1370 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) - (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1370); });
break;
case 24:
/* FRSP */
assert((insn & 0xFC1F07FF) == 0xFC000018);
({ double tmp_1371 = (intp->regs_FPR[((insn >> 11) & 0x1F)]); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1371); });
break;
case 60:
/* FNMSUB */
assert((insn & 0xFC00003F) == 0xFC00003C);
({ double tmp_1372 = (-(((intp->regs_FPR[((insn >> 16) & 0x1F)]) * (intp->regs_FPR[((insn >> 6) & 0x1F)])) - (intp->regs_FPR[((insn >> 11) & 0x1F)]))); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1372); });
break;
case 16:
switch (((insn >> 6) & 0x1F)) {
case 1:
/* FNEG */
assert((insn & 0xFC1F07FF) == 0xFC000050);
({ double tmp_1373 = (-(intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1373); });
break;
case 2:
/* FMR */
assert((insn & 0xFC1F07FF) == 0xFC000090);
({ double tmp_1374 = (intp->regs_FPR[((insn >> 11) & 0x1F)]); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1374); });
break;
case 8:
/* FABS */
assert((insn & 0xFC1F07FF) == 0xFC000210);
({ double tmp_1375 = ({ word_64 tmp = (({ double tmp = (intp->regs_FPR[((insn >> 11) & 0x1F)]); *(word_64*)&tmp; }) & 9223372036854775807); *(double*)&tmp; }); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1375); });
break;
default:
assert(0);
}
break;
case 50:
/* FMUL */
assert((insn & 0xFC00F83F) == 0xFC000032);
({ double tmp_1376 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) * (intp->regs_FPR[((insn >> 6) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1376); });
break;
case 56:
/* FMSUB */
assert((insn & 0xFC00003F) == 0xFC000038);
({ double tmp_1377 = (((intp->regs_FPR[((insn >> 16) & 0x1F)]) * (intp->regs_FPR[((insn >> 6) & 0x1F)])) - (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1377); });
break;
case 58:
/* FMADD */
assert((insn & 0xFC00003F) == 0xFC00003A);
({ double tmp_1378 = (((intp->regs_FPR[((insn >> 16) & 0x1F)]) * (intp->regs_FPR[((insn >> 6) & 0x1F)])) + (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1378); });
break;
case 36:
/* FDIV */
assert((insn & 0xFC0007FF) == 0xFC000024);
({ double tmp_1379 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) / (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1379); });
break;
case 30:
/* FCTIWZ */
assert((insn & 0xFC1F07FF) == 0xFC00001E);
({ double tmp_1380 = ({ word_64 tmp = ((word_64)((word_32)(sword_32)(intp->regs_FPR[((insn >> 11) & 0x1F)]))); *(double*)&tmp; }); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1380); });
break;
case 0:
/* FCMPU */
assert((insn & 0xFC6007FF) == 0xFC000000);
({ word_1 tmp_1381 = (((intp->regs_FPR[((insn >> 16) & 0x1F)]) < (intp->regs_FPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F) + 1 - 1)) | (tmp_1381 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F)))); });
({ word_1 tmp_1382 = (((intp->regs_FPR[((insn >> 16) & 0x1F)]) > (intp->regs_FPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F) + 1 - 1)) | (tmp_1382 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F)))); });
({ word_1 tmp_1383 = (((intp->regs_FPR[((insn >> 16) & 0x1F)]) == (intp->regs_FPR[((insn >> 11) & 0x1F)])) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F) + 1 - 1)) | (tmp_1383 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F)))); });
({ word_1 tmp_1384 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F), 1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1 - 1)) | (tmp_1384 << (1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F)))); });
break;
case 42:
/* FADD */
assert((insn & 0xFC0007FF) == 0xFC00002A);
({ double tmp_1385 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) + (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1385); });
break;
default:
assert(0);
}
break;
case 19:
switch (((insn >> 0) & 0x7FF)) {
case 0:
/* MCRF */
assert((insn & 0xFC63FFFF) == 0x4C000000);
({ word_4 tmp_1386 = (((intp->regs_SPR[1]) >> (4 * ((7 - ((insn >> 18) & 0x7)) & 0x7))) & ((1 << 4) - 1)); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(4 * ((7 - ((insn >> 23) & 0x7)) & 0x7), 4 * ((7 - ((insn >> 23) & 0x7)) & 0x7) + 4 - 1)) | (tmp_1386 << (4 * ((7 - ((insn >> 23) & 0x7)) & 0x7)))); });
break;
case 300:
/* ISYNC */
assert((insn & 0xFFFFFFFF) == 0x4C00012C);
0 /* nop */;
break;
case 386:
/* CRXOR */
assert((insn & 0xFC0007FF) == 0x4C000182);
({ word_1 tmp_1387 = (((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) ^ (((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1))) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_1387 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 834:
/* CRORC */
assert((insn & 0xFC0007FF) == 0x4C000342);
({ word_1 tmp_1388 = (((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) | (((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) ^ 1) & 0x1)) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_1388 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 898:
/* CROR */
assert((insn & 0xFC0007FF) == 0x4C000382);
({ word_1 tmp_1389 = (((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) | (((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1))) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_1389 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 66:
/* CRNOR */
assert((insn & 0xFC0007FF) == 0x4C000042);
({ word_1 tmp_1390 = (((((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) | (((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1))) & 0x1) ^ 1) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_1390 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 450:
/* CRNAND */
assert((insn & 0xFC0007FF) == 0x4C0001C2);
({ word_1 tmp_1391 = (((((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) & (((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1))) & 0x1) ^ 1) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_1391 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 578:
/* CREQV */
assert((insn & 0xFC0007FF) == 0x4C000242);
({ word_1 tmp_1392 = (((((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) ^ (((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1))) & 0x1) ^ 1) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_1392 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 258:
/* CRANDC */
assert((insn & 0xFC0007FF) == 0x4C000102);
({ word_1 tmp_1393 = (((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) & (((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) ^ 1) & 0x1)) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_1393 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 514:
/* CRAND */
assert((insn & 0xFC0007FF) == 0x4C000202);
({ word_1 tmp_1394 = (((((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) & ((1 << 1) - 1)) & (((intp->regs_SPR[1]) >> (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))) & ((1 << 1) - 1))) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F), 1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F) + 1 - 1)) | (tmp_1394 << (1 * ((31 - ((insn >> 21) & 0x1F)) & 0x1F)))); });
break;
case 32:
switch (((insn >> 11) & 0x1F)) {
case 0:
switch (((insn >> 21) & 0x1F)) {
case 5:
/* BNELR+ */
assert((insn & 0xFFE0FFFF) == 0x4CA00020);
intp->have_jumped = 1;
(((intp->regs_SPR[1]) & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) ? 0 /* nop */ : (next_pc = ((intp->regs_SPR[0]) & 4294967292)));
break;
case 4:
/* BNELR */
assert((insn & 0xFFE0FFFF) == 0x4C800020);
intp->have_jumped = 1;
(((intp->regs_SPR[1]) & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) ? 0 /* nop */ : (next_pc = ((intp->regs_SPR[0]) & 4294967292)));
break;
case 20:
/* BLR */
assert((insn & 0xFFE0FFFF) == 0x4E800020);
intp->have_jumped = 1;
(next_pc = ((intp->regs_SPR[0]) & 4294967292));
break;
case 12:
/* BEQLR */
assert((insn & 0xFFE0FFFF) == 0x4D800020);
intp->have_jumped = 1;
(((intp->regs_SPR[1]) & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) ? (next_pc = ((intp->regs_SPR[0]) & 4294967292)) : 0 /* nop */);
break;
default:
assert(0);
}
break;
default:
assert(0);
}
break;
case 33:
/* BLRL */
assert((insn & 0xFFE0FFFF) == 0x4E800021);
intp->have_jumped = 1;
{
word_32 tmp_1395 = (intp->regs_SPR[0]);
({ word_32 tmp_1396 = (pc + 4); ((intp->regs_SPR[0]) = tmp_1396); });
(next_pc = (tmp_1395 & 4294967292));
}
;
break;
case 1056:
/* BCTR */
assert((insn & 0xFFE0FFFF) == 0x4E800420);
intp->have_jumped = 1;
(next_pc = ((intp->regs_SPR[3]) & 4294967292));
break;
default:
assert(0);
}
break;
case 33:
/* LWZU */
assert((insn & 0xFC000000) == 0x84000000);
{
word_32 tmp_1397 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)));
({ word_32 tmp_1398 = mem_get_32(intp, tmp_1397); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1398); });
({ word_32 tmp_1399 = tmp_1397; ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1399); });
}
;
break;
case 32:
/* LWZ */
assert((insn & 0xFC000000) == 0x80000000);
({ word_32 tmp_1400 = ((((insn >> 16) & 0x1F) == 0) ? mem_get_32(intp, ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))) : mem_get_32(intp, ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1400); });
break;
case 41:
/* LHZU */
assert((insn & 0xFC000000) == 0xA4000000);
{
word_32 tmp_1401 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)));
({ word_32 tmp_1402 = mem_get_16(intp, tmp_1401); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1402); });
({ word_32 tmp_1403 = tmp_1401; ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1403); });
}
;
break;
case 40:
/* LHZ */
assert((insn & 0xFC000000) == 0xA0000000);
({ word_32 tmp_1404 = mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1404); });
break;
case 43:
/* LHAU */
assert((insn & 0xFC000000) == 0xAC000000);
{
word_32 tmp_1405 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)));
({ word_32 tmp_1406 = ((mem_get_16(intp, tmp_1405) & 0x8000) ? ((word_32)mem_get_16(intp, tmp_1405) | 0xFFFF0000) : (word_32)mem_get_16(intp, tmp_1405)); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1406); });
({ word_32 tmp_1407 = tmp_1405; ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1407); });
}
;
break;
case 42:
/* LHA */
assert((insn & 0xFC000000) == 0xA8000000);
({ word_32 tmp_1408 = ((mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))))) & 0x8000) ? ((word_32)mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))))) | 0xFFFF0000) : (word_32)mem_get_16(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)))))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1408); });
break;
case 48:
/* LFS */
assert((insn & 0xFC000000) == 0xC0000000);
({ double tmp_1409 = ((double)({ word_32 tmp = mem_get_32(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))))); *(float*)&tmp; })); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1409); });
break;
case 50:
/* LFD */
assert((insn & 0xFC000000) == 0xC8000000);
({ double tmp_1410 = ({ word_64 tmp = mem_get_64(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))))); *(double*)&tmp; }); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1410); });
break;
case 35:
/* LBZU */
assert((insn & 0xFC000000) == 0x8C000000);
{
word_32 tmp_1411 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)));
({ word_32 tmp_1412 = mem_get_8(intp, tmp_1411); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1412); });
({ word_32 tmp_1413 = tmp_1411; ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1413); });
}
;
break;
case 34:
/* LBZ */
assert((insn & 0xFC000000) == 0x88000000);
({ word_32 tmp_1414 = mem_get_8(intp, ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1414); });
break;
case 59:
switch (((insn >> 0) & 0x3F)) {
case 40:
/* FSUBS */
assert((insn & 0xFC0007FF) == 0xEC000028);
({ double tmp_1415 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) - (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1415); });
break;
case 50:
/* FMULS */
assert((insn & 0xFC00F83F) == 0xEC000032);
({ double tmp_1416 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) * (intp->regs_FPR[((insn >> 6) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1416); });
break;
case 56:
/* FMSUBS */
assert((insn & 0xFC00003F) == 0xEC000038);
({ double tmp_1417 = (((intp->regs_FPR[((insn >> 16) & 0x1F)]) * (intp->regs_FPR[((insn >> 6) & 0x1F)])) - (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1417); });
break;
case 58:
/* FMADDS */
assert((insn & 0xFC00003F) == 0xEC00003A);
({ double tmp_1418 = (((intp->regs_FPR[((insn >> 16) & 0x1F)]) * (intp->regs_FPR[((insn >> 6) & 0x1F)])) + (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1418); });
break;
case 36:
/* FDIVS */
assert((insn & 0xFC0007FF) == 0xEC000024);
({ double tmp_1419 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) / (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1419); });
break;
case 42:
/* FADDS */
assert((insn & 0xFC0007FF) == 0xEC00002A);
({ double tmp_1420 = ((intp->regs_FPR[((insn >> 16) & 0x1F)]) + (intp->regs_FPR[((insn >> 11) & 0x1F)])); ((intp->regs_FPR[((insn >> 21) & 0x1F)]) = tmp_1420); });
break;
default:
assert(0);
}
break;
case 11:
/* CMPWI */
assert((insn & 0xFC600000) == 0x2C000000);
({ word_1 tmp_1421 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F) + 1 - 1)) | (tmp_1421 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F)))); });
({ word_1 tmp_1422 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F) + 1 - 1)) | (tmp_1422 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F)))); });
({ word_1 tmp_1423 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F) + 1 - 1)) | (tmp_1423 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F)))); });
({ word_1 tmp_1424 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F), 1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1 - 1)) | (tmp_1424 << (1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F)))); });
break;
case 10:
/* CMPLWI */
assert((insn & 0xFC600000) == 0x28000000);
({ word_1 tmp_1425 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) < ((insn >> 0) & 0xFFFF)) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F) + 1 - 1)) | (tmp_1425 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 3) & 0x1F)))); });
({ word_1 tmp_1426 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) > ((insn >> 0) & 0xFFFF)) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F) + 1 - 1)) | (tmp_1426 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 2) & 0x1F)))); });
({ word_1 tmp_1427 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == ((insn >> 0) & 0xFFFF)) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F), 1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F) + 1 - 1)) | (tmp_1427 << (1 * ((((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1) & 0x1F)))); });
({ word_1 tmp_1428 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F), 1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F) + 1 - 1)) | (tmp_1428 << (1 * ((((7 - ((insn >> 23) & 0x7)) & 0x1F) << 2) & 0x1F)))); });
break;
case 16:
switch (((insn >> 21) & 0x1F)) {
case 5:
/* BNE- */
assert((insn & 0xFFE00003) == 0x40A00000);
intp->have_jumped = 1;
(((intp->regs_SPR[1]) & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) ? 0 /* nop */ : (next_pc = (pc + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2))));
break;
case 4:
/* BNE */
assert((insn & 0xFFE00003) == 0x40800000);
intp->have_jumped = 1;
(((intp->regs_SPR[1]) & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) ? 0 /* nop */ : (next_pc = (pc + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2))));
break;
case 13:
/* BEQ+ */
assert((insn & 0xFFE00003) == 0x41A00000);
intp->have_jumped = 1;
(((intp->regs_SPR[1]) & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) ? (next_pc = (pc + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2))) : 0 /* nop */);
break;
case 12:
/* BEQ */
assert((insn & 0xFFE00003) == 0x41800000);
intp->have_jumped = 1;
(((intp->regs_SPR[1]) & (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F))) ? (next_pc = (pc + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2))) : 0 /* nop */);
break;
case 18:
/* BDZ */
assert((insn & 0xFFE00003) == 0x42400000);
intp->have_jumped = 1;
({ word_32 tmp_1429 = ((intp->regs_SPR[3]) - 1); ((intp->regs_SPR[3]) = tmp_1429); });
(((intp->regs_SPR[3]) == 0) ? (next_pc = (pc + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2))) : 0 /* nop */);
break;
case 16:
/* BDNZ */
assert((insn & 0xFFE00003) == 0x42000000);
intp->have_jumped = 1;
({ word_32 tmp_1430 = ((intp->regs_SPR[3]) - 1); ((intp->regs_SPR[3]) = tmp_1430); });
(((intp->regs_SPR[3]) == 0) ? 0 /* nop */ : (next_pc = (pc + (((((insn >> 2) & 0x3FFF) & 0x2000) ? ((word_32)((insn >> 2) & 0x3FFF) | 0xFFFFC000) : (word_32)((insn >> 2) & 0x3FFF)) << 2))));
break;
default:
assert(0);
}
break;
case 18:
switch (((insn >> 0) & 0x3)) {
case 1:
/* BL */
assert((insn & 0xFC000003) == 0x48000001);
intp->have_jumped = 1;
({ word_32 tmp_1431 = (pc + 4); ((intp->regs_SPR[0]) = tmp_1431); });
(next_pc = (pc + (((((insn >> 2) & 0xFFFFFF) & 0x800000) ? ((word_32)((insn >> 2) & 0xFFFFFF) | 0xFF000000) : (word_32)((insn >> 2) & 0xFFFFFF)) << 2)));
break;
case 0:
/* B */
assert((insn & 0xFC000003) == 0x48000000);
intp->have_jumped = 1;
(next_pc = (pc + (((((insn >> 2) & 0xFFFFFF) & 0x800000) ? ((word_32)((insn >> 2) & 0xFFFFFF) | 0xFF000000) : (word_32)((insn >> 2) & 0xFFFFFF)) << 2)));
break;
default:
assert(0);
}
break;
case 29:
/* ANDIS. */
assert((insn & 0xFC000000) == 0x74000000);
({ word_32 tmp_1432 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) & (((insn >> 0) & 0xFFFF) << 16)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1432); });
({ word_1 tmp_1433 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1433 << (1 * 31))); });
({ word_1 tmp_1434 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1434 << (1 * 30))); });
({ word_1 tmp_1435 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1435 << (1 * 29))); });
({ word_1 tmp_1436 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1436 << (1 * 28))); });
break;
case 28:
/* ANDI. */
assert((insn & 0xFC000000) == 0x70000000);
({ word_32 tmp_1437 = ((intp->regs_GPR[((insn >> 21) & 0x1F)]) & ((insn >> 0) & 0xFFFF)); ((intp->regs_GPR[((insn >> 16) & 0x1F)]) = tmp_1437); });
({ word_1 tmp_1438 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1438 << (1 * 31))); });
({ word_1 tmp_1439 = (((sword_32)(intp->regs_GPR[((insn >> 16) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1439 << (1 * 30))); });
({ word_1 tmp_1440 = (((intp->regs_GPR[((insn >> 16) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1440 << (1 * 29))); });
({ word_1 tmp_1441 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1441 << (1 * 28))); });
break;
case 15:
/* ADDIS */
assert((insn & 0xFC000000) == 0x3C000000);
({ word_32 tmp_1442 = ((((insn >> 16) & 0x1F) == 0) ? (((insn >> 0) & 0xFFFF) << 16) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + (((insn >> 0) & 0xFFFF) << 16))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1442); });
break;
case 13:
/* ADDIC. */
assert((insn & 0xFC000000) == 0x34000000);
({ word_1 tmp_1443 = addcarry_32((intp->regs_GPR[((insn >> 16) & 0x1F)]), ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1443 << 29)); });
({ word_32 tmp_1444 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1444); });
({ word_1 tmp_1445 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) < (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 31, 1 * 31 + 1 - 1)) | (tmp_1445 << (1 * 31))); });
({ word_1 tmp_1446 = (((sword_32)(intp->regs_GPR[((insn >> 21) & 0x1F)]) > (sword_32)0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 30, 1 * 30 + 1 - 1)) | (tmp_1446 << (1 * 30))); });
({ word_1 tmp_1447 = (((intp->regs_GPR[((insn >> 21) & 0x1F)]) == 0) ? 1 : 0); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 29, 1 * 29 + 1 - 1)) | (tmp_1447 << (1 * 29))); });
({ word_1 tmp_1448 = ((intp->regs_SPR[2] >> 31) & 0x1); ((intp->regs_SPR[1]) = ((intp->regs_SPR[1]) & ~mask_32(1 * 28, 1 * 28 + 1 - 1)) | (tmp_1448 << (1 * 28))); });
break;
case 12:
/* ADDIC */
assert((insn & 0xFC000000) == 0x30000000);
({ word_1 tmp_1449 = addcarry_32((intp->regs_GPR[((insn >> 16) & 0x1F)]), ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); (intp->regs_SPR[2] = (intp->regs_SPR[2] & 0xDFFFFFFF) | (tmp_1449 << 29)); });
({ word_32 tmp_1450 = ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1450); });
break;
case 14:
/* ADDI */
assert((insn & 0xFC000000) == 0x38000000);
({ word_32 tmp_1451 = ((((insn >> 16) & 0x1F) == 0) ? ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)) : ((intp->regs_GPR[((insn >> 16) & 0x1F)]) + ((((insn >> 0) & 0xFFFF) & 0x8000) ? ((word_32)((insn >> 0) & 0xFFFF) | 0xFFFF0000) : (word_32)((insn >> 0) & 0xFFFF)))); ((intp->regs_GPR[((insn >> 21) & 0x1F)]) = tmp_1451); });
break;
default:
assert(0);
}
intp->pc = next_pc;
++intp->insn_count;
}
void dump_ppc_registers (interpreter_t *intp) {
printf("LR: 0x%x\n", intp->regs_SPR[0]);
printf("CR: 0x%x\n", intp->regs_SPR[1]);
printf("XER: 0x%x\n", intp->regs_SPR[2]);
printf("CTR: 0x%x\n", intp->regs_SPR[3]);
printf("FPSCR: 0x%x\n", intp->regs_SPR[4]);
printf("GPR0: 0x%x\n", intp->regs_GPR[0]);
printf("GPR1: 0x%x\n", intp->regs_GPR[1]);
printf("GPR2: 0x%x\n", intp->regs_GPR[2]);
printf("GPR3: 0x%x\n", intp->regs_GPR[3]);
printf("GPR4: 0x%x\n", intp->regs_GPR[4]);
printf("GPR5: 0x%x\n", intp->regs_GPR[5]);
printf("GPR6: 0x%x\n", intp->regs_GPR[6]);
printf("GPR7: 0x%x\n", intp->regs_GPR[7]);
printf("GPR8: 0x%x\n", intp->regs_GPR[8]);
printf("GPR9: 0x%x\n", intp->regs_GPR[9]);
printf("GPR10: 0x%x\n", intp->regs_GPR[10]);
printf("GPR11: 0x%x\n", intp->regs_GPR[11]);
printf("GPR12: 0x%x\n", intp->regs_GPR[12]);
printf("GPR13: 0x%x\n", intp->regs_GPR[13]);
printf("GPR14: 0x%x\n", intp->regs_GPR[14]);
printf("GPR15: 0x%x\n", intp->regs_GPR[15]);
printf("GPR16: 0x%x\n", intp->regs_GPR[16]);
printf("GPR17: 0x%x\n", intp->regs_GPR[17]);
printf("GPR18: 0x%x\n", intp->regs_GPR[18]);
printf("GPR19: 0x%x\n", intp->regs_GPR[19]);
printf("GPR20: 0x%x\n", intp->regs_GPR[20]);
printf("GPR21: 0x%x\n", intp->regs_GPR[21]);
printf("GPR22: 0x%x\n", intp->regs_GPR[22]);
printf("GPR23: 0x%x\n", intp->regs_GPR[23]);
printf("GPR24: 0x%x\n", intp->regs_GPR[24]);
printf("GPR25: 0x%x\n", intp->regs_GPR[25]);
printf("GPR26: 0x%x\n", intp->regs_GPR[26]);
printf("GPR27: 0x%x\n", intp->regs_GPR[27]);
printf("GPR28: 0x%x\n", intp->regs_GPR[28]);
printf("GPR29: 0x%x\n", intp->regs_GPR[29]);
printf("GPR30: 0x%x\n", intp->regs_GPR[30]);
printf("GPR31: 0x%x\n", intp->regs_GPR[31]);
printf("FPR0: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[0], intp->regs_FPR[0]);
printf("FPR1: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[1], intp->regs_FPR[1]);
printf("FPR2: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[2], intp->regs_FPR[2]);
printf("FPR3: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[3], intp->regs_FPR[3]);
printf("FPR4: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[4], intp->regs_FPR[4]);
printf("FPR5: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[5], intp->regs_FPR[5]);
printf("FPR6: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[6], intp->regs_FPR[6]);
printf("FPR7: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[7], intp->regs_FPR[7]);
printf("FPR8: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[8], intp->regs_FPR[8]);
printf("FPR9: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[9], intp->regs_FPR[9]);
printf("FPR10: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[10], intp->regs_FPR[10]);
printf("FPR11: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[11], intp->regs_FPR[11]);
printf("FPR12: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[12], intp->regs_FPR[12]);
printf("FPR13: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[13], intp->regs_FPR[13]);
printf("FPR14: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[14], intp->regs_FPR[14]);
printf("FPR15: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[15], intp->regs_FPR[15]);
printf("FPR16: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[16], intp->regs_FPR[16]);
printf("FPR17: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[17], intp->regs_FPR[17]);
printf("FPR18: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[18], intp->regs_FPR[18]);
printf("FPR19: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[19], intp->regs_FPR[19]);
printf("FPR20: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[20], intp->regs_FPR[20]);
printf("FPR21: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[21], intp->regs_FPR[21]);
printf("FPR22: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[22], intp->regs_FPR[22]);
printf("FPR23: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[23], intp->regs_FPR[23]);
printf("FPR24: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[24], intp->regs_FPR[24]);
printf("FPR25: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[25], intp->regs_FPR[25]);
printf("FPR26: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[26], intp->regs_FPR[26]);
printf("FPR27: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[27], intp->regs_FPR[27]);
printf("FPR28: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[28], intp->regs_FPR[28]);
printf("FPR29: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[29], intp->regs_FPR[29]);
printf("FPR30: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[30], intp->regs_FPR[30]);
printf("FPR31: 0x%lx (%f)\n", *(word_64*)&intp->regs_FPR[31], intp->regs_FPR[31]);
printf("PC: 0x%x\n", intp->pc);
}
