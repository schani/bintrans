#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compiler_tmp_963007 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_962998 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963003 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_962996 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_962986 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_962995 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_962994 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_962991 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_954982 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_954977 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954975 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_954929 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954974 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954933 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954934 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954937 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954967 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954971 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954968 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954959 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954964 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954960 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954963 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954938 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954941 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954951 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954958 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954952 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954957 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954955 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954944 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954947 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954949 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954948 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954945 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_954939 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_963007 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 6 6 T)
*/
{
{
reg_t tmp_963008;
rhs_func(&tmp_963008, 11, env);
emit(COMPOSE_AND_IMM(tmp_963008, 1, tmp_963008));
unref_integer_reg(tmp_963008);
}
}

void compiler_tmp_962998 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (=
  (CASE
   ((0 1 2)
    (MEM
     (CASE
      ((0)
       (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
        ((4)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))
        ((5) (FIELD DISP32 NIL NIL))))
      ((1)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
        ((4)
         (+ (SEX (FIELD DISP8 NIL NIL))
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0))))))))
      ((2)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
        ((4)
         (+ (FIELD DISP32 NIL NIL)
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0)))))))))))
   ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
  (INTEGER 0))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_963000 = alloc_label(), tmp_963001 = alloc_label(), tmp_963002 = alloc_label();
reg_t tmp_962999;
compiler_tmp_963003(tmp_963000, tmp_963001, env);

tmp_962999 = ref_integer_reg_for_writing(-1);
emit_label(tmp_963000);
push_alloc();
compiler_tmp_962994(&tmp_962999, tmp_962999 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_963002);
emit_label(tmp_963001);
push_alloc();
compiler_tmp_962995(&tmp_962999, tmp_962999 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_963002);
free_label(tmp_963000);
free_label(tmp_963001);
free_label(tmp_963002);
if (foreign_target == -1)
*target = tmp_962999;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_962999, *target));
unref_integer_reg(tmp_962999);
}

}
}

void compiler_tmp_963003 (label_t true_label, label_t false_label, void **env)
/*
(=
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (INTEGER 0))
*/
{
{
reg_t tmp_963004, tmp_963005, tmp_963006;
compiler_tmp_954933(&tmp_963004, -1, env);
compiler_tmp_954958(&tmp_963005, -1, env);
tmp_963006 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_CMPEQ(tmp_963004, tmp_963005, tmp_963006));
unref_integer_reg(tmp_963004);
unref_integer_reg(tmp_963005);
emit_branch(COMPOSE_BEQ(tmp_963006, 0), false_label);
unref_integer_reg(tmp_963006);
emit_branch(COMPOSE_BR(31, 0), true_label);
}
}

void compiler_tmp_962996 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 7 7 T)
*/
{
{
reg_t tmp_962997;
rhs_func(&tmp_962997, 12, env);
emit(COMPOSE_AND_IMM(tmp_962997, 1, tmp_962997));
unref_integer_reg(tmp_962997);
}
}

void compiler_tmp_962986 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (BIT-SET-P
  (CASE
   ((0 1 2)
    (MEM
     (CASE
      ((0)
       (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
        ((4)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))
        ((5) (FIELD DISP32 NIL NIL))))
      ((1)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
        ((4)
         (+ (SEX (FIELD DISP8 NIL NIL))
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0))))))))
      ((2)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
        ((4)
         (+ (FIELD DISP32 NIL NIL)
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0)))))))))))
   ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
  (- (INTEGER 32) (INTEGER 1)))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_962988 = alloc_label(), tmp_962989 = alloc_label(), tmp_962990 = alloc_label();
reg_t tmp_962987;
compiler_tmp_962991(tmp_962988, tmp_962989, env);

tmp_962987 = ref_integer_reg_for_writing(-1);
emit_label(tmp_962988);
push_alloc();
compiler_tmp_962994(&tmp_962987, tmp_962987 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_962990);
emit_label(tmp_962989);
push_alloc();
compiler_tmp_962995(&tmp_962987, tmp_962987 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_962990);
free_label(tmp_962988);
free_label(tmp_962989);
free_label(tmp_962990);
if (foreign_target == -1)
*target = tmp_962987;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_962987, *target));
unref_integer_reg(tmp_962987);
}

}
}

void compiler_tmp_962995 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_962994 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 1)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 1);
}

void compiler_tmp_962991 (label_t true_label, label_t false_label, void **env)
/*
(BIT-SET-P
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (- (INTEGER 32) (INTEGER 1)))
*/
{
{
reg_t tmp_962992, tmp_962993;
compiler_tmp_954933(&tmp_962992, -1, env);
tmp_962993 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_SRL_IMM(tmp_962992, (32 - 1), tmp_962993));
unref_integer_reg(tmp_962992);
emit_branch(COMPOSE_BLBS(tmp_962993, 0), true_label);
unref_integer_reg(tmp_962993);
emit_branch(COMPOSE_BR(31, 0), false_label);
}
}

void compiler_tmp_954982 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 0 0 T)
*/
{
{
reg_t tmp_954983;
rhs_func(&tmp_954983, 10, env);
emit(COMPOSE_AND_IMM(tmp_954983, 1, tmp_954983));
unref_integer_reg(tmp_954983);
}
}

void compiler_tmp_954977 (reg_t *target, int foreign_target, void **env)
/*
(+CARRY
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (SEX (FIELD IMM8 NIL NIL)))
*/
{
{
reg_t tmp_954980, tmp_954981, tmp_954978, tmp_954979;
compiler_tmp_954933(&tmp_954980, -1, env);
tmp_954978 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ZAPNOT_IMM(tmp_954980, 15, tmp_954978));
unref_integer_reg(tmp_954980);
compiler_tmp_954974(&tmp_954981, -1, env);
tmp_954979 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ZAPNOT_IMM(tmp_954981, 15, tmp_954979));
unref_integer_reg(tmp_954981);*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDQ(tmp_954978, tmp_954979, *target));
unref_integer_reg(tmp_954978);
unref_integer_reg(tmp_954979);
emit(COMPOSE_SRL_IMM(*target, 32, *target));
}
}

void compiler_tmp_954975 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 11 11 T)
*/
{
{
reg_t tmp_954976;
rhs_func(&tmp_954976, 13, env);
emit(COMPOSE_AND_IMM(tmp_954976, 1, tmp_954976));
unref_integer_reg(tmp_954976);
}
}

void compiler_tmp_954929 (reg_t *target, int foreign_target, void **env)
/*
(+OVERFLOW
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (SEX (FIELD IMM8 NIL NIL)))
*/
{
{
reg_t tmp_954930, tmp_954931, tmp_954932;
compiler_tmp_954933(&tmp_954930, -1, env);
compiler_tmp_954974(&tmp_954931, -1, env);
tmp_954932 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ADDQ(tmp_954930, tmp_954931, tmp_954932));
unref_integer_reg(tmp_954930);
unref_integer_reg(tmp_954931);
emit(COMPOSE_SRA_IMM(tmp_954932, 32, tmp_954932));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDQ_IMM(31, 1, *target));
emit(COMPOSE_CMOVEQ_IMM(tmp_954932, 0, *target));
emit(COMPOSE_NOT(tmp_954932, tmp_954932));
emit(COMPOSE_CMOVEQ_IMM(tmp_954932, 0, *target));
unref_integer_reg(tmp_954932);
}
}

void compiler_tmp_954974 (reg_t *target, int foreign_target, void **env)
/*
(SEX (FIELD IMM8 NIL NIL))
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
}

void compiler_tmp_954933 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2)
  (MEM
   (CASE
    ((0)
     (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
      ((4)
       (+
        (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
         ((5)
          (CASE ((0) (FIELD DISP32 NIL NIL))
           ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
        (CASE
         ((0 1 2 3 5 6 7)
          (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
           (ZEX (FIELD SCALE NIL NIL))))
         ((4) (INTEGER 0)))))
      ((5) (FIELD DISP32 NIL NIL))))
    ((1)
     (CASE
      ((0 1 2 3 5 6 7)
       (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
      ((4)
       (+ (SEX (FIELD DISP8 NIL NIL))
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0))))))))
    ((2)
     (CASE
      ((0 1 2 3 5 6 7)
       (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
      ((4)
       (+ (FIELD DISP32 NIL NIL)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))))))))
 ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
*/
{
switch (mod) {
case 0:
case 1:
case 2:
compiler_tmp_954934(&(*target), foreign_target, env);
break;
case 3:
compiler_tmp_954939(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_954934 (reg_t *target, int foreign_target, void **env)
/*
(MEM
 (CASE
  ((0)
   (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
    ((4)
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0)))))
    ((5) (FIELD DISP32 NIL NIL))))
  ((1)
   (CASE
    ((0 1 2 3 5 6 7)
     (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
    ((4)
     (+ (SEX (FIELD DISP8 NIL NIL))
      (+
       (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
        ((5)
         (CASE ((0) (FIELD DISP32 NIL NIL))
          ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
       (CASE
        ((0 1 2 3 5 6 7)
         (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
          (ZEX (FIELD SCALE NIL NIL))))
        ((4) (INTEGER 0))))))))
  ((2)
   (CASE
    ((0 1 2 3 5 6 7)
     (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
    ((4)
     (+ (FIELD DISP32 NIL NIL)
      (+
       (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
        ((5)
         (CASE ((0) (FIELD DISP32 NIL NIL))
          ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
       (CASE
        ((0 1 2 3 5 6 7)
         (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
          (ZEX (FIELD SCALE NIL NIL))))
        ((4) (INTEGER 0))))))))))
*/
{
{
reg_t tmp_954935, tmp_954936;
compiler_tmp_954937(&tmp_954935, -1, env);
#ifdef EMU_I386
tmp_954936 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ZAPNOT_IMM(tmp_954935, 15, tmp_954936));
unref_integer_reg(tmp_954935);
#else
tmp_954936 = tmp_954935;
#endif
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_mem_32(*target, tmp_954936);
unref_integer_reg(tmp_954936);
}
}

void compiler_tmp_954937 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0)
  (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
   ((4)
    (+
     (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
      ((5)
       (CASE ((0) (FIELD DISP32 NIL NIL))
        ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
     (CASE
      ((0 1 2 3 5 6 7)
       (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
        (ZEX (FIELD SCALE NIL NIL))))
      ((4) (INTEGER 0)))))
   ((5) (FIELD DISP32 NIL NIL))))
 ((1)
  (CASE
   ((0 1 2 3 5 6 7)
    (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
   ((4)
    (+ (SEX (FIELD DISP8 NIL NIL))
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0))))))))
 ((2)
  (CASE
   ((0 1 2 3 5 6 7)
    (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
   ((4)
    (+ (FIELD DISP32 NIL NIL)
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0)))))))))
*/
{
switch (mod) {
case 0:
compiler_tmp_954938(&(*target), foreign_target, env);
break;
case 1:
compiler_tmp_954959(&(*target), foreign_target, env);
break;
case 2:
compiler_tmp_954967(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_954967 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
 ((4)
  (+ (FIELD DISP32 NIL NIL)
   (+
    (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
     ((5)
      (CASE ((0) (FIELD DISP32 NIL NIL))
       ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
    (CASE
     ((0 1 2 3 5 6 7)
      (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
       (ZEX (FIELD SCALE NIL NIL))))
     ((4) (INTEGER 0)))))))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_954968(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_954971(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_954971 (reg_t *target, int foreign_target, void **env)
/*
(+ (FIELD DISP32 NIL NIL)
 (+
  (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
   ((5)
    (CASE ((0) (FIELD DISP32 NIL NIL))
     ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
  (CASE
   ((0 1 2 3 5 6 7)
    (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
     (ZEX (FIELD SCALE NIL NIL))))
   ((4) (INTEGER 0)))))
*/
{
{
reg_t tmp_954972, tmp_954973;
compiler_tmp_954948(&tmp_954972, -1, env);
compiler_tmp_954941(&tmp_954973, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_954972, tmp_954973, *target));
unref_integer_reg(tmp_954972);
unref_integer_reg(tmp_954973);
}
}

void compiler_tmp_954968 (reg_t *target, int foreign_target, void **env)
/*
(+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL))
*/
{
{
reg_t tmp_954969, tmp_954970;
compiler_tmp_954939(&tmp_954969, -1, env);
compiler_tmp_954948(&tmp_954970, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_954969, tmp_954970, *target));
unref_integer_reg(tmp_954969);
unref_integer_reg(tmp_954970);
}
}

void compiler_tmp_954959 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
 ((4)
  (+ (SEX (FIELD DISP8 NIL NIL))
   (+
    (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
     ((5)
      (CASE ((0) (FIELD DISP32 NIL NIL))
       ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
    (CASE
     ((0 1 2 3 5 6 7)
      (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
       (ZEX (FIELD SCALE NIL NIL))))
     ((4) (INTEGER 0)))))))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_954960(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_954964(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_954964 (reg_t *target, int foreign_target, void **env)
/*
(+ (SEX (FIELD DISP8 NIL NIL))
 (+
  (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
   ((5)
    (CASE ((0) (FIELD DISP32 NIL NIL))
     ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
  (CASE
   ((0 1 2 3 5 6 7)
    (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
     (ZEX (FIELD SCALE NIL NIL))))
   ((4) (INTEGER 0)))))
*/
{
{
reg_t tmp_954965, tmp_954966;
compiler_tmp_954963(&tmp_954965, -1, env);
compiler_tmp_954941(&tmp_954966, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_954965, tmp_954966, *target));
unref_integer_reg(tmp_954965);
unref_integer_reg(tmp_954966);
}
}

void compiler_tmp_954960 (reg_t *target, int foreign_target, void **env)
/*
(+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL)))
*/
{
{
reg_t tmp_954961, tmp_954962;
compiler_tmp_954939(&tmp_954961, -1, env);
compiler_tmp_954963(&tmp_954962, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_954961, tmp_954962, *target));
unref_integer_reg(tmp_954961);
unref_integer_reg(tmp_954962);
}
}

void compiler_tmp_954963 (reg_t *target, int foreign_target, void **env)
/*
(SEX (FIELD DISP8 NIL NIL))
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
}

void compiler_tmp_954938 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
 ((4)
  (+
   (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
    ((5)
     (CASE ((0) (FIELD DISP32 NIL NIL))
      ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
   (CASE
    ((0 1 2 3 5 6 7)
     (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
      (ZEX (FIELD SCALE NIL NIL))))
    ((4) (INTEGER 0)))))
 ((5) (FIELD DISP32 NIL NIL)))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 6:
case 7:
compiler_tmp_954939(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_954941(&(*target), foreign_target, env);
break;
case 5:
compiler_tmp_954948(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_954941 (reg_t *target, int foreign_target, void **env)
/*
(+
 (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
  ((5)
   (CASE ((0) (FIELD DISP32 NIL NIL))
    ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
 (CASE
  ((0 1 2 3 5 6 7)
   (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
    (ZEX (FIELD SCALE NIL NIL))))
  ((4) (INTEGER 0))))
*/
{
{
reg_t tmp_954942, tmp_954943;
compiler_tmp_954944(&tmp_954942, -1, env);
compiler_tmp_954951(&tmp_954943, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_954942, tmp_954943, *target));
unref_integer_reg(tmp_954942);
unref_integer_reg(tmp_954943);
}
}

void compiler_tmp_954951 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
   (ZEX (FIELD SCALE NIL NIL))))
 ((4) (INTEGER 0)))
*/
{
switch (index) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_954952(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_954958(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_954958 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_954952 (reg_t *target, int foreign_target, void **env)
/*
(SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL)) (ZEX (FIELD SCALE NIL NIL)))
*/
{
{
reg_t tmp_954953, tmp_954954;
compiler_tmp_954955(&tmp_954953, -1, env);
compiler_tmp_954957(&tmp_954954, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_SLL(tmp_954953, tmp_954954, *target));
unref_integer_reg(tmp_954953);
unref_integer_reg(tmp_954954);
emit(COMPOSE_ADDL((*target), 31, (*target)));
}
}

void compiler_tmp_954957 (reg_t *target, int foreign_target, void **env)
/*
(ZEX (FIELD SCALE NIL NIL))
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, scale);
}

void compiler_tmp_954955 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD INDEX NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + index));
else {
reg_t tmp_954956 = ref_integer_reg_for_reading((0 + index));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_954956, *target));
unref_integer_reg(tmp_954956);
}
}

void compiler_tmp_954944 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
 ((5)
  (CASE ((0) (FIELD DISP32 NIL NIL))
   ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
*/
{
switch (base) {
case 0:
case 1:
case 2:
case 3:
case 4:
case 6:
case 7:
compiler_tmp_954945(&(*target), foreign_target, env);
break;
case 5:
compiler_tmp_954947(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_954947 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0) (FIELD DISP32 NIL NIL)) ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))
*/
{
switch (mod) {
case 0:
compiler_tmp_954948(&(*target), foreign_target, env);
break;
case 1:
case 2:
case 3:
compiler_tmp_954949(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_954949 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER EBP GPR (INTEGER 5))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading(5);
else {
reg_t tmp_954950 = ref_integer_reg_for_reading(5);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_954950, *target));
unref_integer_reg(tmp_954950);
}
}

void compiler_tmp_954948 (reg_t *target, int foreign_target, void **env)
/*
(FIELD DISP32 NIL NIL)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, disp32);
}

void compiler_tmp_954945 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD BASE NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + base));
else {
reg_t tmp_954946 = ref_integer_reg_for_reading((0 + base));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_954946, *target));
unref_integer_reg(tmp_954946);
}
}

void compiler_tmp_954939 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD RM NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + rm));
else {
reg_t tmp_954940 = ref_integer_reg_for_reading((0 + rm));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_954940, *target));
unref_integer_reg(tmp_954940);
}
}

void compile_add_rm32_simm8_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_954929;
killed |= 0x800;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_954975(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_954977;
killed |= 0x1;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_954982(rhs_func, env);
}
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_955314();
goto next_tmp_954985;
next_tmp_954985:
goto finish_tmp_954984;
finish_tmp_954984:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_955689();
goto next_tmp_955317;
next_tmp_955317:
goto finish_tmp_955316;
finish_tmp_955316:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_956099();
goto next_tmp_955692;
next_tmp_955692:
goto finish_tmp_955691;
finish_tmp_955691:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_956431();
goto next_tmp_956102;
next_tmp_956102:
goto finish_tmp_956101;
finish_tmp_956101:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_956808();
goto next_tmp_956434;
next_tmp_956434:
goto finish_tmp_956433;
finish_tmp_956433:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_957194();
goto next_tmp_956811;
next_tmp_956811:
goto finish_tmp_956810;
finish_tmp_956810:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_957450();
goto next_tmp_957197;
next_tmp_957197:
goto finish_tmp_957196;
finish_tmp_957196:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; }))
{
genfunc_tmp_957450();
goto next_tmp_957453;
next_tmp_957453:
goto finish_tmp_957452;
finish_tmp_957452:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_957835();
goto next_tmp_957456;
next_tmp_957456:
goto finish_tmp_957455;
finish_tmp_957455:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_958221();
goto next_tmp_957838;
next_tmp_957838:
goto finish_tmp_957837;
finish_tmp_957837:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_958607();
goto next_tmp_958224;
next_tmp_958224:
goto finish_tmp_958223;
finish_tmp_958223:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_958984();
goto next_tmp_958610;
next_tmp_958610:
goto finish_tmp_958609;
finish_tmp_958609:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_959389();
goto next_tmp_958987;
next_tmp_958987:
goto finish_tmp_958986;
finish_tmp_958986:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_959797();
goto next_tmp_959392;
next_tmp_959392:
goto finish_tmp_959391;
finish_tmp_959391:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_960174();
goto next_tmp_959800;
next_tmp_959800:
goto finish_tmp_959799;
finish_tmp_959799:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_960556();
goto next_tmp_960177;
next_tmp_960177:
goto finish_tmp_960176;
finish_tmp_960176:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_960942();
goto next_tmp_960559;
next_tmp_960559:
goto finish_tmp_960558;
finish_tmp_960558:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_961328();
goto next_tmp_960945;
next_tmp_960945:
goto finish_tmp_960944;
finish_tmp_960944:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_961705();
goto next_tmp_961331;
next_tmp_961331:
goto finish_tmp_961330;
finish_tmp_961330:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_962091();
goto next_tmp_961708;
next_tmp_961708:
goto finish_tmp_961707;
finish_tmp_961707:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_962477();
goto next_tmp_962094;
next_tmp_962094:
goto finish_tmp_962093;
finish_tmp_962093:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_962854();
goto next_tmp_962480;
next_tmp_962480:
goto finish_tmp_962479;
finish_tmp_962479:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 3; })&& ({ word_2 tmp = mod; 0 || tmp == 3; }))
{
genfunc_tmp_962984();
goto next_tmp_962857;
next_tmp_962857:
goto finish_tmp_962856;
finish_tmp_962856:
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_962986;
killed |= 0x80;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_962996(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_962998;
killed |= 0x40;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_963007(rhs_func, env);
}
}
}
void genfunc_tmp_962984 (void) {
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_962950 = tmp_952086;
if ((tmp_962950 >> 8) == 0)
field_imm = tmp_962950;
else goto fail_tmp_962949;
}
/* commit */
tmp_952084 = ref_gpr_reg_for_reading(0 + rm);
tmp_952083 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952083);
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 1 */
}
goto done_tmp_962983;
fail_tmp_962949:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
tmp_952088 = ref_gpr_reg_for_reading(0 + rm);
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952087);
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 2 */
}
done_tmp_962983:
}
reg_t genfunc_tmp_962934 (void) {
reg_t tmp_952088;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_962871 = tmp_952086;
if ((tmp_962871 >> 8) == 0)
field_imm = tmp_962871;
else goto fail_tmp_962870;
}
/* commit */
tmp_952084 = ref_gpr_reg_for_reading(0 + rm);
tmp_952083 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 1 */
}
goto done_tmp_962933;
fail_tmp_962870:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
tmp_952088 = ref_gpr_reg_for_reading(0 + rm);
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 2 */
}
done_tmp_962933:
return tmp_952088;
}
reg_t genfunc_tmp_962903 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_962885 = tmp_952086;
if ((tmp_962885 >> 8) == 0)
field_imm = tmp_962885;
else goto fail_tmp_962884;
}
/* commit */
tmp_952084 = ref_gpr_reg_for_reading(0 + rm);
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 1 */
}
goto done_tmp_962902;
fail_tmp_962884:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
tmp_952088 = ref_gpr_reg_for_reading(0 + rm);
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 2 */
}
done_tmp_962902:
return tmp_952080;
}
void genfunc_tmp_962854 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_962604();
goto next_tmp_962483;
next_tmp_962483:
goto tmp_962482;
tmp_962482:
}
{
tmp_951328 = genfunc_tmp_962851();
goto next_tmp_962607;
next_tmp_962607:
goto tmp_962606;
tmp_962606:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 10 */
}
done_tmp_962853:
}
reg_t genfunc_tmp_962851 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_962779 = tmp_952086;
if ((tmp_962779 >> 8) == 0)
field_imm = tmp_962779;
else goto fail_tmp_962778;
}
/* commit */
{
tmp_952084 = genfunc_tmp_962770();
goto next_tmp_962781;
next_tmp_962781:
goto tmp_962780;
tmp_962780:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_962850;
fail_tmp_962778:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_962770();
goto next_tmp_962612;
next_tmp_962612:
goto tmp_962611;
tmp_962611:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_962850:
return tmp_951328;
}
reg_t genfunc_tmp_962820 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_962799 = tmp_952086;
if ((tmp_962799 >> 8) == 0)
field_imm = tmp_962799;
else goto fail_tmp_962798;
}
/* commit */
{
tmp_952084 = genfunc_tmp_962770();
goto next_tmp_962801;
next_tmp_962801:
goto tmp_962800;
tmp_962800:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_962819;
fail_tmp_962798:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_962770();
goto next_tmp_962790;
next_tmp_962790:
goto tmp_962789;
tmp_962789:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_962819:
return tmp_952080;
}
reg_t genfunc_tmp_962770 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_962604();
goto next_tmp_962747;
next_tmp_962747:
goto tmp_962746;
tmp_962746:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_962769:
return tmp_952088;
}
reg_t genfunc_tmp_962722 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_962691 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_962691 >> 8) == 0)
field_imm = tmp_962691;
else goto fail_tmp_962690;
}
/* commit */
{
tmp_952040 = genfunc_tmp_962653();
goto next_tmp_962693;
next_tmp_962693:
goto tmp_962692;
tmp_962692:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_962721;
fail_tmp_962690:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_962713 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_962713))
field_imm = inv_maskmask(8, tmp_962713);
else goto fail_tmp_962712;
}
/* commit */
{
tmp_951257 = genfunc_tmp_962653();
goto next_tmp_962715;
next_tmp_962715:
goto tmp_962714;
tmp_962714:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_962721;
fail_tmp_962712:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_962653();
goto next_tmp_962719;
next_tmp_962719:
goto tmp_962718;
tmp_962718:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_962721:
return tmp_952044;
}
reg_t genfunc_tmp_962653 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_962604();
goto next_tmp_962650;
next_tmp_962650:
goto tmp_962649;
tmp_962649:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_962652:
return tmp_952080;
}
reg_t genfunc_tmp_962604 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_962571 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_962571 >> 8) == 0)
field_imm = tmp_962571;
else goto fail_tmp_962570;
}
/* commit */
{
tmp_952040 = genfunc_tmp_962515();
goto next_tmp_962573;
next_tmp_962573:
goto tmp_962572;
tmp_962572:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_962603;
fail_tmp_962570:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_962595 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_962595))
field_imm = inv_maskmask(8, tmp_962595);
else goto fail_tmp_962594;
}
/* commit */
{
tmp_951257 = genfunc_tmp_962515();
goto next_tmp_962597;
next_tmp_962597:
goto tmp_962596;
tmp_962596:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_962603;
fail_tmp_962594:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_962515();
goto next_tmp_962601;
next_tmp_962601:
goto tmp_962600;
tmp_962600:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_962603:
return tmp_951324;
}
reg_t genfunc_tmp_962568 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_962537 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_962537 >> 8) == 0)
field_imm = tmp_962537;
else goto fail_tmp_962536;
}
/* commit */
{
tmp_952040 = genfunc_tmp_962515();
goto next_tmp_962539;
next_tmp_962539:
goto tmp_962538;
tmp_962538:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_962567;
fail_tmp_962536:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_962559 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_962559))
field_imm = inv_maskmask(8, tmp_962559);
else goto fail_tmp_962558;
}
/* commit */
{
tmp_951257 = genfunc_tmp_962515();
goto next_tmp_962561;
next_tmp_962561:
goto tmp_962560;
tmp_962560:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_962567;
fail_tmp_962558:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_962515();
goto next_tmp_962565;
next_tmp_962565:
goto tmp_962564;
tmp_962564:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_962567:
return tmp_952044;
}
reg_t genfunc_tmp_962515 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_962512;
field_ra = 31;
/* commit */
tmp_951424 = ref_gpr_reg_for_reading(0 + 5);
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 1 */
}
goto done_tmp_962514;
fail_tmp_962512:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_962513;
field_ra = 31;
/* commit */
tmp_951392 = ref_gpr_reg_for_reading(0 + 5);
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 1 */
}
goto done_tmp_962514;
fail_tmp_962513:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_952082 = ref_gpr_reg_for_reading(0 + 5);
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_962514:
return tmp_952058;
}
void genfunc_tmp_962477 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_962227();
goto next_tmp_962097;
next_tmp_962097:
goto tmp_962096;
tmp_962096:
}
{
tmp_951328 = genfunc_tmp_962474();
goto next_tmp_962230;
next_tmp_962230:
goto tmp_962229;
tmp_962229:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 14 */
}
done_tmp_962476:
}
reg_t genfunc_tmp_962474 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_962402 = tmp_952086;
if ((tmp_962402 >> 8) == 0)
field_imm = tmp_962402;
else goto fail_tmp_962401;
}
/* commit */
{
tmp_952084 = genfunc_tmp_962393();
goto next_tmp_962404;
next_tmp_962404:
goto tmp_962403;
tmp_962403:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 7 */
}
goto done_tmp_962473;
fail_tmp_962401:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_962393();
goto next_tmp_962235;
next_tmp_962235:
goto tmp_962234;
tmp_962234:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 8 */
}
done_tmp_962473:
return tmp_951328;
}
reg_t genfunc_tmp_962443 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_962422 = tmp_952086;
if ((tmp_962422 >> 8) == 0)
field_imm = tmp_962422;
else goto fail_tmp_962421;
}
/* commit */
{
tmp_952084 = genfunc_tmp_962393();
goto next_tmp_962424;
next_tmp_962424:
goto tmp_962423;
tmp_962423:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 7 */
}
goto done_tmp_962442;
fail_tmp_962421:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_962393();
goto next_tmp_962413;
next_tmp_962413:
goto tmp_962412;
tmp_962412:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 8 */
}
done_tmp_962442:
return tmp_952080;
}
reg_t genfunc_tmp_962393 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_962227();
goto next_tmp_962370;
next_tmp_962370:
goto tmp_962369;
tmp_962369:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_962392:
return tmp_952088;
}
reg_t genfunc_tmp_962345 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_962314 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_962314 >> 8) == 0)
field_imm = tmp_962314;
else goto fail_tmp_962313;
}
/* commit */
{
tmp_952040 = genfunc_tmp_962276();
goto next_tmp_962316;
next_tmp_962316:
goto tmp_962315;
tmp_962315:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 7 */
}
goto done_tmp_962344;
fail_tmp_962313:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_962336 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_962336))
field_imm = inv_maskmask(8, tmp_962336);
else goto fail_tmp_962335;
}
/* commit */
{
tmp_951257 = genfunc_tmp_962276();
goto next_tmp_962338;
next_tmp_962338:
goto tmp_962337;
tmp_962337:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 7 */
}
goto done_tmp_962344;
fail_tmp_962335:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_962276();
goto next_tmp_962342;
next_tmp_962342:
goto tmp_962341;
tmp_962341:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 7 */
}
done_tmp_962344:
return tmp_952044;
}
reg_t genfunc_tmp_962276 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_962227();
goto next_tmp_962273;
next_tmp_962273:
goto tmp_962272;
tmp_962272:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_962275:
return tmp_952080;
}
reg_t genfunc_tmp_962227 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_962194 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_962194 >> 8) == 0)
field_imm = tmp_962194;
else goto fail_tmp_962193;
}
/* commit */
{
tmp_952040 = genfunc_tmp_962138();
goto next_tmp_962196;
next_tmp_962196:
goto tmp_962195;
tmp_962195:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_962226;
fail_tmp_962193:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_962218 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_962218))
field_imm = inv_maskmask(8, tmp_962218);
else goto fail_tmp_962217;
}
/* commit */
{
tmp_951257 = genfunc_tmp_962138();
goto next_tmp_962220;
next_tmp_962220:
goto tmp_962219;
tmp_962219:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_962226;
fail_tmp_962217:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_962138();
goto next_tmp_962224;
next_tmp_962224:
goto tmp_962223;
tmp_962223:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_962226:
return tmp_951324;
}
reg_t genfunc_tmp_962191 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_962160 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_962160 >> 8) == 0)
field_imm = tmp_962160;
else goto fail_tmp_962159;
}
/* commit */
{
tmp_952040 = genfunc_tmp_962138();
goto next_tmp_962162;
next_tmp_962162:
goto tmp_962161;
tmp_962161:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_962190;
fail_tmp_962159:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_962182 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_962182))
field_imm = inv_maskmask(8, tmp_962182);
else goto fail_tmp_962181;
}
/* commit */
{
tmp_951257 = genfunc_tmp_962138();
goto next_tmp_962184;
next_tmp_962184:
goto tmp_962183;
tmp_962183:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_962190;
fail_tmp_962181:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_962138();
goto next_tmp_962188;
next_tmp_962188:
goto tmp_962187;
tmp_962187:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_962190:
return tmp_952044;
}
reg_t genfunc_tmp_962138 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_962129;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_959433();
goto next_tmp_962131;
next_tmp_962131:
goto tmp_962130;
tmp_962130:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 3 */
}
goto done_tmp_962137;
fail_tmp_962129:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_962133;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_959433();
goto next_tmp_962135;
next_tmp_962135:
goto tmp_962134;
tmp_962134:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 3 */
}
goto done_tmp_962137;
fail_tmp_962133:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_952082 = genfunc_tmp_959433();
goto next_tmp_962113;
next_tmp_962113:
goto tmp_962112;
tmp_962112:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 4 */
}
done_tmp_962137:
return tmp_952058;
}
void genfunc_tmp_962091 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_961841();
goto next_tmp_961711;
next_tmp_961711:
goto tmp_961710;
tmp_961710:
}
{
tmp_951328 = genfunc_tmp_962088();
goto next_tmp_961844;
next_tmp_961844:
goto tmp_961843;
tmp_961843:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 12 */
}
done_tmp_962090:
}
reg_t genfunc_tmp_962088 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_962016 = tmp_952086;
if ((tmp_962016 >> 8) == 0)
field_imm = tmp_962016;
else goto fail_tmp_962015;
}
/* commit */
{
tmp_952084 = genfunc_tmp_962007();
goto next_tmp_962018;
next_tmp_962018:
goto tmp_962017;
tmp_962017:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 6 */
}
goto done_tmp_962087;
fail_tmp_962015:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_962007();
goto next_tmp_961849;
next_tmp_961849:
goto tmp_961848;
tmp_961848:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 7 */
}
done_tmp_962087:
return tmp_951328;
}
reg_t genfunc_tmp_962057 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_962036 = tmp_952086;
if ((tmp_962036 >> 8) == 0)
field_imm = tmp_962036;
else goto fail_tmp_962035;
}
/* commit */
{
tmp_952084 = genfunc_tmp_962007();
goto next_tmp_962038;
next_tmp_962038:
goto tmp_962037;
tmp_962037:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 6 */
}
goto done_tmp_962056;
fail_tmp_962035:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_962007();
goto next_tmp_962027;
next_tmp_962027:
goto tmp_962026;
tmp_962026:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 7 */
}
done_tmp_962056:
return tmp_952080;
}
reg_t genfunc_tmp_962007 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_961841();
goto next_tmp_961984;
next_tmp_961984:
goto tmp_961983;
tmp_961983:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_962006:
return tmp_952088;
}
reg_t genfunc_tmp_961959 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_961928 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_961928 >> 8) == 0)
field_imm = tmp_961928;
else goto fail_tmp_961927;
}
/* commit */
{
tmp_952040 = genfunc_tmp_961890();
goto next_tmp_961930;
next_tmp_961930:
goto tmp_961929;
tmp_961929:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 6 */
}
goto done_tmp_961958;
fail_tmp_961927:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_961950 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_961950))
field_imm = inv_maskmask(8, tmp_961950);
else goto fail_tmp_961949;
}
/* commit */
{
tmp_951257 = genfunc_tmp_961890();
goto next_tmp_961952;
next_tmp_961952:
goto tmp_961951;
tmp_961951:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 6 */
}
goto done_tmp_961958;
fail_tmp_961949:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_961890();
goto next_tmp_961956;
next_tmp_961956:
goto tmp_961955;
tmp_961955:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 6 */
}
done_tmp_961958:
return tmp_952044;
}
reg_t genfunc_tmp_961890 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_961841();
goto next_tmp_961887;
next_tmp_961887:
goto tmp_961886;
tmp_961886:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_961889:
return tmp_952080;
}
reg_t genfunc_tmp_961841 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_961808 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_961808 >> 8) == 0)
field_imm = tmp_961808;
else goto fail_tmp_961807;
}
/* commit */
{
tmp_952040 = genfunc_tmp_961752();
goto next_tmp_961810;
next_tmp_961810:
goto tmp_961809;
tmp_961809:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_961840;
fail_tmp_961807:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_961832 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_961832))
field_imm = inv_maskmask(8, tmp_961832);
else goto fail_tmp_961831;
}
/* commit */
{
tmp_951257 = genfunc_tmp_961752();
goto next_tmp_961834;
next_tmp_961834:
goto tmp_961833;
tmp_961833:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_961840;
fail_tmp_961831:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_961752();
goto next_tmp_961838;
next_tmp_961838:
goto tmp_961837;
tmp_961837:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_961840:
return tmp_951324;
}
reg_t genfunc_tmp_961805 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_961774 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_961774 >> 8) == 0)
field_imm = tmp_961774;
else goto fail_tmp_961773;
}
/* commit */
{
tmp_952040 = genfunc_tmp_961752();
goto next_tmp_961776;
next_tmp_961776:
goto tmp_961775;
tmp_961775:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_961804;
fail_tmp_961773:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_961796 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_961796))
field_imm = inv_maskmask(8, tmp_961796);
else goto fail_tmp_961795;
}
/* commit */
{
tmp_951257 = genfunc_tmp_961752();
goto next_tmp_961798;
next_tmp_961798:
goto tmp_961797;
tmp_961797:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_961804;
fail_tmp_961795:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_961752();
goto next_tmp_961802;
next_tmp_961802:
goto tmp_961801;
tmp_961801:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_961804:
return tmp_952044;
}
reg_t genfunc_tmp_961752 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_961743;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_959025();
goto next_tmp_961745;
next_tmp_961745:
goto tmp_961744;
tmp_961744:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 2 */
}
goto done_tmp_961751;
fail_tmp_961743:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_961747;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_959025();
goto next_tmp_961749;
next_tmp_961749:
goto tmp_961748;
tmp_961748:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 2 */
}
goto done_tmp_961751;
fail_tmp_961747:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_952082 = genfunc_tmp_959025();
goto next_tmp_961727;
next_tmp_961727:
goto tmp_961726;
tmp_961726:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 3 */
}
done_tmp_961751:
return tmp_952058;
}
void genfunc_tmp_961705 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_961455();
goto next_tmp_961334;
next_tmp_961334:
goto tmp_961333;
tmp_961333:
}
{
tmp_951328 = genfunc_tmp_961702();
goto next_tmp_961458;
next_tmp_961458:
goto tmp_961457;
tmp_961457:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 10 */
}
done_tmp_961704:
}
reg_t genfunc_tmp_961702 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_961630 = tmp_952086;
if ((tmp_961630 >> 8) == 0)
field_imm = tmp_961630;
else goto fail_tmp_961629;
}
/* commit */
{
tmp_952084 = genfunc_tmp_961621();
goto next_tmp_961632;
next_tmp_961632:
goto tmp_961631;
tmp_961631:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_961701;
fail_tmp_961629:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_961621();
goto next_tmp_961463;
next_tmp_961463:
goto tmp_961462;
tmp_961462:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_961701:
return tmp_951328;
}
reg_t genfunc_tmp_961671 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_961650 = tmp_952086;
if ((tmp_961650 >> 8) == 0)
field_imm = tmp_961650;
else goto fail_tmp_961649;
}
/* commit */
{
tmp_952084 = genfunc_tmp_961621();
goto next_tmp_961652;
next_tmp_961652:
goto tmp_961651;
tmp_961651:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_961670;
fail_tmp_961649:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_961621();
goto next_tmp_961641;
next_tmp_961641:
goto tmp_961640;
tmp_961640:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_961670:
return tmp_952080;
}
reg_t genfunc_tmp_961621 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_961455();
goto next_tmp_961598;
next_tmp_961598:
goto tmp_961597;
tmp_961597:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_961620:
return tmp_952088;
}
reg_t genfunc_tmp_961573 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_961542 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_961542 >> 8) == 0)
field_imm = tmp_961542;
else goto fail_tmp_961541;
}
/* commit */
{
tmp_952040 = genfunc_tmp_961504();
goto next_tmp_961544;
next_tmp_961544:
goto tmp_961543;
tmp_961543:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_961572;
fail_tmp_961541:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_961564 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_961564))
field_imm = inv_maskmask(8, tmp_961564);
else goto fail_tmp_961563;
}
/* commit */
{
tmp_951257 = genfunc_tmp_961504();
goto next_tmp_961566;
next_tmp_961566:
goto tmp_961565;
tmp_961565:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_961572;
fail_tmp_961563:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_961504();
goto next_tmp_961570;
next_tmp_961570:
goto tmp_961569;
tmp_961569:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_961572:
return tmp_952044;
}
reg_t genfunc_tmp_961504 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_961455();
goto next_tmp_961501;
next_tmp_961501:
goto tmp_961500;
tmp_961500:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_961503:
return tmp_952080;
}
reg_t genfunc_tmp_961455 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_961422 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_961422 >> 8) == 0)
field_imm = tmp_961422;
else goto fail_tmp_961421;
}
/* commit */
{
tmp_952040 = genfunc_tmp_961366();
goto next_tmp_961424;
next_tmp_961424:
goto tmp_961423;
tmp_961423:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_961454;
fail_tmp_961421:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_961446 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_961446))
field_imm = inv_maskmask(8, tmp_961446);
else goto fail_tmp_961445;
}
/* commit */
{
tmp_951257 = genfunc_tmp_961366();
goto next_tmp_961448;
next_tmp_961448:
goto tmp_961447;
tmp_961447:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_961454;
fail_tmp_961445:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_961366();
goto next_tmp_961452;
next_tmp_961452:
goto tmp_961451;
tmp_961451:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_961454:
return tmp_951324;
}
reg_t genfunc_tmp_961419 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_961388 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_961388 >> 8) == 0)
field_imm = tmp_961388;
else goto fail_tmp_961387;
}
/* commit */
{
tmp_952040 = genfunc_tmp_961366();
goto next_tmp_961390;
next_tmp_961390:
goto tmp_961389;
tmp_961389:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_961418;
fail_tmp_961387:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_961410 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_961410))
field_imm = inv_maskmask(8, tmp_961410);
else goto fail_tmp_961409;
}
/* commit */
{
tmp_951257 = genfunc_tmp_961366();
goto next_tmp_961412;
next_tmp_961412:
goto tmp_961411;
tmp_961411:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_961418;
fail_tmp_961409:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_961366();
goto next_tmp_961416;
next_tmp_961416:
goto tmp_961415;
tmp_961415:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_961418:
return tmp_952044;
}
reg_t genfunc_tmp_961366 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_961363;
field_ra = 31;
/* commit */
tmp_951424 = ref_gpr_reg_for_reading(0 + base);
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 1 */
}
goto done_tmp_961365;
fail_tmp_961363:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_961364;
field_ra = 31;
/* commit */
tmp_951392 = ref_gpr_reg_for_reading(0 + base);
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 1 */
}
goto done_tmp_961365;
fail_tmp_961364:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_952082 = ref_gpr_reg_for_reading(0 + base);
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_961365:
return tmp_952058;
}
void genfunc_tmp_961328 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_961078();
goto next_tmp_960948;
next_tmp_960948:
goto tmp_960947;
tmp_960947:
}
{
tmp_951328 = genfunc_tmp_961325();
goto next_tmp_961081;
next_tmp_961081:
goto tmp_961080;
tmp_961080:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 14 */
}
done_tmp_961327:
}
reg_t genfunc_tmp_961325 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_961253 = tmp_952086;
if ((tmp_961253 >> 8) == 0)
field_imm = tmp_961253;
else goto fail_tmp_961252;
}
/* commit */
{
tmp_952084 = genfunc_tmp_961244();
goto next_tmp_961255;
next_tmp_961255:
goto tmp_961254;
tmp_961254:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 7 */
}
goto done_tmp_961324;
fail_tmp_961252:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_961244();
goto next_tmp_961086;
next_tmp_961086:
goto tmp_961085;
tmp_961085:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 8 */
}
done_tmp_961324:
return tmp_951328;
}
reg_t genfunc_tmp_961294 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_961273 = tmp_952086;
if ((tmp_961273 >> 8) == 0)
field_imm = tmp_961273;
else goto fail_tmp_961272;
}
/* commit */
{
tmp_952084 = genfunc_tmp_961244();
goto next_tmp_961275;
next_tmp_961275:
goto tmp_961274;
tmp_961274:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 7 */
}
goto done_tmp_961293;
fail_tmp_961272:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_961244();
goto next_tmp_961264;
next_tmp_961264:
goto tmp_961263;
tmp_961263:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 8 */
}
done_tmp_961293:
return tmp_952080;
}
reg_t genfunc_tmp_961244 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_961078();
goto next_tmp_961221;
next_tmp_961221:
goto tmp_961220;
tmp_961220:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_961243:
return tmp_952088;
}
reg_t genfunc_tmp_961196 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_961165 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_961165 >> 8) == 0)
field_imm = tmp_961165;
else goto fail_tmp_961164;
}
/* commit */
{
tmp_952040 = genfunc_tmp_961127();
goto next_tmp_961167;
next_tmp_961167:
goto tmp_961166;
tmp_961166:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 7 */
}
goto done_tmp_961195;
fail_tmp_961164:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_961187 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_961187))
field_imm = inv_maskmask(8, tmp_961187);
else goto fail_tmp_961186;
}
/* commit */
{
tmp_951257 = genfunc_tmp_961127();
goto next_tmp_961189;
next_tmp_961189:
goto tmp_961188;
tmp_961188:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 7 */
}
goto done_tmp_961195;
fail_tmp_961186:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_961127();
goto next_tmp_961193;
next_tmp_961193:
goto tmp_961192;
tmp_961192:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 7 */
}
done_tmp_961195:
return tmp_952044;
}
reg_t genfunc_tmp_961127 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_961078();
goto next_tmp_961124;
next_tmp_961124:
goto tmp_961123;
tmp_961123:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_961126:
return tmp_952080;
}
reg_t genfunc_tmp_961078 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_961045 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_961045 >> 8) == 0)
field_imm = tmp_961045;
else goto fail_tmp_961044;
}
/* commit */
{
tmp_952040 = genfunc_tmp_960989();
goto next_tmp_961047;
next_tmp_961047:
goto tmp_961046;
tmp_961046:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_961077;
fail_tmp_961044:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_961069 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_961069))
field_imm = inv_maskmask(8, tmp_961069);
else goto fail_tmp_961068;
}
/* commit */
{
tmp_951257 = genfunc_tmp_960989();
goto next_tmp_961071;
next_tmp_961071:
goto tmp_961070;
tmp_961070:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_961077;
fail_tmp_961068:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_960989();
goto next_tmp_961075;
next_tmp_961075:
goto tmp_961074;
tmp_961074:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_961077:
return tmp_951324;
}
reg_t genfunc_tmp_961042 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_961011 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_961011 >> 8) == 0)
field_imm = tmp_961011;
else goto fail_tmp_961010;
}
/* commit */
{
tmp_952040 = genfunc_tmp_960989();
goto next_tmp_961013;
next_tmp_961013:
goto tmp_961012;
tmp_961012:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_961041;
fail_tmp_961010:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_961033 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_961033))
field_imm = inv_maskmask(8, tmp_961033);
else goto fail_tmp_961032;
}
/* commit */
{
tmp_951257 = genfunc_tmp_960989();
goto next_tmp_961035;
next_tmp_961035:
goto tmp_961034;
tmp_961034:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_961041;
fail_tmp_961032:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_960989();
goto next_tmp_961039;
next_tmp_961039:
goto tmp_961038;
tmp_961038:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_961041:
return tmp_952044;
}
reg_t genfunc_tmp_960989 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_960980;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_955760();
goto next_tmp_960982;
next_tmp_960982:
goto tmp_960981;
tmp_960981:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 3 */
}
goto done_tmp_960988;
fail_tmp_960980:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_960984;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_955760();
goto next_tmp_960986;
next_tmp_960986:
goto tmp_960985;
tmp_960985:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 3 */
}
goto done_tmp_960988;
fail_tmp_960984:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_952082 = genfunc_tmp_955760();
goto next_tmp_960964;
next_tmp_960964:
goto tmp_960963;
tmp_960963:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 4 */
}
done_tmp_960988:
return tmp_952058;
}
void genfunc_tmp_960942 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_960692();
goto next_tmp_960562;
next_tmp_960562:
goto tmp_960561;
tmp_960561:
}
{
tmp_951328 = genfunc_tmp_960939();
goto next_tmp_960695;
next_tmp_960695:
goto tmp_960694;
tmp_960694:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 12 */
}
done_tmp_960941:
}
reg_t genfunc_tmp_960939 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_960867 = tmp_952086;
if ((tmp_960867 >> 8) == 0)
field_imm = tmp_960867;
else goto fail_tmp_960866;
}
/* commit */
{
tmp_952084 = genfunc_tmp_960858();
goto next_tmp_960869;
next_tmp_960869:
goto tmp_960868;
tmp_960868:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 6 */
}
goto done_tmp_960938;
fail_tmp_960866:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_960858();
goto next_tmp_960700;
next_tmp_960700:
goto tmp_960699;
tmp_960699:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 7 */
}
done_tmp_960938:
return tmp_951328;
}
reg_t genfunc_tmp_960908 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_960887 = tmp_952086;
if ((tmp_960887 >> 8) == 0)
field_imm = tmp_960887;
else goto fail_tmp_960886;
}
/* commit */
{
tmp_952084 = genfunc_tmp_960858();
goto next_tmp_960889;
next_tmp_960889:
goto tmp_960888;
tmp_960888:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 6 */
}
goto done_tmp_960907;
fail_tmp_960886:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_960858();
goto next_tmp_960878;
next_tmp_960878:
goto tmp_960877;
tmp_960877:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 7 */
}
done_tmp_960907:
return tmp_952080;
}
reg_t genfunc_tmp_960858 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_960692();
goto next_tmp_960835;
next_tmp_960835:
goto tmp_960834;
tmp_960834:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_960857:
return tmp_952088;
}
reg_t genfunc_tmp_960810 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_960779 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_960779 >> 8) == 0)
field_imm = tmp_960779;
else goto fail_tmp_960778;
}
/* commit */
{
tmp_952040 = genfunc_tmp_960741();
goto next_tmp_960781;
next_tmp_960781:
goto tmp_960780;
tmp_960780:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 6 */
}
goto done_tmp_960809;
fail_tmp_960778:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_960801 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_960801))
field_imm = inv_maskmask(8, tmp_960801);
else goto fail_tmp_960800;
}
/* commit */
{
tmp_951257 = genfunc_tmp_960741();
goto next_tmp_960803;
next_tmp_960803:
goto tmp_960802;
tmp_960802:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 6 */
}
goto done_tmp_960809;
fail_tmp_960800:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_960741();
goto next_tmp_960807;
next_tmp_960807:
goto tmp_960806;
tmp_960806:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 6 */
}
done_tmp_960809:
return tmp_952044;
}
reg_t genfunc_tmp_960741 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_960692();
goto next_tmp_960738;
next_tmp_960738:
goto tmp_960737;
tmp_960737:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_960740:
return tmp_952080;
}
reg_t genfunc_tmp_960692 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_960659 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_960659 >> 8) == 0)
field_imm = tmp_960659;
else goto fail_tmp_960658;
}
/* commit */
{
tmp_952040 = genfunc_tmp_960603();
goto next_tmp_960661;
next_tmp_960661:
goto tmp_960660;
tmp_960660:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_960691;
fail_tmp_960658:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_960683 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_960683))
field_imm = inv_maskmask(8, tmp_960683);
else goto fail_tmp_960682;
}
/* commit */
{
tmp_951257 = genfunc_tmp_960603();
goto next_tmp_960685;
next_tmp_960685:
goto tmp_960684;
tmp_960684:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_960691;
fail_tmp_960682:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_960603();
goto next_tmp_960689;
next_tmp_960689:
goto tmp_960688;
tmp_960688:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_960691:
return tmp_951324;
}
reg_t genfunc_tmp_960656 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_960625 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_960625 >> 8) == 0)
field_imm = tmp_960625;
else goto fail_tmp_960624;
}
/* commit */
{
tmp_952040 = genfunc_tmp_960603();
goto next_tmp_960627;
next_tmp_960627:
goto tmp_960626;
tmp_960626:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_960655;
fail_tmp_960624:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_960647 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_960647))
field_imm = inv_maskmask(8, tmp_960647);
else goto fail_tmp_960646;
}
/* commit */
{
tmp_951257 = genfunc_tmp_960603();
goto next_tmp_960649;
next_tmp_960649:
goto tmp_960648;
tmp_960648:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_960655;
fail_tmp_960646:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_960603();
goto next_tmp_960653;
next_tmp_960653:
goto tmp_960652;
tmp_960652:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_960655:
return tmp_952044;
}
reg_t genfunc_tmp_960603 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_960594;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_955350();
goto next_tmp_960596;
next_tmp_960596:
goto tmp_960595;
tmp_960595:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 2 */
}
goto done_tmp_960602;
fail_tmp_960594:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_960598;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_955350();
goto next_tmp_960600;
next_tmp_960600:
goto tmp_960599;
tmp_960599:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 2 */
}
goto done_tmp_960602;
fail_tmp_960598:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_952082 = genfunc_tmp_955350();
goto next_tmp_960578;
next_tmp_960578:
goto tmp_960577;
tmp_960577:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 3 */
}
done_tmp_960602:
return tmp_952058;
}
void genfunc_tmp_960556 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_960306();
goto next_tmp_960180;
next_tmp_960180:
goto tmp_960179;
tmp_960179:
}
{
tmp_951328 = genfunc_tmp_960553();
goto next_tmp_960309;
next_tmp_960309:
goto tmp_960308;
tmp_960308:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 10 */
}
done_tmp_960555:
}
reg_t genfunc_tmp_960553 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_960481 = tmp_952086;
if ((tmp_960481 >> 8) == 0)
field_imm = tmp_960481;
else goto fail_tmp_960480;
}
/* commit */
{
tmp_952084 = genfunc_tmp_960472();
goto next_tmp_960483;
next_tmp_960483:
goto tmp_960482;
tmp_960482:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_960552;
fail_tmp_960480:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_960472();
goto next_tmp_960314;
next_tmp_960314:
goto tmp_960313;
tmp_960313:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_960552:
return tmp_951328;
}
reg_t genfunc_tmp_960522 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_960501 = tmp_952086;
if ((tmp_960501 >> 8) == 0)
field_imm = tmp_960501;
else goto fail_tmp_960500;
}
/* commit */
{
tmp_952084 = genfunc_tmp_960472();
goto next_tmp_960503;
next_tmp_960503:
goto tmp_960502;
tmp_960502:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_960521;
fail_tmp_960500:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_960472();
goto next_tmp_960492;
next_tmp_960492:
goto tmp_960491;
tmp_960491:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_960521:
return tmp_952080;
}
reg_t genfunc_tmp_960472 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_960306();
goto next_tmp_960449;
next_tmp_960449:
goto tmp_960448;
tmp_960448:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_960471:
return tmp_952088;
}
reg_t genfunc_tmp_960424 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_960393 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_960393 >> 8) == 0)
field_imm = tmp_960393;
else goto fail_tmp_960392;
}
/* commit */
{
tmp_952040 = genfunc_tmp_960355();
goto next_tmp_960395;
next_tmp_960395:
goto tmp_960394;
tmp_960394:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_960423;
fail_tmp_960392:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_960415 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_960415))
field_imm = inv_maskmask(8, tmp_960415);
else goto fail_tmp_960414;
}
/* commit */
{
tmp_951257 = genfunc_tmp_960355();
goto next_tmp_960417;
next_tmp_960417:
goto tmp_960416;
tmp_960416:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_960423;
fail_tmp_960414:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_960355();
goto next_tmp_960421;
next_tmp_960421:
goto tmp_960420;
tmp_960420:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_960423:
return tmp_952044;
}
reg_t genfunc_tmp_960355 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_960306();
goto next_tmp_960352;
next_tmp_960352:
goto tmp_960351;
tmp_960351:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_960354:
return tmp_952080;
}
reg_t genfunc_tmp_960306 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_960273 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_960273 >> 8) == 0)
field_imm = tmp_960273;
else goto fail_tmp_960272;
}
/* commit */
{
tmp_952040 = genfunc_tmp_960217();
goto next_tmp_960275;
next_tmp_960275:
goto tmp_960274;
tmp_960274:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_960305;
fail_tmp_960272:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_960297 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_960297))
field_imm = inv_maskmask(8, tmp_960297);
else goto fail_tmp_960296;
}
/* commit */
{
tmp_951257 = genfunc_tmp_960217();
goto next_tmp_960299;
next_tmp_960299:
goto tmp_960298;
tmp_960298:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_960305;
fail_tmp_960296:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_960217();
goto next_tmp_960303;
next_tmp_960303:
goto tmp_960302;
tmp_960302:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_960305:
return tmp_951324;
}
reg_t genfunc_tmp_960270 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_960239 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_960239 >> 8) == 0)
field_imm = tmp_960239;
else goto fail_tmp_960238;
}
/* commit */
{
tmp_952040 = genfunc_tmp_960217();
goto next_tmp_960241;
next_tmp_960241:
goto tmp_960240;
tmp_960240:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_960269;
fail_tmp_960238:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_960261 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_960261))
field_imm = inv_maskmask(8, tmp_960261);
else goto fail_tmp_960260;
}
/* commit */
{
tmp_951257 = genfunc_tmp_960217();
goto next_tmp_960263;
next_tmp_960263:
goto tmp_960262;
tmp_960262:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_960269;
fail_tmp_960260:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_960217();
goto next_tmp_960267;
next_tmp_960267:
goto tmp_960266;
tmp_960266:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_960269:
return tmp_952044;
}
reg_t genfunc_tmp_960217 (void) {
reg_t tmp_952058;
/* ADDQ_IMM */
{
word_5 tmp_952075;
word_5 field_rc;
word_5 tmp_952076;
word_5 field_ra;
word_64 tmp_952078;
word_8 field_imm;
tmp_952078 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_960202 = tmp_952078;
if ((tmp_960202 >> 8) == 0)
field_imm = tmp_960202;
else goto fail_tmp_960201;
}
/* commit */
tmp_952076 = ref_gpr_reg_for_reading(0 + rm);
tmp_952075 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952075;
field_ra = tmp_952076;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952076);
/* can fail: T   num insns: 1 */
}
goto done_tmp_960216;
fail_tmp_960201:
/* LDA */
{
word_5 tmp_951579;
word_5 field_ra;
word_5 tmp_951580;
word_5 field_rb;
word_64 tmp_951582;
word_16 field_memory_disp;
tmp_951582 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_960210 = tmp_951582;
if ((tmp_960210 >> 16) == 0xFFFFFFFFFFFF || (tmp_960210 >> 16) == 0)
field_memory_disp = (tmp_960210 & 0xFFFF);
else goto fail_tmp_960209;
}
/* commit */
tmp_951580 = ref_gpr_reg_for_reading(0 + rm);
tmp_951579 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951579;
field_rb = tmp_951580;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951580);
/* can fail: T   num insns: 1 */
}
goto done_tmp_960216;
fail_tmp_960209:
/* LDAH */
{
word_5 tmp_951575;
word_5 field_ra;
word_5 tmp_951576;
word_5 field_rb;
word_64 tmp_951578;
word_16 field_memory_disp;
tmp_951578 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_960214 = tmp_951578;
if ((tmp_960214 & 0xFFFF) == 0)
{
word_64 tmp_960215 = (tmp_960214 >> 16);
if ((tmp_960215 >> 16) == 0xFFFFFFFFFFFF || (tmp_960215 >> 16) == 0)
field_memory_disp = (tmp_960215 & 0xFFFF);
else goto fail_tmp_960213;
}
else goto fail_tmp_960213;
}
/* commit */
tmp_951576 = ref_gpr_reg_for_reading(0 + rm);
tmp_951575 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951575;
field_rb = tmp_951576;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951576);
/* can fail: T   num insns: 1 */
}
goto done_tmp_960216;
fail_tmp_960213:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_reading(0 + rm);
tmp_952082 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952082, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_960216:
return tmp_952058;
}
void genfunc_tmp_960174 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_959924();
goto next_tmp_959803;
next_tmp_959803:
goto tmp_959802;
tmp_959802:
}
{
tmp_951328 = genfunc_tmp_960171();
goto next_tmp_959927;
next_tmp_959927:
goto tmp_959926;
tmp_959926:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 10 */
}
done_tmp_960173:
}
reg_t genfunc_tmp_960171 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_960099 = tmp_952086;
if ((tmp_960099 >> 8) == 0)
field_imm = tmp_960099;
else goto fail_tmp_960098;
}
/* commit */
{
tmp_952084 = genfunc_tmp_960090();
goto next_tmp_960101;
next_tmp_960101:
goto tmp_960100;
tmp_960100:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_960170;
fail_tmp_960098:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_960090();
goto next_tmp_959932;
next_tmp_959932:
goto tmp_959931;
tmp_959931:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_960170:
return tmp_951328;
}
reg_t genfunc_tmp_960140 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_960119 = tmp_952086;
if ((tmp_960119 >> 8) == 0)
field_imm = tmp_960119;
else goto fail_tmp_960118;
}
/* commit */
{
tmp_952084 = genfunc_tmp_960090();
goto next_tmp_960121;
next_tmp_960121:
goto tmp_960120;
tmp_960120:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_960139;
fail_tmp_960118:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_960090();
goto next_tmp_960110;
next_tmp_960110:
goto tmp_960109;
tmp_960109:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_960139:
return tmp_952080;
}
reg_t genfunc_tmp_960090 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_959924();
goto next_tmp_960067;
next_tmp_960067:
goto tmp_960066;
tmp_960066:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_960089:
return tmp_952088;
}
reg_t genfunc_tmp_960042 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_960011 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_960011 >> 8) == 0)
field_imm = tmp_960011;
else goto fail_tmp_960010;
}
/* commit */
{
tmp_952040 = genfunc_tmp_959973();
goto next_tmp_960013;
next_tmp_960013:
goto tmp_960012;
tmp_960012:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_960041;
fail_tmp_960010:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_960033 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_960033))
field_imm = inv_maskmask(8, tmp_960033);
else goto fail_tmp_960032;
}
/* commit */
{
tmp_951257 = genfunc_tmp_959973();
goto next_tmp_960035;
next_tmp_960035:
goto tmp_960034;
tmp_960034:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_960041;
fail_tmp_960032:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_959973();
goto next_tmp_960039;
next_tmp_960039:
goto tmp_960038;
tmp_960038:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_960041:
return tmp_952044;
}
reg_t genfunc_tmp_959973 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_959924();
goto next_tmp_959970;
next_tmp_959970:
goto tmp_959969;
tmp_959969:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_959972:
return tmp_952080;
}
reg_t genfunc_tmp_959924 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_959891 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_959891 >> 8) == 0)
field_imm = tmp_959891;
else goto fail_tmp_959890;
}
/* commit */
{
tmp_952040 = genfunc_tmp_959835();
goto next_tmp_959893;
next_tmp_959893:
goto tmp_959892;
tmp_959892:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_959923;
fail_tmp_959890:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_959915 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_959915))
field_imm = inv_maskmask(8, tmp_959915);
else goto fail_tmp_959914;
}
/* commit */
{
tmp_951257 = genfunc_tmp_959835();
goto next_tmp_959917;
next_tmp_959917:
goto tmp_959916;
tmp_959916:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_959923;
fail_tmp_959914:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_959835();
goto next_tmp_959921;
next_tmp_959921:
goto tmp_959920;
tmp_959920:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_959923:
return tmp_951324;
}
reg_t genfunc_tmp_959888 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_959857 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_959857 >> 8) == 0)
field_imm = tmp_959857;
else goto fail_tmp_959856;
}
/* commit */
{
tmp_952040 = genfunc_tmp_959835();
goto next_tmp_959859;
next_tmp_959859:
goto tmp_959858;
tmp_959858:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_959887;
fail_tmp_959856:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_959879 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_959879))
field_imm = inv_maskmask(8, tmp_959879);
else goto fail_tmp_959878;
}
/* commit */
{
tmp_951257 = genfunc_tmp_959835();
goto next_tmp_959881;
next_tmp_959881:
goto tmp_959880;
tmp_959880:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_959887;
fail_tmp_959878:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_959835();
goto next_tmp_959885;
next_tmp_959885:
goto tmp_959884;
tmp_959884:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_959887:
return tmp_952044;
}
reg_t genfunc_tmp_959835 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_959832;
field_ra = 31;
/* commit */
tmp_951424 = ref_gpr_reg_for_reading(0 + 5);
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 1 */
}
goto done_tmp_959834;
fail_tmp_959832:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_959833;
field_ra = 31;
/* commit */
tmp_951392 = ref_gpr_reg_for_reading(0 + 5);
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 1 */
}
goto done_tmp_959834;
fail_tmp_959833:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_952082 = ref_gpr_reg_for_reading(0 + 5);
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_959834:
return tmp_952058;
}
void genfunc_tmp_959797 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_959547();
goto next_tmp_959395;
next_tmp_959395:
goto tmp_959394;
tmp_959394:
}
{
tmp_951328 = genfunc_tmp_959794();
goto next_tmp_959550;
next_tmp_959550:
goto tmp_959549;
tmp_959549:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 14 */
}
done_tmp_959796:
}
reg_t genfunc_tmp_959794 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_959722 = tmp_952086;
if ((tmp_959722 >> 8) == 0)
field_imm = tmp_959722;
else goto fail_tmp_959721;
}
/* commit */
{
tmp_952084 = genfunc_tmp_959713();
goto next_tmp_959724;
next_tmp_959724:
goto tmp_959723;
tmp_959723:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 7 */
}
goto done_tmp_959793;
fail_tmp_959721:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_959713();
goto next_tmp_959555;
next_tmp_959555:
goto tmp_959554;
tmp_959554:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 8 */
}
done_tmp_959793:
return tmp_951328;
}
reg_t genfunc_tmp_959763 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_959742 = tmp_952086;
if ((tmp_959742 >> 8) == 0)
field_imm = tmp_959742;
else goto fail_tmp_959741;
}
/* commit */
{
tmp_952084 = genfunc_tmp_959713();
goto next_tmp_959744;
next_tmp_959744:
goto tmp_959743;
tmp_959743:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 7 */
}
goto done_tmp_959762;
fail_tmp_959741:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_959713();
goto next_tmp_959733;
next_tmp_959733:
goto tmp_959732;
tmp_959732:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 8 */
}
done_tmp_959762:
return tmp_952080;
}
reg_t genfunc_tmp_959713 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_959547();
goto next_tmp_959690;
next_tmp_959690:
goto tmp_959689;
tmp_959689:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_959712:
return tmp_952088;
}
reg_t genfunc_tmp_959665 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_959634 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_959634 >> 8) == 0)
field_imm = tmp_959634;
else goto fail_tmp_959633;
}
/* commit */
{
tmp_952040 = genfunc_tmp_959596();
goto next_tmp_959636;
next_tmp_959636:
goto tmp_959635;
tmp_959635:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 7 */
}
goto done_tmp_959664;
fail_tmp_959633:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_959656 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_959656))
field_imm = inv_maskmask(8, tmp_959656);
else goto fail_tmp_959655;
}
/* commit */
{
tmp_951257 = genfunc_tmp_959596();
goto next_tmp_959658;
next_tmp_959658:
goto tmp_959657;
tmp_959657:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 7 */
}
goto done_tmp_959664;
fail_tmp_959655:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_959596();
goto next_tmp_959662;
next_tmp_959662:
goto tmp_959661;
tmp_959661:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 7 */
}
done_tmp_959664:
return tmp_952044;
}
reg_t genfunc_tmp_959596 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_959547();
goto next_tmp_959593;
next_tmp_959593:
goto tmp_959592;
tmp_959592:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_959595:
return tmp_952080;
}
reg_t genfunc_tmp_959547 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_959514 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_959514 >> 8) == 0)
field_imm = tmp_959514;
else goto fail_tmp_959513;
}
/* commit */
{
tmp_952040 = genfunc_tmp_959458();
goto next_tmp_959516;
next_tmp_959516:
goto tmp_959515;
tmp_959515:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_959546;
fail_tmp_959513:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_959538 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_959538))
field_imm = inv_maskmask(8, tmp_959538);
else goto fail_tmp_959537;
}
/* commit */
{
tmp_951257 = genfunc_tmp_959458();
goto next_tmp_959540;
next_tmp_959540:
goto tmp_959539;
tmp_959539:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_959546;
fail_tmp_959537:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_959458();
goto next_tmp_959544;
next_tmp_959544:
goto tmp_959543;
tmp_959543:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_959546:
return tmp_951324;
}
reg_t genfunc_tmp_959511 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_959480 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_959480 >> 8) == 0)
field_imm = tmp_959480;
else goto fail_tmp_959479;
}
/* commit */
{
tmp_952040 = genfunc_tmp_959458();
goto next_tmp_959482;
next_tmp_959482:
goto tmp_959481;
tmp_959481:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_959510;
fail_tmp_959479:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_959502 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_959502))
field_imm = inv_maskmask(8, tmp_959502);
else goto fail_tmp_959501;
}
/* commit */
{
tmp_951257 = genfunc_tmp_959458();
goto next_tmp_959504;
next_tmp_959504:
goto tmp_959503;
tmp_959503:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_959510;
fail_tmp_959501:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_959458();
goto next_tmp_959508;
next_tmp_959508:
goto tmp_959507;
tmp_959507:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_959510:
return tmp_952044;
}
reg_t genfunc_tmp_959458 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_959449;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_959433();
goto next_tmp_959451;
next_tmp_959451:
goto tmp_959450;
tmp_959450:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 3 */
}
goto done_tmp_959457;
fail_tmp_959449:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_959453;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_959433();
goto next_tmp_959455;
next_tmp_959455:
goto tmp_959454;
tmp_959454:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 3 */
}
goto done_tmp_959457;
fail_tmp_959453:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_952082 = genfunc_tmp_959433();
goto next_tmp_959411;
next_tmp_959411:
goto tmp_959410;
tmp_959410:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 4 */
}
done_tmp_959457:
return tmp_952058;
}
reg_t genfunc_tmp_959433 (void) {
reg_t tmp_952082;
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_reading(0 + 5);
{
tmp_952082 = genfunc_tmp_955743();
goto next_tmp_959416;
next_tmp_959416:
goto tmp_959415;
tmp_959415:
}
tmp_952079 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_959432:
return tmp_952082;
}
void genfunc_tmp_959389 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_959139();
goto next_tmp_958990;
next_tmp_958990:
goto tmp_958989;
tmp_958989:
}
{
tmp_951328 = genfunc_tmp_959386();
goto next_tmp_959142;
next_tmp_959142:
goto tmp_959141;
tmp_959141:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 12 */
}
done_tmp_959388:
}
reg_t genfunc_tmp_959386 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_959314 = tmp_952086;
if ((tmp_959314 >> 8) == 0)
field_imm = tmp_959314;
else goto fail_tmp_959313;
}
/* commit */
{
tmp_952084 = genfunc_tmp_959305();
goto next_tmp_959316;
next_tmp_959316:
goto tmp_959315;
tmp_959315:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 6 */
}
goto done_tmp_959385;
fail_tmp_959313:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_959305();
goto next_tmp_959147;
next_tmp_959147:
goto tmp_959146;
tmp_959146:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 7 */
}
done_tmp_959385:
return tmp_951328;
}
reg_t genfunc_tmp_959355 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_959334 = tmp_952086;
if ((tmp_959334 >> 8) == 0)
field_imm = tmp_959334;
else goto fail_tmp_959333;
}
/* commit */
{
tmp_952084 = genfunc_tmp_959305();
goto next_tmp_959336;
next_tmp_959336:
goto tmp_959335;
tmp_959335:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 6 */
}
goto done_tmp_959354;
fail_tmp_959333:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_959305();
goto next_tmp_959325;
next_tmp_959325:
goto tmp_959324;
tmp_959324:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 7 */
}
done_tmp_959354:
return tmp_952080;
}
reg_t genfunc_tmp_959305 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_959139();
goto next_tmp_959282;
next_tmp_959282:
goto tmp_959281;
tmp_959281:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_959304:
return tmp_952088;
}
reg_t genfunc_tmp_959257 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_959226 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_959226 >> 8) == 0)
field_imm = tmp_959226;
else goto fail_tmp_959225;
}
/* commit */
{
tmp_952040 = genfunc_tmp_959188();
goto next_tmp_959228;
next_tmp_959228:
goto tmp_959227;
tmp_959227:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 6 */
}
goto done_tmp_959256;
fail_tmp_959225:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_959248 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_959248))
field_imm = inv_maskmask(8, tmp_959248);
else goto fail_tmp_959247;
}
/* commit */
{
tmp_951257 = genfunc_tmp_959188();
goto next_tmp_959250;
next_tmp_959250:
goto tmp_959249;
tmp_959249:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 6 */
}
goto done_tmp_959256;
fail_tmp_959247:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_959188();
goto next_tmp_959254;
next_tmp_959254:
goto tmp_959253;
tmp_959253:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 6 */
}
done_tmp_959256:
return tmp_952044;
}
reg_t genfunc_tmp_959188 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_959139();
goto next_tmp_959185;
next_tmp_959185:
goto tmp_959184;
tmp_959184:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_959187:
return tmp_952080;
}
reg_t genfunc_tmp_959139 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_959106 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_959106 >> 8) == 0)
field_imm = tmp_959106;
else goto fail_tmp_959105;
}
/* commit */
{
tmp_952040 = genfunc_tmp_959050();
goto next_tmp_959108;
next_tmp_959108:
goto tmp_959107;
tmp_959107:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_959138;
fail_tmp_959105:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_959130 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_959130))
field_imm = inv_maskmask(8, tmp_959130);
else goto fail_tmp_959129;
}
/* commit */
{
tmp_951257 = genfunc_tmp_959050();
goto next_tmp_959132;
next_tmp_959132:
goto tmp_959131;
tmp_959131:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_959138;
fail_tmp_959129:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_959050();
goto next_tmp_959136;
next_tmp_959136:
goto tmp_959135;
tmp_959135:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_959138:
return tmp_951324;
}
reg_t genfunc_tmp_959103 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_959072 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_959072 >> 8) == 0)
field_imm = tmp_959072;
else goto fail_tmp_959071;
}
/* commit */
{
tmp_952040 = genfunc_tmp_959050();
goto next_tmp_959074;
next_tmp_959074:
goto tmp_959073;
tmp_959073:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_959102;
fail_tmp_959071:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_959094 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_959094))
field_imm = inv_maskmask(8, tmp_959094);
else goto fail_tmp_959093;
}
/* commit */
{
tmp_951257 = genfunc_tmp_959050();
goto next_tmp_959096;
next_tmp_959096:
goto tmp_959095;
tmp_959095:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_959102;
fail_tmp_959093:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_959050();
goto next_tmp_959100;
next_tmp_959100:
goto tmp_959099;
tmp_959099:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_959102:
return tmp_952044;
}
reg_t genfunc_tmp_959050 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_959041;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_959025();
goto next_tmp_959043;
next_tmp_959043:
goto tmp_959042;
tmp_959042:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 2 */
}
goto done_tmp_959049;
fail_tmp_959041:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_959045;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_959025();
goto next_tmp_959047;
next_tmp_959047:
goto tmp_959046;
tmp_959046:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 2 */
}
goto done_tmp_959049;
fail_tmp_959045:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_952082 = genfunc_tmp_959025();
goto next_tmp_959006;
next_tmp_959006:
goto tmp_959005;
tmp_959005:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 3 */
}
done_tmp_959049:
return tmp_952058;
}
reg_t genfunc_tmp_959025 (void) {
reg_t tmp_952082;
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_reading(0 + 5);
tmp_952082 = ref_gpr_reg_for_reading(0 + index);
tmp_952079 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 1 */
}
done_tmp_959024:
return tmp_952082;
}
void genfunc_tmp_958984 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_958734();
goto next_tmp_958613;
next_tmp_958613:
goto tmp_958612;
tmp_958612:
}
{
tmp_951328 = genfunc_tmp_958981();
goto next_tmp_958737;
next_tmp_958737:
goto tmp_958736;
tmp_958736:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 10 */
}
done_tmp_958983:
}
reg_t genfunc_tmp_958981 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_958909 = tmp_952086;
if ((tmp_958909 >> 8) == 0)
field_imm = tmp_958909;
else goto fail_tmp_958908;
}
/* commit */
{
tmp_952084 = genfunc_tmp_958900();
goto next_tmp_958911;
next_tmp_958911:
goto tmp_958910;
tmp_958910:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_958980;
fail_tmp_958908:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_958900();
goto next_tmp_958742;
next_tmp_958742:
goto tmp_958741;
tmp_958741:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_958980:
return tmp_951328;
}
reg_t genfunc_tmp_958950 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_958929 = tmp_952086;
if ((tmp_958929 >> 8) == 0)
field_imm = tmp_958929;
else goto fail_tmp_958928;
}
/* commit */
{
tmp_952084 = genfunc_tmp_958900();
goto next_tmp_958931;
next_tmp_958931:
goto tmp_958930;
tmp_958930:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_958949;
fail_tmp_958928:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_958900();
goto next_tmp_958920;
next_tmp_958920:
goto tmp_958919;
tmp_958919:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_958949:
return tmp_952080;
}
reg_t genfunc_tmp_958900 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_958734();
goto next_tmp_958877;
next_tmp_958877:
goto tmp_958876;
tmp_958876:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_958899:
return tmp_952088;
}
reg_t genfunc_tmp_958852 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_958821 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_958821 >> 8) == 0)
field_imm = tmp_958821;
else goto fail_tmp_958820;
}
/* commit */
{
tmp_952040 = genfunc_tmp_958783();
goto next_tmp_958823;
next_tmp_958823:
goto tmp_958822;
tmp_958822:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_958851;
fail_tmp_958820:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_958843 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_958843))
field_imm = inv_maskmask(8, tmp_958843);
else goto fail_tmp_958842;
}
/* commit */
{
tmp_951257 = genfunc_tmp_958783();
goto next_tmp_958845;
next_tmp_958845:
goto tmp_958844;
tmp_958844:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_958851;
fail_tmp_958842:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_958783();
goto next_tmp_958849;
next_tmp_958849:
goto tmp_958848;
tmp_958848:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_958851:
return tmp_952044;
}
reg_t genfunc_tmp_958783 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_958734();
goto next_tmp_958780;
next_tmp_958780:
goto tmp_958779;
tmp_958779:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_958782:
return tmp_952080;
}
reg_t genfunc_tmp_958734 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_958701 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_958701 >> 8) == 0)
field_imm = tmp_958701;
else goto fail_tmp_958700;
}
/* commit */
{
tmp_952040 = genfunc_tmp_958645();
goto next_tmp_958703;
next_tmp_958703:
goto tmp_958702;
tmp_958702:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_958733;
fail_tmp_958700:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_958725 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_958725))
field_imm = inv_maskmask(8, tmp_958725);
else goto fail_tmp_958724;
}
/* commit */
{
tmp_951257 = genfunc_tmp_958645();
goto next_tmp_958727;
next_tmp_958727:
goto tmp_958726;
tmp_958726:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_958733;
fail_tmp_958724:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_958645();
goto next_tmp_958731;
next_tmp_958731:
goto tmp_958730;
tmp_958730:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_958733:
return tmp_951324;
}
reg_t genfunc_tmp_958698 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_958667 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_958667 >> 8) == 0)
field_imm = tmp_958667;
else goto fail_tmp_958666;
}
/* commit */
{
tmp_952040 = genfunc_tmp_958645();
goto next_tmp_958669;
next_tmp_958669:
goto tmp_958668;
tmp_958668:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_958697;
fail_tmp_958666:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_958689 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_958689))
field_imm = inv_maskmask(8, tmp_958689);
else goto fail_tmp_958688;
}
/* commit */
{
tmp_951257 = genfunc_tmp_958645();
goto next_tmp_958691;
next_tmp_958691:
goto tmp_958690;
tmp_958690:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_958697;
fail_tmp_958688:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_958645();
goto next_tmp_958695;
next_tmp_958695:
goto tmp_958694;
tmp_958694:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_958697:
return tmp_952044;
}
reg_t genfunc_tmp_958645 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_958642;
field_ra = 31;
/* commit */
tmp_951424 = ref_gpr_reg_for_reading(0 + base);
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 1 */
}
goto done_tmp_958644;
fail_tmp_958642:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_958643;
field_ra = 31;
/* commit */
tmp_951392 = ref_gpr_reg_for_reading(0 + base);
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 1 */
}
goto done_tmp_958644;
fail_tmp_958643:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_952082 = ref_gpr_reg_for_reading(0 + base);
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_958644:
return tmp_952058;
}
void genfunc_tmp_958607 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_958357();
goto next_tmp_958227;
next_tmp_958227:
goto tmp_958226;
tmp_958226:
}
{
tmp_951328 = genfunc_tmp_958604();
goto next_tmp_958360;
next_tmp_958360:
goto tmp_958359;
tmp_958359:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 14 */
}
done_tmp_958606:
}
reg_t genfunc_tmp_958604 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_958532 = tmp_952086;
if ((tmp_958532 >> 8) == 0)
field_imm = tmp_958532;
else goto fail_tmp_958531;
}
/* commit */
{
tmp_952084 = genfunc_tmp_958523();
goto next_tmp_958534;
next_tmp_958534:
goto tmp_958533;
tmp_958533:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 7 */
}
goto done_tmp_958603;
fail_tmp_958531:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_958523();
goto next_tmp_958365;
next_tmp_958365:
goto tmp_958364;
tmp_958364:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 8 */
}
done_tmp_958603:
return tmp_951328;
}
reg_t genfunc_tmp_958573 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_958552 = tmp_952086;
if ((tmp_958552 >> 8) == 0)
field_imm = tmp_958552;
else goto fail_tmp_958551;
}
/* commit */
{
tmp_952084 = genfunc_tmp_958523();
goto next_tmp_958554;
next_tmp_958554:
goto tmp_958553;
tmp_958553:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 7 */
}
goto done_tmp_958572;
fail_tmp_958551:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_958523();
goto next_tmp_958543;
next_tmp_958543:
goto tmp_958542;
tmp_958542:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 8 */
}
done_tmp_958572:
return tmp_952080;
}
reg_t genfunc_tmp_958523 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_958357();
goto next_tmp_958500;
next_tmp_958500:
goto tmp_958499;
tmp_958499:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_958522:
return tmp_952088;
}
reg_t genfunc_tmp_958475 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_958444 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_958444 >> 8) == 0)
field_imm = tmp_958444;
else goto fail_tmp_958443;
}
/* commit */
{
tmp_952040 = genfunc_tmp_958406();
goto next_tmp_958446;
next_tmp_958446:
goto tmp_958445;
tmp_958445:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 7 */
}
goto done_tmp_958474;
fail_tmp_958443:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_958466 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_958466))
field_imm = inv_maskmask(8, tmp_958466);
else goto fail_tmp_958465;
}
/* commit */
{
tmp_951257 = genfunc_tmp_958406();
goto next_tmp_958468;
next_tmp_958468:
goto tmp_958467;
tmp_958467:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 7 */
}
goto done_tmp_958474;
fail_tmp_958465:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_958406();
goto next_tmp_958472;
next_tmp_958472:
goto tmp_958471;
tmp_958471:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 7 */
}
done_tmp_958474:
return tmp_952044;
}
reg_t genfunc_tmp_958406 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_958357();
goto next_tmp_958403;
next_tmp_958403:
goto tmp_958402;
tmp_958402:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 6 */
}
done_tmp_958405:
return tmp_952080;
}
reg_t genfunc_tmp_958357 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_958324 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_958324 >> 8) == 0)
field_imm = tmp_958324;
else goto fail_tmp_958323;
}
/* commit */
{
tmp_952040 = genfunc_tmp_958268();
goto next_tmp_958326;
next_tmp_958326:
goto tmp_958325;
tmp_958325:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_958356;
fail_tmp_958323:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_958348 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_958348))
field_imm = inv_maskmask(8, tmp_958348);
else goto fail_tmp_958347;
}
/* commit */
{
tmp_951257 = genfunc_tmp_958268();
goto next_tmp_958350;
next_tmp_958350:
goto tmp_958349;
tmp_958349:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_958356;
fail_tmp_958347:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_958268();
goto next_tmp_958354;
next_tmp_958354:
goto tmp_958353;
tmp_958353:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_958356:
return tmp_951324;
}
reg_t genfunc_tmp_958321 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_958290 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_958290 >> 8) == 0)
field_imm = tmp_958290;
else goto fail_tmp_958289;
}
/* commit */
{
tmp_952040 = genfunc_tmp_958268();
goto next_tmp_958292;
next_tmp_958292:
goto tmp_958291;
tmp_958291:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_958320;
fail_tmp_958289:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_958312 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_958312))
field_imm = inv_maskmask(8, tmp_958312);
else goto fail_tmp_958311;
}
/* commit */
{
tmp_951257 = genfunc_tmp_958268();
goto next_tmp_958314;
next_tmp_958314:
goto tmp_958313;
tmp_958313:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_958320;
fail_tmp_958311:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_958268();
goto next_tmp_958318;
next_tmp_958318:
goto tmp_958317;
tmp_958317:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_958320:
return tmp_952044;
}
reg_t genfunc_tmp_958268 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_958259;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_955760();
goto next_tmp_958261;
next_tmp_958261:
goto tmp_958260;
tmp_958260:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 3 */
}
goto done_tmp_958267;
fail_tmp_958259:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_958263;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_955760();
goto next_tmp_958265;
next_tmp_958265:
goto tmp_958264;
tmp_958264:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 3 */
}
goto done_tmp_958267;
fail_tmp_958263:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_952082 = genfunc_tmp_955760();
goto next_tmp_958243;
next_tmp_958243:
goto tmp_958242;
tmp_958242:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 4 */
}
done_tmp_958267:
return tmp_952058;
}
void genfunc_tmp_958221 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_957971();
goto next_tmp_957841;
next_tmp_957841:
goto tmp_957840;
tmp_957840:
}
{
tmp_951328 = genfunc_tmp_958218();
goto next_tmp_957974;
next_tmp_957974:
goto tmp_957973;
tmp_957973:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 12 */
}
done_tmp_958220:
}
reg_t genfunc_tmp_958218 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_958146 = tmp_952086;
if ((tmp_958146 >> 8) == 0)
field_imm = tmp_958146;
else goto fail_tmp_958145;
}
/* commit */
{
tmp_952084 = genfunc_tmp_958137();
goto next_tmp_958148;
next_tmp_958148:
goto tmp_958147;
tmp_958147:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 6 */
}
goto done_tmp_958217;
fail_tmp_958145:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_958137();
goto next_tmp_957979;
next_tmp_957979:
goto tmp_957978;
tmp_957978:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 7 */
}
done_tmp_958217:
return tmp_951328;
}
reg_t genfunc_tmp_958187 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_958166 = tmp_952086;
if ((tmp_958166 >> 8) == 0)
field_imm = tmp_958166;
else goto fail_tmp_958165;
}
/* commit */
{
tmp_952084 = genfunc_tmp_958137();
goto next_tmp_958168;
next_tmp_958168:
goto tmp_958167;
tmp_958167:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 6 */
}
goto done_tmp_958186;
fail_tmp_958165:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_958137();
goto next_tmp_958157;
next_tmp_958157:
goto tmp_958156;
tmp_958156:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 7 */
}
done_tmp_958186:
return tmp_952080;
}
reg_t genfunc_tmp_958137 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_957971();
goto next_tmp_958114;
next_tmp_958114:
goto tmp_958113;
tmp_958113:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_958136:
return tmp_952088;
}
reg_t genfunc_tmp_958089 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_958058 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_958058 >> 8) == 0)
field_imm = tmp_958058;
else goto fail_tmp_958057;
}
/* commit */
{
tmp_952040 = genfunc_tmp_958020();
goto next_tmp_958060;
next_tmp_958060:
goto tmp_958059;
tmp_958059:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 6 */
}
goto done_tmp_958088;
fail_tmp_958057:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_958080 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_958080))
field_imm = inv_maskmask(8, tmp_958080);
else goto fail_tmp_958079;
}
/* commit */
{
tmp_951257 = genfunc_tmp_958020();
goto next_tmp_958082;
next_tmp_958082:
goto tmp_958081;
tmp_958081:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 6 */
}
goto done_tmp_958088;
fail_tmp_958079:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_958020();
goto next_tmp_958086;
next_tmp_958086:
goto tmp_958085;
tmp_958085:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 6 */
}
done_tmp_958088:
return tmp_952044;
}
reg_t genfunc_tmp_958020 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_957971();
goto next_tmp_958017;
next_tmp_958017:
goto tmp_958016;
tmp_958016:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_958019:
return tmp_952080;
}
reg_t genfunc_tmp_957971 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_957938 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_957938 >> 8) == 0)
field_imm = tmp_957938;
else goto fail_tmp_957937;
}
/* commit */
{
tmp_952040 = genfunc_tmp_957882();
goto next_tmp_957940;
next_tmp_957940:
goto tmp_957939;
tmp_957939:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_957970;
fail_tmp_957937:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_957962 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_957962))
field_imm = inv_maskmask(8, tmp_957962);
else goto fail_tmp_957961;
}
/* commit */
{
tmp_951257 = genfunc_tmp_957882();
goto next_tmp_957964;
next_tmp_957964:
goto tmp_957963;
tmp_957963:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_957970;
fail_tmp_957961:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_957882();
goto next_tmp_957968;
next_tmp_957968:
goto tmp_957967;
tmp_957967:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_957970:
return tmp_951324;
}
reg_t genfunc_tmp_957935 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_957904 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_957904 >> 8) == 0)
field_imm = tmp_957904;
else goto fail_tmp_957903;
}
/* commit */
{
tmp_952040 = genfunc_tmp_957882();
goto next_tmp_957906;
next_tmp_957906:
goto tmp_957905;
tmp_957905:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_957934;
fail_tmp_957903:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_957926 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_957926))
field_imm = inv_maskmask(8, tmp_957926);
else goto fail_tmp_957925;
}
/* commit */
{
tmp_951257 = genfunc_tmp_957882();
goto next_tmp_957928;
next_tmp_957928:
goto tmp_957927;
tmp_957927:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_957934;
fail_tmp_957925:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_957882();
goto next_tmp_957932;
next_tmp_957932:
goto tmp_957931;
tmp_957931:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_957934:
return tmp_952044;
}
reg_t genfunc_tmp_957882 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_957873;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_955350();
goto next_tmp_957875;
next_tmp_957875:
goto tmp_957874;
tmp_957874:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 2 */
}
goto done_tmp_957881;
fail_tmp_957873:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_957877;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_955350();
goto next_tmp_957879;
next_tmp_957879:
goto tmp_957878;
tmp_957878:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 2 */
}
goto done_tmp_957881;
fail_tmp_957877:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_952082 = genfunc_tmp_955350();
goto next_tmp_957857;
next_tmp_957857:
goto tmp_957856;
tmp_957856:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 3 */
}
done_tmp_957881:
return tmp_952058;
}
void genfunc_tmp_957835 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_957585();
goto next_tmp_957459;
next_tmp_957459:
goto tmp_957458;
tmp_957458:
}
{
tmp_951328 = genfunc_tmp_957832();
goto next_tmp_957588;
next_tmp_957588:
goto tmp_957587;
tmp_957587:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 10 */
}
done_tmp_957834:
}
reg_t genfunc_tmp_957832 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_957760 = tmp_952086;
if ((tmp_957760 >> 8) == 0)
field_imm = tmp_957760;
else goto fail_tmp_957759;
}
/* commit */
{
tmp_952084 = genfunc_tmp_957751();
goto next_tmp_957762;
next_tmp_957762:
goto tmp_957761;
tmp_957761:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_957831;
fail_tmp_957759:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_957751();
goto next_tmp_957593;
next_tmp_957593:
goto tmp_957592;
tmp_957592:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_957831:
return tmp_951328;
}
reg_t genfunc_tmp_957801 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_957780 = tmp_952086;
if ((tmp_957780 >> 8) == 0)
field_imm = tmp_957780;
else goto fail_tmp_957779;
}
/* commit */
{
tmp_952084 = genfunc_tmp_957751();
goto next_tmp_957782;
next_tmp_957782:
goto tmp_957781;
tmp_957781:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_957800;
fail_tmp_957779:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_957751();
goto next_tmp_957771;
next_tmp_957771:
goto tmp_957770;
tmp_957770:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_957800:
return tmp_952080;
}
reg_t genfunc_tmp_957751 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_957585();
goto next_tmp_957728;
next_tmp_957728:
goto tmp_957727;
tmp_957727:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_957750:
return tmp_952088;
}
reg_t genfunc_tmp_957703 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_957672 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_957672 >> 8) == 0)
field_imm = tmp_957672;
else goto fail_tmp_957671;
}
/* commit */
{
tmp_952040 = genfunc_tmp_957634();
goto next_tmp_957674;
next_tmp_957674:
goto tmp_957673;
tmp_957673:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_957702;
fail_tmp_957671:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_957694 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_957694))
field_imm = inv_maskmask(8, tmp_957694);
else goto fail_tmp_957693;
}
/* commit */
{
tmp_951257 = genfunc_tmp_957634();
goto next_tmp_957696;
next_tmp_957696:
goto tmp_957695;
tmp_957695:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_957702;
fail_tmp_957693:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_957634();
goto next_tmp_957700;
next_tmp_957700:
goto tmp_957699;
tmp_957699:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_957702:
return tmp_952044;
}
reg_t genfunc_tmp_957634 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_957585();
goto next_tmp_957631;
next_tmp_957631:
goto tmp_957630;
tmp_957630:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_957633:
return tmp_952080;
}
reg_t genfunc_tmp_957585 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_957552 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_957552 >> 8) == 0)
field_imm = tmp_957552;
else goto fail_tmp_957551;
}
/* commit */
{
tmp_952040 = genfunc_tmp_957496();
goto next_tmp_957554;
next_tmp_957554:
goto tmp_957553;
tmp_957553:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_957584;
fail_tmp_957551:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_957576 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_957576))
field_imm = inv_maskmask(8, tmp_957576);
else goto fail_tmp_957575;
}
/* commit */
{
tmp_951257 = genfunc_tmp_957496();
goto next_tmp_957578;
next_tmp_957578:
goto tmp_957577;
tmp_957577:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_957584;
fail_tmp_957575:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_957496();
goto next_tmp_957582;
next_tmp_957582:
goto tmp_957581;
tmp_957581:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_957584:
return tmp_951324;
}
reg_t genfunc_tmp_957549 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_957518 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_957518 >> 8) == 0)
field_imm = tmp_957518;
else goto fail_tmp_957517;
}
/* commit */
{
tmp_952040 = genfunc_tmp_957496();
goto next_tmp_957520;
next_tmp_957520:
goto tmp_957519;
tmp_957519:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_957548;
fail_tmp_957517:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_957540 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_957540))
field_imm = inv_maskmask(8, tmp_957540);
else goto fail_tmp_957539;
}
/* commit */
{
tmp_951257 = genfunc_tmp_957496();
goto next_tmp_957542;
next_tmp_957542:
goto tmp_957541;
tmp_957541:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_957548;
fail_tmp_957539:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_957496();
goto next_tmp_957546;
next_tmp_957546:
goto tmp_957545;
tmp_957545:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_957548:
return tmp_952044;
}
reg_t genfunc_tmp_957496 (void) {
reg_t tmp_952058;
/* ADDQ_IMM */
{
word_5 tmp_952075;
word_5 field_rc;
word_5 tmp_952076;
word_5 field_ra;
word_64 tmp_952078;
word_8 field_imm;
tmp_952078 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_957481 = tmp_952078;
if ((tmp_957481 >> 8) == 0)
field_imm = tmp_957481;
else goto fail_tmp_957480;
}
/* commit */
tmp_952076 = ref_gpr_reg_for_reading(0 + rm);
tmp_952075 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952075;
field_ra = tmp_952076;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952076);
/* can fail: T   num insns: 1 */
}
goto done_tmp_957495;
fail_tmp_957480:
/* LDA */
{
word_5 tmp_951579;
word_5 field_ra;
word_5 tmp_951580;
word_5 field_rb;
word_64 tmp_951582;
word_16 field_memory_disp;
tmp_951582 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_957489 = tmp_951582;
if ((tmp_957489 >> 16) == 0xFFFFFFFFFFFF || (tmp_957489 >> 16) == 0)
field_memory_disp = (tmp_957489 & 0xFFFF);
else goto fail_tmp_957488;
}
/* commit */
tmp_951580 = ref_gpr_reg_for_reading(0 + rm);
tmp_951579 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951579;
field_rb = tmp_951580;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951580);
/* can fail: T   num insns: 1 */
}
goto done_tmp_957495;
fail_tmp_957488:
/* LDAH */
{
word_5 tmp_951575;
word_5 field_ra;
word_5 tmp_951576;
word_5 field_rb;
word_64 tmp_951578;
word_16 field_memory_disp;
tmp_951578 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_957493 = tmp_951578;
if ((tmp_957493 & 0xFFFF) == 0)
{
word_64 tmp_957494 = (tmp_957493 >> 16);
if ((tmp_957494 >> 16) == 0xFFFFFFFFFFFF || (tmp_957494 >> 16) == 0)
field_memory_disp = (tmp_957494 & 0xFFFF);
else goto fail_tmp_957492;
}
else goto fail_tmp_957492;
}
/* commit */
tmp_951576 = ref_gpr_reg_for_reading(0 + rm);
tmp_951575 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951575;
field_rb = tmp_951576;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951576);
/* can fail: T   num insns: 1 */
}
goto done_tmp_957495;
fail_tmp_957492:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_reading(0 + rm);
tmp_952082 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952082, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_957495:
return tmp_952058;
}
void genfunc_tmp_957450 (void) {
/* STL */
{
word_5 field_rb;
word_64 tmp_951325;
word_16 field_memory_disp;
word_5 tmp_951327;
word_5 field_ra;
tmp_951325 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_957445 = tmp_951325;
if ((tmp_957445 >> 16) == 0xFFFFFFFFFFFF || (tmp_957445 >> 16) == 0)
field_memory_disp = (tmp_957445 & 0xFFFF);
else goto fail_tmp_957444;
}
/* commit */
{
tmp_951327 = genfunc_tmp_957442();
goto next_tmp_957447;
next_tmp_957447:
goto tmp_957446;
tmp_957446:
}
field_ra = tmp_951327;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951327);
/* can fail: T   num insns: 5 */
}
goto done_tmp_957449;
fail_tmp_957444:
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
tmp_951324 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_951324, ((word_64)disp32));
{
tmp_951328 = genfunc_tmp_957442();
goto next_tmp_957200;
next_tmp_957200:
goto tmp_957199;
tmp_957199:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 6 */
}
done_tmp_957449:
}
reg_t genfunc_tmp_957442 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_957370 = tmp_952086;
if ((tmp_957370 >> 8) == 0)
field_imm = tmp_957370;
else goto fail_tmp_957369;
}
/* commit */
{
tmp_952084 = genfunc_tmp_957361();
goto next_tmp_957372;
next_tmp_957372:
goto tmp_957371;
tmp_957371:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 3 */
}
goto done_tmp_957441;
fail_tmp_957369:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_957361();
goto next_tmp_957205;
next_tmp_957205:
goto tmp_957204;
tmp_957204:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 4 */
}
done_tmp_957441:
return tmp_951328;
}
reg_t genfunc_tmp_957411 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_957390 = tmp_952086;
if ((tmp_957390 >> 8) == 0)
field_imm = tmp_957390;
else goto fail_tmp_957389;
}
/* commit */
{
tmp_952084 = genfunc_tmp_957361();
goto next_tmp_957392;
next_tmp_957392:
goto tmp_957391;
tmp_957391:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 3 */
}
goto done_tmp_957410;
fail_tmp_957389:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_957361();
goto next_tmp_957381;
next_tmp_957381:
goto tmp_957380;
tmp_957380:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 4 */
}
done_tmp_957410:
return tmp_952080;
}
reg_t genfunc_tmp_957361 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_951565;
word_16 field_memory_disp;
tmp_951565 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_957339 = tmp_951565;
if ((tmp_957339 >> 16) == 0xFFFFFFFFFFFF || (tmp_957339 >> 16) == 0)
field_memory_disp = (tmp_957339 & 0xFFFF);
else goto fail_tmp_957338;
}
/* commit */
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_957360;
fail_tmp_957338:
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
tmp_951564 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_951564, ((word_64)disp32));
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 2 */
}
done_tmp_957360:
return tmp_952088;
}
reg_t genfunc_tmp_957314 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_957283 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_957283 >> 8) == 0)
field_imm = tmp_957283;
else goto fail_tmp_957282;
}
/* commit */
{
tmp_952040 = genfunc_tmp_957245();
goto next_tmp_957285;
next_tmp_957285:
goto tmp_957284;
tmp_957284:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_957313;
fail_tmp_957282:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_957305 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_957305))
field_imm = inv_maskmask(8, tmp_957305);
else goto fail_tmp_957304;
}
/* commit */
{
tmp_951257 = genfunc_tmp_957245();
goto next_tmp_957307;
next_tmp_957307:
goto tmp_957306;
tmp_957306:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_957313;
fail_tmp_957304:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_957245();
goto next_tmp_957311;
next_tmp_957311:
goto tmp_957310;
tmp_957310:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_957313:
return tmp_952044;
}
reg_t genfunc_tmp_957245 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_951565;
word_16 field_memory_disp;
tmp_951565 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_957243 = tmp_951565;
if ((tmp_957243 >> 16) == 0xFFFFFFFFFFFF || (tmp_957243 >> 16) == 0)
field_memory_disp = (tmp_957243 & 0xFFFF);
else goto fail_tmp_957242;
}
/* commit */
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_957244;
fail_tmp_957242:
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
tmp_951564 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_951564, ((word_64)disp32));
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 2 */
}
done_tmp_957244:
return tmp_952080;
}
void genfunc_tmp_957194 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_956944();
goto next_tmp_956814;
next_tmp_956814:
goto tmp_956813;
tmp_956813:
}
{
tmp_951328 = genfunc_tmp_957191();
goto next_tmp_956947;
next_tmp_956947:
goto tmp_956946;
tmp_956946:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 12 */
}
done_tmp_957193:
}
reg_t genfunc_tmp_957191 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_957119 = tmp_952086;
if ((tmp_957119 >> 8) == 0)
field_imm = tmp_957119;
else goto fail_tmp_957118;
}
/* commit */
{
tmp_952084 = genfunc_tmp_957110();
goto next_tmp_957121;
next_tmp_957121:
goto tmp_957120;
tmp_957120:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 6 */
}
goto done_tmp_957190;
fail_tmp_957118:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_957110();
goto next_tmp_956952;
next_tmp_956952:
goto tmp_956951;
tmp_956951:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 7 */
}
done_tmp_957190:
return tmp_951328;
}
reg_t genfunc_tmp_957160 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_957139 = tmp_952086;
if ((tmp_957139 >> 8) == 0)
field_imm = tmp_957139;
else goto fail_tmp_957138;
}
/* commit */
{
tmp_952084 = genfunc_tmp_957110();
goto next_tmp_957141;
next_tmp_957141:
goto tmp_957140;
tmp_957140:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 6 */
}
goto done_tmp_957159;
fail_tmp_957138:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_957110();
goto next_tmp_957130;
next_tmp_957130:
goto tmp_957129;
tmp_957129:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 7 */
}
done_tmp_957159:
return tmp_952080;
}
reg_t genfunc_tmp_957110 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_956944();
goto next_tmp_957087;
next_tmp_957087:
goto tmp_957086;
tmp_957086:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_957109:
return tmp_952088;
}
reg_t genfunc_tmp_957062 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_957031 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_957031 >> 8) == 0)
field_imm = tmp_957031;
else goto fail_tmp_957030;
}
/* commit */
{
tmp_952040 = genfunc_tmp_956993();
goto next_tmp_957033;
next_tmp_957033:
goto tmp_957032;
tmp_957032:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 6 */
}
goto done_tmp_957061;
fail_tmp_957030:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_957053 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_957053))
field_imm = inv_maskmask(8, tmp_957053);
else goto fail_tmp_957052;
}
/* commit */
{
tmp_951257 = genfunc_tmp_956993();
goto next_tmp_957055;
next_tmp_957055:
goto tmp_957054;
tmp_957054:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 6 */
}
goto done_tmp_957061;
fail_tmp_957052:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_956993();
goto next_tmp_957059;
next_tmp_957059:
goto tmp_957058;
tmp_957058:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 6 */
}
done_tmp_957061:
return tmp_952044;
}
reg_t genfunc_tmp_956993 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_956944();
goto next_tmp_956990;
next_tmp_956990:
goto tmp_956989;
tmp_956989:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 5 */
}
done_tmp_956992:
return tmp_952080;
}
reg_t genfunc_tmp_956944 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_956911 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_956911 >> 8) == 0)
field_imm = tmp_956911;
else goto fail_tmp_956910;
}
/* commit */
{
tmp_952040 = genfunc_tmp_956855();
goto next_tmp_956913;
next_tmp_956913:
goto tmp_956912;
tmp_956912:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_956943;
fail_tmp_956910:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_956935 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_956935))
field_imm = inv_maskmask(8, tmp_956935);
else goto fail_tmp_956934;
}
/* commit */
{
tmp_951257 = genfunc_tmp_956855();
goto next_tmp_956937;
next_tmp_956937:
goto tmp_956936;
tmp_956936:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_956943;
fail_tmp_956934:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_956855();
goto next_tmp_956941;
next_tmp_956941:
goto tmp_956940;
tmp_956940:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_956943:
return tmp_951324;
}
reg_t genfunc_tmp_956908 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_956877 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_956877 >> 8) == 0)
field_imm = tmp_956877;
else goto fail_tmp_956876;
}
/* commit */
{
tmp_952040 = genfunc_tmp_956855();
goto next_tmp_956879;
next_tmp_956879:
goto tmp_956878;
tmp_956878:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_956907;
fail_tmp_956876:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_956899 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_956899))
field_imm = inv_maskmask(8, tmp_956899);
else goto fail_tmp_956898;
}
/* commit */
{
tmp_951257 = genfunc_tmp_956855();
goto next_tmp_956901;
next_tmp_956901:
goto tmp_956900;
tmp_956900:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_956907;
fail_tmp_956898:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_956855();
goto next_tmp_956905;
next_tmp_956905:
goto tmp_956904;
tmp_956904:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_956907:
return tmp_952044;
}
reg_t genfunc_tmp_956855 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_956846;
field_ra = 31;
/* commit */
{
tmp_951424 = genfunc_tmp_955743();
goto next_tmp_956848;
next_tmp_956848:
goto tmp_956847;
tmp_956847:
}
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 2 */
}
goto done_tmp_956854;
fail_tmp_956846:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_956850;
field_ra = 31;
/* commit */
{
tmp_951392 = genfunc_tmp_955743();
goto next_tmp_956852;
next_tmp_956852:
goto tmp_956851;
tmp_956851:
}
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 2 */
}
goto done_tmp_956854;
fail_tmp_956850:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_952082 = genfunc_tmp_955743();
goto next_tmp_956830;
next_tmp_956830:
goto tmp_956829;
tmp_956829:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 3 */
}
done_tmp_956854:
return tmp_952058;
}
void genfunc_tmp_956808 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_956558();
goto next_tmp_956437;
next_tmp_956437:
goto tmp_956436;
tmp_956436:
}
{
tmp_951328 = genfunc_tmp_956805();
goto next_tmp_956561;
next_tmp_956561:
goto tmp_956560;
tmp_956560:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 10 */
}
done_tmp_956807:
}
reg_t genfunc_tmp_956805 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_956733 = tmp_952086;
if ((tmp_956733 >> 8) == 0)
field_imm = tmp_956733;
else goto fail_tmp_956732;
}
/* commit */
{
tmp_952084 = genfunc_tmp_956724();
goto next_tmp_956735;
next_tmp_956735:
goto tmp_956734;
tmp_956734:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_956804;
fail_tmp_956732:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_956724();
goto next_tmp_956566;
next_tmp_956566:
goto tmp_956565;
tmp_956565:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_956804:
return tmp_951328;
}
reg_t genfunc_tmp_956774 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_956753 = tmp_952086;
if ((tmp_956753 >> 8) == 0)
field_imm = tmp_956753;
else goto fail_tmp_956752;
}
/* commit */
{
tmp_952084 = genfunc_tmp_956724();
goto next_tmp_956755;
next_tmp_956755:
goto tmp_956754;
tmp_956754:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_956773;
fail_tmp_956752:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_956724();
goto next_tmp_956744;
next_tmp_956744:
goto tmp_956743;
tmp_956743:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_956773:
return tmp_952080;
}
reg_t genfunc_tmp_956724 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_956558();
goto next_tmp_956701;
next_tmp_956701:
goto tmp_956700;
tmp_956700:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_956723:
return tmp_952088;
}
reg_t genfunc_tmp_956676 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_956645 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_956645 >> 8) == 0)
field_imm = tmp_956645;
else goto fail_tmp_956644;
}
/* commit */
{
tmp_952040 = genfunc_tmp_956607();
goto next_tmp_956647;
next_tmp_956647:
goto tmp_956646;
tmp_956646:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_956675;
fail_tmp_956644:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_956667 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_956667))
field_imm = inv_maskmask(8, tmp_956667);
else goto fail_tmp_956666;
}
/* commit */
{
tmp_951257 = genfunc_tmp_956607();
goto next_tmp_956669;
next_tmp_956669:
goto tmp_956668;
tmp_956668:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_956675;
fail_tmp_956666:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_956607();
goto next_tmp_956673;
next_tmp_956673:
goto tmp_956672;
tmp_956672:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_956675:
return tmp_952044;
}
reg_t genfunc_tmp_956607 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_956558();
goto next_tmp_956604;
next_tmp_956604:
goto tmp_956603;
tmp_956603:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_956606:
return tmp_952080;
}
reg_t genfunc_tmp_956558 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_956525 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_956525 >> 8) == 0)
field_imm = tmp_956525;
else goto fail_tmp_956524;
}
/* commit */
{
tmp_952040 = genfunc_tmp_956469();
goto next_tmp_956527;
next_tmp_956527:
goto tmp_956526;
tmp_956526:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_956557;
fail_tmp_956524:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_956549 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_956549))
field_imm = inv_maskmask(8, tmp_956549);
else goto fail_tmp_956548;
}
/* commit */
{
tmp_951257 = genfunc_tmp_956469();
goto next_tmp_956551;
next_tmp_956551:
goto tmp_956550;
tmp_956550:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_956557;
fail_tmp_956548:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_956469();
goto next_tmp_956555;
next_tmp_956555:
goto tmp_956554;
tmp_956554:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_956557:
return tmp_951324;
}
reg_t genfunc_tmp_956522 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_956491 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_956491 >> 8) == 0)
field_imm = tmp_956491;
else goto fail_tmp_956490;
}
/* commit */
{
tmp_952040 = genfunc_tmp_956469();
goto next_tmp_956493;
next_tmp_956493:
goto tmp_956492;
tmp_956492:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_956521;
fail_tmp_956490:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_956513 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_956513))
field_imm = inv_maskmask(8, tmp_956513);
else goto fail_tmp_956512;
}
/* commit */
{
tmp_951257 = genfunc_tmp_956469();
goto next_tmp_956515;
next_tmp_956515:
goto tmp_956514;
tmp_956514:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_956521;
fail_tmp_956512:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_956469();
goto next_tmp_956519;
next_tmp_956519:
goto tmp_956518;
tmp_956518:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_956521:
return tmp_952044;
}
reg_t genfunc_tmp_956469 (void) {
reg_t tmp_952058;
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951424;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_956466;
field_ra = 31;
/* commit */
tmp_951424 = ref_gpr_reg_for_reading(0 + index);
tmp_951422 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_rb = tmp_951424;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951424);
/* can fail: T   num insns: 1 */
}
goto done_tmp_956468;
fail_tmp_956466:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_951392;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_956467;
field_ra = 31;
/* commit */
tmp_951392 = ref_gpr_reg_for_reading(0 + index);
tmp_951390 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_rb = tmp_951392;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951392);
/* can fail: T   num insns: 1 */
}
goto done_tmp_956468;
fail_tmp_956467:
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_952080, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_952082 = ref_gpr_reg_for_reading(0 + index);
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_956468:
return tmp_952058;
}
void genfunc_tmp_956431 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_956181();
goto next_tmp_956105;
next_tmp_956105:
goto tmp_956104;
tmp_956104:
}
{
tmp_951328 = genfunc_tmp_956428();
goto next_tmp_956184;
next_tmp_956184:
goto tmp_956183;
tmp_956183:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 6 */
}
done_tmp_956430:
}
reg_t genfunc_tmp_956428 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_956356 = tmp_952086;
if ((tmp_956356 >> 8) == 0)
field_imm = tmp_956356;
else goto fail_tmp_956355;
}
/* commit */
{
tmp_952084 = genfunc_tmp_956347();
goto next_tmp_956358;
next_tmp_956358:
goto tmp_956357;
tmp_956357:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 3 */
}
goto done_tmp_956427;
fail_tmp_956355:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_956347();
goto next_tmp_956189;
next_tmp_956189:
goto tmp_956188;
tmp_956188:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 4 */
}
done_tmp_956427:
return tmp_951328;
}
reg_t genfunc_tmp_956397 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_956376 = tmp_952086;
if ((tmp_956376 >> 8) == 0)
field_imm = tmp_956376;
else goto fail_tmp_956375;
}
/* commit */
{
tmp_952084 = genfunc_tmp_956347();
goto next_tmp_956378;
next_tmp_956378:
goto tmp_956377;
tmp_956377:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 3 */
}
goto done_tmp_956396;
fail_tmp_956375:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_956347();
goto next_tmp_956367;
next_tmp_956367:
goto tmp_956366;
tmp_956366:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 4 */
}
done_tmp_956396:
return tmp_952080;
}
reg_t genfunc_tmp_956347 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_956181();
goto next_tmp_956324;
next_tmp_956324:
goto tmp_956323;
tmp_956323:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 2 */
}
done_tmp_956346:
return tmp_952088;
}
reg_t genfunc_tmp_956299 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_956268 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_956268 >> 8) == 0)
field_imm = tmp_956268;
else goto fail_tmp_956267;
}
/* commit */
{
tmp_952040 = genfunc_tmp_956230();
goto next_tmp_956270;
next_tmp_956270:
goto tmp_956269;
tmp_956269:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_956298;
fail_tmp_956267:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_956290 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_956290))
field_imm = inv_maskmask(8, tmp_956290);
else goto fail_tmp_956289;
}
/* commit */
{
tmp_951257 = genfunc_tmp_956230();
goto next_tmp_956292;
next_tmp_956292:
goto tmp_956291;
tmp_956291:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_956298;
fail_tmp_956289:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_956230();
goto next_tmp_956296;
next_tmp_956296:
goto tmp_956295;
tmp_956295:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_956298:
return tmp_952044;
}
reg_t genfunc_tmp_956230 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_956181();
goto next_tmp_956227;
next_tmp_956227:
goto tmp_956226;
tmp_956226:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 2 */
}
done_tmp_956229:
return tmp_952080;
}
reg_t genfunc_tmp_956181 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_956157 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_956157 >> 8) == 0)
field_imm = tmp_956157;
else goto fail_tmp_956156;
}
/* commit */
tmp_952040 = ref_gpr_reg_for_reading(0 + base);
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 1 */
}
goto done_tmp_956180;
fail_tmp_956156:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_956178 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_956178))
field_imm = inv_maskmask(8, tmp_956178);
else goto fail_tmp_956177;
}
/* commit */
tmp_951257 = ref_gpr_reg_for_reading(0 + base);
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 1 */
}
goto done_tmp_956180;
fail_tmp_956177:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
tmp_951249 = ref_gpr_reg_for_reading(0 + base);
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 1 */
}
done_tmp_956180:
return tmp_951324;
}
reg_t genfunc_tmp_956154 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_956132 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_956132 >> 8) == 0)
field_imm = tmp_956132;
else goto fail_tmp_956131;
}
/* commit */
tmp_952040 = ref_gpr_reg_for_reading(0 + base);
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 1 */
}
goto done_tmp_956153;
fail_tmp_956131:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_956151 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_956151))
field_imm = inv_maskmask(8, tmp_956151);
else goto fail_tmp_956150;
}
/* commit */
tmp_951257 = ref_gpr_reg_for_reading(0 + base);
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 1 */
}
goto done_tmp_956153;
fail_tmp_956150:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
tmp_951249 = ref_gpr_reg_for_reading(0 + base);
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 1 */
}
done_tmp_956153:
return tmp_952044;
}
void genfunc_tmp_956099 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_955849();
goto next_tmp_955695;
next_tmp_955695:
goto tmp_955694;
tmp_955694:
}
{
tmp_951328 = genfunc_tmp_956096();
goto next_tmp_955852;
next_tmp_955852:
goto tmp_955851;
tmp_955851:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 10 */
}
done_tmp_956098:
}
reg_t genfunc_tmp_956096 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_956024 = tmp_952086;
if ((tmp_956024 >> 8) == 0)
field_imm = tmp_956024;
else goto fail_tmp_956023;
}
/* commit */
{
tmp_952084 = genfunc_tmp_956015();
goto next_tmp_956026;
next_tmp_956026:
goto tmp_956025;
tmp_956025:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_956095;
fail_tmp_956023:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_956015();
goto next_tmp_955857;
next_tmp_955857:
goto tmp_955856;
tmp_955856:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_956095:
return tmp_951328;
}
reg_t genfunc_tmp_956065 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_956044 = tmp_952086;
if ((tmp_956044 >> 8) == 0)
field_imm = tmp_956044;
else goto fail_tmp_956043;
}
/* commit */
{
tmp_952084 = genfunc_tmp_956015();
goto next_tmp_956046;
next_tmp_956046:
goto tmp_956045;
tmp_956045:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 5 */
}
goto done_tmp_956064;
fail_tmp_956043:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_956015();
goto next_tmp_956035;
next_tmp_956035:
goto tmp_956034;
tmp_956034:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 6 */
}
done_tmp_956064:
return tmp_952080;
}
reg_t genfunc_tmp_956015 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_955849();
goto next_tmp_955992;
next_tmp_955992:
goto tmp_955991;
tmp_955991:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_956014:
return tmp_952088;
}
reg_t genfunc_tmp_955967 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_955936 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_955936 >> 8) == 0)
field_imm = tmp_955936;
else goto fail_tmp_955935;
}
/* commit */
{
tmp_952040 = genfunc_tmp_955898();
goto next_tmp_955938;
next_tmp_955938:
goto tmp_955937;
tmp_955937:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 5 */
}
goto done_tmp_955966;
fail_tmp_955935:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_955958 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_955958))
field_imm = inv_maskmask(8, tmp_955958);
else goto fail_tmp_955957;
}
/* commit */
{
tmp_951257 = genfunc_tmp_955898();
goto next_tmp_955960;
next_tmp_955960:
goto tmp_955959;
tmp_955959:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 5 */
}
goto done_tmp_955966;
fail_tmp_955957:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_955898();
goto next_tmp_955964;
next_tmp_955964:
goto tmp_955963;
tmp_955963:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 5 */
}
done_tmp_955966:
return tmp_952044;
}
reg_t genfunc_tmp_955898 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_955849();
goto next_tmp_955895;
next_tmp_955895:
goto tmp_955894;
tmp_955894:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 4 */
}
done_tmp_955897:
return tmp_952080;
}
reg_t genfunc_tmp_955849 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_955816 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_955816 >> 8) == 0)
field_imm = tmp_955816;
else goto fail_tmp_955815;
}
/* commit */
{
tmp_952040 = genfunc_tmp_955760();
goto next_tmp_955818;
next_tmp_955818:
goto tmp_955817;
tmp_955817:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_955848;
fail_tmp_955815:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_955840 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_955840))
field_imm = inv_maskmask(8, tmp_955840);
else goto fail_tmp_955839;
}
/* commit */
{
tmp_951257 = genfunc_tmp_955760();
goto next_tmp_955842;
next_tmp_955842:
goto tmp_955841;
tmp_955841:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_955848;
fail_tmp_955839:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_955760();
goto next_tmp_955846;
next_tmp_955846:
goto tmp_955845;
tmp_955845:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_955848:
return tmp_951324;
}
reg_t genfunc_tmp_955813 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_955782 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_955782 >> 8) == 0)
field_imm = tmp_955782;
else goto fail_tmp_955781;
}
/* commit */
{
tmp_952040 = genfunc_tmp_955760();
goto next_tmp_955784;
next_tmp_955784:
goto tmp_955783;
tmp_955783:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_955812;
fail_tmp_955781:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_955804 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_955804))
field_imm = inv_maskmask(8, tmp_955804);
else goto fail_tmp_955803;
}
/* commit */
{
tmp_951257 = genfunc_tmp_955760();
goto next_tmp_955806;
next_tmp_955806:
goto tmp_955805;
tmp_955805:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_955812;
fail_tmp_955803:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_955760();
goto next_tmp_955810;
next_tmp_955810:
goto tmp_955809;
tmp_955809:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_955812:
return tmp_952044;
}
reg_t genfunc_tmp_955760 (void) {
reg_t tmp_952058;
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_reading(0 + base);
{
tmp_952082 = genfunc_tmp_955743();
goto next_tmp_955711;
next_tmp_955711:
goto tmp_955710;
tmp_955710:
}
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 2 */
}
done_tmp_955759:
return tmp_952058;
}
reg_t genfunc_tmp_955743 (void) {
reg_t tmp_952082;
/* EXTQH */
{
word_5 tmp_951800;
word_5 field_rc;
word_5 tmp_951801;
word_5 field_ra;
word_5 field_rb;
if (64 != ((word_64)scale)) goto fail_tmp_955724;
field_rb = 31;
/* commit */
tmp_951801 = ref_gpr_reg_for_reading(0 + index);
tmp_951800 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951800;
field_ra = tmp_951801;
emit(COMPOSE_EXTQH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951801);
/* can fail: T   num insns: 1 */
}
goto done_tmp_955742;
fail_tmp_955724:
/* EXTQH_IMM */
{
word_5 tmp_951796;
word_5 field_rc;
word_5 tmp_951797;
word_5 field_ra;
word_64 tmp_951799;
word_8 field_imm;
tmp_951799 = ((word_64)scale);
{
word_64 tmp_955726 = ((64 - tmp_951799) & 0xFFFFFFFFFFFFFFFF);
if (tmp_955726 % 8 == 0)
{
word_64 tmp_955727 = (tmp_955726 / 8);
if ((tmp_955727 & 7) == tmp_955727)
{
word_64 tmp_955728 = tmp_955727;
if ((tmp_955728 >> 8) == 0)
field_imm = tmp_955728;
else goto fail_tmp_955725;
}
else goto fail_tmp_955725;
}
else goto fail_tmp_955725;
}
/* commit */
tmp_951797 = ref_gpr_reg_for_reading(0 + index);
tmp_951796 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951796;
field_ra = tmp_951797;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951797);
/* can fail: T   num insns: 1 */
}
goto done_tmp_955742;
fail_tmp_955725:
/* S4ADDQ */
{
word_5 tmp_951422;
word_5 field_rc;
word_5 tmp_951423;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_955734;
field_rb = 31;
/* commit */
tmp_951423 = ref_gpr_reg_for_reading(0 + index);
tmp_951422 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951422;
field_ra = tmp_951423;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951423);
/* can fail: T   num insns: 1 */
}
goto done_tmp_955742;
fail_tmp_955734:
/* S4ADDQ_IMM */
{
word_5 tmp_951418;
word_5 field_rc;
word_5 tmp_951419;
word_5 field_ra;
word_64 tmp_951421;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_955735;
tmp_951421 = 0;
field_imm = 0;
/* commit */
tmp_951419 = ref_gpr_reg_for_reading(0 + index);
tmp_951418 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951418;
field_ra = tmp_951419;
emit(COMPOSE_S4ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951419);
/* can fail: T   num insns: 1 */
}
goto done_tmp_955742;
fail_tmp_955735:
/* S8ADDQ */
{
word_5 tmp_951390;
word_5 field_rc;
word_5 tmp_951391;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_955737;
field_rb = 31;
/* commit */
tmp_951391 = ref_gpr_reg_for_reading(0 + index);
tmp_951390 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951390;
field_ra = tmp_951391;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951391);
/* can fail: T   num insns: 1 */
}
goto done_tmp_955742;
fail_tmp_955737:
/* S8ADDQ_IMM */
{
word_5 tmp_951386;
word_5 field_rc;
word_5 tmp_951387;
word_5 field_ra;
word_64 tmp_951389;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_955738;
tmp_951389 = 0;
field_imm = 0;
/* commit */
tmp_951387 = ref_gpr_reg_for_reading(0 + index);
tmp_951386 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951386;
field_ra = tmp_951387;
emit(COMPOSE_S8ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951387);
/* can fail: T   num insns: 1 */
}
goto done_tmp_955742;
fail_tmp_955738:
/* SLL */
{
word_5 tmp_951358;
word_5 field_rc;
word_5 tmp_951359;
word_5 field_ra;
word_5 field_rb;
if (0 != ((word_64)scale)) goto fail_tmp_955739;
field_rb = 31;
/* commit */
tmp_951359 = ref_gpr_reg_for_reading(0 + index);
tmp_951358 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951358;
field_ra = tmp_951359;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_951359);
/* can fail: T   num insns: 1 */
}
goto done_tmp_955742;
fail_tmp_955739:
/* SLL_IMM */
{
word_5 tmp_951354;
word_5 field_rc;
word_5 tmp_951355;
word_5 field_ra;
word_64 tmp_951357;
word_8 field_imm;
tmp_951357 = ((word_64)scale);
field_imm = tmp_951357;
/* commit */
tmp_951355 = ref_gpr_reg_for_reading(0 + index);
tmp_951354 = tmp_952082 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951354;
field_ra = tmp_951355;
emit(COMPOSE_SLL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951355);
/* can fail: NIL   num insns: 1 */
}
done_tmp_955742:
return tmp_952082;
}
void genfunc_tmp_955689 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_955439();
goto next_tmp_955320;
next_tmp_955320:
goto tmp_955319;
tmp_955319:
}
{
tmp_951328 = genfunc_tmp_955686();
goto next_tmp_955442;
next_tmp_955442:
goto tmp_955441;
tmp_955441:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 8 */
}
done_tmp_955688:
}
reg_t genfunc_tmp_955686 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_955614 = tmp_952086;
if ((tmp_955614 >> 8) == 0)
field_imm = tmp_955614;
else goto fail_tmp_955613;
}
/* commit */
{
tmp_952084 = genfunc_tmp_955605();
goto next_tmp_955616;
next_tmp_955616:
goto tmp_955615;
tmp_955615:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 4 */
}
goto done_tmp_955685;
fail_tmp_955613:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_955605();
goto next_tmp_955447;
next_tmp_955447:
goto tmp_955446;
tmp_955446:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 5 */
}
done_tmp_955685:
return tmp_951328;
}
reg_t genfunc_tmp_955655 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_955634 = tmp_952086;
if ((tmp_955634 >> 8) == 0)
field_imm = tmp_955634;
else goto fail_tmp_955633;
}
/* commit */
{
tmp_952084 = genfunc_tmp_955605();
goto next_tmp_955636;
next_tmp_955636:
goto tmp_955635;
tmp_955635:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 4 */
}
goto done_tmp_955654;
fail_tmp_955633:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_955605();
goto next_tmp_955625;
next_tmp_955625:
goto tmp_955624;
tmp_955624:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 5 */
}
done_tmp_955654:
return tmp_952080;
}
reg_t genfunc_tmp_955605 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_955439();
goto next_tmp_955582;
next_tmp_955582:
goto tmp_955581;
tmp_955581:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 3 */
}
done_tmp_955604:
return tmp_952088;
}
reg_t genfunc_tmp_955557 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_955526 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_955526 >> 8) == 0)
field_imm = tmp_955526;
else goto fail_tmp_955525;
}
/* commit */
{
tmp_952040 = genfunc_tmp_955488();
goto next_tmp_955528;
next_tmp_955528:
goto tmp_955527;
tmp_955527:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 4 */
}
goto done_tmp_955556;
fail_tmp_955525:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_955548 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_955548))
field_imm = inv_maskmask(8, tmp_955548);
else goto fail_tmp_955547;
}
/* commit */
{
tmp_951257 = genfunc_tmp_955488();
goto next_tmp_955550;
next_tmp_955550:
goto tmp_955549;
tmp_955549:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 4 */
}
goto done_tmp_955556;
fail_tmp_955547:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_955488();
goto next_tmp_955554;
next_tmp_955554:
goto tmp_955553;
tmp_955553:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 4 */
}
done_tmp_955556:
return tmp_952044;
}
reg_t genfunc_tmp_955488 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_955439();
goto next_tmp_955485;
next_tmp_955485:
goto tmp_955484;
tmp_955484:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 3 */
}
done_tmp_955487:
return tmp_952080;
}
reg_t genfunc_tmp_955439 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_955406 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_955406 >> 8) == 0)
field_imm = tmp_955406;
else goto fail_tmp_955405;
}
/* commit */
{
tmp_952040 = genfunc_tmp_955350();
goto next_tmp_955408;
next_tmp_955408:
goto tmp_955407;
tmp_955407:
}
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 2 */
}
goto done_tmp_955438;
fail_tmp_955405:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_955430 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_955430))
field_imm = inv_maskmask(8, tmp_955430);
else goto fail_tmp_955429;
}
/* commit */
{
tmp_951257 = genfunc_tmp_955350();
goto next_tmp_955432;
next_tmp_955432:
goto tmp_955431;
tmp_955431:
}
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 2 */
}
goto done_tmp_955438;
fail_tmp_955429:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_955350();
goto next_tmp_955436;
next_tmp_955436:
goto tmp_955435;
tmp_955435:
}
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 2 */
}
done_tmp_955438:
return tmp_951324;
}
reg_t genfunc_tmp_955403 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_955372 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_955372 >> 8) == 0)
field_imm = tmp_955372;
else goto fail_tmp_955371;
}
/* commit */
{
tmp_952040 = genfunc_tmp_955350();
goto next_tmp_955374;
next_tmp_955374:
goto tmp_955373;
tmp_955373:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 2 */
}
goto done_tmp_955402;
fail_tmp_955371:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_955394 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_955394))
field_imm = inv_maskmask(8, tmp_955394);
else goto fail_tmp_955393;
}
/* commit */
{
tmp_951257 = genfunc_tmp_955350();
goto next_tmp_955396;
next_tmp_955396:
goto tmp_955395;
tmp_955395:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 2 */
}
goto done_tmp_955402;
fail_tmp_955393:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_955350();
goto next_tmp_955400;
next_tmp_955400:
goto tmp_955399;
tmp_955399:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 2 */
}
done_tmp_955402:
return tmp_952044;
}
reg_t genfunc_tmp_955350 (void) {
reg_t tmp_952058;
/* ADDQ */
{
word_5 tmp_952079;
word_5 field_rc;
word_5 tmp_952080;
word_5 field_ra;
word_5 tmp_952082;
word_5 field_rb;
/* commit */
tmp_952080 = ref_gpr_reg_for_reading(0 + base);
tmp_952082 = ref_gpr_reg_for_reading(0 + index);
tmp_952079 = tmp_952058 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952079;
field_ra = tmp_952080;
field_rb = tmp_952082;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952082);
unref_gpr_reg(tmp_952080);
/* can fail: NIL   num insns: 1 */
}
done_tmp_955349:
return tmp_952058;
}
void genfunc_tmp_955314 (void) {
/* STL */
{
word_5 tmp_951324;
word_5 field_rb;
word_64 tmp_951326;
word_16 field_memory_disp;
word_5 tmp_951328;
word_5 field_ra;
tmp_951326 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951324 = genfunc_tmp_955064();
goto next_tmp_954988;
next_tmp_954988:
goto tmp_954987;
tmp_954987:
}
{
tmp_951328 = genfunc_tmp_955311();
goto next_tmp_955067;
next_tmp_955067:
goto tmp_955066;
tmp_955066:
}
field_rb = tmp_951324;
field_ra = tmp_951328;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951328);
unref_gpr_reg(tmp_951324);
/* can fail: NIL   num insns: 6 */
}
done_tmp_955313:
}
reg_t genfunc_tmp_955311 (void) {
reg_t tmp_951328;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_955239 = tmp_952086;
if ((tmp_955239 >> 8) == 0)
field_imm = tmp_955239;
else goto fail_tmp_955238;
}
/* commit */
{
tmp_952084 = genfunc_tmp_955230();
goto next_tmp_955241;
next_tmp_955241:
goto tmp_955240;
tmp_955240:
}
tmp_952083 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 3 */
}
goto done_tmp_955310;
fail_tmp_955238:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_955230();
goto next_tmp_955072;
next_tmp_955072:
goto tmp_955071;
tmp_955071:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_951328 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 4 */
}
done_tmp_955310:
return tmp_951328;
}
reg_t genfunc_tmp_955280 (void) {
reg_t tmp_952080;
/* ADDL_IMM */
{
word_5 tmp_952083;
word_5 field_rc;
word_5 tmp_952084;
word_5 field_ra;
word_32 tmp_952086;
word_8 field_imm;
tmp_952086 = ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8);
{
word_32 tmp_955259 = tmp_952086;
if ((tmp_955259 >> 8) == 0)
field_imm = tmp_955259;
else goto fail_tmp_955258;
}
/* commit */
{
tmp_952084 = genfunc_tmp_955230();
goto next_tmp_955261;
next_tmp_955261:
goto tmp_955260;
tmp_955260:
}
tmp_952083 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952083;
field_ra = tmp_952084;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952084);
/* can fail: T   num insns: 3 */
}
goto done_tmp_955279;
fail_tmp_955258:
/* ADDL */
{
word_5 tmp_952087;
word_5 field_rc;
word_5 tmp_952088;
word_5 field_ra;
word_5 tmp_952090;
word_5 field_rb;
/* commit */
{
tmp_952088 = genfunc_tmp_955230();
goto next_tmp_955250;
next_tmp_955250:
goto tmp_955249;
tmp_955249:
}
tmp_952090 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_952090, ((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8));
tmp_952087 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952087;
field_ra = tmp_952088;
field_rb = tmp_952090;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_952090);
unref_gpr_reg(tmp_952088);
/* can fail: NIL   num insns: 4 */
}
done_tmp_955279:
return tmp_952080;
}
reg_t genfunc_tmp_955230 (void) {
reg_t tmp_952088;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_955064();
goto next_tmp_955207;
next_tmp_955207:
goto tmp_955206;
tmp_955206:
}
tmp_951563 = tmp_952088 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 2 */
}
done_tmp_955229:
return tmp_952088;
}
reg_t genfunc_tmp_955182 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_955151 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_955151 >> 8) == 0)
field_imm = tmp_955151;
else goto fail_tmp_955150;
}
/* commit */
{
tmp_952040 = genfunc_tmp_955113();
goto next_tmp_955153;
next_tmp_955153:
goto tmp_955152;
tmp_955152:
}
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 3 */
}
goto done_tmp_955181;
fail_tmp_955150:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_955173 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_955173))
field_imm = inv_maskmask(8, tmp_955173);
else goto fail_tmp_955172;
}
/* commit */
{
tmp_951257 = genfunc_tmp_955113();
goto next_tmp_955175;
next_tmp_955175:
goto tmp_955174;
tmp_955174:
}
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 3 */
}
goto done_tmp_955181;
fail_tmp_955172:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_951249 = genfunc_tmp_955113();
goto next_tmp_955179;
next_tmp_955179:
goto tmp_955178;
tmp_955178:
}
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 3 */
}
done_tmp_955181:
return tmp_952044;
}
reg_t genfunc_tmp_955113 (void) {
reg_t tmp_952080;
/* LDL */
{
word_5 tmp_951563;
word_5 field_ra;
word_5 tmp_951564;
word_5 field_rb;
word_64 tmp_951566;
word_16 field_memory_disp;
tmp_951566 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_951564 = genfunc_tmp_955064();
goto next_tmp_955110;
next_tmp_955110:
goto tmp_955109;
tmp_955109:
}
tmp_951563 = tmp_952080 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_951563;
field_rb = tmp_951564;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_951564);
/* can fail: NIL   num insns: 2 */
}
done_tmp_955112:
return tmp_952080;
}
reg_t genfunc_tmp_955064 (void) {
reg_t tmp_951324;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_955040 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_955040 >> 8) == 0)
field_imm = tmp_955040;
else goto fail_tmp_955039;
}
/* commit */
tmp_952040 = ref_gpr_reg_for_reading(0 + rm);
tmp_952039 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 1 */
}
goto done_tmp_955063;
fail_tmp_955039:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_955061 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_955061))
field_imm = inv_maskmask(8, tmp_955061);
else goto fail_tmp_955060;
}
/* commit */
tmp_951257 = ref_gpr_reg_for_reading(0 + rm);
tmp_951256 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 1 */
}
goto done_tmp_955063;
fail_tmp_955060:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
tmp_951249 = ref_gpr_reg_for_reading(0 + rm);
tmp_951248 = tmp_951324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 1 */
}
done_tmp_955063:
return tmp_951324;
}
reg_t genfunc_tmp_955037 (void) {
reg_t tmp_952044;
/* BIC_IMM */
{
word_5 tmp_952039;
word_5 field_rc;
word_5 tmp_952040;
word_5 field_ra;
word_64 tmp_952042;
word_8 field_imm;
tmp_952042 = 4294967295;
{
word_64 tmp_955015 = (~tmp_952042 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_955015 >> 8) == 0)
field_imm = tmp_955015;
else goto fail_tmp_955014;
}
/* commit */
tmp_952040 = ref_gpr_reg_for_reading(0 + rm);
tmp_952039 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_952039;
field_ra = tmp_952040;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_952040);
/* can fail: T   num insns: 1 */
}
goto done_tmp_955036;
fail_tmp_955014:
/* ZAP_IMM */
{
word_5 tmp_951256;
word_5 field_rc;
word_5 tmp_951257;
word_5 field_ra;
word_64 tmp_951259;
word_8 field_imm;
tmp_951259 = 4294967295;
{
word_64 tmp_955034 = (~tmp_951259 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_955034))
field_imm = inv_maskmask(8, tmp_955034);
else goto fail_tmp_955033;
}
/* commit */
tmp_951257 = ref_gpr_reg_for_reading(0 + rm);
tmp_951256 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951256;
field_ra = tmp_951257;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951257);
/* can fail: T   num insns: 1 */
}
goto done_tmp_955036;
fail_tmp_955033:
/* ZAPNOT_IMM */
{
word_5 tmp_951248;
word_5 field_rc;
word_5 tmp_951249;
word_5 field_ra;
word_64 tmp_951251;
word_8 field_imm;
tmp_951251 = 4294967295;
field_imm = 15;
/* commit */
tmp_951249 = ref_gpr_reg_for_reading(0 + rm);
tmp_951248 = tmp_952044 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_951248;
field_ra = tmp_951249;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_951249);
/* can fail: NIL   num insns: 1 */
}
done_tmp_955036:
return tmp_952044;
}
