#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compile_mov_eax_moffs32_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 )
{
genfunc_tmp_873862();
goto next_tmp_873653;
next_tmp_873653:
goto finish_tmp_873652;
finish_tmp_873652:
}
}
void genfunc_tmp_873862 (void) {
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_731383;
word_16 field_memory_disp;
tmp_731383 = ((word_64)imm32);
field_rb = 31;
{
word_64 tmp_873860 = tmp_731383;
if ((tmp_873860 >> 16) == 0xFFFFFFFFFFFF || (tmp_873860 >> 16) == 0)
field_memory_disp = (tmp_873860 & 0xFFFF);
else goto fail_tmp_873859;
}
/* commit */
tmp_731381 = ref_gpr_reg_for_writing(0 + 0);
field_ra = tmp_731381;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731381);
/* can fail: T   num insns: 1 */
}
goto done_tmp_873861;
fail_tmp_873859:
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
tmp_731382 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731382, ((word_64)imm32));
tmp_731381 = ref_gpr_reg_for_writing(0 + 0);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731381);
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_873861:
}
reg_t genfunc_tmp_873812 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_731383;
word_16 field_memory_disp;
tmp_731383 = ((word_64)imm32);
field_rb = 31;
{
word_64 tmp_873790 = tmp_731383;
if ((tmp_873790 >> 16) == 0xFFFFFFFFFFFF || (tmp_873790 >> 16) == 0)
field_memory_disp = (tmp_873790 & 0xFFFF);
else goto fail_tmp_873789;
}
/* commit */
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_873811;
fail_tmp_873789:
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
tmp_731382 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731382, ((word_64)imm32));
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_873811:
return tmp_731906;
}
reg_t genfunc_tmp_873765 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_873734 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_873734 >> 8) == 0)
field_imm = tmp_873734;
else goto fail_tmp_873733;
}
/* commit */
{
tmp_731858 = genfunc_tmp_873696();
goto next_tmp_873736;
next_tmp_873736:
goto tmp_873735;
tmp_873735:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_873764;
fail_tmp_873733:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_873756 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_873756))
field_imm = inv_maskmask(8, tmp_873756);
else goto fail_tmp_873755;
}
/* commit */
{
tmp_731075 = genfunc_tmp_873696();
goto next_tmp_873758;
next_tmp_873758:
goto tmp_873757;
tmp_873757:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_873764;
fail_tmp_873755:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_873696();
goto next_tmp_873762;
next_tmp_873762:
goto tmp_873761;
tmp_873761:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_873764:
return tmp_731862;
}
reg_t genfunc_tmp_873696 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_731383;
word_16 field_memory_disp;
tmp_731383 = ((word_64)imm32);
field_rb = 31;
{
word_64 tmp_873694 = tmp_731383;
if ((tmp_873694 >> 16) == 0xFFFFFFFFFFFF || (tmp_873694 >> 16) == 0)
field_memory_disp = (tmp_873694 & 0xFFFF);
else goto fail_tmp_873693;
}
/* commit */
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_873695;
fail_tmp_873693:
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
tmp_731382 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731382, ((word_64)imm32));
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_873695:
return tmp_731898;
}
