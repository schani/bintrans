#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compiler_tmp_997022 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_997013 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997018 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_997011 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_997001 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997010 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997009 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997006 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_986778 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_986768 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986772 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986777 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986775 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986766 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_986718 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986764 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986723 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986724 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986727 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986757 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986761 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986758 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986749 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986754 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986750 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986753 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986728 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986731 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986741 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986748 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986742 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986747 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986745 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986734 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986737 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986739 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986738 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986735 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_986729 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997022 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 6 6 T)
*/
{
{
reg_t tmp_997023;
rhs_func(&tmp_997023, 11, env);
emit(COMPOSE_AND_IMM(tmp_997023, 1, tmp_997023));
unref_integer_reg(tmp_997023);
}
}

void compiler_tmp_997013 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (=
  (CASE
   ((0 1 2)
    (MEM
     (CASE
      ((0)
       (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
        ((4)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))
        ((5) (FIELD DISP32 NIL NIL))))
      ((1)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
        ((4)
         (+ (SEX (FIELD DISP8 NIL NIL))
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0))))))))
      ((2)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
        ((4)
         (+ (FIELD DISP32 NIL NIL)
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0)))))))))))
   ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
  (INTEGER 0))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_997015 = alloc_label(), tmp_997016 = alloc_label(), tmp_997017 = alloc_label();
reg_t tmp_997014;
compiler_tmp_997018(tmp_997015, tmp_997016, env);

tmp_997014 = ref_integer_reg_for_writing(-1);
emit_label(tmp_997015);
push_alloc();
compiler_tmp_997009(&tmp_997014, tmp_997014 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_997017);
emit_label(tmp_997016);
push_alloc();
compiler_tmp_997010(&tmp_997014, tmp_997014 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_997017);
free_label(tmp_997015);
free_label(tmp_997016);
free_label(tmp_997017);
if (foreign_target == -1)
*target = tmp_997014;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_997014, *target));
unref_integer_reg(tmp_997014);
}

}
}

void compiler_tmp_997018 (label_t true_label, label_t false_label, void **env)
/*
(=
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (INTEGER 0))
*/
{
{
reg_t tmp_997019, tmp_997020, tmp_997021;
compiler_tmp_986723(&tmp_997019, -1, env);
compiler_tmp_986748(&tmp_997020, -1, env);
tmp_997021 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_CMPEQ(tmp_997019, tmp_997020, tmp_997021));
unref_integer_reg(tmp_997019);
unref_integer_reg(tmp_997020);
emit_branch(COMPOSE_BEQ(tmp_997021, 0), false_label);
unref_integer_reg(tmp_997021);
emit_branch(COMPOSE_BR(31, 0), true_label);
}
}

void compiler_tmp_997011 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 7 7 T)
*/
{
{
reg_t tmp_997012;
rhs_func(&tmp_997012, 12, env);
emit(COMPOSE_AND_IMM(tmp_997012, 1, tmp_997012));
unref_integer_reg(tmp_997012);
}
}

void compiler_tmp_997001 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (BIT-SET-P
  (CASE
   ((0 1 2)
    (MEM
     (CASE
      ((0)
       (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
        ((4)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))
        ((5) (FIELD DISP32 NIL NIL))))
      ((1)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
        ((4)
         (+ (SEX (FIELD DISP8 NIL NIL))
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0))))))))
      ((2)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
        ((4)
         (+ (FIELD DISP32 NIL NIL)
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0)))))))))))
   ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
  (- (INTEGER 32) (INTEGER 1)))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_997003 = alloc_label(), tmp_997004 = alloc_label(), tmp_997005 = alloc_label();
reg_t tmp_997002;
compiler_tmp_997006(tmp_997003, tmp_997004, env);

tmp_997002 = ref_integer_reg_for_writing(-1);
emit_label(tmp_997003);
push_alloc();
compiler_tmp_997009(&tmp_997002, tmp_997002 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_997005);
emit_label(tmp_997004);
push_alloc();
compiler_tmp_997010(&tmp_997002, tmp_997002 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_997005);
free_label(tmp_997003);
free_label(tmp_997004);
free_label(tmp_997005);
if (foreign_target == -1)
*target = tmp_997002;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_997002, *target));
unref_integer_reg(tmp_997002);
}

}
}

void compiler_tmp_997010 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_997009 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 1)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 1);
}

void compiler_tmp_997006 (label_t true_label, label_t false_label, void **env)
/*
(BIT-SET-P
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (- (INTEGER 32) (INTEGER 1)))
*/
{
{
reg_t tmp_997007, tmp_997008;
compiler_tmp_986723(&tmp_997007, -1, env);
tmp_997008 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_SRL_IMM(tmp_997007, (32 - 1), tmp_997008));
unref_integer_reg(tmp_997007);
emit_branch(COMPOSE_BLBS(tmp_997008, 0), true_label);
unref_integer_reg(tmp_997008);
emit_branch(COMPOSE_BR(31, 0), false_label);
}
}

void compiler_tmp_986778 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 11 11 T)
*/
{
{
reg_t tmp_986779;
rhs_func(&tmp_986779, 13, env);
emit(COMPOSE_AND_IMM(tmp_986779, 1, tmp_986779));
unref_integer_reg(tmp_986779);
}
}

void compiler_tmp_986768 (reg_t *target, int foreign_target, void **env)
/*
(+OVERFLOW
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (+ (BITNEG (REGISTER NIL GPR (FIELD REG NIL NIL))) (INTEGER 1)))
*/
{
{
reg_t tmp_986769, tmp_986770, tmp_986771;
compiler_tmp_986723(&tmp_986769, -1, env);
compiler_tmp_986772(&tmp_986770, -1, env);
tmp_986771 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ADDQ(tmp_986769, tmp_986770, tmp_986771));
unref_integer_reg(tmp_986769);
unref_integer_reg(tmp_986770);
emit(COMPOSE_SRA_IMM(tmp_986771, 32, tmp_986771));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDQ_IMM(31, 1, *target));
emit(COMPOSE_CMOVEQ_IMM(tmp_986771, 0, *target));
emit(COMPOSE_NOT(tmp_986771, tmp_986771));
emit(COMPOSE_CMOVEQ_IMM(tmp_986771, 0, *target));
unref_integer_reg(tmp_986771);
}
}

void compiler_tmp_986772 (reg_t *target, int foreign_target, void **env)
/*
(+ (BITNEG (REGISTER NIL GPR (FIELD REG NIL NIL))) (INTEGER 1))
*/
{
{
reg_t tmp_986773, tmp_986774;
compiler_tmp_986775(&tmp_986773, -1, env);
compiler_tmp_986777(&tmp_986774, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_986773, tmp_986774, *target));
unref_integer_reg(tmp_986773);
unref_integer_reg(tmp_986774);
}
}

void compiler_tmp_986777 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 1)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 1);
}

void compiler_tmp_986775 (reg_t *target, int foreign_target, void **env)
/*
(BITNEG (REGISTER NIL GPR (FIELD REG NIL NIL)))
*/
{
{
reg_t tmp_986776;
compiler_tmp_986764(&tmp_986776, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_NOT(tmp_986776, *target));
unref_integer_reg(tmp_986776);
}
}

void compiler_tmp_986766 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 0 0 T)
*/
{
{
reg_t tmp_986767;
rhs_func(&tmp_986767, 10, env);
emit(COMPOSE_AND_IMM(tmp_986767, 1, tmp_986767));
unref_integer_reg(tmp_986767);
}
}

void compiler_tmp_986718 (reg_t *target, int foreign_target, void **env)
/*
(-CARRY
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (REGISTER NIL GPR (FIELD REG NIL NIL)))
*/
{
{
reg_t tmp_986721, tmp_986722, tmp_986719, tmp_986720;
compiler_tmp_986723(&tmp_986721, -1, env);
tmp_986719 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ZAPNOT_IMM(tmp_986721, 15, tmp_986719));
unref_integer_reg(tmp_986721);
compiler_tmp_986764(&tmp_986722, -1, env);
tmp_986720 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ZAPNOT_IMM(tmp_986722, 15, tmp_986720));
unref_integer_reg(tmp_986722);*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_SUBQ(tmp_986719, tmp_986720, *target));
unref_integer_reg(tmp_986719);
unref_integer_reg(tmp_986720);
emit(COMPOSE_SRL_IMM(*target, 32, *target));
emit(COMPOSE_AND_IMM(*target, 1, *target));
}
}

void compiler_tmp_986764 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD REG NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + reg));
else {
reg_t tmp_986765 = ref_integer_reg_for_reading((0 + reg));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_986765, *target));
unref_integer_reg(tmp_986765);
}
}

void compiler_tmp_986723 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2)
  (MEM
   (CASE
    ((0)
     (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
      ((4)
       (+
        (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
         ((5)
          (CASE ((0) (FIELD DISP32 NIL NIL))
           ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
        (CASE
         ((0 1 2 3 5 6 7)
          (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
           (ZEX (FIELD SCALE NIL NIL))))
         ((4) (INTEGER 0)))))
      ((5) (FIELD DISP32 NIL NIL))))
    ((1)
     (CASE
      ((0 1 2 3 5 6 7)
       (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
      ((4)
       (+ (SEX (FIELD DISP8 NIL NIL))
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0))))))))
    ((2)
     (CASE
      ((0 1 2 3 5 6 7)
       (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
      ((4)
       (+ (FIELD DISP32 NIL NIL)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))))))))
 ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
*/
{
switch (mod) {
case 0:
case 1:
case 2:
compiler_tmp_986724(&(*target), foreign_target, env);
break;
case 3:
compiler_tmp_986729(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_986724 (reg_t *target, int foreign_target, void **env)
/*
(MEM
 (CASE
  ((0)
   (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
    ((4)
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0)))))
    ((5) (FIELD DISP32 NIL NIL))))
  ((1)
   (CASE
    ((0 1 2 3 5 6 7)
     (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
    ((4)
     (+ (SEX (FIELD DISP8 NIL NIL))
      (+
       (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
        ((5)
         (CASE ((0) (FIELD DISP32 NIL NIL))
          ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
       (CASE
        ((0 1 2 3 5 6 7)
         (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
          (ZEX (FIELD SCALE NIL NIL))))
        ((4) (INTEGER 0))))))))
  ((2)
   (CASE
    ((0 1 2 3 5 6 7)
     (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
    ((4)
     (+ (FIELD DISP32 NIL NIL)
      (+
       (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
        ((5)
         (CASE ((0) (FIELD DISP32 NIL NIL))
          ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
       (CASE
        ((0 1 2 3 5 6 7)
         (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
          (ZEX (FIELD SCALE NIL NIL))))
        ((4) (INTEGER 0))))))))))
*/
{
{
reg_t tmp_986725, tmp_986726;
compiler_tmp_986727(&tmp_986725, -1, env);
#ifdef EMU_I386
tmp_986726 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ZAPNOT_IMM(tmp_986725, 15, tmp_986726));
unref_integer_reg(tmp_986725);
#else
tmp_986726 = tmp_986725;
#endif
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_mem_32(*target, tmp_986726);
unref_integer_reg(tmp_986726);
}
}

void compiler_tmp_986727 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0)
  (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
   ((4)
    (+
     (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
      ((5)
       (CASE ((0) (FIELD DISP32 NIL NIL))
        ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
     (CASE
      ((0 1 2 3 5 6 7)
       (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
        (ZEX (FIELD SCALE NIL NIL))))
      ((4) (INTEGER 0)))))
   ((5) (FIELD DISP32 NIL NIL))))
 ((1)
  (CASE
   ((0 1 2 3 5 6 7)
    (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
   ((4)
    (+ (SEX (FIELD DISP8 NIL NIL))
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0))))))))
 ((2)
  (CASE
   ((0 1 2 3 5 6 7)
    (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
   ((4)
    (+ (FIELD DISP32 NIL NIL)
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0)))))))))
*/
{
switch (mod) {
case 0:
compiler_tmp_986728(&(*target), foreign_target, env);
break;
case 1:
compiler_tmp_986749(&(*target), foreign_target, env);
break;
case 2:
compiler_tmp_986757(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_986757 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
 ((4)
  (+ (FIELD DISP32 NIL NIL)
   (+
    (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
     ((5)
      (CASE ((0) (FIELD DISP32 NIL NIL))
       ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
    (CASE
     ((0 1 2 3 5 6 7)
      (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
       (ZEX (FIELD SCALE NIL NIL))))
     ((4) (INTEGER 0)))))))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_986758(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_986761(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_986761 (reg_t *target, int foreign_target, void **env)
/*
(+ (FIELD DISP32 NIL NIL)
 (+
  (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
   ((5)
    (CASE ((0) (FIELD DISP32 NIL NIL))
     ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
  (CASE
   ((0 1 2 3 5 6 7)
    (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
     (ZEX (FIELD SCALE NIL NIL))))
   ((4) (INTEGER 0)))))
*/
{
{
reg_t tmp_986762, tmp_986763;
compiler_tmp_986738(&tmp_986762, -1, env);
compiler_tmp_986731(&tmp_986763, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_986762, tmp_986763, *target));
unref_integer_reg(tmp_986762);
unref_integer_reg(tmp_986763);
}
}

void compiler_tmp_986758 (reg_t *target, int foreign_target, void **env)
/*
(+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL))
*/
{
{
reg_t tmp_986759, tmp_986760;
compiler_tmp_986729(&tmp_986759, -1, env);
compiler_tmp_986738(&tmp_986760, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_986759, tmp_986760, *target));
unref_integer_reg(tmp_986759);
unref_integer_reg(tmp_986760);
}
}

void compiler_tmp_986749 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
 ((4)
  (+ (SEX (FIELD DISP8 NIL NIL))
   (+
    (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
     ((5)
      (CASE ((0) (FIELD DISP32 NIL NIL))
       ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
    (CASE
     ((0 1 2 3 5 6 7)
      (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
       (ZEX (FIELD SCALE NIL NIL))))
     ((4) (INTEGER 0)))))))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_986750(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_986754(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_986754 (reg_t *target, int foreign_target, void **env)
/*
(+ (SEX (FIELD DISP8 NIL NIL))
 (+
  (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
   ((5)
    (CASE ((0) (FIELD DISP32 NIL NIL))
     ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
  (CASE
   ((0 1 2 3 5 6 7)
    (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
     (ZEX (FIELD SCALE NIL NIL))))
   ((4) (INTEGER 0)))))
*/
{
{
reg_t tmp_986755, tmp_986756;
compiler_tmp_986753(&tmp_986755, -1, env);
compiler_tmp_986731(&tmp_986756, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_986755, tmp_986756, *target));
unref_integer_reg(tmp_986755);
unref_integer_reg(tmp_986756);
}
}

void compiler_tmp_986750 (reg_t *target, int foreign_target, void **env)
/*
(+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL)))
*/
{
{
reg_t tmp_986751, tmp_986752;
compiler_tmp_986729(&tmp_986751, -1, env);
compiler_tmp_986753(&tmp_986752, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_986751, tmp_986752, *target));
unref_integer_reg(tmp_986751);
unref_integer_reg(tmp_986752);
}
}

void compiler_tmp_986753 (reg_t *target, int foreign_target, void **env)
/*
(SEX (FIELD DISP8 NIL NIL))
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
}

void compiler_tmp_986728 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
 ((4)
  (+
   (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
    ((5)
     (CASE ((0) (FIELD DISP32 NIL NIL))
      ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
   (CASE
    ((0 1 2 3 5 6 7)
     (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
      (ZEX (FIELD SCALE NIL NIL))))
    ((4) (INTEGER 0)))))
 ((5) (FIELD DISP32 NIL NIL)))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 6:
case 7:
compiler_tmp_986729(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_986731(&(*target), foreign_target, env);
break;
case 5:
compiler_tmp_986738(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_986731 (reg_t *target, int foreign_target, void **env)
/*
(+
 (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
  ((5)
   (CASE ((0) (FIELD DISP32 NIL NIL))
    ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
 (CASE
  ((0 1 2 3 5 6 7)
   (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
    (ZEX (FIELD SCALE NIL NIL))))
  ((4) (INTEGER 0))))
*/
{
{
reg_t tmp_986732, tmp_986733;
compiler_tmp_986734(&tmp_986732, -1, env);
compiler_tmp_986741(&tmp_986733, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_986732, tmp_986733, *target));
unref_integer_reg(tmp_986732);
unref_integer_reg(tmp_986733);
}
}

void compiler_tmp_986741 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
   (ZEX (FIELD SCALE NIL NIL))))
 ((4) (INTEGER 0)))
*/
{
switch (index) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_986742(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_986748(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_986748 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_986742 (reg_t *target, int foreign_target, void **env)
/*
(SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL)) (ZEX (FIELD SCALE NIL NIL)))
*/
{
{
reg_t tmp_986743, tmp_986744;
compiler_tmp_986745(&tmp_986743, -1, env);
compiler_tmp_986747(&tmp_986744, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_SLL(tmp_986743, tmp_986744, *target));
unref_integer_reg(tmp_986743);
unref_integer_reg(tmp_986744);
emit(COMPOSE_ADDL((*target), 31, (*target)));
}
}

void compiler_tmp_986747 (reg_t *target, int foreign_target, void **env)
/*
(ZEX (FIELD SCALE NIL NIL))
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, scale);
}

void compiler_tmp_986745 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD INDEX NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + index));
else {
reg_t tmp_986746 = ref_integer_reg_for_reading((0 + index));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_986746, *target));
unref_integer_reg(tmp_986746);
}
}

void compiler_tmp_986734 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
 ((5)
  (CASE ((0) (FIELD DISP32 NIL NIL))
   ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
*/
{
switch (base) {
case 0:
case 1:
case 2:
case 3:
case 4:
case 6:
case 7:
compiler_tmp_986735(&(*target), foreign_target, env);
break;
case 5:
compiler_tmp_986737(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_986737 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0) (FIELD DISP32 NIL NIL)) ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))
*/
{
switch (mod) {
case 0:
compiler_tmp_986738(&(*target), foreign_target, env);
break;
case 1:
case 2:
case 3:
compiler_tmp_986739(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_986739 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER EBP GPR (INTEGER 5))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading(5);
else {
reg_t tmp_986740 = ref_integer_reg_for_reading(5);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_986740, *target));
unref_integer_reg(tmp_986740);
}
}

void compiler_tmp_986738 (reg_t *target, int foreign_target, void **env)
/*
(FIELD DISP32 NIL NIL)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, disp32);
}

void compiler_tmp_986735 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD BASE NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + base));
else {
reg_t tmp_986736 = ref_integer_reg_for_reading((0 + base));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_986736, *target));
unref_integer_reg(tmp_986736);
}
}

void compiler_tmp_986729 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD RM NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + rm));
else {
reg_t tmp_986730 = ref_integer_reg_for_reading((0 + rm));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_986730, *target));
unref_integer_reg(tmp_986730);
}
}

void compile_sub_rm32_r32_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_986718;
killed |= 0x1;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_986766(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_986768;
killed |= 0x800;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_986778(rhs_func, env);
}
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_987199();
goto next_tmp_986781;
next_tmp_986781:
goto finish_tmp_986780;
finish_tmp_986780:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_987679();
goto next_tmp_987202;
next_tmp_987202:
goto finish_tmp_987201;
finish_tmp_987201:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_988203();
goto next_tmp_987682;
next_tmp_987682:
goto finish_tmp_987681;
finish_tmp_987681:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_988624();
goto next_tmp_988206;
next_tmp_988206:
goto finish_tmp_988205;
finish_tmp_988205:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_989106();
goto next_tmp_988627;
next_tmp_988627:
goto finish_tmp_988626;
finish_tmp_988626:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_989600();
goto next_tmp_989109;
next_tmp_989109:
goto finish_tmp_989108;
finish_tmp_989108:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_989923();
goto next_tmp_989603;
next_tmp_989603:
goto finish_tmp_989602;
finish_tmp_989602:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; }))
{
genfunc_tmp_989923();
goto next_tmp_989926;
next_tmp_989926:
goto finish_tmp_989925;
finish_tmp_989925:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_990413();
goto next_tmp_989929;
next_tmp_989929:
goto finish_tmp_989928;
finish_tmp_989928:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_990907();
goto next_tmp_990416;
next_tmp_990416:
goto finish_tmp_990415;
finish_tmp_990415:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_991401();
goto next_tmp_990910;
next_tmp_990910:
goto finish_tmp_990909;
finish_tmp_990909:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_991883();
goto next_tmp_991404;
next_tmp_991404:
goto finish_tmp_991403;
finish_tmp_991403:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_992404();
goto next_tmp_991886;
next_tmp_991886:
goto finish_tmp_991885;
finish_tmp_991885:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_992929();
goto next_tmp_992407;
next_tmp_992407:
goto finish_tmp_992406;
finish_tmp_992406:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_993411();
goto next_tmp_992932;
next_tmp_992932:
goto finish_tmp_992931;
finish_tmp_992931:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_993898();
goto next_tmp_993414;
next_tmp_993414:
goto finish_tmp_993413;
finish_tmp_993413:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_994392();
goto next_tmp_993901;
next_tmp_993901:
goto finish_tmp_993900;
finish_tmp_993900:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_994886();
goto next_tmp_994395;
next_tmp_994395:
goto finish_tmp_994394;
finish_tmp_994394:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_995368();
goto next_tmp_994889;
next_tmp_994889:
goto finish_tmp_994888;
finish_tmp_994888:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_995862();
goto next_tmp_995371;
next_tmp_995371:
goto finish_tmp_995370;
finish_tmp_995370:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_996356();
goto next_tmp_995865;
next_tmp_995865:
goto finish_tmp_995864;
finish_tmp_995864:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_996838();
goto next_tmp_996359;
next_tmp_996359:
goto finish_tmp_996358;
finish_tmp_996358:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 3; })&& ({ word_2 tmp = mod; 0 || tmp == 3; }))
{
genfunc_tmp_996999();
goto next_tmp_996841;
next_tmp_996841:
goto finish_tmp_996840;
finish_tmp_996840:
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_997001;
killed |= 0x80;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_997011(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_997013;
killed |= 0x40;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_997022(rhs_func, env);
}
}
}
void genfunc_tmp_996999 (void) {
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
tmp_981576 = ref_gpr_reg_for_reading(0 + rm);
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981575);
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 1 */
}
done_tmp_996998:
}
reg_t genfunc_tmp_996940 (void) {
reg_t tmp_996843;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
tmp_981576 = ref_gpr_reg_for_reading(0 + rm);
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_996843 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 1 */
}
done_tmp_996939:
return tmp_996843;
}
reg_t genfunc_tmp_996900 (void) {
reg_t tmp_996859;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
tmp_981576 = ref_gpr_reg_for_reading(0 + rm);
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_996859 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 1 */
}
done_tmp_996899:
return tmp_996859;
}
void genfunc_tmp_996838 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_996520();
goto next_tmp_996363;
next_tmp_996363:
goto tmp_996362;
tmp_996362:
}
{
tmp_981603 = genfunc_tmp_996835();
goto next_tmp_996524;
next_tmp_996524:
goto tmp_996523;
tmp_996523:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_996837:
}
reg_t genfunc_tmp_996835 (void) {
reg_t tmp_996522;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_996784();
goto next_tmp_996827;
next_tmp_996827:
goto tmp_996826;
tmp_996826:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_996522 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_996834:
return tmp_996522;
}
reg_t genfunc_tmp_996787 (void) {
reg_t tmp_996538;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_996784();
goto next_tmp_996580;
next_tmp_996580:
goto tmp_996579;
tmp_996579:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_996538 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_996786:
return tmp_996538;
}
reg_t genfunc_tmp_996784 (void) {
reg_t tmp_996578;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_996520();
goto next_tmp_996758;
next_tmp_996758:
goto tmp_996757;
tmp_996757:
}
tmp_981838 = tmp_996578 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_996783:
return tmp_996578;
}
reg_t genfunc_tmp_996727 (void) {
reg_t tmp_996663;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_996688 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_996688 >> 8) == 0)
field_imm = tmp_996688;
else goto fail_tmp_996687;
}
/* commit */
{
tmp_982315 = genfunc_tmp_996639();
goto next_tmp_996691;
next_tmp_996691:
goto tmp_996690;
tmp_996690:
}
tmp_982314 = tmp_996663 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_996726;
fail_tmp_996687:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_996716 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_996716))
field_imm = inv_maskmask(8, tmp_996716);
else goto fail_tmp_996715;
}
/* commit */
{
tmp_981532 = genfunc_tmp_996639();
goto next_tmp_996719;
next_tmp_996719:
goto tmp_996718;
tmp_996718:
}
tmp_981531 = tmp_996663 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_996726;
fail_tmp_996715:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_996639();
goto next_tmp_996724;
next_tmp_996724:
goto tmp_996723;
tmp_996723:
}
tmp_981523 = tmp_996663 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_996726:
return tmp_996663;
}
reg_t genfunc_tmp_996639 (void) {
reg_t tmp_996594;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_996520();
goto next_tmp_996636;
next_tmp_996636:
goto tmp_996635;
tmp_996635:
}
tmp_981838 = tmp_996594 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_996638:
return tmp_996594;
}
reg_t genfunc_tmp_996520 (void) {
reg_t tmp_996361;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_996479 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_996479 >> 8) == 0)
field_imm = tmp_996479;
else goto fail_tmp_996478;
}
/* commit */
{
tmp_982315 = genfunc_tmp_996408();
goto next_tmp_996482;
next_tmp_996482:
goto tmp_996481;
tmp_996481:
}
tmp_982314 = tmp_996361 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_996519;
fail_tmp_996478:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_996509 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_996509))
field_imm = inv_maskmask(8, tmp_996509);
else goto fail_tmp_996508;
}
/* commit */
{
tmp_981532 = genfunc_tmp_996408();
goto next_tmp_996512;
next_tmp_996512:
goto tmp_996511;
tmp_996511:
}
tmp_981531 = tmp_996361 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_996519;
fail_tmp_996508:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_996408();
goto next_tmp_996517;
next_tmp_996517:
goto tmp_996516;
tmp_996516:
}
tmp_981523 = tmp_996361 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_996519:
return tmp_996361;
}
reg_t genfunc_tmp_996476 (void) {
reg_t tmp_996412;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_996437 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_996437 >> 8) == 0)
field_imm = tmp_996437;
else goto fail_tmp_996436;
}
/* commit */
{
tmp_982315 = genfunc_tmp_996408();
goto next_tmp_996440;
next_tmp_996440:
goto tmp_996439;
tmp_996439:
}
tmp_982314 = tmp_996412 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_996475;
fail_tmp_996436:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_996465 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_996465))
field_imm = inv_maskmask(8, tmp_996465);
else goto fail_tmp_996464;
}
/* commit */
{
tmp_981532 = genfunc_tmp_996408();
goto next_tmp_996468;
next_tmp_996468:
goto tmp_996467;
tmp_996467:
}
tmp_981531 = tmp_996412 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_996475;
fail_tmp_996464:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_996408();
goto next_tmp_996473;
next_tmp_996473:
goto tmp_996472;
tmp_996472:
}
tmp_981523 = tmp_996412 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_996475:
return tmp_996412;
}
reg_t genfunc_tmp_996408 (void) {
reg_t tmp_996377;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_996405;
field_ra = 31;
/* commit */
tmp_981699 = ref_gpr_reg_for_reading(0 + 5);
tmp_981697 = tmp_996377 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 1 */
}
goto done_tmp_996407;
fail_tmp_996405:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_996406;
field_ra = 31;
/* commit */
tmp_981667 = ref_gpr_reg_for_reading(0 + 5);
tmp_981665 = tmp_996377 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 1 */
}
goto done_tmp_996407;
fail_tmp_996406:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_982357 = ref_gpr_reg_for_reading(0 + 5);
tmp_982354 = tmp_996377 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_996407:
return tmp_996377;
}
void genfunc_tmp_996356 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_996038();
goto next_tmp_995869;
next_tmp_995869:
goto tmp_995868;
tmp_995868:
}
{
tmp_981603 = genfunc_tmp_996353();
goto next_tmp_996042;
next_tmp_996042:
goto tmp_996041;
tmp_996041:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 13 */
}
done_tmp_996355:
}
reg_t genfunc_tmp_996353 (void) {
reg_t tmp_996040;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_996302();
goto next_tmp_996345;
next_tmp_996345:
goto tmp_996344;
tmp_996344:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_996040 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 7 */
}
done_tmp_996352:
return tmp_996040;
}
reg_t genfunc_tmp_996305 (void) {
reg_t tmp_996056;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_996302();
goto next_tmp_996098;
next_tmp_996098:
goto tmp_996097;
tmp_996097:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_996056 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 7 */
}
done_tmp_996304:
return tmp_996056;
}
reg_t genfunc_tmp_996302 (void) {
reg_t tmp_996096;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_996038();
goto next_tmp_996276;
next_tmp_996276:
goto tmp_996275;
tmp_996275:
}
tmp_981838 = tmp_996096 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_996301:
return tmp_996096;
}
reg_t genfunc_tmp_996245 (void) {
reg_t tmp_996181;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_996206 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_996206 >> 8) == 0)
field_imm = tmp_996206;
else goto fail_tmp_996205;
}
/* commit */
{
tmp_982315 = genfunc_tmp_996157();
goto next_tmp_996209;
next_tmp_996209:
goto tmp_996208;
tmp_996208:
}
tmp_982314 = tmp_996181 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 7 */
}
goto done_tmp_996244;
fail_tmp_996205:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_996234 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_996234))
field_imm = inv_maskmask(8, tmp_996234);
else goto fail_tmp_996233;
}
/* commit */
{
tmp_981532 = genfunc_tmp_996157();
goto next_tmp_996237;
next_tmp_996237:
goto tmp_996236;
tmp_996236:
}
tmp_981531 = tmp_996181 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 7 */
}
goto done_tmp_996244;
fail_tmp_996233:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_996157();
goto next_tmp_996242;
next_tmp_996242:
goto tmp_996241;
tmp_996241:
}
tmp_981523 = tmp_996181 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 7 */
}
done_tmp_996244:
return tmp_996181;
}
reg_t genfunc_tmp_996157 (void) {
reg_t tmp_996112;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_996038();
goto next_tmp_996154;
next_tmp_996154:
goto tmp_996153;
tmp_996153:
}
tmp_981838 = tmp_996112 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_996156:
return tmp_996112;
}
reg_t genfunc_tmp_996038 (void) {
reg_t tmp_995867;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_995997 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_995997 >> 8) == 0)
field_imm = tmp_995997;
else goto fail_tmp_995996;
}
/* commit */
{
tmp_982315 = genfunc_tmp_995926();
goto next_tmp_996000;
next_tmp_996000:
goto tmp_995999;
tmp_995999:
}
tmp_982314 = tmp_995867 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_996037;
fail_tmp_995996:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_996027 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_996027))
field_imm = inv_maskmask(8, tmp_996027);
else goto fail_tmp_996026;
}
/* commit */
{
tmp_981532 = genfunc_tmp_995926();
goto next_tmp_996030;
next_tmp_996030:
goto tmp_996029;
tmp_996029:
}
tmp_981531 = tmp_995867 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_996037;
fail_tmp_996026:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_995926();
goto next_tmp_996035;
next_tmp_996035:
goto tmp_996034;
tmp_996034:
}
tmp_981523 = tmp_995867 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_996037:
return tmp_995867;
}
reg_t genfunc_tmp_995994 (void) {
reg_t tmp_995930;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_995955 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_995955 >> 8) == 0)
field_imm = tmp_995955;
else goto fail_tmp_995954;
}
/* commit */
{
tmp_982315 = genfunc_tmp_995926();
goto next_tmp_995958;
next_tmp_995958:
goto tmp_995957;
tmp_995957:
}
tmp_982314 = tmp_995930 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_995993;
fail_tmp_995954:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_995983 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_995983))
field_imm = inv_maskmask(8, tmp_995983);
else goto fail_tmp_995982;
}
/* commit */
{
tmp_981532 = genfunc_tmp_995926();
goto next_tmp_995986;
next_tmp_995986:
goto tmp_995985;
tmp_995985:
}
tmp_981531 = tmp_995930 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_995993;
fail_tmp_995982:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_995926();
goto next_tmp_995991;
next_tmp_995991:
goto tmp_995990;
tmp_995990:
}
tmp_981523 = tmp_995930 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_995993:
return tmp_995930;
}
reg_t genfunc_tmp_995926 (void) {
reg_t tmp_995883;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_995915;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_992465();
goto next_tmp_995918;
next_tmp_995918:
goto tmp_995917;
tmp_995917:
}
tmp_981697 = tmp_995883 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 3 */
}
goto done_tmp_995925;
fail_tmp_995915:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_995920;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_992465();
goto next_tmp_995923;
next_tmp_995923:
goto tmp_995922;
tmp_995922:
}
tmp_981665 = tmp_995883 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 3 */
}
goto done_tmp_995925;
fail_tmp_995920:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_982357 = genfunc_tmp_992465();
goto next_tmp_995892;
next_tmp_995892:
goto tmp_995891;
tmp_995891:
}
tmp_982354 = tmp_995883 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 4 */
}
done_tmp_995925:
return tmp_995883;
}
void genfunc_tmp_995862 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_995544();
goto next_tmp_995375;
next_tmp_995375:
goto tmp_995374;
tmp_995374:
}
{
tmp_981603 = genfunc_tmp_995859();
goto next_tmp_995548;
next_tmp_995548:
goto tmp_995547;
tmp_995547:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 11 */
}
done_tmp_995861:
}
reg_t genfunc_tmp_995859 (void) {
reg_t tmp_995546;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_995808();
goto next_tmp_995851;
next_tmp_995851:
goto tmp_995850;
tmp_995850:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_995546 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 6 */
}
done_tmp_995858:
return tmp_995546;
}
reg_t genfunc_tmp_995811 (void) {
reg_t tmp_995562;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_995808();
goto next_tmp_995604;
next_tmp_995604:
goto tmp_995603;
tmp_995603:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_995562 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 6 */
}
done_tmp_995810:
return tmp_995562;
}
reg_t genfunc_tmp_995808 (void) {
reg_t tmp_995602;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_995544();
goto next_tmp_995782;
next_tmp_995782:
goto tmp_995781;
tmp_995781:
}
tmp_981838 = tmp_995602 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_995807:
return tmp_995602;
}
reg_t genfunc_tmp_995751 (void) {
reg_t tmp_995687;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_995712 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_995712 >> 8) == 0)
field_imm = tmp_995712;
else goto fail_tmp_995711;
}
/* commit */
{
tmp_982315 = genfunc_tmp_995663();
goto next_tmp_995715;
next_tmp_995715:
goto tmp_995714;
tmp_995714:
}
tmp_982314 = tmp_995687 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 6 */
}
goto done_tmp_995750;
fail_tmp_995711:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_995740 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_995740))
field_imm = inv_maskmask(8, tmp_995740);
else goto fail_tmp_995739;
}
/* commit */
{
tmp_981532 = genfunc_tmp_995663();
goto next_tmp_995743;
next_tmp_995743:
goto tmp_995742;
tmp_995742:
}
tmp_981531 = tmp_995687 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 6 */
}
goto done_tmp_995750;
fail_tmp_995739:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_995663();
goto next_tmp_995748;
next_tmp_995748:
goto tmp_995747;
tmp_995747:
}
tmp_981523 = tmp_995687 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 6 */
}
done_tmp_995750:
return tmp_995687;
}
reg_t genfunc_tmp_995663 (void) {
reg_t tmp_995618;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_995544();
goto next_tmp_995660;
next_tmp_995660:
goto tmp_995659;
tmp_995659:
}
tmp_981838 = tmp_995618 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_995662:
return tmp_995618;
}
reg_t genfunc_tmp_995544 (void) {
reg_t tmp_995373;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_995503 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_995503 >> 8) == 0)
field_imm = tmp_995503;
else goto fail_tmp_995502;
}
/* commit */
{
tmp_982315 = genfunc_tmp_995432();
goto next_tmp_995506;
next_tmp_995506:
goto tmp_995505;
tmp_995505:
}
tmp_982314 = tmp_995373 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_995543;
fail_tmp_995502:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_995533 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_995533))
field_imm = inv_maskmask(8, tmp_995533);
else goto fail_tmp_995532;
}
/* commit */
{
tmp_981532 = genfunc_tmp_995432();
goto next_tmp_995536;
next_tmp_995536:
goto tmp_995535;
tmp_995535:
}
tmp_981531 = tmp_995373 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_995543;
fail_tmp_995532:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_995432();
goto next_tmp_995541;
next_tmp_995541:
goto tmp_995540;
tmp_995540:
}
tmp_981523 = tmp_995373 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_995543:
return tmp_995373;
}
reg_t genfunc_tmp_995500 (void) {
reg_t tmp_995436;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_995461 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_995461 >> 8) == 0)
field_imm = tmp_995461;
else goto fail_tmp_995460;
}
/* commit */
{
tmp_982315 = genfunc_tmp_995432();
goto next_tmp_995464;
next_tmp_995464:
goto tmp_995463;
tmp_995463:
}
tmp_982314 = tmp_995436 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_995499;
fail_tmp_995460:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_995489 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_995489))
field_imm = inv_maskmask(8, tmp_995489);
else goto fail_tmp_995488;
}
/* commit */
{
tmp_981532 = genfunc_tmp_995432();
goto next_tmp_995492;
next_tmp_995492:
goto tmp_995491;
tmp_995491:
}
tmp_981531 = tmp_995436 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_995499;
fail_tmp_995488:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_995432();
goto next_tmp_995497;
next_tmp_995497:
goto tmp_995496;
tmp_995496:
}
tmp_981523 = tmp_995436 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_995499:
return tmp_995436;
}
reg_t genfunc_tmp_995432 (void) {
reg_t tmp_995389;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_995421;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_991940();
goto next_tmp_995424;
next_tmp_995424:
goto tmp_995423;
tmp_995423:
}
tmp_981697 = tmp_995389 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 2 */
}
goto done_tmp_995431;
fail_tmp_995421:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_995426;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_991940();
goto next_tmp_995429;
next_tmp_995429:
goto tmp_995428;
tmp_995428:
}
tmp_981665 = tmp_995389 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 2 */
}
goto done_tmp_995431;
fail_tmp_995426:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_982357 = genfunc_tmp_991940();
goto next_tmp_995398;
next_tmp_995398:
goto tmp_995397;
tmp_995397:
}
tmp_982354 = tmp_995389 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 3 */
}
done_tmp_995431:
return tmp_995389;
}
void genfunc_tmp_995368 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_995050();
goto next_tmp_994893;
next_tmp_994893:
goto tmp_994892;
tmp_994892:
}
{
tmp_981603 = genfunc_tmp_995365();
goto next_tmp_995054;
next_tmp_995054:
goto tmp_995053;
tmp_995053:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_995367:
}
reg_t genfunc_tmp_995365 (void) {
reg_t tmp_995052;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_995314();
goto next_tmp_995357;
next_tmp_995357:
goto tmp_995356;
tmp_995356:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_995052 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_995364:
return tmp_995052;
}
reg_t genfunc_tmp_995317 (void) {
reg_t tmp_995068;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_995314();
goto next_tmp_995110;
next_tmp_995110:
goto tmp_995109;
tmp_995109:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_995068 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_995316:
return tmp_995068;
}
reg_t genfunc_tmp_995314 (void) {
reg_t tmp_995108;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_995050();
goto next_tmp_995288;
next_tmp_995288:
goto tmp_995287;
tmp_995287:
}
tmp_981838 = tmp_995108 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_995313:
return tmp_995108;
}
reg_t genfunc_tmp_995257 (void) {
reg_t tmp_995193;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_995218 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_995218 >> 8) == 0)
field_imm = tmp_995218;
else goto fail_tmp_995217;
}
/* commit */
{
tmp_982315 = genfunc_tmp_995169();
goto next_tmp_995221;
next_tmp_995221:
goto tmp_995220;
tmp_995220:
}
tmp_982314 = tmp_995193 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_995256;
fail_tmp_995217:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_995246 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_995246))
field_imm = inv_maskmask(8, tmp_995246);
else goto fail_tmp_995245;
}
/* commit */
{
tmp_981532 = genfunc_tmp_995169();
goto next_tmp_995249;
next_tmp_995249:
goto tmp_995248;
tmp_995248:
}
tmp_981531 = tmp_995193 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_995256;
fail_tmp_995245:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_995169();
goto next_tmp_995254;
next_tmp_995254:
goto tmp_995253;
tmp_995253:
}
tmp_981523 = tmp_995193 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_995256:
return tmp_995193;
}
reg_t genfunc_tmp_995169 (void) {
reg_t tmp_995124;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_995050();
goto next_tmp_995166;
next_tmp_995166:
goto tmp_995165;
tmp_995165:
}
tmp_981838 = tmp_995124 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_995168:
return tmp_995124;
}
reg_t genfunc_tmp_995050 (void) {
reg_t tmp_994891;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_995009 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_995009 >> 8) == 0)
field_imm = tmp_995009;
else goto fail_tmp_995008;
}
/* commit */
{
tmp_982315 = genfunc_tmp_994938();
goto next_tmp_995012;
next_tmp_995012:
goto tmp_995011;
tmp_995011:
}
tmp_982314 = tmp_994891 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_995049;
fail_tmp_995008:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_995039 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_995039))
field_imm = inv_maskmask(8, tmp_995039);
else goto fail_tmp_995038;
}
/* commit */
{
tmp_981532 = genfunc_tmp_994938();
goto next_tmp_995042;
next_tmp_995042:
goto tmp_995041;
tmp_995041:
}
tmp_981531 = tmp_994891 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_995049;
fail_tmp_995038:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_994938();
goto next_tmp_995047;
next_tmp_995047:
goto tmp_995046;
tmp_995046:
}
tmp_981523 = tmp_994891 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_995049:
return tmp_994891;
}
reg_t genfunc_tmp_995006 (void) {
reg_t tmp_994942;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_994967 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_994967 >> 8) == 0)
field_imm = tmp_994967;
else goto fail_tmp_994966;
}
/* commit */
{
tmp_982315 = genfunc_tmp_994938();
goto next_tmp_994970;
next_tmp_994970:
goto tmp_994969;
tmp_994969:
}
tmp_982314 = tmp_994942 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_995005;
fail_tmp_994966:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_994995 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_994995))
field_imm = inv_maskmask(8, tmp_994995);
else goto fail_tmp_994994;
}
/* commit */
{
tmp_981532 = genfunc_tmp_994938();
goto next_tmp_994998;
next_tmp_994998:
goto tmp_994997;
tmp_994997:
}
tmp_981531 = tmp_994942 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_995005;
fail_tmp_994994:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_994938();
goto next_tmp_995003;
next_tmp_995003:
goto tmp_995002;
tmp_995002:
}
tmp_981523 = tmp_994942 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_995005:
return tmp_994942;
}
reg_t genfunc_tmp_994938 (void) {
reg_t tmp_994907;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_994935;
field_ra = 31;
/* commit */
tmp_981699 = ref_gpr_reg_for_reading(0 + base);
tmp_981697 = tmp_994907 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 1 */
}
goto done_tmp_994937;
fail_tmp_994935:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_994936;
field_ra = 31;
/* commit */
tmp_981667 = ref_gpr_reg_for_reading(0 + base);
tmp_981665 = tmp_994907 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 1 */
}
goto done_tmp_994937;
fail_tmp_994936:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_982357 = ref_gpr_reg_for_reading(0 + base);
tmp_982354 = tmp_994907 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_994937:
return tmp_994907;
}
void genfunc_tmp_994886 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_994568();
goto next_tmp_994399;
next_tmp_994399:
goto tmp_994398;
tmp_994398:
}
{
tmp_981603 = genfunc_tmp_994883();
goto next_tmp_994572;
next_tmp_994572:
goto tmp_994571;
tmp_994571:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 13 */
}
done_tmp_994885:
}
reg_t genfunc_tmp_994883 (void) {
reg_t tmp_994570;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_994832();
goto next_tmp_994875;
next_tmp_994875:
goto tmp_994874;
tmp_994874:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_994570 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 7 */
}
done_tmp_994882:
return tmp_994570;
}
reg_t genfunc_tmp_994835 (void) {
reg_t tmp_994586;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_994832();
goto next_tmp_994628;
next_tmp_994628:
goto tmp_994627;
tmp_994627:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_994586 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 7 */
}
done_tmp_994834:
return tmp_994586;
}
reg_t genfunc_tmp_994832 (void) {
reg_t tmp_994626;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_994568();
goto next_tmp_994806;
next_tmp_994806:
goto tmp_994805;
tmp_994805:
}
tmp_981838 = tmp_994626 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_994831:
return tmp_994626;
}
reg_t genfunc_tmp_994775 (void) {
reg_t tmp_994711;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_994736 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_994736 >> 8) == 0)
field_imm = tmp_994736;
else goto fail_tmp_994735;
}
/* commit */
{
tmp_982315 = genfunc_tmp_994687();
goto next_tmp_994739;
next_tmp_994739:
goto tmp_994738;
tmp_994738:
}
tmp_982314 = tmp_994711 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 7 */
}
goto done_tmp_994774;
fail_tmp_994735:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_994764 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_994764))
field_imm = inv_maskmask(8, tmp_994764);
else goto fail_tmp_994763;
}
/* commit */
{
tmp_981532 = genfunc_tmp_994687();
goto next_tmp_994767;
next_tmp_994767:
goto tmp_994766;
tmp_994766:
}
tmp_981531 = tmp_994711 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 7 */
}
goto done_tmp_994774;
fail_tmp_994763:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_994687();
goto next_tmp_994772;
next_tmp_994772:
goto tmp_994771;
tmp_994771:
}
tmp_981523 = tmp_994711 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 7 */
}
done_tmp_994774:
return tmp_994711;
}
reg_t genfunc_tmp_994687 (void) {
reg_t tmp_994642;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_994568();
goto next_tmp_994684;
next_tmp_994684:
goto tmp_994683;
tmp_994683:
}
tmp_981838 = tmp_994642 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_994686:
return tmp_994642;
}
reg_t genfunc_tmp_994568 (void) {
reg_t tmp_994397;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_994527 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_994527 >> 8) == 0)
field_imm = tmp_994527;
else goto fail_tmp_994526;
}
/* commit */
{
tmp_982315 = genfunc_tmp_994456();
goto next_tmp_994530;
next_tmp_994530:
goto tmp_994529;
tmp_994529:
}
tmp_982314 = tmp_994397 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_994567;
fail_tmp_994526:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_994557 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_994557))
field_imm = inv_maskmask(8, tmp_994557);
else goto fail_tmp_994556;
}
/* commit */
{
tmp_981532 = genfunc_tmp_994456();
goto next_tmp_994560;
next_tmp_994560:
goto tmp_994559;
tmp_994559:
}
tmp_981531 = tmp_994397 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_994567;
fail_tmp_994556:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_994456();
goto next_tmp_994565;
next_tmp_994565:
goto tmp_994564;
tmp_994564:
}
tmp_981523 = tmp_994397 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_994567:
return tmp_994397;
}
reg_t genfunc_tmp_994524 (void) {
reg_t tmp_994460;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_994485 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_994485 >> 8) == 0)
field_imm = tmp_994485;
else goto fail_tmp_994484;
}
/* commit */
{
tmp_982315 = genfunc_tmp_994456();
goto next_tmp_994488;
next_tmp_994488:
goto tmp_994487;
tmp_994487:
}
tmp_982314 = tmp_994460 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_994523;
fail_tmp_994484:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_994513 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_994513))
field_imm = inv_maskmask(8, tmp_994513);
else goto fail_tmp_994512;
}
/* commit */
{
tmp_981532 = genfunc_tmp_994456();
goto next_tmp_994516;
next_tmp_994516:
goto tmp_994515;
tmp_994515:
}
tmp_981531 = tmp_994460 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_994523;
fail_tmp_994512:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_994456();
goto next_tmp_994521;
next_tmp_994521:
goto tmp_994520;
tmp_994520:
}
tmp_981523 = tmp_994460 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_994523:
return tmp_994460;
}
reg_t genfunc_tmp_994456 (void) {
reg_t tmp_994413;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_994445;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_987773();
goto next_tmp_994448;
next_tmp_994448:
goto tmp_994447;
tmp_994447:
}
tmp_981697 = tmp_994413 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 3 */
}
goto done_tmp_994455;
fail_tmp_994445:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_994450;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_987773();
goto next_tmp_994453;
next_tmp_994453:
goto tmp_994452;
tmp_994452:
}
tmp_981665 = tmp_994413 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 3 */
}
goto done_tmp_994455;
fail_tmp_994450:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_982357 = genfunc_tmp_987773();
goto next_tmp_994422;
next_tmp_994422:
goto tmp_994421;
tmp_994421:
}
tmp_982354 = tmp_994413 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 4 */
}
done_tmp_994455:
return tmp_994413;
}
void genfunc_tmp_994392 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_994074();
goto next_tmp_993905;
next_tmp_993905:
goto tmp_993904;
tmp_993904:
}
{
tmp_981603 = genfunc_tmp_994389();
goto next_tmp_994078;
next_tmp_994078:
goto tmp_994077;
tmp_994077:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 11 */
}
done_tmp_994391:
}
reg_t genfunc_tmp_994389 (void) {
reg_t tmp_994076;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_994338();
goto next_tmp_994381;
next_tmp_994381:
goto tmp_994380;
tmp_994380:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_994076 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 6 */
}
done_tmp_994388:
return tmp_994076;
}
reg_t genfunc_tmp_994341 (void) {
reg_t tmp_994092;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_994338();
goto next_tmp_994134;
next_tmp_994134:
goto tmp_994133;
tmp_994133:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_994092 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 6 */
}
done_tmp_994340:
return tmp_994092;
}
reg_t genfunc_tmp_994338 (void) {
reg_t tmp_994132;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_994074();
goto next_tmp_994312;
next_tmp_994312:
goto tmp_994311;
tmp_994311:
}
tmp_981838 = tmp_994132 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_994337:
return tmp_994132;
}
reg_t genfunc_tmp_994281 (void) {
reg_t tmp_994217;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_994242 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_994242 >> 8) == 0)
field_imm = tmp_994242;
else goto fail_tmp_994241;
}
/* commit */
{
tmp_982315 = genfunc_tmp_994193();
goto next_tmp_994245;
next_tmp_994245:
goto tmp_994244;
tmp_994244:
}
tmp_982314 = tmp_994217 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 6 */
}
goto done_tmp_994280;
fail_tmp_994241:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_994270 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_994270))
field_imm = inv_maskmask(8, tmp_994270);
else goto fail_tmp_994269;
}
/* commit */
{
tmp_981532 = genfunc_tmp_994193();
goto next_tmp_994273;
next_tmp_994273:
goto tmp_994272;
tmp_994272:
}
tmp_981531 = tmp_994217 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 6 */
}
goto done_tmp_994280;
fail_tmp_994269:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_994193();
goto next_tmp_994278;
next_tmp_994278:
goto tmp_994277;
tmp_994277:
}
tmp_981523 = tmp_994217 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 6 */
}
done_tmp_994280:
return tmp_994217;
}
reg_t genfunc_tmp_994193 (void) {
reg_t tmp_994148;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_994074();
goto next_tmp_994190;
next_tmp_994190:
goto tmp_994189;
tmp_994189:
}
tmp_981838 = tmp_994148 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_994192:
return tmp_994148;
}
reg_t genfunc_tmp_994074 (void) {
reg_t tmp_993903;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_994033 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_994033 >> 8) == 0)
field_imm = tmp_994033;
else goto fail_tmp_994032;
}
/* commit */
{
tmp_982315 = genfunc_tmp_993962();
goto next_tmp_994036;
next_tmp_994036:
goto tmp_994035;
tmp_994035:
}
tmp_982314 = tmp_993903 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_994073;
fail_tmp_994032:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_994063 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_994063))
field_imm = inv_maskmask(8, tmp_994063);
else goto fail_tmp_994062;
}
/* commit */
{
tmp_981532 = genfunc_tmp_993962();
goto next_tmp_994066;
next_tmp_994066:
goto tmp_994065;
tmp_994065:
}
tmp_981531 = tmp_993903 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_994073;
fail_tmp_994062:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_993962();
goto next_tmp_994071;
next_tmp_994071:
goto tmp_994070;
tmp_994070:
}
tmp_981523 = tmp_993903 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_994073:
return tmp_993903;
}
reg_t genfunc_tmp_994030 (void) {
reg_t tmp_993966;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_993991 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_993991 >> 8) == 0)
field_imm = tmp_993991;
else goto fail_tmp_993990;
}
/* commit */
{
tmp_982315 = genfunc_tmp_993962();
goto next_tmp_993994;
next_tmp_993994:
goto tmp_993993;
tmp_993993:
}
tmp_982314 = tmp_993966 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_994029;
fail_tmp_993990:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_994019 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_994019))
field_imm = inv_maskmask(8, tmp_994019);
else goto fail_tmp_994018;
}
/* commit */
{
tmp_981532 = genfunc_tmp_993962();
goto next_tmp_994022;
next_tmp_994022:
goto tmp_994021;
tmp_994021:
}
tmp_981531 = tmp_993966 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_994029;
fail_tmp_994018:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_993962();
goto next_tmp_994027;
next_tmp_994027:
goto tmp_994026;
tmp_994026:
}
tmp_981523 = tmp_993966 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_994029:
return tmp_993966;
}
reg_t genfunc_tmp_993962 (void) {
reg_t tmp_993919;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_993951;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_987249();
goto next_tmp_993954;
next_tmp_993954:
goto tmp_993953;
tmp_993953:
}
tmp_981697 = tmp_993919 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 2 */
}
goto done_tmp_993961;
fail_tmp_993951:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_993956;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_987249();
goto next_tmp_993959;
next_tmp_993959:
goto tmp_993958;
tmp_993958:
}
tmp_981665 = tmp_993919 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 2 */
}
goto done_tmp_993961;
fail_tmp_993956:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_982357 = genfunc_tmp_987249();
goto next_tmp_993928;
next_tmp_993928:
goto tmp_993927;
tmp_993927:
}
tmp_982354 = tmp_993919 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 3 */
}
done_tmp_993961:
return tmp_993919;
}
void genfunc_tmp_993898 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_993580();
goto next_tmp_993418;
next_tmp_993418:
goto tmp_993417;
tmp_993417:
}
{
tmp_981603 = genfunc_tmp_993895();
goto next_tmp_993584;
next_tmp_993584:
goto tmp_993583;
tmp_993583:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_993897:
}
reg_t genfunc_tmp_993895 (void) {
reg_t tmp_993582;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_993844();
goto next_tmp_993887;
next_tmp_993887:
goto tmp_993886;
tmp_993886:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_993582 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_993894:
return tmp_993582;
}
reg_t genfunc_tmp_993847 (void) {
reg_t tmp_993598;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_993844();
goto next_tmp_993640;
next_tmp_993640:
goto tmp_993639;
tmp_993639:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_993598 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_993846:
return tmp_993598;
}
reg_t genfunc_tmp_993844 (void) {
reg_t tmp_993638;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_993580();
goto next_tmp_993818;
next_tmp_993818:
goto tmp_993817;
tmp_993817:
}
tmp_981838 = tmp_993638 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_993843:
return tmp_993638;
}
reg_t genfunc_tmp_993787 (void) {
reg_t tmp_993723;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_993748 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_993748 >> 8) == 0)
field_imm = tmp_993748;
else goto fail_tmp_993747;
}
/* commit */
{
tmp_982315 = genfunc_tmp_993699();
goto next_tmp_993751;
next_tmp_993751:
goto tmp_993750;
tmp_993750:
}
tmp_982314 = tmp_993723 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_993786;
fail_tmp_993747:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_993776 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_993776))
field_imm = inv_maskmask(8, tmp_993776);
else goto fail_tmp_993775;
}
/* commit */
{
tmp_981532 = genfunc_tmp_993699();
goto next_tmp_993779;
next_tmp_993779:
goto tmp_993778;
tmp_993778:
}
tmp_981531 = tmp_993723 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_993786;
fail_tmp_993775:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_993699();
goto next_tmp_993784;
next_tmp_993784:
goto tmp_993783;
tmp_993783:
}
tmp_981523 = tmp_993723 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_993786:
return tmp_993723;
}
reg_t genfunc_tmp_993699 (void) {
reg_t tmp_993654;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_993580();
goto next_tmp_993696;
next_tmp_993696:
goto tmp_993695;
tmp_993695:
}
tmp_981838 = tmp_993654 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_993698:
return tmp_993654;
}
reg_t genfunc_tmp_993580 (void) {
reg_t tmp_993416;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_993539 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_993539 >> 8) == 0)
field_imm = tmp_993539;
else goto fail_tmp_993538;
}
/* commit */
{
tmp_982315 = genfunc_tmp_993468();
goto next_tmp_993542;
next_tmp_993542:
goto tmp_993541;
tmp_993541:
}
tmp_982314 = tmp_993416 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_993579;
fail_tmp_993538:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_993569 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_993569))
field_imm = inv_maskmask(8, tmp_993569);
else goto fail_tmp_993568;
}
/* commit */
{
tmp_981532 = genfunc_tmp_993468();
goto next_tmp_993572;
next_tmp_993572:
goto tmp_993571;
tmp_993571:
}
tmp_981531 = tmp_993416 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_993579;
fail_tmp_993568:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_993468();
goto next_tmp_993577;
next_tmp_993577:
goto tmp_993576;
tmp_993576:
}
tmp_981523 = tmp_993416 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_993579:
return tmp_993416;
}
reg_t genfunc_tmp_993536 (void) {
reg_t tmp_993472;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_993497 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_993497 >> 8) == 0)
field_imm = tmp_993497;
else goto fail_tmp_993496;
}
/* commit */
{
tmp_982315 = genfunc_tmp_993468();
goto next_tmp_993500;
next_tmp_993500:
goto tmp_993499;
tmp_993499:
}
tmp_982314 = tmp_993472 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_993535;
fail_tmp_993496:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_993525 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_993525))
field_imm = inv_maskmask(8, tmp_993525);
else goto fail_tmp_993524;
}
/* commit */
{
tmp_981532 = genfunc_tmp_993468();
goto next_tmp_993528;
next_tmp_993528:
goto tmp_993527;
tmp_993527:
}
tmp_981531 = tmp_993472 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_993535;
fail_tmp_993524:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_993468();
goto next_tmp_993533;
next_tmp_993533:
goto tmp_993532;
tmp_993532:
}
tmp_981523 = tmp_993472 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_993535:
return tmp_993472;
}
reg_t genfunc_tmp_993468 (void) {
reg_t tmp_993432;
/* ADDQ_IMM */
{
word_5 tmp_982350;
word_5 field_rc;
word_5 tmp_982351;
word_5 field_ra;
word_64 tmp_982353;
word_8 field_imm;
tmp_982353 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_993449 = tmp_982353;
if ((tmp_993449 >> 8) == 0)
field_imm = tmp_993449;
else goto fail_tmp_993448;
}
/* commit */
tmp_982351 = ref_gpr_reg_for_reading(0 + rm);
tmp_982350 = tmp_993432 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982350;
field_ra = tmp_982351;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982351);
/* can fail: T   num insns: 1 */
}
goto done_tmp_993467;
fail_tmp_993448:
/* LDA */
{
word_5 tmp_981854;
word_5 field_ra;
word_5 tmp_981855;
word_5 field_rb;
word_64 tmp_981857;
word_16 field_memory_disp;
tmp_981857 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_993460 = tmp_981857;
if ((tmp_993460 >> 16) == 0xFFFFFFFFFFFF || (tmp_993460 >> 16) == 0)
field_memory_disp = (tmp_993460 & 0xFFFF);
else goto fail_tmp_993459;
}
/* commit */
tmp_981855 = ref_gpr_reg_for_reading(0 + rm);
tmp_981854 = tmp_993432 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981854;
field_rb = tmp_981855;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981855);
/* can fail: T   num insns: 1 */
}
goto done_tmp_993467;
fail_tmp_993459:
/* LDAH */
{
word_5 tmp_981850;
word_5 field_ra;
word_5 tmp_981851;
word_5 field_rb;
word_64 tmp_981853;
word_16 field_memory_disp;
tmp_981853 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_993465 = tmp_981853;
if ((tmp_993465 & 0xFFFF) == 0)
{
word_64 tmp_993466 = (tmp_993465 >> 16);
if ((tmp_993466 >> 16) == 0xFFFFFFFFFFFF || (tmp_993466 >> 16) == 0)
field_memory_disp = (tmp_993466 & 0xFFFF);
else goto fail_tmp_993464;
}
else goto fail_tmp_993464;
}
/* commit */
tmp_981851 = ref_gpr_reg_for_reading(0 + rm);
tmp_981850 = tmp_993432 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981850;
field_rb = tmp_981851;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981851);
/* can fail: T   num insns: 1 */
}
goto done_tmp_993467;
fail_tmp_993464:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_reading(0 + rm);
tmp_982357 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982357, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_982354 = tmp_993432 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_993467:
return tmp_993432;
}
void genfunc_tmp_993411 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_993093();
goto next_tmp_992936;
next_tmp_992936:
goto tmp_992935;
tmp_992935:
}
{
tmp_981603 = genfunc_tmp_993408();
goto next_tmp_993097;
next_tmp_993097:
goto tmp_993096;
tmp_993096:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_993410:
}
reg_t genfunc_tmp_993408 (void) {
reg_t tmp_993095;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_993357();
goto next_tmp_993400;
next_tmp_993400:
goto tmp_993399;
tmp_993399:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_993095 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_993407:
return tmp_993095;
}
reg_t genfunc_tmp_993360 (void) {
reg_t tmp_993111;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_993357();
goto next_tmp_993153;
next_tmp_993153:
goto tmp_993152;
tmp_993152:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_993111 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_993359:
return tmp_993111;
}
reg_t genfunc_tmp_993357 (void) {
reg_t tmp_993151;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_993093();
goto next_tmp_993331;
next_tmp_993331:
goto tmp_993330;
tmp_993330:
}
tmp_981838 = tmp_993151 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_993356:
return tmp_993151;
}
reg_t genfunc_tmp_993300 (void) {
reg_t tmp_993236;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_993261 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_993261 >> 8) == 0)
field_imm = tmp_993261;
else goto fail_tmp_993260;
}
/* commit */
{
tmp_982315 = genfunc_tmp_993212();
goto next_tmp_993264;
next_tmp_993264:
goto tmp_993263;
tmp_993263:
}
tmp_982314 = tmp_993236 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_993299;
fail_tmp_993260:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_993289 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_993289))
field_imm = inv_maskmask(8, tmp_993289);
else goto fail_tmp_993288;
}
/* commit */
{
tmp_981532 = genfunc_tmp_993212();
goto next_tmp_993292;
next_tmp_993292:
goto tmp_993291;
tmp_993291:
}
tmp_981531 = tmp_993236 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_993299;
fail_tmp_993288:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_993212();
goto next_tmp_993297;
next_tmp_993297:
goto tmp_993296;
tmp_993296:
}
tmp_981523 = tmp_993236 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_993299:
return tmp_993236;
}
reg_t genfunc_tmp_993212 (void) {
reg_t tmp_993167;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_993093();
goto next_tmp_993209;
next_tmp_993209:
goto tmp_993208;
tmp_993208:
}
tmp_981838 = tmp_993167 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_993211:
return tmp_993167;
}
reg_t genfunc_tmp_993093 (void) {
reg_t tmp_992934;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_993052 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_993052 >> 8) == 0)
field_imm = tmp_993052;
else goto fail_tmp_993051;
}
/* commit */
{
tmp_982315 = genfunc_tmp_992981();
goto next_tmp_993055;
next_tmp_993055:
goto tmp_993054;
tmp_993054:
}
tmp_982314 = tmp_992934 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_993092;
fail_tmp_993051:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_993082 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_993082))
field_imm = inv_maskmask(8, tmp_993082);
else goto fail_tmp_993081;
}
/* commit */
{
tmp_981532 = genfunc_tmp_992981();
goto next_tmp_993085;
next_tmp_993085:
goto tmp_993084;
tmp_993084:
}
tmp_981531 = tmp_992934 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_993092;
fail_tmp_993081:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_992981();
goto next_tmp_993090;
next_tmp_993090:
goto tmp_993089;
tmp_993089:
}
tmp_981523 = tmp_992934 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_993092:
return tmp_992934;
}
reg_t genfunc_tmp_993049 (void) {
reg_t tmp_992985;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_993010 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_993010 >> 8) == 0)
field_imm = tmp_993010;
else goto fail_tmp_993009;
}
/* commit */
{
tmp_982315 = genfunc_tmp_992981();
goto next_tmp_993013;
next_tmp_993013:
goto tmp_993012;
tmp_993012:
}
tmp_982314 = tmp_992985 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_993048;
fail_tmp_993009:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_993038 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_993038))
field_imm = inv_maskmask(8, tmp_993038);
else goto fail_tmp_993037;
}
/* commit */
{
tmp_981532 = genfunc_tmp_992981();
goto next_tmp_993041;
next_tmp_993041:
goto tmp_993040;
tmp_993040:
}
tmp_981531 = tmp_992985 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_993048;
fail_tmp_993037:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_992981();
goto next_tmp_993046;
next_tmp_993046:
goto tmp_993045;
tmp_993045:
}
tmp_981523 = tmp_992985 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_993048:
return tmp_992985;
}
reg_t genfunc_tmp_992981 (void) {
reg_t tmp_992950;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_992978;
field_ra = 31;
/* commit */
tmp_981699 = ref_gpr_reg_for_reading(0 + 5);
tmp_981697 = tmp_992950 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 1 */
}
goto done_tmp_992980;
fail_tmp_992978:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_992979;
field_ra = 31;
/* commit */
tmp_981667 = ref_gpr_reg_for_reading(0 + 5);
tmp_981665 = tmp_992950 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 1 */
}
goto done_tmp_992980;
fail_tmp_992979:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_982357 = ref_gpr_reg_for_reading(0 + 5);
tmp_982354 = tmp_992950 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_992980:
return tmp_992950;
}
void genfunc_tmp_992929 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_992611();
goto next_tmp_992411;
next_tmp_992411:
goto tmp_992410;
tmp_992410:
}
{
tmp_981603 = genfunc_tmp_992926();
goto next_tmp_992615;
next_tmp_992615:
goto tmp_992614;
tmp_992614:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 13 */
}
done_tmp_992928:
}
reg_t genfunc_tmp_992926 (void) {
reg_t tmp_992613;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_992875();
goto next_tmp_992918;
next_tmp_992918:
goto tmp_992917;
tmp_992917:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_992613 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 7 */
}
done_tmp_992925:
return tmp_992613;
}
reg_t genfunc_tmp_992878 (void) {
reg_t tmp_992629;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_992875();
goto next_tmp_992671;
next_tmp_992671:
goto tmp_992670;
tmp_992670:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_992629 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 7 */
}
done_tmp_992877:
return tmp_992629;
}
reg_t genfunc_tmp_992875 (void) {
reg_t tmp_992669;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_992611();
goto next_tmp_992849;
next_tmp_992849:
goto tmp_992848;
tmp_992848:
}
tmp_981838 = tmp_992669 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_992874:
return tmp_992669;
}
reg_t genfunc_tmp_992818 (void) {
reg_t tmp_992754;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_992779 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_992779 >> 8) == 0)
field_imm = tmp_992779;
else goto fail_tmp_992778;
}
/* commit */
{
tmp_982315 = genfunc_tmp_992730();
goto next_tmp_992782;
next_tmp_992782:
goto tmp_992781;
tmp_992781:
}
tmp_982314 = tmp_992754 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 7 */
}
goto done_tmp_992817;
fail_tmp_992778:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_992807 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_992807))
field_imm = inv_maskmask(8, tmp_992807);
else goto fail_tmp_992806;
}
/* commit */
{
tmp_981532 = genfunc_tmp_992730();
goto next_tmp_992810;
next_tmp_992810:
goto tmp_992809;
tmp_992809:
}
tmp_981531 = tmp_992754 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 7 */
}
goto done_tmp_992817;
fail_tmp_992806:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_992730();
goto next_tmp_992815;
next_tmp_992815:
goto tmp_992814;
tmp_992814:
}
tmp_981523 = tmp_992754 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 7 */
}
done_tmp_992817:
return tmp_992754;
}
reg_t genfunc_tmp_992730 (void) {
reg_t tmp_992685;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_992611();
goto next_tmp_992727;
next_tmp_992727:
goto tmp_992726;
tmp_992726:
}
tmp_981838 = tmp_992685 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_992729:
return tmp_992685;
}
reg_t genfunc_tmp_992611 (void) {
reg_t tmp_992409;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_992570 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_992570 >> 8) == 0)
field_imm = tmp_992570;
else goto fail_tmp_992569;
}
/* commit */
{
tmp_982315 = genfunc_tmp_992499();
goto next_tmp_992573;
next_tmp_992573:
goto tmp_992572;
tmp_992572:
}
tmp_982314 = tmp_992409 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_992610;
fail_tmp_992569:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_992600 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_992600))
field_imm = inv_maskmask(8, tmp_992600);
else goto fail_tmp_992599;
}
/* commit */
{
tmp_981532 = genfunc_tmp_992499();
goto next_tmp_992603;
next_tmp_992603:
goto tmp_992602;
tmp_992602:
}
tmp_981531 = tmp_992409 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_992610;
fail_tmp_992599:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_992499();
goto next_tmp_992608;
next_tmp_992608:
goto tmp_992607;
tmp_992607:
}
tmp_981523 = tmp_992409 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_992610:
return tmp_992409;
}
reg_t genfunc_tmp_992567 (void) {
reg_t tmp_992503;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_992528 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_992528 >> 8) == 0)
field_imm = tmp_992528;
else goto fail_tmp_992527;
}
/* commit */
{
tmp_982315 = genfunc_tmp_992499();
goto next_tmp_992531;
next_tmp_992531:
goto tmp_992530;
tmp_992530:
}
tmp_982314 = tmp_992503 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_992566;
fail_tmp_992527:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_992556 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_992556))
field_imm = inv_maskmask(8, tmp_992556);
else goto fail_tmp_992555;
}
/* commit */
{
tmp_981532 = genfunc_tmp_992499();
goto next_tmp_992559;
next_tmp_992559:
goto tmp_992558;
tmp_992558:
}
tmp_981531 = tmp_992503 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_992566;
fail_tmp_992555:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_992499();
goto next_tmp_992564;
next_tmp_992564:
goto tmp_992563;
tmp_992563:
}
tmp_981523 = tmp_992503 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_992566:
return tmp_992503;
}
reg_t genfunc_tmp_992499 (void) {
reg_t tmp_992425;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_992488;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_992465();
goto next_tmp_992491;
next_tmp_992491:
goto tmp_992490;
tmp_992490:
}
tmp_981697 = tmp_992425 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 3 */
}
goto done_tmp_992498;
fail_tmp_992488:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_992493;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_992465();
goto next_tmp_992496;
next_tmp_992496:
goto tmp_992495;
tmp_992495:
}
tmp_981665 = tmp_992425 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 3 */
}
goto done_tmp_992498;
fail_tmp_992493:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_982357 = genfunc_tmp_992465();
goto next_tmp_992434;
next_tmp_992434:
goto tmp_992433;
tmp_992433:
}
tmp_982354 = tmp_992425 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 4 */
}
done_tmp_992498:
return tmp_992425;
}
reg_t genfunc_tmp_992465 (void) {
reg_t tmp_992432;
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_reading(0 + 5);
{
tmp_982357 = genfunc_tmp_987749();
goto next_tmp_992441;
next_tmp_992441:
goto tmp_992440;
tmp_992440:
}
tmp_982354 = tmp_992432 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_992464:
return tmp_992432;
}
void genfunc_tmp_992404 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_992086();
goto next_tmp_991890;
next_tmp_991890:
goto tmp_991889;
tmp_991889:
}
{
tmp_981603 = genfunc_tmp_992401();
goto next_tmp_992090;
next_tmp_992090:
goto tmp_992089;
tmp_992089:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 11 */
}
done_tmp_992403:
}
reg_t genfunc_tmp_992401 (void) {
reg_t tmp_992088;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_992350();
goto next_tmp_992393;
next_tmp_992393:
goto tmp_992392;
tmp_992392:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_992088 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 6 */
}
done_tmp_992400:
return tmp_992088;
}
reg_t genfunc_tmp_992353 (void) {
reg_t tmp_992104;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_992350();
goto next_tmp_992146;
next_tmp_992146:
goto tmp_992145;
tmp_992145:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_992104 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 6 */
}
done_tmp_992352:
return tmp_992104;
}
reg_t genfunc_tmp_992350 (void) {
reg_t tmp_992144;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_992086();
goto next_tmp_992324;
next_tmp_992324:
goto tmp_992323;
tmp_992323:
}
tmp_981838 = tmp_992144 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_992349:
return tmp_992144;
}
reg_t genfunc_tmp_992293 (void) {
reg_t tmp_992229;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_992254 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_992254 >> 8) == 0)
field_imm = tmp_992254;
else goto fail_tmp_992253;
}
/* commit */
{
tmp_982315 = genfunc_tmp_992205();
goto next_tmp_992257;
next_tmp_992257:
goto tmp_992256;
tmp_992256:
}
tmp_982314 = tmp_992229 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 6 */
}
goto done_tmp_992292;
fail_tmp_992253:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_992282 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_992282))
field_imm = inv_maskmask(8, tmp_992282);
else goto fail_tmp_992281;
}
/* commit */
{
tmp_981532 = genfunc_tmp_992205();
goto next_tmp_992285;
next_tmp_992285:
goto tmp_992284;
tmp_992284:
}
tmp_981531 = tmp_992229 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 6 */
}
goto done_tmp_992292;
fail_tmp_992281:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_992205();
goto next_tmp_992290;
next_tmp_992290:
goto tmp_992289;
tmp_992289:
}
tmp_981523 = tmp_992229 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 6 */
}
done_tmp_992292:
return tmp_992229;
}
reg_t genfunc_tmp_992205 (void) {
reg_t tmp_992160;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_992086();
goto next_tmp_992202;
next_tmp_992202:
goto tmp_992201;
tmp_992201:
}
tmp_981838 = tmp_992160 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_992204:
return tmp_992160;
}
reg_t genfunc_tmp_992086 (void) {
reg_t tmp_991888;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_992045 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_992045 >> 8) == 0)
field_imm = tmp_992045;
else goto fail_tmp_992044;
}
/* commit */
{
tmp_982315 = genfunc_tmp_991974();
goto next_tmp_992048;
next_tmp_992048:
goto tmp_992047;
tmp_992047:
}
tmp_982314 = tmp_991888 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_992085;
fail_tmp_992044:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_992075 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_992075))
field_imm = inv_maskmask(8, tmp_992075);
else goto fail_tmp_992074;
}
/* commit */
{
tmp_981532 = genfunc_tmp_991974();
goto next_tmp_992078;
next_tmp_992078:
goto tmp_992077;
tmp_992077:
}
tmp_981531 = tmp_991888 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_992085;
fail_tmp_992074:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_991974();
goto next_tmp_992083;
next_tmp_992083:
goto tmp_992082;
tmp_992082:
}
tmp_981523 = tmp_991888 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_992085:
return tmp_991888;
}
reg_t genfunc_tmp_992042 (void) {
reg_t tmp_991978;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_992003 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_992003 >> 8) == 0)
field_imm = tmp_992003;
else goto fail_tmp_992002;
}
/* commit */
{
tmp_982315 = genfunc_tmp_991974();
goto next_tmp_992006;
next_tmp_992006:
goto tmp_992005;
tmp_992005:
}
tmp_982314 = tmp_991978 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_992041;
fail_tmp_992002:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_992031 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_992031))
field_imm = inv_maskmask(8, tmp_992031);
else goto fail_tmp_992030;
}
/* commit */
{
tmp_981532 = genfunc_tmp_991974();
goto next_tmp_992034;
next_tmp_992034:
goto tmp_992033;
tmp_992033:
}
tmp_981531 = tmp_991978 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_992041;
fail_tmp_992030:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_991974();
goto next_tmp_992039;
next_tmp_992039:
goto tmp_992038;
tmp_992038:
}
tmp_981523 = tmp_991978 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_992041:
return tmp_991978;
}
reg_t genfunc_tmp_991974 (void) {
reg_t tmp_991904;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_991963;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_991940();
goto next_tmp_991966;
next_tmp_991966:
goto tmp_991965;
tmp_991965:
}
tmp_981697 = tmp_991904 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 2 */
}
goto done_tmp_991973;
fail_tmp_991963:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_991968;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_991940();
goto next_tmp_991971;
next_tmp_991971:
goto tmp_991970;
tmp_991970:
}
tmp_981665 = tmp_991904 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 2 */
}
goto done_tmp_991973;
fail_tmp_991968:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_982357 = genfunc_tmp_991940();
goto next_tmp_991913;
next_tmp_991913:
goto tmp_991912;
tmp_991912:
}
tmp_982354 = tmp_991904 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 3 */
}
done_tmp_991973:
return tmp_991904;
}
reg_t genfunc_tmp_991940 (void) {
reg_t tmp_991911;
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_reading(0 + 5);
tmp_982357 = ref_gpr_reg_for_reading(0 + index);
tmp_982354 = tmp_991911 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 1 */
}
done_tmp_991939:
return tmp_991911;
}
void genfunc_tmp_991883 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_991565();
goto next_tmp_991408;
next_tmp_991408:
goto tmp_991407;
tmp_991407:
}
{
tmp_981603 = genfunc_tmp_991880();
goto next_tmp_991569;
next_tmp_991569:
goto tmp_991568;
tmp_991568:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_991882:
}
reg_t genfunc_tmp_991880 (void) {
reg_t tmp_991567;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_991829();
goto next_tmp_991872;
next_tmp_991872:
goto tmp_991871;
tmp_991871:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_991567 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_991879:
return tmp_991567;
}
reg_t genfunc_tmp_991832 (void) {
reg_t tmp_991583;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_991829();
goto next_tmp_991625;
next_tmp_991625:
goto tmp_991624;
tmp_991624:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_991583 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_991831:
return tmp_991583;
}
reg_t genfunc_tmp_991829 (void) {
reg_t tmp_991623;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_991565();
goto next_tmp_991803;
next_tmp_991803:
goto tmp_991802;
tmp_991802:
}
tmp_981838 = tmp_991623 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_991828:
return tmp_991623;
}
reg_t genfunc_tmp_991772 (void) {
reg_t tmp_991708;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_991733 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_991733 >> 8) == 0)
field_imm = tmp_991733;
else goto fail_tmp_991732;
}
/* commit */
{
tmp_982315 = genfunc_tmp_991684();
goto next_tmp_991736;
next_tmp_991736:
goto tmp_991735;
tmp_991735:
}
tmp_982314 = tmp_991708 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_991771;
fail_tmp_991732:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_991761 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_991761))
field_imm = inv_maskmask(8, tmp_991761);
else goto fail_tmp_991760;
}
/* commit */
{
tmp_981532 = genfunc_tmp_991684();
goto next_tmp_991764;
next_tmp_991764:
goto tmp_991763;
tmp_991763:
}
tmp_981531 = tmp_991708 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_991771;
fail_tmp_991760:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_991684();
goto next_tmp_991769;
next_tmp_991769:
goto tmp_991768;
tmp_991768:
}
tmp_981523 = tmp_991708 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_991771:
return tmp_991708;
}
reg_t genfunc_tmp_991684 (void) {
reg_t tmp_991639;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_991565();
goto next_tmp_991681;
next_tmp_991681:
goto tmp_991680;
tmp_991680:
}
tmp_981838 = tmp_991639 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_991683:
return tmp_991639;
}
reg_t genfunc_tmp_991565 (void) {
reg_t tmp_991406;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_991524 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_991524 >> 8) == 0)
field_imm = tmp_991524;
else goto fail_tmp_991523;
}
/* commit */
{
tmp_982315 = genfunc_tmp_991453();
goto next_tmp_991527;
next_tmp_991527:
goto tmp_991526;
tmp_991526:
}
tmp_982314 = tmp_991406 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_991564;
fail_tmp_991523:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_991554 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_991554))
field_imm = inv_maskmask(8, tmp_991554);
else goto fail_tmp_991553;
}
/* commit */
{
tmp_981532 = genfunc_tmp_991453();
goto next_tmp_991557;
next_tmp_991557:
goto tmp_991556;
tmp_991556:
}
tmp_981531 = tmp_991406 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_991564;
fail_tmp_991553:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_991453();
goto next_tmp_991562;
next_tmp_991562:
goto tmp_991561;
tmp_991561:
}
tmp_981523 = tmp_991406 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_991564:
return tmp_991406;
}
reg_t genfunc_tmp_991521 (void) {
reg_t tmp_991457;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_991482 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_991482 >> 8) == 0)
field_imm = tmp_991482;
else goto fail_tmp_991481;
}
/* commit */
{
tmp_982315 = genfunc_tmp_991453();
goto next_tmp_991485;
next_tmp_991485:
goto tmp_991484;
tmp_991484:
}
tmp_982314 = tmp_991457 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_991520;
fail_tmp_991481:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_991510 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_991510))
field_imm = inv_maskmask(8, tmp_991510);
else goto fail_tmp_991509;
}
/* commit */
{
tmp_981532 = genfunc_tmp_991453();
goto next_tmp_991513;
next_tmp_991513:
goto tmp_991512;
tmp_991512:
}
tmp_981531 = tmp_991457 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_991520;
fail_tmp_991509:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_991453();
goto next_tmp_991518;
next_tmp_991518:
goto tmp_991517;
tmp_991517:
}
tmp_981523 = tmp_991457 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_991520:
return tmp_991457;
}
reg_t genfunc_tmp_991453 (void) {
reg_t tmp_991422;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_991450;
field_ra = 31;
/* commit */
tmp_981699 = ref_gpr_reg_for_reading(0 + base);
tmp_981697 = tmp_991422 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 1 */
}
goto done_tmp_991452;
fail_tmp_991450:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_991451;
field_ra = 31;
/* commit */
tmp_981667 = ref_gpr_reg_for_reading(0 + base);
tmp_981665 = tmp_991422 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 1 */
}
goto done_tmp_991452;
fail_tmp_991451:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_982357 = ref_gpr_reg_for_reading(0 + base);
tmp_982354 = tmp_991422 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_991452:
return tmp_991422;
}
void genfunc_tmp_991401 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_991083();
goto next_tmp_990914;
next_tmp_990914:
goto tmp_990913;
tmp_990913:
}
{
tmp_981603 = genfunc_tmp_991398();
goto next_tmp_991087;
next_tmp_991087:
goto tmp_991086;
tmp_991086:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 13 */
}
done_tmp_991400:
}
reg_t genfunc_tmp_991398 (void) {
reg_t tmp_991085;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_991347();
goto next_tmp_991390;
next_tmp_991390:
goto tmp_991389;
tmp_991389:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_991085 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 7 */
}
done_tmp_991397:
return tmp_991085;
}
reg_t genfunc_tmp_991350 (void) {
reg_t tmp_991101;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_991347();
goto next_tmp_991143;
next_tmp_991143:
goto tmp_991142;
tmp_991142:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_991101 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 7 */
}
done_tmp_991349:
return tmp_991101;
}
reg_t genfunc_tmp_991347 (void) {
reg_t tmp_991141;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_991083();
goto next_tmp_991321;
next_tmp_991321:
goto tmp_991320;
tmp_991320:
}
tmp_981838 = tmp_991141 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_991346:
return tmp_991141;
}
reg_t genfunc_tmp_991290 (void) {
reg_t tmp_991226;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_991251 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_991251 >> 8) == 0)
field_imm = tmp_991251;
else goto fail_tmp_991250;
}
/* commit */
{
tmp_982315 = genfunc_tmp_991202();
goto next_tmp_991254;
next_tmp_991254:
goto tmp_991253;
tmp_991253:
}
tmp_982314 = tmp_991226 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 7 */
}
goto done_tmp_991289;
fail_tmp_991250:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_991279 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_991279))
field_imm = inv_maskmask(8, tmp_991279);
else goto fail_tmp_991278;
}
/* commit */
{
tmp_981532 = genfunc_tmp_991202();
goto next_tmp_991282;
next_tmp_991282:
goto tmp_991281;
tmp_991281:
}
tmp_981531 = tmp_991226 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 7 */
}
goto done_tmp_991289;
fail_tmp_991278:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_991202();
goto next_tmp_991287;
next_tmp_991287:
goto tmp_991286;
tmp_991286:
}
tmp_981523 = tmp_991226 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 7 */
}
done_tmp_991289:
return tmp_991226;
}
reg_t genfunc_tmp_991202 (void) {
reg_t tmp_991157;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_991083();
goto next_tmp_991199;
next_tmp_991199:
goto tmp_991198;
tmp_991198:
}
tmp_981838 = tmp_991157 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_991201:
return tmp_991157;
}
reg_t genfunc_tmp_991083 (void) {
reg_t tmp_990912;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_991042 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_991042 >> 8) == 0)
field_imm = tmp_991042;
else goto fail_tmp_991041;
}
/* commit */
{
tmp_982315 = genfunc_tmp_990971();
goto next_tmp_991045;
next_tmp_991045:
goto tmp_991044;
tmp_991044:
}
tmp_982314 = tmp_990912 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_991082;
fail_tmp_991041:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_991072 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_991072))
field_imm = inv_maskmask(8, tmp_991072);
else goto fail_tmp_991071;
}
/* commit */
{
tmp_981532 = genfunc_tmp_990971();
goto next_tmp_991075;
next_tmp_991075:
goto tmp_991074;
tmp_991074:
}
tmp_981531 = tmp_990912 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_991082;
fail_tmp_991071:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_990971();
goto next_tmp_991080;
next_tmp_991080:
goto tmp_991079;
tmp_991079:
}
tmp_981523 = tmp_990912 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_991082:
return tmp_990912;
}
reg_t genfunc_tmp_991039 (void) {
reg_t tmp_990975;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_991000 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_991000 >> 8) == 0)
field_imm = tmp_991000;
else goto fail_tmp_990999;
}
/* commit */
{
tmp_982315 = genfunc_tmp_990971();
goto next_tmp_991003;
next_tmp_991003:
goto tmp_991002;
tmp_991002:
}
tmp_982314 = tmp_990975 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_991038;
fail_tmp_990999:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_991028 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_991028))
field_imm = inv_maskmask(8, tmp_991028);
else goto fail_tmp_991027;
}
/* commit */
{
tmp_981532 = genfunc_tmp_990971();
goto next_tmp_991031;
next_tmp_991031:
goto tmp_991030;
tmp_991030:
}
tmp_981531 = tmp_990975 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_991038;
fail_tmp_991027:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_990971();
goto next_tmp_991036;
next_tmp_991036:
goto tmp_991035;
tmp_991035:
}
tmp_981523 = tmp_990975 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_991038:
return tmp_990975;
}
reg_t genfunc_tmp_990971 (void) {
reg_t tmp_990928;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_990960;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_987773();
goto next_tmp_990963;
next_tmp_990963:
goto tmp_990962;
tmp_990962:
}
tmp_981697 = tmp_990928 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 3 */
}
goto done_tmp_990970;
fail_tmp_990960:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_990965;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_987773();
goto next_tmp_990968;
next_tmp_990968:
goto tmp_990967;
tmp_990967:
}
tmp_981665 = tmp_990928 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 3 */
}
goto done_tmp_990970;
fail_tmp_990965:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_982357 = genfunc_tmp_987773();
goto next_tmp_990937;
next_tmp_990937:
goto tmp_990936;
tmp_990936:
}
tmp_982354 = tmp_990928 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 4 */
}
done_tmp_990970:
return tmp_990928;
}
void genfunc_tmp_990907 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_990589();
goto next_tmp_990420;
next_tmp_990420:
goto tmp_990419;
tmp_990419:
}
{
tmp_981603 = genfunc_tmp_990904();
goto next_tmp_990593;
next_tmp_990593:
goto tmp_990592;
tmp_990592:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 11 */
}
done_tmp_990906:
}
reg_t genfunc_tmp_990904 (void) {
reg_t tmp_990591;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_990853();
goto next_tmp_990896;
next_tmp_990896:
goto tmp_990895;
tmp_990895:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_990591 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 6 */
}
done_tmp_990903:
return tmp_990591;
}
reg_t genfunc_tmp_990856 (void) {
reg_t tmp_990607;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_990853();
goto next_tmp_990649;
next_tmp_990649:
goto tmp_990648;
tmp_990648:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_990607 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 6 */
}
done_tmp_990855:
return tmp_990607;
}
reg_t genfunc_tmp_990853 (void) {
reg_t tmp_990647;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_990589();
goto next_tmp_990827;
next_tmp_990827:
goto tmp_990826;
tmp_990826:
}
tmp_981838 = tmp_990647 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_990852:
return tmp_990647;
}
reg_t genfunc_tmp_990796 (void) {
reg_t tmp_990732;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_990757 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_990757 >> 8) == 0)
field_imm = tmp_990757;
else goto fail_tmp_990756;
}
/* commit */
{
tmp_982315 = genfunc_tmp_990708();
goto next_tmp_990760;
next_tmp_990760:
goto tmp_990759;
tmp_990759:
}
tmp_982314 = tmp_990732 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 6 */
}
goto done_tmp_990795;
fail_tmp_990756:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_990785 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_990785))
field_imm = inv_maskmask(8, tmp_990785);
else goto fail_tmp_990784;
}
/* commit */
{
tmp_981532 = genfunc_tmp_990708();
goto next_tmp_990788;
next_tmp_990788:
goto tmp_990787;
tmp_990787:
}
tmp_981531 = tmp_990732 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 6 */
}
goto done_tmp_990795;
fail_tmp_990784:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_990708();
goto next_tmp_990793;
next_tmp_990793:
goto tmp_990792;
tmp_990792:
}
tmp_981523 = tmp_990732 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 6 */
}
done_tmp_990795:
return tmp_990732;
}
reg_t genfunc_tmp_990708 (void) {
reg_t tmp_990663;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_990589();
goto next_tmp_990705;
next_tmp_990705:
goto tmp_990704;
tmp_990704:
}
tmp_981838 = tmp_990663 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_990707:
return tmp_990663;
}
reg_t genfunc_tmp_990589 (void) {
reg_t tmp_990418;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_990548 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_990548 >> 8) == 0)
field_imm = tmp_990548;
else goto fail_tmp_990547;
}
/* commit */
{
tmp_982315 = genfunc_tmp_990477();
goto next_tmp_990551;
next_tmp_990551:
goto tmp_990550;
tmp_990550:
}
tmp_982314 = tmp_990418 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_990588;
fail_tmp_990547:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_990578 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_990578))
field_imm = inv_maskmask(8, tmp_990578);
else goto fail_tmp_990577;
}
/* commit */
{
tmp_981532 = genfunc_tmp_990477();
goto next_tmp_990581;
next_tmp_990581:
goto tmp_990580;
tmp_990580:
}
tmp_981531 = tmp_990418 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_990588;
fail_tmp_990577:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_990477();
goto next_tmp_990586;
next_tmp_990586:
goto tmp_990585;
tmp_990585:
}
tmp_981523 = tmp_990418 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_990588:
return tmp_990418;
}
reg_t genfunc_tmp_990545 (void) {
reg_t tmp_990481;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_990506 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_990506 >> 8) == 0)
field_imm = tmp_990506;
else goto fail_tmp_990505;
}
/* commit */
{
tmp_982315 = genfunc_tmp_990477();
goto next_tmp_990509;
next_tmp_990509:
goto tmp_990508;
tmp_990508:
}
tmp_982314 = tmp_990481 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_990544;
fail_tmp_990505:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_990534 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_990534))
field_imm = inv_maskmask(8, tmp_990534);
else goto fail_tmp_990533;
}
/* commit */
{
tmp_981532 = genfunc_tmp_990477();
goto next_tmp_990537;
next_tmp_990537:
goto tmp_990536;
tmp_990536:
}
tmp_981531 = tmp_990481 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_990544;
fail_tmp_990533:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_990477();
goto next_tmp_990542;
next_tmp_990542:
goto tmp_990541;
tmp_990541:
}
tmp_981523 = tmp_990481 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_990544:
return tmp_990481;
}
reg_t genfunc_tmp_990477 (void) {
reg_t tmp_990434;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_990466;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_987249();
goto next_tmp_990469;
next_tmp_990469:
goto tmp_990468;
tmp_990468:
}
tmp_981697 = tmp_990434 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 2 */
}
goto done_tmp_990476;
fail_tmp_990466:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_990471;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_987249();
goto next_tmp_990474;
next_tmp_990474:
goto tmp_990473;
tmp_990473:
}
tmp_981665 = tmp_990434 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 2 */
}
goto done_tmp_990476;
fail_tmp_990471:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_982357 = genfunc_tmp_987249();
goto next_tmp_990443;
next_tmp_990443:
goto tmp_990442;
tmp_990442:
}
tmp_982354 = tmp_990434 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 3 */
}
done_tmp_990476:
return tmp_990434;
}
void genfunc_tmp_990413 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_990095();
goto next_tmp_989933;
next_tmp_989933:
goto tmp_989932;
tmp_989932:
}
{
tmp_981603 = genfunc_tmp_990410();
goto next_tmp_990099;
next_tmp_990099:
goto tmp_990098;
tmp_990098:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_990412:
}
reg_t genfunc_tmp_990410 (void) {
reg_t tmp_990097;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_990359();
goto next_tmp_990402;
next_tmp_990402:
goto tmp_990401;
tmp_990401:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_990097 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_990409:
return tmp_990097;
}
reg_t genfunc_tmp_990362 (void) {
reg_t tmp_990113;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_990359();
goto next_tmp_990155;
next_tmp_990155:
goto tmp_990154;
tmp_990154:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_990113 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_990361:
return tmp_990113;
}
reg_t genfunc_tmp_990359 (void) {
reg_t tmp_990153;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_990095();
goto next_tmp_990333;
next_tmp_990333:
goto tmp_990332;
tmp_990332:
}
tmp_981838 = tmp_990153 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_990358:
return tmp_990153;
}
reg_t genfunc_tmp_990302 (void) {
reg_t tmp_990238;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_990263 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_990263 >> 8) == 0)
field_imm = tmp_990263;
else goto fail_tmp_990262;
}
/* commit */
{
tmp_982315 = genfunc_tmp_990214();
goto next_tmp_990266;
next_tmp_990266:
goto tmp_990265;
tmp_990265:
}
tmp_982314 = tmp_990238 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_990301;
fail_tmp_990262:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_990291 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_990291))
field_imm = inv_maskmask(8, tmp_990291);
else goto fail_tmp_990290;
}
/* commit */
{
tmp_981532 = genfunc_tmp_990214();
goto next_tmp_990294;
next_tmp_990294:
goto tmp_990293;
tmp_990293:
}
tmp_981531 = tmp_990238 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_990301;
fail_tmp_990290:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_990214();
goto next_tmp_990299;
next_tmp_990299:
goto tmp_990298;
tmp_990298:
}
tmp_981523 = tmp_990238 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_990301:
return tmp_990238;
}
reg_t genfunc_tmp_990214 (void) {
reg_t tmp_990169;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_990095();
goto next_tmp_990211;
next_tmp_990211:
goto tmp_990210;
tmp_990210:
}
tmp_981838 = tmp_990169 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_990213:
return tmp_990169;
}
reg_t genfunc_tmp_990095 (void) {
reg_t tmp_989931;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_990054 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_990054 >> 8) == 0)
field_imm = tmp_990054;
else goto fail_tmp_990053;
}
/* commit */
{
tmp_982315 = genfunc_tmp_989983();
goto next_tmp_990057;
next_tmp_990057:
goto tmp_990056;
tmp_990056:
}
tmp_982314 = tmp_989931 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_990094;
fail_tmp_990053:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_990084 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_990084))
field_imm = inv_maskmask(8, tmp_990084);
else goto fail_tmp_990083;
}
/* commit */
{
tmp_981532 = genfunc_tmp_989983();
goto next_tmp_990087;
next_tmp_990087:
goto tmp_990086;
tmp_990086:
}
tmp_981531 = tmp_989931 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_990094;
fail_tmp_990083:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_989983();
goto next_tmp_990092;
next_tmp_990092:
goto tmp_990091;
tmp_990091:
}
tmp_981523 = tmp_989931 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_990094:
return tmp_989931;
}
reg_t genfunc_tmp_990051 (void) {
reg_t tmp_989987;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_990012 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_990012 >> 8) == 0)
field_imm = tmp_990012;
else goto fail_tmp_990011;
}
/* commit */
{
tmp_982315 = genfunc_tmp_989983();
goto next_tmp_990015;
next_tmp_990015:
goto tmp_990014;
tmp_990014:
}
tmp_982314 = tmp_989987 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_990050;
fail_tmp_990011:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_990040 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_990040))
field_imm = inv_maskmask(8, tmp_990040);
else goto fail_tmp_990039;
}
/* commit */
{
tmp_981532 = genfunc_tmp_989983();
goto next_tmp_990043;
next_tmp_990043:
goto tmp_990042;
tmp_990042:
}
tmp_981531 = tmp_989987 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_990050;
fail_tmp_990039:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_989983();
goto next_tmp_990048;
next_tmp_990048:
goto tmp_990047;
tmp_990047:
}
tmp_981523 = tmp_989987 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_990050:
return tmp_989987;
}
reg_t genfunc_tmp_989983 (void) {
reg_t tmp_989947;
/* ADDQ_IMM */
{
word_5 tmp_982350;
word_5 field_rc;
word_5 tmp_982351;
word_5 field_ra;
word_64 tmp_982353;
word_8 field_imm;
tmp_982353 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_989964 = tmp_982353;
if ((tmp_989964 >> 8) == 0)
field_imm = tmp_989964;
else goto fail_tmp_989963;
}
/* commit */
tmp_982351 = ref_gpr_reg_for_reading(0 + rm);
tmp_982350 = tmp_989947 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982350;
field_ra = tmp_982351;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982351);
/* can fail: T   num insns: 1 */
}
goto done_tmp_989982;
fail_tmp_989963:
/* LDA */
{
word_5 tmp_981854;
word_5 field_ra;
word_5 tmp_981855;
word_5 field_rb;
word_64 tmp_981857;
word_16 field_memory_disp;
tmp_981857 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_989975 = tmp_981857;
if ((tmp_989975 >> 16) == 0xFFFFFFFFFFFF || (tmp_989975 >> 16) == 0)
field_memory_disp = (tmp_989975 & 0xFFFF);
else goto fail_tmp_989974;
}
/* commit */
tmp_981855 = ref_gpr_reg_for_reading(0 + rm);
tmp_981854 = tmp_989947 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981854;
field_rb = tmp_981855;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981855);
/* can fail: T   num insns: 1 */
}
goto done_tmp_989982;
fail_tmp_989974:
/* LDAH */
{
word_5 tmp_981850;
word_5 field_ra;
word_5 tmp_981851;
word_5 field_rb;
word_64 tmp_981853;
word_16 field_memory_disp;
tmp_981853 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_989980 = tmp_981853;
if ((tmp_989980 & 0xFFFF) == 0)
{
word_64 tmp_989981 = (tmp_989980 >> 16);
if ((tmp_989981 >> 16) == 0xFFFFFFFFFFFF || (tmp_989981 >> 16) == 0)
field_memory_disp = (tmp_989981 & 0xFFFF);
else goto fail_tmp_989979;
}
else goto fail_tmp_989979;
}
/* commit */
tmp_981851 = ref_gpr_reg_for_reading(0 + rm);
tmp_981850 = tmp_989947 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981850;
field_rb = tmp_981851;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981851);
/* can fail: T   num insns: 1 */
}
goto done_tmp_989982;
fail_tmp_989979:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_reading(0 + rm);
tmp_982357 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982357, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_982354 = tmp_989947 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_989982:
return tmp_989947;
}
void genfunc_tmp_989923 (void) {
/* STL */
{
word_5 field_rb;
word_64 tmp_981600;
word_16 field_memory_disp;
word_5 tmp_981602;
word_5 field_ra;
tmp_981600 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_989917 = tmp_981600;
if ((tmp_989917 >> 16) == 0xFFFFFFFFFFFF || (tmp_989917 >> 16) == 0)
field_memory_disp = (tmp_989917 & 0xFFFF);
else goto fail_tmp_989916;
}
/* commit */
{
tmp_981602 = genfunc_tmp_989914();
goto next_tmp_989920;
next_tmp_989920:
goto tmp_989919;
tmp_989919:
}
field_ra = tmp_981602;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981602);
/* can fail: T   num insns: 4 */
}
goto done_tmp_989922;
fail_tmp_989916:
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
tmp_981599 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_981599, ((word_64)disp32));
{
tmp_981603 = genfunc_tmp_989914();
goto next_tmp_989607;
next_tmp_989607:
goto tmp_989606;
tmp_989606:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 5 */
}
done_tmp_989922:
}
reg_t genfunc_tmp_989914 (void) {
reg_t tmp_989605;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_989863();
goto next_tmp_989906;
next_tmp_989906:
goto tmp_989905;
tmp_989905:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_989605 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 3 */
}
done_tmp_989913:
return tmp_989605;
}
reg_t genfunc_tmp_989866 (void) {
reg_t tmp_989621;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_989863();
goto next_tmp_989663;
next_tmp_989663:
goto tmp_989662;
tmp_989662:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_989621 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 3 */
}
done_tmp_989865:
return tmp_989621;
}
reg_t genfunc_tmp_989863 (void) {
reg_t tmp_989661;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_981840;
word_16 field_memory_disp;
tmp_981840 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_989838 = tmp_981840;
if ((tmp_989838 >> 16) == 0xFFFFFFFFFFFF || (tmp_989838 >> 16) == 0)
field_memory_disp = (tmp_989838 & 0xFFFF);
else goto fail_tmp_989837;
}
/* commit */
tmp_981838 = tmp_989661 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_989862;
fail_tmp_989837:
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
tmp_981839 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_981839, ((word_64)disp32));
tmp_981838 = tmp_989661 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 2 */
}
done_tmp_989862:
return tmp_989661;
}
reg_t genfunc_tmp_989808 (void) {
reg_t tmp_989744;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_989769 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_989769 >> 8) == 0)
field_imm = tmp_989769;
else goto fail_tmp_989768;
}
/* commit */
{
tmp_982315 = genfunc_tmp_989720();
goto next_tmp_989772;
next_tmp_989772:
goto tmp_989771;
tmp_989771:
}
tmp_982314 = tmp_989744 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_989807;
fail_tmp_989768:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_989797 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_989797))
field_imm = inv_maskmask(8, tmp_989797);
else goto fail_tmp_989796;
}
/* commit */
{
tmp_981532 = genfunc_tmp_989720();
goto next_tmp_989800;
next_tmp_989800:
goto tmp_989799;
tmp_989799:
}
tmp_981531 = tmp_989744 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_989807;
fail_tmp_989796:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_989720();
goto next_tmp_989805;
next_tmp_989805:
goto tmp_989804;
tmp_989804:
}
tmp_981523 = tmp_989744 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_989807:
return tmp_989744;
}
reg_t genfunc_tmp_989720 (void) {
reg_t tmp_989677;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_981840;
word_16 field_memory_disp;
tmp_981840 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_989718 = tmp_981840;
if ((tmp_989718 >> 16) == 0xFFFFFFFFFFFF || (tmp_989718 >> 16) == 0)
field_memory_disp = (tmp_989718 & 0xFFFF);
else goto fail_tmp_989717;
}
/* commit */
tmp_981838 = tmp_989677 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_989719;
fail_tmp_989717:
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
tmp_981839 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_981839, ((word_64)disp32));
tmp_981838 = tmp_989677 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 2 */
}
done_tmp_989719:
return tmp_989677;
}
void genfunc_tmp_989600 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_989282();
goto next_tmp_989113;
next_tmp_989113:
goto tmp_989112;
tmp_989112:
}
{
tmp_981603 = genfunc_tmp_989597();
goto next_tmp_989286;
next_tmp_989286:
goto tmp_989285;
tmp_989285:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 11 */
}
done_tmp_989599:
}
reg_t genfunc_tmp_989597 (void) {
reg_t tmp_989284;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_989546();
goto next_tmp_989589;
next_tmp_989589:
goto tmp_989588;
tmp_989588:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_989284 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 6 */
}
done_tmp_989596:
return tmp_989284;
}
reg_t genfunc_tmp_989549 (void) {
reg_t tmp_989300;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_989546();
goto next_tmp_989342;
next_tmp_989342:
goto tmp_989341;
tmp_989341:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_989300 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 6 */
}
done_tmp_989548:
return tmp_989300;
}
reg_t genfunc_tmp_989546 (void) {
reg_t tmp_989340;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_989282();
goto next_tmp_989520;
next_tmp_989520:
goto tmp_989519;
tmp_989519:
}
tmp_981838 = tmp_989340 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_989545:
return tmp_989340;
}
reg_t genfunc_tmp_989489 (void) {
reg_t tmp_989425;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_989450 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_989450 >> 8) == 0)
field_imm = tmp_989450;
else goto fail_tmp_989449;
}
/* commit */
{
tmp_982315 = genfunc_tmp_989401();
goto next_tmp_989453;
next_tmp_989453:
goto tmp_989452;
tmp_989452:
}
tmp_982314 = tmp_989425 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 6 */
}
goto done_tmp_989488;
fail_tmp_989449:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_989478 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_989478))
field_imm = inv_maskmask(8, tmp_989478);
else goto fail_tmp_989477;
}
/* commit */
{
tmp_981532 = genfunc_tmp_989401();
goto next_tmp_989481;
next_tmp_989481:
goto tmp_989480;
tmp_989480:
}
tmp_981531 = tmp_989425 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 6 */
}
goto done_tmp_989488;
fail_tmp_989477:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_989401();
goto next_tmp_989486;
next_tmp_989486:
goto tmp_989485;
tmp_989485:
}
tmp_981523 = tmp_989425 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 6 */
}
done_tmp_989488:
return tmp_989425;
}
reg_t genfunc_tmp_989401 (void) {
reg_t tmp_989356;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_989282();
goto next_tmp_989398;
next_tmp_989398:
goto tmp_989397;
tmp_989397:
}
tmp_981838 = tmp_989356 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_989400:
return tmp_989356;
}
reg_t genfunc_tmp_989282 (void) {
reg_t tmp_989111;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_989241 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_989241 >> 8) == 0)
field_imm = tmp_989241;
else goto fail_tmp_989240;
}
/* commit */
{
tmp_982315 = genfunc_tmp_989170();
goto next_tmp_989244;
next_tmp_989244:
goto tmp_989243;
tmp_989243:
}
tmp_982314 = tmp_989111 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_989281;
fail_tmp_989240:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_989271 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_989271))
field_imm = inv_maskmask(8, tmp_989271);
else goto fail_tmp_989270;
}
/* commit */
{
tmp_981532 = genfunc_tmp_989170();
goto next_tmp_989274;
next_tmp_989274:
goto tmp_989273;
tmp_989273:
}
tmp_981531 = tmp_989111 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_989281;
fail_tmp_989270:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_989170();
goto next_tmp_989279;
next_tmp_989279:
goto tmp_989278;
tmp_989278:
}
tmp_981523 = tmp_989111 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_989281:
return tmp_989111;
}
reg_t genfunc_tmp_989238 (void) {
reg_t tmp_989174;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_989199 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_989199 >> 8) == 0)
field_imm = tmp_989199;
else goto fail_tmp_989198;
}
/* commit */
{
tmp_982315 = genfunc_tmp_989170();
goto next_tmp_989202;
next_tmp_989202:
goto tmp_989201;
tmp_989201:
}
tmp_982314 = tmp_989174 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_989237;
fail_tmp_989198:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_989227 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_989227))
field_imm = inv_maskmask(8, tmp_989227);
else goto fail_tmp_989226;
}
/* commit */
{
tmp_981532 = genfunc_tmp_989170();
goto next_tmp_989230;
next_tmp_989230:
goto tmp_989229;
tmp_989229:
}
tmp_981531 = tmp_989174 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_989237;
fail_tmp_989226:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_989170();
goto next_tmp_989235;
next_tmp_989235:
goto tmp_989234;
tmp_989234:
}
tmp_981523 = tmp_989174 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_989237:
return tmp_989174;
}
reg_t genfunc_tmp_989170 (void) {
reg_t tmp_989127;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_989159;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_987749();
goto next_tmp_989162;
next_tmp_989162:
goto tmp_989161;
tmp_989161:
}
tmp_981697 = tmp_989127 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 2 */
}
goto done_tmp_989169;
fail_tmp_989159:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_989164;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_987749();
goto next_tmp_989167;
next_tmp_989167:
goto tmp_989166;
tmp_989166:
}
tmp_981665 = tmp_989127 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 2 */
}
goto done_tmp_989169;
fail_tmp_989164:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_982357 = genfunc_tmp_987749();
goto next_tmp_989136;
next_tmp_989136:
goto tmp_989135;
tmp_989135:
}
tmp_982354 = tmp_989127 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 3 */
}
done_tmp_989169:
return tmp_989127;
}
void genfunc_tmp_989106 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_988788();
goto next_tmp_988631;
next_tmp_988631:
goto tmp_988630;
tmp_988630:
}
{
tmp_981603 = genfunc_tmp_989103();
goto next_tmp_988792;
next_tmp_988792:
goto tmp_988791;
tmp_988791:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_989105:
}
reg_t genfunc_tmp_989103 (void) {
reg_t tmp_988790;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_989052();
goto next_tmp_989095;
next_tmp_989095:
goto tmp_989094;
tmp_989094:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_988790 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_989102:
return tmp_988790;
}
reg_t genfunc_tmp_989055 (void) {
reg_t tmp_988806;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_989052();
goto next_tmp_988848;
next_tmp_988848:
goto tmp_988847;
tmp_988847:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_988806 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_989054:
return tmp_988806;
}
reg_t genfunc_tmp_989052 (void) {
reg_t tmp_988846;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_988788();
goto next_tmp_989026;
next_tmp_989026:
goto tmp_989025;
tmp_989025:
}
tmp_981838 = tmp_988846 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_989051:
return tmp_988846;
}
reg_t genfunc_tmp_988995 (void) {
reg_t tmp_988931;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_988956 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_988956 >> 8) == 0)
field_imm = tmp_988956;
else goto fail_tmp_988955;
}
/* commit */
{
tmp_982315 = genfunc_tmp_988907();
goto next_tmp_988959;
next_tmp_988959:
goto tmp_988958;
tmp_988958:
}
tmp_982314 = tmp_988931 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_988994;
fail_tmp_988955:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_988984 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_988984))
field_imm = inv_maskmask(8, tmp_988984);
else goto fail_tmp_988983;
}
/* commit */
{
tmp_981532 = genfunc_tmp_988907();
goto next_tmp_988987;
next_tmp_988987:
goto tmp_988986;
tmp_988986:
}
tmp_981531 = tmp_988931 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_988994;
fail_tmp_988983:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_988907();
goto next_tmp_988992;
next_tmp_988992:
goto tmp_988991;
tmp_988991:
}
tmp_981523 = tmp_988931 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_988994:
return tmp_988931;
}
reg_t genfunc_tmp_988907 (void) {
reg_t tmp_988862;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_988788();
goto next_tmp_988904;
next_tmp_988904:
goto tmp_988903;
tmp_988903:
}
tmp_981838 = tmp_988862 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_988906:
return tmp_988862;
}
reg_t genfunc_tmp_988788 (void) {
reg_t tmp_988629;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_988747 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_988747 >> 8) == 0)
field_imm = tmp_988747;
else goto fail_tmp_988746;
}
/* commit */
{
tmp_982315 = genfunc_tmp_988676();
goto next_tmp_988750;
next_tmp_988750:
goto tmp_988749;
tmp_988749:
}
tmp_982314 = tmp_988629 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_988787;
fail_tmp_988746:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_988777 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_988777))
field_imm = inv_maskmask(8, tmp_988777);
else goto fail_tmp_988776;
}
/* commit */
{
tmp_981532 = genfunc_tmp_988676();
goto next_tmp_988780;
next_tmp_988780:
goto tmp_988779;
tmp_988779:
}
tmp_981531 = tmp_988629 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_988787;
fail_tmp_988776:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_988676();
goto next_tmp_988785;
next_tmp_988785:
goto tmp_988784;
tmp_988784:
}
tmp_981523 = tmp_988629 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_988787:
return tmp_988629;
}
reg_t genfunc_tmp_988744 (void) {
reg_t tmp_988680;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_988705 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_988705 >> 8) == 0)
field_imm = tmp_988705;
else goto fail_tmp_988704;
}
/* commit */
{
tmp_982315 = genfunc_tmp_988676();
goto next_tmp_988708;
next_tmp_988708:
goto tmp_988707;
tmp_988707:
}
tmp_982314 = tmp_988680 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_988743;
fail_tmp_988704:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_988733 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_988733))
field_imm = inv_maskmask(8, tmp_988733);
else goto fail_tmp_988732;
}
/* commit */
{
tmp_981532 = genfunc_tmp_988676();
goto next_tmp_988736;
next_tmp_988736:
goto tmp_988735;
tmp_988735:
}
tmp_981531 = tmp_988680 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_988743;
fail_tmp_988732:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_988676();
goto next_tmp_988741;
next_tmp_988741:
goto tmp_988740;
tmp_988740:
}
tmp_981523 = tmp_988680 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_988743:
return tmp_988680;
}
reg_t genfunc_tmp_988676 (void) {
reg_t tmp_988645;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_988673;
field_ra = 31;
/* commit */
tmp_981699 = ref_gpr_reg_for_reading(0 + index);
tmp_981697 = tmp_988645 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 1 */
}
goto done_tmp_988675;
fail_tmp_988673:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_988674;
field_ra = 31;
/* commit */
tmp_981667 = ref_gpr_reg_for_reading(0 + index);
tmp_981665 = tmp_988645 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 1 */
}
goto done_tmp_988675;
fail_tmp_988674:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_982357 = ref_gpr_reg_for_reading(0 + index);
tmp_982354 = tmp_988645 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_988675:
return tmp_988645;
}
void genfunc_tmp_988624 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_988306();
goto next_tmp_988210;
next_tmp_988210:
goto tmp_988209;
tmp_988209:
}
{
tmp_981603 = genfunc_tmp_988621();
goto next_tmp_988310;
next_tmp_988310:
goto tmp_988309;
tmp_988309:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 5 */
}
done_tmp_988623:
}
reg_t genfunc_tmp_988621 (void) {
reg_t tmp_988308;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_988570();
goto next_tmp_988613;
next_tmp_988613:
goto tmp_988612;
tmp_988612:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_988308 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 3 */
}
done_tmp_988620:
return tmp_988308;
}
reg_t genfunc_tmp_988573 (void) {
reg_t tmp_988324;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_988570();
goto next_tmp_988366;
next_tmp_988366:
goto tmp_988365;
tmp_988365:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_988324 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 3 */
}
done_tmp_988572:
return tmp_988324;
}
reg_t genfunc_tmp_988570 (void) {
reg_t tmp_988364;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_988306();
goto next_tmp_988544;
next_tmp_988544:
goto tmp_988543;
tmp_988543:
}
tmp_981838 = tmp_988364 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 2 */
}
done_tmp_988569:
return tmp_988364;
}
reg_t genfunc_tmp_988513 (void) {
reg_t tmp_988449;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_988474 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_988474 >> 8) == 0)
field_imm = tmp_988474;
else goto fail_tmp_988473;
}
/* commit */
{
tmp_982315 = genfunc_tmp_988425();
goto next_tmp_988477;
next_tmp_988477:
goto tmp_988476;
tmp_988476:
}
tmp_982314 = tmp_988449 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_988512;
fail_tmp_988473:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_988502 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_988502))
field_imm = inv_maskmask(8, tmp_988502);
else goto fail_tmp_988501;
}
/* commit */
{
tmp_981532 = genfunc_tmp_988425();
goto next_tmp_988505;
next_tmp_988505:
goto tmp_988504;
tmp_988504:
}
tmp_981531 = tmp_988449 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_988512;
fail_tmp_988501:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_988425();
goto next_tmp_988510;
next_tmp_988510:
goto tmp_988509;
tmp_988509:
}
tmp_981523 = tmp_988449 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_988512:
return tmp_988449;
}
reg_t genfunc_tmp_988425 (void) {
reg_t tmp_988380;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_988306();
goto next_tmp_988422;
next_tmp_988422:
goto tmp_988421;
tmp_988421:
}
tmp_981838 = tmp_988380 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 2 */
}
done_tmp_988424:
return tmp_988380;
}
reg_t genfunc_tmp_988306 (void) {
reg_t tmp_988208;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_988277 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_988277 >> 8) == 0)
field_imm = tmp_988277;
else goto fail_tmp_988276;
}
/* commit */
tmp_982315 = ref_gpr_reg_for_reading(0 + base);
tmp_982314 = tmp_988208 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 1 */
}
goto done_tmp_988305;
fail_tmp_988276:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_988303 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_988303))
field_imm = inv_maskmask(8, tmp_988303);
else goto fail_tmp_988302;
}
/* commit */
tmp_981532 = ref_gpr_reg_for_reading(0 + base);
tmp_981531 = tmp_988208 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 1 */
}
goto done_tmp_988305;
fail_tmp_988302:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
tmp_981524 = ref_gpr_reg_for_reading(0 + base);
tmp_981523 = tmp_988208 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 1 */
}
done_tmp_988305:
return tmp_988208;
}
reg_t genfunc_tmp_988274 (void) {
reg_t tmp_988226;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_988247 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_988247 >> 8) == 0)
field_imm = tmp_988247;
else goto fail_tmp_988246;
}
/* commit */
tmp_982315 = ref_gpr_reg_for_reading(0 + base);
tmp_982314 = tmp_988226 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 1 */
}
goto done_tmp_988273;
fail_tmp_988246:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_988271 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_988271))
field_imm = inv_maskmask(8, tmp_988271);
else goto fail_tmp_988270;
}
/* commit */
tmp_981532 = ref_gpr_reg_for_reading(0 + base);
tmp_981531 = tmp_988226 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 1 */
}
goto done_tmp_988273;
fail_tmp_988270:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
tmp_981524 = ref_gpr_reg_for_reading(0 + base);
tmp_981523 = tmp_988226 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 1 */
}
done_tmp_988273:
return tmp_988226;
}
void genfunc_tmp_988203 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_987885();
goto next_tmp_987686;
next_tmp_987686:
goto tmp_987685;
tmp_987685:
}
{
tmp_981603 = genfunc_tmp_988200();
goto next_tmp_987889;
next_tmp_987889:
goto tmp_987888;
tmp_987888:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_988202:
}
reg_t genfunc_tmp_988200 (void) {
reg_t tmp_987887;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_988149();
goto next_tmp_988192;
next_tmp_988192:
goto tmp_988191;
tmp_988191:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_987887 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_988199:
return tmp_987887;
}
reg_t genfunc_tmp_988152 (void) {
reg_t tmp_987903;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_988149();
goto next_tmp_987945;
next_tmp_987945:
goto tmp_987944;
tmp_987944:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_987903 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 5 */
}
done_tmp_988151:
return tmp_987903;
}
reg_t genfunc_tmp_988149 (void) {
reg_t tmp_987943;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_987885();
goto next_tmp_988123;
next_tmp_988123:
goto tmp_988122;
tmp_988122:
}
tmp_981838 = tmp_987943 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_988148:
return tmp_987943;
}
reg_t genfunc_tmp_988092 (void) {
reg_t tmp_988028;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_988053 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_988053 >> 8) == 0)
field_imm = tmp_988053;
else goto fail_tmp_988052;
}
/* commit */
{
tmp_982315 = genfunc_tmp_988004();
goto next_tmp_988056;
next_tmp_988056:
goto tmp_988055;
tmp_988055:
}
tmp_982314 = tmp_988028 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_988091;
fail_tmp_988052:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_988081 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_988081))
field_imm = inv_maskmask(8, tmp_988081);
else goto fail_tmp_988080;
}
/* commit */
{
tmp_981532 = genfunc_tmp_988004();
goto next_tmp_988084;
next_tmp_988084:
goto tmp_988083;
tmp_988083:
}
tmp_981531 = tmp_988028 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_988091;
fail_tmp_988080:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_988004();
goto next_tmp_988089;
next_tmp_988089:
goto tmp_988088;
tmp_988088:
}
tmp_981523 = tmp_988028 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_988091:
return tmp_988028;
}
reg_t genfunc_tmp_988004 (void) {
reg_t tmp_987959;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_987885();
goto next_tmp_988001;
next_tmp_988001:
goto tmp_988000;
tmp_988000:
}
tmp_981838 = tmp_987959 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_988003:
return tmp_987959;
}
reg_t genfunc_tmp_987885 (void) {
reg_t tmp_987684;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_987844 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_987844 >> 8) == 0)
field_imm = tmp_987844;
else goto fail_tmp_987843;
}
/* commit */
{
tmp_982315 = genfunc_tmp_987773();
goto next_tmp_987847;
next_tmp_987847:
goto tmp_987846;
tmp_987846:
}
tmp_982314 = tmp_987684 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_987884;
fail_tmp_987843:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_987874 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_987874))
field_imm = inv_maskmask(8, tmp_987874);
else goto fail_tmp_987873;
}
/* commit */
{
tmp_981532 = genfunc_tmp_987773();
goto next_tmp_987877;
next_tmp_987877:
goto tmp_987876;
tmp_987876:
}
tmp_981531 = tmp_987684 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_987884;
fail_tmp_987873:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_987773();
goto next_tmp_987882;
next_tmp_987882:
goto tmp_987881;
tmp_987881:
}
tmp_981523 = tmp_987684 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_987884:
return tmp_987684;
}
reg_t genfunc_tmp_987841 (void) {
reg_t tmp_987777;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_987802 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_987802 >> 8) == 0)
field_imm = tmp_987802;
else goto fail_tmp_987801;
}
/* commit */
{
tmp_982315 = genfunc_tmp_987773();
goto next_tmp_987805;
next_tmp_987805:
goto tmp_987804;
tmp_987804:
}
tmp_982314 = tmp_987777 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_987840;
fail_tmp_987801:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_987830 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_987830))
field_imm = inv_maskmask(8, tmp_987830);
else goto fail_tmp_987829;
}
/* commit */
{
tmp_981532 = genfunc_tmp_987773();
goto next_tmp_987833;
next_tmp_987833:
goto tmp_987832;
tmp_987832:
}
tmp_981531 = tmp_987777 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_987840;
fail_tmp_987829:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_987773();
goto next_tmp_987838;
next_tmp_987838:
goto tmp_987837;
tmp_987837:
}
tmp_981523 = tmp_987777 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_987840:
return tmp_987777;
}
reg_t genfunc_tmp_987773 (void) {
reg_t tmp_987700;
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_reading(0 + base);
{
tmp_982357 = genfunc_tmp_987749();
goto next_tmp_987709;
next_tmp_987709:
goto tmp_987708;
tmp_987708:
}
tmp_982354 = tmp_987700 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_987772:
return tmp_987700;
}
reg_t genfunc_tmp_987749 (void) {
reg_t tmp_987707;
/* EXTQH */
{
word_5 tmp_982075;
word_5 field_rc;
word_5 tmp_982076;
word_5 field_ra;
word_5 field_rb;
if (64 != ((word_64)scale)) goto fail_tmp_987728;
field_rb = 31;
/* commit */
tmp_982076 = ref_gpr_reg_for_reading(0 + index);
tmp_982075 = tmp_987707 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982075;
field_ra = tmp_982076;
emit(COMPOSE_EXTQH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982076);
/* can fail: T   num insns: 1 */
}
goto done_tmp_987748;
fail_tmp_987728:
/* EXTQH_IMM */
{
word_5 tmp_982071;
word_5 field_rc;
word_5 tmp_982072;
word_5 field_ra;
word_64 tmp_982074;
word_8 field_imm;
tmp_982074 = ((word_64)scale);
{
word_64 tmp_987730 = ((64 - tmp_982074) & 0xFFFFFFFFFFFFFFFF);
if (tmp_987730 % 8 == 0)
{
word_64 tmp_987731 = (tmp_987730 / 8);
if ((tmp_987731 & 7) == tmp_987731)
{
word_64 tmp_987732 = tmp_987731;
if ((tmp_987732 >> 8) == 0)
field_imm = tmp_987732;
else goto fail_tmp_987729;
}
else goto fail_tmp_987729;
}
else goto fail_tmp_987729;
}
/* commit */
tmp_982072 = ref_gpr_reg_for_reading(0 + index);
tmp_982071 = tmp_987707 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982071;
field_ra = tmp_982072;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982072);
/* can fail: T   num insns: 1 */
}
goto done_tmp_987748;
fail_tmp_987729:
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 tmp_981698;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_987740;
field_rb = 31;
/* commit */
tmp_981698 = ref_gpr_reg_for_reading(0 + index);
tmp_981697 = tmp_987707 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_ra = tmp_981698;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981698);
/* can fail: T   num insns: 1 */
}
goto done_tmp_987748;
fail_tmp_987740:
/* S4ADDQ_IMM */
{
word_5 tmp_981693;
word_5 field_rc;
word_5 tmp_981694;
word_5 field_ra;
word_64 tmp_981696;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_987741;
tmp_981696 = 0;
field_imm = 0;
/* commit */
tmp_981694 = ref_gpr_reg_for_reading(0 + index);
tmp_981693 = tmp_987707 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981693;
field_ra = tmp_981694;
emit(COMPOSE_S4ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981694);
/* can fail: T   num insns: 1 */
}
goto done_tmp_987748;
fail_tmp_987741:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 tmp_981666;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_987743;
field_rb = 31;
/* commit */
tmp_981666 = ref_gpr_reg_for_reading(0 + index);
tmp_981665 = tmp_987707 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_ra = tmp_981666;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981666);
/* can fail: T   num insns: 1 */
}
goto done_tmp_987748;
fail_tmp_987743:
/* S8ADDQ_IMM */
{
word_5 tmp_981661;
word_5 field_rc;
word_5 tmp_981662;
word_5 field_ra;
word_64 tmp_981664;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_987744;
tmp_981664 = 0;
field_imm = 0;
/* commit */
tmp_981662 = ref_gpr_reg_for_reading(0 + index);
tmp_981661 = tmp_987707 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981661;
field_ra = tmp_981662;
emit(COMPOSE_S8ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981662);
/* can fail: T   num insns: 1 */
}
goto done_tmp_987748;
fail_tmp_987744:
/* SLL */
{
word_5 tmp_981633;
word_5 field_rc;
word_5 tmp_981634;
word_5 field_ra;
word_5 field_rb;
if (0 != ((word_64)scale)) goto fail_tmp_987745;
field_rb = 31;
/* commit */
tmp_981634 = ref_gpr_reg_for_reading(0 + index);
tmp_981633 = tmp_987707 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981633;
field_ra = tmp_981634;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981634);
/* can fail: T   num insns: 1 */
}
goto done_tmp_987748;
fail_tmp_987745:
/* SLL_IMM */
{
word_5 tmp_981629;
word_5 field_rc;
word_5 tmp_981630;
word_5 field_ra;
word_64 tmp_981632;
word_8 field_imm;
tmp_981632 = ((word_64)scale);
field_imm = tmp_981632;
/* commit */
tmp_981630 = ref_gpr_reg_for_reading(0 + index);
tmp_981629 = tmp_987707 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981629;
field_ra = tmp_981630;
emit(COMPOSE_SLL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981630);
/* can fail: NIL   num insns: 1 */
}
done_tmp_987748:
return tmp_987707;
}
void genfunc_tmp_987679 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_987361();
goto next_tmp_987206;
next_tmp_987206:
goto tmp_987205;
tmp_987205:
}
{
tmp_981603 = genfunc_tmp_987676();
goto next_tmp_987365;
next_tmp_987365:
goto tmp_987364;
tmp_987364:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 7 */
}
done_tmp_987678:
}
reg_t genfunc_tmp_987676 (void) {
reg_t tmp_987363;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_987625();
goto next_tmp_987668;
next_tmp_987668:
goto tmp_987667;
tmp_987667:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_987363 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 4 */
}
done_tmp_987675:
return tmp_987363;
}
reg_t genfunc_tmp_987628 (void) {
reg_t tmp_987379;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_987625();
goto next_tmp_987421;
next_tmp_987421:
goto tmp_987420;
tmp_987420:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_987379 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 4 */
}
done_tmp_987627:
return tmp_987379;
}
reg_t genfunc_tmp_987625 (void) {
reg_t tmp_987419;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_987361();
goto next_tmp_987599;
next_tmp_987599:
goto tmp_987598;
tmp_987598:
}
tmp_981838 = tmp_987419 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 3 */
}
done_tmp_987624:
return tmp_987419;
}
reg_t genfunc_tmp_987568 (void) {
reg_t tmp_987504;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_987529 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_987529 >> 8) == 0)
field_imm = tmp_987529;
else goto fail_tmp_987528;
}
/* commit */
{
tmp_982315 = genfunc_tmp_987480();
goto next_tmp_987532;
next_tmp_987532:
goto tmp_987531;
tmp_987531:
}
tmp_982314 = tmp_987504 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_987567;
fail_tmp_987528:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_987557 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_987557))
field_imm = inv_maskmask(8, tmp_987557);
else goto fail_tmp_987556;
}
/* commit */
{
tmp_981532 = genfunc_tmp_987480();
goto next_tmp_987560;
next_tmp_987560:
goto tmp_987559;
tmp_987559:
}
tmp_981531 = tmp_987504 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_987567;
fail_tmp_987556:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_987480();
goto next_tmp_987565;
next_tmp_987565:
goto tmp_987564;
tmp_987564:
}
tmp_981523 = tmp_987504 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_987567:
return tmp_987504;
}
reg_t genfunc_tmp_987480 (void) {
reg_t tmp_987435;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_987361();
goto next_tmp_987477;
next_tmp_987477:
goto tmp_987476;
tmp_987476:
}
tmp_981838 = tmp_987435 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 3 */
}
done_tmp_987479:
return tmp_987435;
}
reg_t genfunc_tmp_987361 (void) {
reg_t tmp_987204;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_987320 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_987320 >> 8) == 0)
field_imm = tmp_987320;
else goto fail_tmp_987319;
}
/* commit */
{
tmp_982315 = genfunc_tmp_987249();
goto next_tmp_987323;
next_tmp_987323:
goto tmp_987322;
tmp_987322:
}
tmp_982314 = tmp_987204 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 2 */
}
goto done_tmp_987360;
fail_tmp_987319:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_987350 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_987350))
field_imm = inv_maskmask(8, tmp_987350);
else goto fail_tmp_987349;
}
/* commit */
{
tmp_981532 = genfunc_tmp_987249();
goto next_tmp_987353;
next_tmp_987353:
goto tmp_987352;
tmp_987352:
}
tmp_981531 = tmp_987204 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 2 */
}
goto done_tmp_987360;
fail_tmp_987349:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_987249();
goto next_tmp_987358;
next_tmp_987358:
goto tmp_987357;
tmp_987357:
}
tmp_981523 = tmp_987204 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 2 */
}
done_tmp_987360:
return tmp_987204;
}
reg_t genfunc_tmp_987317 (void) {
reg_t tmp_987253;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_987278 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_987278 >> 8) == 0)
field_imm = tmp_987278;
else goto fail_tmp_987277;
}
/* commit */
{
tmp_982315 = genfunc_tmp_987249();
goto next_tmp_987281;
next_tmp_987281:
goto tmp_987280;
tmp_987280:
}
tmp_982314 = tmp_987253 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 2 */
}
goto done_tmp_987316;
fail_tmp_987277:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_987306 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_987306))
field_imm = inv_maskmask(8, tmp_987306);
else goto fail_tmp_987305;
}
/* commit */
{
tmp_981532 = genfunc_tmp_987249();
goto next_tmp_987309;
next_tmp_987309:
goto tmp_987308;
tmp_987308:
}
tmp_981531 = tmp_987253 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 2 */
}
goto done_tmp_987316;
fail_tmp_987305:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_987249();
goto next_tmp_987314;
next_tmp_987314:
goto tmp_987313;
tmp_987313:
}
tmp_981523 = tmp_987253 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 2 */
}
done_tmp_987316:
return tmp_987253;
}
reg_t genfunc_tmp_987249 (void) {
reg_t tmp_987220;
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_reading(0 + base);
tmp_982357 = ref_gpr_reg_for_reading(0 + index);
tmp_982354 = tmp_987220 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 1 */
}
done_tmp_987248:
return tmp_987220;
}
void genfunc_tmp_987199 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_986881();
goto next_tmp_986785;
next_tmp_986785:
goto tmp_986784;
tmp_986784:
}
{
tmp_981603 = genfunc_tmp_987196();
goto next_tmp_986885;
next_tmp_986885:
goto tmp_986884;
tmp_986884:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 5 */
}
done_tmp_987198:
}
reg_t genfunc_tmp_987196 (void) {
reg_t tmp_986883;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_987145();
goto next_tmp_987188;
next_tmp_987188:
goto tmp_987187;
tmp_987187:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_986883 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 3 */
}
done_tmp_987195:
return tmp_986883;
}
reg_t genfunc_tmp_987148 (void) {
reg_t tmp_986899;
/* SUBL */
{
word_5 tmp_981575;
word_5 field_rc;
word_5 tmp_981576;
word_5 field_ra;
word_5 tmp_981578;
word_5 field_rb;
/* commit */
{
tmp_981576 = genfunc_tmp_987145();
goto next_tmp_986941;
next_tmp_986941:
goto tmp_986940;
tmp_986940:
}
tmp_981578 = ref_gpr_reg_for_reading(0 + reg);
tmp_981575 = tmp_986899 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981575;
field_ra = tmp_981576;
field_rb = tmp_981578;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981578);
unref_gpr_reg(tmp_981576);
/* can fail: NIL   num insns: 3 */
}
done_tmp_987147:
return tmp_986899;
}
reg_t genfunc_tmp_987145 (void) {
reg_t tmp_986939;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_986881();
goto next_tmp_987119;
next_tmp_987119:
goto tmp_987118;
tmp_987118:
}
tmp_981838 = tmp_986939 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 2 */
}
done_tmp_987144:
return tmp_986939;
}
reg_t genfunc_tmp_987088 (void) {
reg_t tmp_987024;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_987049 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_987049 >> 8) == 0)
field_imm = tmp_987049;
else goto fail_tmp_987048;
}
/* commit */
{
tmp_982315 = genfunc_tmp_987000();
goto next_tmp_987052;
next_tmp_987052:
goto tmp_987051;
tmp_987051:
}
tmp_982314 = tmp_987024 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_987087;
fail_tmp_987048:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_987077 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_987077))
field_imm = inv_maskmask(8, tmp_987077);
else goto fail_tmp_987076;
}
/* commit */
{
tmp_981532 = genfunc_tmp_987000();
goto next_tmp_987080;
next_tmp_987080:
goto tmp_987079;
tmp_987079:
}
tmp_981531 = tmp_987024 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_987087;
fail_tmp_987076:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_987000();
goto next_tmp_987085;
next_tmp_987085:
goto tmp_987084;
tmp_987084:
}
tmp_981523 = tmp_987024 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_987087:
return tmp_987024;
}
reg_t genfunc_tmp_987000 (void) {
reg_t tmp_986955;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_986881();
goto next_tmp_986997;
next_tmp_986997:
goto tmp_986996;
tmp_986996:
}
tmp_981838 = tmp_986955 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 2 */
}
done_tmp_986999:
return tmp_986955;
}
reg_t genfunc_tmp_986881 (void) {
reg_t tmp_986783;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_986852 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_986852 >> 8) == 0)
field_imm = tmp_986852;
else goto fail_tmp_986851;
}
/* commit */
tmp_982315 = ref_gpr_reg_for_reading(0 + rm);
tmp_982314 = tmp_986783 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 1 */
}
goto done_tmp_986880;
fail_tmp_986851:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_986878 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_986878))
field_imm = inv_maskmask(8, tmp_986878);
else goto fail_tmp_986877;
}
/* commit */
tmp_981532 = ref_gpr_reg_for_reading(0 + rm);
tmp_981531 = tmp_986783 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 1 */
}
goto done_tmp_986880;
fail_tmp_986877:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
tmp_981524 = ref_gpr_reg_for_reading(0 + rm);
tmp_981523 = tmp_986783 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 1 */
}
done_tmp_986880:
return tmp_986783;
}
reg_t genfunc_tmp_986849 (void) {
reg_t tmp_986801;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_986822 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_986822 >> 8) == 0)
field_imm = tmp_986822;
else goto fail_tmp_986821;
}
/* commit */
tmp_982315 = ref_gpr_reg_for_reading(0 + rm);
tmp_982314 = tmp_986801 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 1 */
}
goto done_tmp_986848;
fail_tmp_986821:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_986846 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_986846))
field_imm = inv_maskmask(8, tmp_986846);
else goto fail_tmp_986845;
}
/* commit */
tmp_981532 = ref_gpr_reg_for_reading(0 + rm);
tmp_981531 = tmp_986801 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 1 */
}
goto done_tmp_986848;
fail_tmp_986845:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
tmp_981524 = ref_gpr_reg_for_reading(0 + rm);
tmp_981523 = tmp_986801 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 1 */
}
done_tmp_986848:
return tmp_986801;
}
