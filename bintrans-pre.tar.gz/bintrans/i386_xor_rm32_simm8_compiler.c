#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compiler_tmp_921846 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_921837 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921842 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_921833 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_921783 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921832 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921788 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_921791 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921792 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921795 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921825 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921829 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921826 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921817 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921822 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921818 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921821 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921796 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921799 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921809 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921816 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921810 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921815 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921813 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921802 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921805 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921807 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921806 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921803 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921797 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921779 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_921775 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_921774 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_921846 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 6 6 T)
*/
{
{
reg_t tmp_921848, tmp_921849, tmp_921847;
rhs_func(&tmp_921848, -1, env);
emit(COMPOSE_SLL_IMM(tmp_921848, 63, tmp_921848));
emit(COMPOSE_SRL_IMM(tmp_921848, 57, tmp_921848));
tmp_921849 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_921849, -1);
emit(COMPOSE_SLL_IMM(tmp_921849, 63, tmp_921849));
emit(COMPOSE_SRL_IMM(tmp_921849, 57, tmp_921849));
tmp_921847 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_921847, tmp_921849, tmp_921847));
unref_integer_reg(tmp_921849);
emit(COMPOSE_BIS(tmp_921847, tmp_921848, tmp_921847));
unref_integer_reg(tmp_921848);
unref_integer_reg(tmp_921847);
}
}

void compiler_tmp_921837 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (=
  (CASE
   ((0 1 2)
    (MEM
     (CASE
      ((0)
       (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
        ((4)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))
        ((5) (FIELD DISP32 NIL NIL))))
      ((1)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
        ((4)
         (+ (SEX (FIELD DISP8 NIL NIL))
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0))))))))
      ((2)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
        ((4)
         (+ (FIELD DISP32 NIL NIL)
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0)))))))))))
   ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
  (INTEGER 0))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_921839 = alloc_label(), tmp_921840 = alloc_label(), tmp_921841 = alloc_label();
reg_t tmp_921838;
compiler_tmp_921842(tmp_921839, tmp_921840, env);

tmp_921838 = ref_integer_reg_for_writing(-1);
emit_label(tmp_921839);
push_alloc();
compiler_tmp_921832(&tmp_921838, tmp_921838 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_921841);
emit_label(tmp_921840);
push_alloc();
compiler_tmp_921774(&tmp_921838, tmp_921838 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_921841);
free_label(tmp_921839);
free_label(tmp_921840);
free_label(tmp_921841);
if (foreign_target == -1)
*target = tmp_921838;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_921838, *target));
unref_integer_reg(tmp_921838);
}

}
}

void compiler_tmp_921842 (label_t true_label, label_t false_label, void **env)
/*
(=
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (INTEGER 0))
*/
{
{
reg_t tmp_921843, tmp_921844, tmp_921845;
compiler_tmp_921791(&tmp_921843, -1, env);
compiler_tmp_921816(&tmp_921844, -1, env);
tmp_921845 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_CMPEQ(tmp_921843, tmp_921844, tmp_921845));
unref_integer_reg(tmp_921843);
unref_integer_reg(tmp_921844);
emit_branch(COMPOSE_BEQ(tmp_921845, 0), false_label);
unref_integer_reg(tmp_921845);
emit_branch(COMPOSE_BR(31, 0), true_label);
}
}

void compiler_tmp_921833 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 7 7 T)
*/
{
{
reg_t tmp_921835, tmp_921836, tmp_921834;
rhs_func(&tmp_921835, -1, env);
emit(COMPOSE_SLL_IMM(tmp_921835, 63, tmp_921835));
emit(COMPOSE_SRL_IMM(tmp_921835, 56, tmp_921835));
tmp_921836 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_921836, -1);
emit(COMPOSE_SLL_IMM(tmp_921836, 63, tmp_921836));
emit(COMPOSE_SRL_IMM(tmp_921836, 56, tmp_921836));
tmp_921834 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_921834, tmp_921836, tmp_921834));
unref_integer_reg(tmp_921836);
emit(COMPOSE_BIS(tmp_921834, tmp_921835, tmp_921834));
unref_integer_reg(tmp_921835);
unref_integer_reg(tmp_921834);
}
}

void compiler_tmp_921783 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (BIT-SET-P
  (CASE
   ((0 1 2)
    (MEM
     (CASE
      ((0)
       (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
        ((4)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))
        ((5) (FIELD DISP32 NIL NIL))))
      ((1)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
        ((4)
         (+ (SEX (FIELD DISP8 NIL NIL))
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0))))))))
      ((2)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
        ((4)
         (+ (FIELD DISP32 NIL NIL)
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0)))))))))))
   ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
  (- (INTEGER 32) (INTEGER 1)))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_921785 = alloc_label(), tmp_921786 = alloc_label(), tmp_921787 = alloc_label();
reg_t tmp_921784;
compiler_tmp_921788(tmp_921785, tmp_921786, env);

tmp_921784 = ref_integer_reg_for_writing(-1);
emit_label(tmp_921785);
push_alloc();
compiler_tmp_921832(&tmp_921784, tmp_921784 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_921787);
emit_label(tmp_921786);
push_alloc();
compiler_tmp_921774(&tmp_921784, tmp_921784 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_921787);
free_label(tmp_921785);
free_label(tmp_921786);
free_label(tmp_921787);
if (foreign_target == -1)
*target = tmp_921784;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_921784, *target));
unref_integer_reg(tmp_921784);
}

}
}

void compiler_tmp_921832 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 1)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 1);
}

void compiler_tmp_921788 (label_t true_label, label_t false_label, void **env)
/*
(BIT-SET-P
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (- (INTEGER 32) (INTEGER 1)))
*/
{
{
reg_t tmp_921789, tmp_921790;
compiler_tmp_921791(&tmp_921789, -1, env);
tmp_921790 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_SRL_IMM(tmp_921789, (32 - 1), tmp_921790));
unref_integer_reg(tmp_921789);
emit_branch(COMPOSE_BLBS(tmp_921790, 0), true_label);
unref_integer_reg(tmp_921790);
emit_branch(COMPOSE_BR(31, 0), false_label);
}
}

void compiler_tmp_921791 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2)
  (MEM
   (CASE
    ((0)
     (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
      ((4)
       (+
        (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
         ((5)
          (CASE ((0) (FIELD DISP32 NIL NIL))
           ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
        (CASE
         ((0 1 2 3 5 6 7)
          (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
           (ZEX (FIELD SCALE NIL NIL))))
         ((4) (INTEGER 0)))))
      ((5) (FIELD DISP32 NIL NIL))))
    ((1)
     (CASE
      ((0 1 2 3 5 6 7)
       (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
      ((4)
       (+ (SEX (FIELD DISP8 NIL NIL))
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0))))))))
    ((2)
     (CASE
      ((0 1 2 3 5 6 7)
       (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
      ((4)
       (+ (FIELD DISP32 NIL NIL)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))))))))
 ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
*/
{
switch (mod) {
case 0:
case 1:
case 2:
compiler_tmp_921792(&(*target), foreign_target, env);
break;
case 3:
compiler_tmp_921797(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_921792 (reg_t *target, int foreign_target, void **env)
/*
(MEM
 (CASE
  ((0)
   (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
    ((4)
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0)))))
    ((5) (FIELD DISP32 NIL NIL))))
  ((1)
   (CASE
    ((0 1 2 3 5 6 7)
     (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
    ((4)
     (+ (SEX (FIELD DISP8 NIL NIL))
      (+
       (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
        ((5)
         (CASE ((0) (FIELD DISP32 NIL NIL))
          ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
       (CASE
        ((0 1 2 3 5 6 7)
         (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
          (ZEX (FIELD SCALE NIL NIL))))
        ((4) (INTEGER 0))))))))
  ((2)
   (CASE
    ((0 1 2 3 5 6 7)
     (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
    ((4)
     (+ (FIELD DISP32 NIL NIL)
      (+
       (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
        ((5)
         (CASE ((0) (FIELD DISP32 NIL NIL))
          ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
       (CASE
        ((0 1 2 3 5 6 7)
         (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
          (ZEX (FIELD SCALE NIL NIL))))
        ((4) (INTEGER 0))))))))))
*/
{
{
reg_t tmp_921793, tmp_921794;
compiler_tmp_921795(&tmp_921793, -1, env);
#ifdef EMU_I386
tmp_921794 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ZAPNOT_IMM(tmp_921793, 15, tmp_921794));
unref_integer_reg(tmp_921793);
#else
tmp_921794 = tmp_921793;
#endif
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_mem_32(*target, tmp_921794);
unref_integer_reg(tmp_921794);
}
}

void compiler_tmp_921795 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0)
  (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
   ((4)
    (+
     (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
      ((5)
       (CASE ((0) (FIELD DISP32 NIL NIL))
        ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
     (CASE
      ((0 1 2 3 5 6 7)
       (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
        (ZEX (FIELD SCALE NIL NIL))))
      ((4) (INTEGER 0)))))
   ((5) (FIELD DISP32 NIL NIL))))
 ((1)
  (CASE
   ((0 1 2 3 5 6 7)
    (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
   ((4)
    (+ (SEX (FIELD DISP8 NIL NIL))
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0))))))))
 ((2)
  (CASE
   ((0 1 2 3 5 6 7)
    (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
   ((4)
    (+ (FIELD DISP32 NIL NIL)
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0)))))))))
*/
{
switch (mod) {
case 0:
compiler_tmp_921796(&(*target), foreign_target, env);
break;
case 1:
compiler_tmp_921817(&(*target), foreign_target, env);
break;
case 2:
compiler_tmp_921825(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_921825 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
 ((4)
  (+ (FIELD DISP32 NIL NIL)
   (+
    (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
     ((5)
      (CASE ((0) (FIELD DISP32 NIL NIL))
       ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
    (CASE
     ((0 1 2 3 5 6 7)
      (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
       (ZEX (FIELD SCALE NIL NIL))))
     ((4) (INTEGER 0)))))))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_921826(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_921829(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_921829 (reg_t *target, int foreign_target, void **env)
/*
(+ (FIELD DISP32 NIL NIL)
 (+
  (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
   ((5)
    (CASE ((0) (FIELD DISP32 NIL NIL))
     ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
  (CASE
   ((0 1 2 3 5 6 7)
    (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
     (ZEX (FIELD SCALE NIL NIL))))
   ((4) (INTEGER 0)))))
*/
{
{
reg_t tmp_921830, tmp_921831;
compiler_tmp_921806(&tmp_921830, -1, env);
compiler_tmp_921799(&tmp_921831, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_921830, tmp_921831, *target));
unref_integer_reg(tmp_921830);
unref_integer_reg(tmp_921831);
}
}

void compiler_tmp_921826 (reg_t *target, int foreign_target, void **env)
/*
(+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL))
*/
{
{
reg_t tmp_921827, tmp_921828;
compiler_tmp_921797(&tmp_921827, -1, env);
compiler_tmp_921806(&tmp_921828, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_921827, tmp_921828, *target));
unref_integer_reg(tmp_921827);
unref_integer_reg(tmp_921828);
}
}

void compiler_tmp_921817 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
 ((4)
  (+ (SEX (FIELD DISP8 NIL NIL))
   (+
    (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
     ((5)
      (CASE ((0) (FIELD DISP32 NIL NIL))
       ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
    (CASE
     ((0 1 2 3 5 6 7)
      (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
       (ZEX (FIELD SCALE NIL NIL))))
     ((4) (INTEGER 0)))))))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_921818(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_921822(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_921822 (reg_t *target, int foreign_target, void **env)
/*
(+ (SEX (FIELD DISP8 NIL NIL))
 (+
  (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
   ((5)
    (CASE ((0) (FIELD DISP32 NIL NIL))
     ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
  (CASE
   ((0 1 2 3 5 6 7)
    (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
     (ZEX (FIELD SCALE NIL NIL))))
   ((4) (INTEGER 0)))))
*/
{
{
reg_t tmp_921823, tmp_921824;
compiler_tmp_921821(&tmp_921823, -1, env);
compiler_tmp_921799(&tmp_921824, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_921823, tmp_921824, *target));
unref_integer_reg(tmp_921823);
unref_integer_reg(tmp_921824);
}
}

void compiler_tmp_921818 (reg_t *target, int foreign_target, void **env)
/*
(+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL)))
*/
{
{
reg_t tmp_921819, tmp_921820;
compiler_tmp_921797(&tmp_921819, -1, env);
compiler_tmp_921821(&tmp_921820, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_921819, tmp_921820, *target));
unref_integer_reg(tmp_921819);
unref_integer_reg(tmp_921820);
}
}

void compiler_tmp_921821 (reg_t *target, int foreign_target, void **env)
/*
(SEX (FIELD DISP8 NIL NIL))
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
}

void compiler_tmp_921796 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
 ((4)
  (+
   (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
    ((5)
     (CASE ((0) (FIELD DISP32 NIL NIL))
      ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
   (CASE
    ((0 1 2 3 5 6 7)
     (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
      (ZEX (FIELD SCALE NIL NIL))))
    ((4) (INTEGER 0)))))
 ((5) (FIELD DISP32 NIL NIL)))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 6:
case 7:
compiler_tmp_921797(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_921799(&(*target), foreign_target, env);
break;
case 5:
compiler_tmp_921806(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_921799 (reg_t *target, int foreign_target, void **env)
/*
(+
 (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
  ((5)
   (CASE ((0) (FIELD DISP32 NIL NIL))
    ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
 (CASE
  ((0 1 2 3 5 6 7)
   (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
    (ZEX (FIELD SCALE NIL NIL))))
  ((4) (INTEGER 0))))
*/
{
{
reg_t tmp_921800, tmp_921801;
compiler_tmp_921802(&tmp_921800, -1, env);
compiler_tmp_921809(&tmp_921801, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_921800, tmp_921801, *target));
unref_integer_reg(tmp_921800);
unref_integer_reg(tmp_921801);
}
}

void compiler_tmp_921809 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
   (ZEX (FIELD SCALE NIL NIL))))
 ((4) (INTEGER 0)))
*/
{
switch (index) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_921810(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_921816(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_921816 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_921810 (reg_t *target, int foreign_target, void **env)
/*
(SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL)) (ZEX (FIELD SCALE NIL NIL)))
*/
{
{
reg_t tmp_921811, tmp_921812;
compiler_tmp_921813(&tmp_921811, -1, env);
compiler_tmp_921815(&tmp_921812, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_SLL(tmp_921811, tmp_921812, *target));
unref_integer_reg(tmp_921811);
unref_integer_reg(tmp_921812);
emit(COMPOSE_ADDL((*target), 31, (*target)));
}
}

void compiler_tmp_921815 (reg_t *target, int foreign_target, void **env)
/*
(ZEX (FIELD SCALE NIL NIL))
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, scale);
}

void compiler_tmp_921813 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD INDEX NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + index));
else {
reg_t tmp_921814 = ref_integer_reg_for_reading((0 + index));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_921814, *target));
unref_integer_reg(tmp_921814);
}
}

void compiler_tmp_921802 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
 ((5)
  (CASE ((0) (FIELD DISP32 NIL NIL))
   ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
*/
{
switch (base) {
case 0:
case 1:
case 2:
case 3:
case 4:
case 6:
case 7:
compiler_tmp_921803(&(*target), foreign_target, env);
break;
case 5:
compiler_tmp_921805(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_921805 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0) (FIELD DISP32 NIL NIL)) ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))
*/
{
switch (mod) {
case 0:
compiler_tmp_921806(&(*target), foreign_target, env);
break;
case 1:
case 2:
case 3:
compiler_tmp_921807(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_921807 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER EBP GPR (INTEGER 5))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading(5);
else {
reg_t tmp_921808 = ref_integer_reg_for_reading(5);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_921808, *target));
unref_integer_reg(tmp_921808);
}
}

void compiler_tmp_921806 (reg_t *target, int foreign_target, void **env)
/*
(FIELD DISP32 NIL NIL)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, disp32);
}

void compiler_tmp_921803 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD BASE NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + base));
else {
reg_t tmp_921804 = ref_integer_reg_for_reading((0 + base));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_921804, *target));
unref_integer_reg(tmp_921804);
}
}

void compiler_tmp_921797 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD RM NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + rm));
else {
reg_t tmp_921798 = ref_integer_reg_for_reading((0 + rm));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_921798, *target));
unref_integer_reg(tmp_921798);
}
}

void compiler_tmp_921779 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 11 11 T)
*/
{
{
reg_t tmp_921781, tmp_921782, tmp_921780;
rhs_func(&tmp_921781, -1, env);
emit(COMPOSE_SLL_IMM(tmp_921781, 63, tmp_921781));
emit(COMPOSE_SRL_IMM(tmp_921781, 52, tmp_921781));
tmp_921782 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_921782, -1);
emit(COMPOSE_SLL_IMM(tmp_921782, 63, tmp_921782));
emit(COMPOSE_SRL_IMM(tmp_921782, 52, tmp_921782));
tmp_921780 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_921780, tmp_921782, tmp_921780));
unref_integer_reg(tmp_921782);
emit(COMPOSE_BIS(tmp_921780, tmp_921781, tmp_921780));
unref_integer_reg(tmp_921781);
unref_integer_reg(tmp_921780);
}
}

void compiler_tmp_921775 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 0 0 T)
*/
{
{
reg_t tmp_921777, tmp_921778, tmp_921776;
rhs_func(&tmp_921777, -1, env);
emit(COMPOSE_SLL_IMM(tmp_921777, 63, tmp_921777));
emit(COMPOSE_SRL_IMM(tmp_921777, 63, tmp_921777));
tmp_921778 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_921778, -1);
emit(COMPOSE_SLL_IMM(tmp_921778, 63, tmp_921778));
emit(COMPOSE_SRL_IMM(tmp_921778, 63, tmp_921778));
tmp_921776 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_921776, tmp_921778, tmp_921776));
unref_integer_reg(tmp_921778);
emit(COMPOSE_BIS(tmp_921776, tmp_921777, tmp_921776));
unref_integer_reg(tmp_921777);
unref_integer_reg(tmp_921776);
}
}

void compiler_tmp_921774 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compile_xor_rm32_simm8_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; })&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_910405();
goto next_tmp_910162;
next_tmp_910162:
goto finish_tmp_910161;
finish_tmp_910161:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; })&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_910665();
goto next_tmp_910408;
next_tmp_910408:
goto finish_tmp_910407;
finish_tmp_910407:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_910954();
goto next_tmp_910668;
next_tmp_910668:
goto finish_tmp_910667;
finish_tmp_910667:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_911214();
goto next_tmp_910957;
next_tmp_910957:
goto finish_tmp_910956;
finish_tmp_910956:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_911538();
goto next_tmp_911217;
next_tmp_911217:
goto finish_tmp_911216;
finish_tmp_911216:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_911798();
goto next_tmp_911541;
next_tmp_911541:
goto finish_tmp_911540;
finish_tmp_911540:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_912044();
goto next_tmp_911801;
next_tmp_911801:
goto finish_tmp_911800;
finish_tmp_911800:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_912304();
goto next_tmp_912047;
next_tmp_912047:
goto finish_tmp_912046;
finish_tmp_912046:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_912595();
goto next_tmp_912307;
next_tmp_912307:
goto finish_tmp_912306;
finish_tmp_912306:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_912855();
goto next_tmp_912598;
next_tmp_912598:
goto finish_tmp_912597;
finish_tmp_912597:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_913155();
goto next_tmp_912858;
next_tmp_912858:
goto finish_tmp_912857;
finish_tmp_912857:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_913415();
goto next_tmp_913158;
next_tmp_913158:
goto finish_tmp_913157;
finish_tmp_913157:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_913585();
goto next_tmp_913418;
next_tmp_913418:
goto finish_tmp_913417;
finish_tmp_913417:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_913847();
goto next_tmp_913588;
next_tmp_913588:
goto finish_tmp_913587;
finish_tmp_913587:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; })&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; }))
{
genfunc_tmp_913585();
goto next_tmp_913850;
next_tmp_913850:
goto finish_tmp_913849;
finish_tmp_913849:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; })&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; }))
{
genfunc_tmp_913847();
goto next_tmp_913853;
next_tmp_913853:
goto finish_tmp_913852;
finish_tmp_913852:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_914149();
goto next_tmp_913856;
next_tmp_913856:
goto finish_tmp_913855;
finish_tmp_913855:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_914409();
goto next_tmp_914152;
next_tmp_914152:
goto finish_tmp_914151;
finish_tmp_914151:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_914709();
goto next_tmp_914412;
next_tmp_914412:
goto finish_tmp_914411;
finish_tmp_914411:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_914969();
goto next_tmp_914712;
next_tmp_914712:
goto finish_tmp_914711;
finish_tmp_914711:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_915269();
goto next_tmp_914972;
next_tmp_914972:
goto finish_tmp_914971;
finish_tmp_914971:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_915529();
goto next_tmp_915272;
next_tmp_915272:
goto finish_tmp_915271;
finish_tmp_915271:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_915820();
goto next_tmp_915532;
next_tmp_915532:
goto finish_tmp_915531;
finish_tmp_915531:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_916080();
goto next_tmp_915823;
next_tmp_915823:
goto finish_tmp_915822;
finish_tmp_915822:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_916399();
goto next_tmp_916083;
next_tmp_916083:
goto finish_tmp_916082;
finish_tmp_916082:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_916659();
goto next_tmp_916402;
next_tmp_916402:
goto finish_tmp_916401;
finish_tmp_916401:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_916981();
goto next_tmp_916662;
next_tmp_916662:
goto finish_tmp_916661;
finish_tmp_916661:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_917241();
goto next_tmp_916984;
next_tmp_916984:
goto finish_tmp_916983;
finish_tmp_916983:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_917532();
goto next_tmp_917244;
next_tmp_917244:
goto finish_tmp_917243;
finish_tmp_917243:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_917792();
goto next_tmp_917535;
next_tmp_917535:
goto finish_tmp_917534;
finish_tmp_917534:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_918088();
goto next_tmp_917795;
next_tmp_917795:
goto finish_tmp_917794;
finish_tmp_917794:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_918348();
goto next_tmp_918091;
next_tmp_918091:
goto finish_tmp_918090;
finish_tmp_918090:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_918648();
goto next_tmp_918351;
next_tmp_918351:
goto finish_tmp_918350;
finish_tmp_918350:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_918908();
goto next_tmp_918651;
next_tmp_918651:
goto finish_tmp_918650;
finish_tmp_918650:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_919208();
goto next_tmp_918911;
next_tmp_918911:
goto finish_tmp_918910;
finish_tmp_918910:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_919468();
goto next_tmp_919211;
next_tmp_919211:
goto finish_tmp_919210;
finish_tmp_919210:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_919759();
goto next_tmp_919471;
next_tmp_919471:
goto finish_tmp_919470;
finish_tmp_919470:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_920019();
goto next_tmp_919762;
next_tmp_919762:
goto finish_tmp_919761;
finish_tmp_919761:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_920319();
goto next_tmp_920022;
next_tmp_920022:
goto finish_tmp_920021;
finish_tmp_920021:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_920579();
goto next_tmp_920322;
next_tmp_920322:
goto finish_tmp_920321;
finish_tmp_920321:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_920879();
goto next_tmp_920582;
next_tmp_920582:
goto finish_tmp_920581;
finish_tmp_920581:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_921139();
goto next_tmp_920882;
next_tmp_920882:
goto finish_tmp_920881;
finish_tmp_920881:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_921430();
goto next_tmp_921142;
next_tmp_921142:
goto finish_tmp_921141;
finish_tmp_921141:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_921690();
goto next_tmp_921433;
next_tmp_921433:
goto finish_tmp_921432;
finish_tmp_921432:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 3; })&& (((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0)&& ({ word_2 tmp = mod; 0 || tmp == 3; }))
{
genfunc_tmp_921703();
goto next_tmp_921693;
next_tmp_921693:
goto finish_tmp_921692;
finish_tmp_921692:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 3; })&& (!(((imm8 & 0x80) ? ((word_32)imm8 | 0xFFFFFF00) : (word_32)imm8) == 0))&& ({ word_2 tmp = mod; 0 || tmp == 3; }))
{
genfunc_tmp_921772();
goto next_tmp_921706;
next_tmp_921706:
goto finish_tmp_921705;
finish_tmp_921705:
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_921774;
killed |= 0x1;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_921775(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_921774;
killed |= 0x800;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_921779(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_921783;
killed |= 0x80;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_921833(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_921837;
killed |= 0x40;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_921846(rhs_func, env);
}
}
}
void genfunc_tmp_921772 (void) {
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_921756;
field_rb = 31;
/* commit */
tmp_731669 = ref_gpr_reg_for_reading(0 + rm);
tmp_731668 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731668);
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 1 */
}
goto done_tmp_921771;
fail_tmp_921756:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_921758 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_921758 >> 8) == 0)
field_imm = tmp_921758;
else goto fail_tmp_921757;
}
/* commit */
tmp_731665 = ref_gpr_reg_for_reading(0 + rm);
tmp_731664 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731664);
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 1 */
}
goto done_tmp_921771;
fail_tmp_921757:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_921768;
field_rb = 31;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + rm);
tmp_731086 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 1 */
}
goto done_tmp_921771;
fail_tmp_921768:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_921770 = tmp_731085;
if ((tmp_921770 >> 8) == 0)
field_imm = tmp_921770;
else goto fail_tmp_921769;
}
/* commit */
tmp_731083 = ref_gpr_reg_for_reading(0 + rm);
tmp_731082 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731082);
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 1 */
}
goto done_tmp_921771;
fail_tmp_921769:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + rm);
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 2 */
}
done_tmp_921771:
}
reg_t genfunc_tmp_921734 (void) {
reg_t tmp_731898;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_921722;
field_rb = 31;
/* commit */
tmp_731669 = ref_gpr_reg_for_reading(0 + rm);
tmp_731668 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 1 */
}
goto done_tmp_921733;
fail_tmp_921722:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_921724 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_921724 >> 8) == 0)
field_imm = tmp_921724;
else goto fail_tmp_921723;
}
/* commit */
tmp_731665 = ref_gpr_reg_for_reading(0 + rm);
tmp_731664 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 1 */
}
goto done_tmp_921733;
fail_tmp_921723:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_921730;
field_rb = 31;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + rm);
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 1 */
}
goto done_tmp_921733;
fail_tmp_921730:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_921732 = tmp_731085;
if ((tmp_921732 >> 8) == 0)
field_imm = tmp_921732;
else goto fail_tmp_921731;
}
/* commit */
tmp_731083 = ref_gpr_reg_for_reading(0 + rm);
tmp_731082 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 1 */
}
goto done_tmp_921733;
fail_tmp_921731:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + rm);
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 2 */
}
done_tmp_921733:
return tmp_731898;
}
void genfunc_tmp_921703 (void) {
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 field_rb;
field_rb = 31;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731897 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731897;
field_ra = tmp_731898;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731897);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_921702:
}
void genfunc_tmp_921690 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_921266();
goto next_tmp_921436;
next_tmp_921436:
goto tmp_921435;
tmp_921435:
}
{
tmp_731146 = genfunc_tmp_921687();
goto next_tmp_921439;
next_tmp_921439:
goto tmp_921438;
tmp_921438:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_921689:
}
reg_t genfunc_tmp_921687 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_921610;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_921310();
goto next_tmp_921612;
next_tmp_921612:
goto tmp_921611;
tmp_921611:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_921686;
fail_tmp_921610:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_921615 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_921615 >> 8) == 0)
field_imm = tmp_921615;
else goto fail_tmp_921614;
}
/* commit */
{
tmp_731665 = genfunc_tmp_921310();
goto next_tmp_921617;
next_tmp_921617:
goto tmp_921616;
tmp_921616:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_921686;
fail_tmp_921614:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_921677;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_921310();
goto next_tmp_921679;
next_tmp_921679:
goto tmp_921678;
tmp_921678:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_921686;
fail_tmp_921677:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_921682 = tmp_731085;
if ((tmp_921682 >> 8) == 0)
field_imm = tmp_921682;
else goto fail_tmp_921681;
}
/* commit */
{
tmp_731083 = genfunc_tmp_921310();
goto next_tmp_921684;
next_tmp_921684:
goto tmp_921683;
tmp_921683:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_921686;
fail_tmp_921681:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_921310();
goto next_tmp_921675;
next_tmp_921675:
goto tmp_921674;
tmp_921674:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_921686:
return tmp_731146;
}
void genfunc_tmp_921430 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_921266();
goto next_tmp_921145;
next_tmp_921145:
goto tmp_921144;
tmp_921144:
}
{
tmp_731146 = genfunc_tmp_921427();
goto next_tmp_921269;
next_tmp_921269:
goto tmp_921268;
tmp_921268:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_921429:
}
reg_t genfunc_tmp_921427 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_921266();
goto next_tmp_921404;
next_tmp_921404:
goto tmp_921403;
tmp_921403:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_921426:
return tmp_731146;
}
reg_t genfunc_tmp_921379 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_921348 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_921348 >> 8) == 0)
field_imm = tmp_921348;
else goto fail_tmp_921347;
}
/* commit */
{
tmp_731858 = genfunc_tmp_921310();
goto next_tmp_921350;
next_tmp_921350:
goto tmp_921349;
tmp_921349:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_921378;
fail_tmp_921347:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_921370 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_921370))
field_imm = inv_maskmask(8, tmp_921370);
else goto fail_tmp_921369;
}
/* commit */
{
tmp_731075 = genfunc_tmp_921310();
goto next_tmp_921372;
next_tmp_921372:
goto tmp_921371;
tmp_921371:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_921378;
fail_tmp_921369:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_921310();
goto next_tmp_921376;
next_tmp_921376:
goto tmp_921375;
tmp_921375:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_921378:
return tmp_731862;
}
reg_t genfunc_tmp_921310 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_921266();
goto next_tmp_921307;
next_tmp_921307:
goto tmp_921306;
tmp_921306:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_921309:
return tmp_731898;
}
reg_t genfunc_tmp_921266 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_921233 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_921233 >> 8) == 0)
field_imm = tmp_921233;
else goto fail_tmp_921232;
}
/* commit */
{
tmp_731858 = genfunc_tmp_921177();
goto next_tmp_921235;
next_tmp_921235:
goto tmp_921234;
tmp_921234:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_921265;
fail_tmp_921232:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_921257 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_921257))
field_imm = inv_maskmask(8, tmp_921257);
else goto fail_tmp_921256;
}
/* commit */
{
tmp_731075 = genfunc_tmp_921177();
goto next_tmp_921259;
next_tmp_921259:
goto tmp_921258;
tmp_921258:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_921265;
fail_tmp_921256:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_921177();
goto next_tmp_921263;
next_tmp_921263:
goto tmp_921262;
tmp_921262:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_921265:
return tmp_731142;
}
reg_t genfunc_tmp_921230 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_921199 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_921199 >> 8) == 0)
field_imm = tmp_921199;
else goto fail_tmp_921198;
}
/* commit */
{
tmp_731858 = genfunc_tmp_921177();
goto next_tmp_921201;
next_tmp_921201:
goto tmp_921200;
tmp_921200:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_921229;
fail_tmp_921198:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_921221 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_921221))
field_imm = inv_maskmask(8, tmp_921221);
else goto fail_tmp_921220;
}
/* commit */
{
tmp_731075 = genfunc_tmp_921177();
goto next_tmp_921223;
next_tmp_921223:
goto tmp_921222;
tmp_921222:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_921229;
fail_tmp_921220:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_921177();
goto next_tmp_921227;
next_tmp_921227:
goto tmp_921226;
tmp_921226:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_921229:
return tmp_731862;
}
reg_t genfunc_tmp_921177 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_921174;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + 5);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_921176;
fail_tmp_921174:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_921175;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + 5);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_921176;
fail_tmp_921175:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + 5);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_921176:
return tmp_731876;
}
void genfunc_tmp_921139 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_920715();
goto next_tmp_920885;
next_tmp_920885:
goto tmp_920884;
tmp_920884:
}
{
tmp_731146 = genfunc_tmp_921136();
goto next_tmp_920888;
next_tmp_920888:
goto tmp_920887;
tmp_920887:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 14 */
}
done_tmp_921138:
}
reg_t genfunc_tmp_921136 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_921059;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_920759();
goto next_tmp_921061;
next_tmp_921061:
goto tmp_921060;
tmp_921060:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 7 */
}
goto done_tmp_921135;
fail_tmp_921059:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_921064 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_921064 >> 8) == 0)
field_imm = tmp_921064;
else goto fail_tmp_921063;
}
/* commit */
{
tmp_731665 = genfunc_tmp_920759();
goto next_tmp_921066;
next_tmp_921066:
goto tmp_921065;
tmp_921065:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 7 */
}
goto done_tmp_921135;
fail_tmp_921063:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_921126;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_920759();
goto next_tmp_921128;
next_tmp_921128:
goto tmp_921127;
tmp_921127:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 7 */
}
goto done_tmp_921135;
fail_tmp_921126:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_921131 = tmp_731085;
if ((tmp_921131 >> 8) == 0)
field_imm = tmp_921131;
else goto fail_tmp_921130;
}
/* commit */
{
tmp_731083 = genfunc_tmp_920759();
goto next_tmp_921133;
next_tmp_921133:
goto tmp_921132;
tmp_921132:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 7 */
}
goto done_tmp_921135;
fail_tmp_921130:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_920759();
goto next_tmp_921124;
next_tmp_921124:
goto tmp_921123;
tmp_921123:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 8 */
}
done_tmp_921135:
return tmp_731146;
}
void genfunc_tmp_920879 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_920715();
goto next_tmp_920585;
next_tmp_920585:
goto tmp_920584;
tmp_920584:
}
{
tmp_731146 = genfunc_tmp_920876();
goto next_tmp_920718;
next_tmp_920718:
goto tmp_920717;
tmp_920717:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_920878:
}
reg_t genfunc_tmp_920876 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_920715();
goto next_tmp_920853;
next_tmp_920853:
goto tmp_920852;
tmp_920852:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_920875:
return tmp_731146;
}
reg_t genfunc_tmp_920828 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_920797 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_920797 >> 8) == 0)
field_imm = tmp_920797;
else goto fail_tmp_920796;
}
/* commit */
{
tmp_731858 = genfunc_tmp_920759();
goto next_tmp_920799;
next_tmp_920799:
goto tmp_920798;
tmp_920798:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 7 */
}
goto done_tmp_920827;
fail_tmp_920796:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_920819 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_920819))
field_imm = inv_maskmask(8, tmp_920819);
else goto fail_tmp_920818;
}
/* commit */
{
tmp_731075 = genfunc_tmp_920759();
goto next_tmp_920821;
next_tmp_920821:
goto tmp_920820;
tmp_920820:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 7 */
}
goto done_tmp_920827;
fail_tmp_920818:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_920759();
goto next_tmp_920825;
next_tmp_920825:
goto tmp_920824;
tmp_920824:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 7 */
}
done_tmp_920827:
return tmp_731862;
}
reg_t genfunc_tmp_920759 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_920715();
goto next_tmp_920756;
next_tmp_920756:
goto tmp_920755;
tmp_920755:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_920758:
return tmp_731898;
}
reg_t genfunc_tmp_920715 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_920682 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_920682 >> 8) == 0)
field_imm = tmp_920682;
else goto fail_tmp_920681;
}
/* commit */
{
tmp_731858 = genfunc_tmp_920626();
goto next_tmp_920684;
next_tmp_920684:
goto tmp_920683;
tmp_920683:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_920714;
fail_tmp_920681:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_920706 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_920706))
field_imm = inv_maskmask(8, tmp_920706);
else goto fail_tmp_920705;
}
/* commit */
{
tmp_731075 = genfunc_tmp_920626();
goto next_tmp_920708;
next_tmp_920708:
goto tmp_920707;
tmp_920707:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_920714;
fail_tmp_920705:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_920626();
goto next_tmp_920712;
next_tmp_920712:
goto tmp_920711;
tmp_920711:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_920714:
return tmp_731142;
}
reg_t genfunc_tmp_920679 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_920648 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_920648 >> 8) == 0)
field_imm = tmp_920648;
else goto fail_tmp_920647;
}
/* commit */
{
tmp_731858 = genfunc_tmp_920626();
goto next_tmp_920650;
next_tmp_920650:
goto tmp_920649;
tmp_920649:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_920678;
fail_tmp_920647:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_920670 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_920670))
field_imm = inv_maskmask(8, tmp_920670);
else goto fail_tmp_920669;
}
/* commit */
{
tmp_731075 = genfunc_tmp_920626();
goto next_tmp_920672;
next_tmp_920672:
goto tmp_920671;
tmp_920671:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_920678;
fail_tmp_920669:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_920626();
goto next_tmp_920676;
next_tmp_920676:
goto tmp_920675;
tmp_920675:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_920678:
return tmp_731862;
}
reg_t genfunc_tmp_920626 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_920617;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_916703();
goto next_tmp_920619;
next_tmp_920619:
goto tmp_920618;
tmp_920618:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_920625;
fail_tmp_920617:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_920621;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_916703();
goto next_tmp_920623;
next_tmp_920623:
goto tmp_920622;
tmp_920622:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_920625;
fail_tmp_920621:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_916703();
goto next_tmp_920601;
next_tmp_920601:
goto tmp_920600;
tmp_920600:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_920625:
return tmp_731876;
}
void genfunc_tmp_920579 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_920155();
goto next_tmp_920325;
next_tmp_920325:
goto tmp_920324;
tmp_920324:
}
{
tmp_731146 = genfunc_tmp_920576();
goto next_tmp_920328;
next_tmp_920328:
goto tmp_920327;
tmp_920327:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_920578:
}
reg_t genfunc_tmp_920576 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_920499;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_920199();
goto next_tmp_920501;
next_tmp_920501:
goto tmp_920500;
tmp_920500:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 6 */
}
goto done_tmp_920575;
fail_tmp_920499:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_920504 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_920504 >> 8) == 0)
field_imm = tmp_920504;
else goto fail_tmp_920503;
}
/* commit */
{
tmp_731665 = genfunc_tmp_920199();
goto next_tmp_920506;
next_tmp_920506:
goto tmp_920505;
tmp_920505:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 6 */
}
goto done_tmp_920575;
fail_tmp_920503:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_920566;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_920199();
goto next_tmp_920568;
next_tmp_920568:
goto tmp_920567;
tmp_920567:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 6 */
}
goto done_tmp_920575;
fail_tmp_920566:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_920571 = tmp_731085;
if ((tmp_920571 >> 8) == 0)
field_imm = tmp_920571;
else goto fail_tmp_920570;
}
/* commit */
{
tmp_731083 = genfunc_tmp_920199();
goto next_tmp_920573;
next_tmp_920573:
goto tmp_920572;
tmp_920572:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 6 */
}
goto done_tmp_920575;
fail_tmp_920570:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_920199();
goto next_tmp_920564;
next_tmp_920564:
goto tmp_920563;
tmp_920563:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_920575:
return tmp_731146;
}
void genfunc_tmp_920319 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_920155();
goto next_tmp_920025;
next_tmp_920025:
goto tmp_920024;
tmp_920024:
}
{
tmp_731146 = genfunc_tmp_920316();
goto next_tmp_920158;
next_tmp_920158:
goto tmp_920157;
tmp_920157:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_920318:
}
reg_t genfunc_tmp_920316 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_920155();
goto next_tmp_920293;
next_tmp_920293:
goto tmp_920292;
tmp_920292:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_920315:
return tmp_731146;
}
reg_t genfunc_tmp_920268 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_920237 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_920237 >> 8) == 0)
field_imm = tmp_920237;
else goto fail_tmp_920236;
}
/* commit */
{
tmp_731858 = genfunc_tmp_920199();
goto next_tmp_920239;
next_tmp_920239:
goto tmp_920238;
tmp_920238:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 6 */
}
goto done_tmp_920267;
fail_tmp_920236:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_920259 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_920259))
field_imm = inv_maskmask(8, tmp_920259);
else goto fail_tmp_920258;
}
/* commit */
{
tmp_731075 = genfunc_tmp_920199();
goto next_tmp_920261;
next_tmp_920261:
goto tmp_920260;
tmp_920260:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 6 */
}
goto done_tmp_920267;
fail_tmp_920258:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_920199();
goto next_tmp_920265;
next_tmp_920265:
goto tmp_920264;
tmp_920264:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 6 */
}
done_tmp_920267:
return tmp_731862;
}
reg_t genfunc_tmp_920199 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_920155();
goto next_tmp_920196;
next_tmp_920196:
goto tmp_920195;
tmp_920195:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_920198:
return tmp_731898;
}
reg_t genfunc_tmp_920155 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_920122 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_920122 >> 8) == 0)
field_imm = tmp_920122;
else goto fail_tmp_920121;
}
/* commit */
{
tmp_731858 = genfunc_tmp_920066();
goto next_tmp_920124;
next_tmp_920124:
goto tmp_920123;
tmp_920123:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_920154;
fail_tmp_920121:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_920146 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_920146))
field_imm = inv_maskmask(8, tmp_920146);
else goto fail_tmp_920145;
}
/* commit */
{
tmp_731075 = genfunc_tmp_920066();
goto next_tmp_920148;
next_tmp_920148:
goto tmp_920147;
tmp_920147:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_920154;
fail_tmp_920145:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_920066();
goto next_tmp_920152;
next_tmp_920152:
goto tmp_920151;
tmp_920151:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_920154:
return tmp_731142;
}
reg_t genfunc_tmp_920119 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_920088 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_920088 >> 8) == 0)
field_imm = tmp_920088;
else goto fail_tmp_920087;
}
/* commit */
{
tmp_731858 = genfunc_tmp_920066();
goto next_tmp_920090;
next_tmp_920090:
goto tmp_920089;
tmp_920089:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_920118;
fail_tmp_920087:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_920110 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_920110))
field_imm = inv_maskmask(8, tmp_920110);
else goto fail_tmp_920109;
}
/* commit */
{
tmp_731075 = genfunc_tmp_920066();
goto next_tmp_920112;
next_tmp_920112:
goto tmp_920111;
tmp_920111:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_920118;
fail_tmp_920109:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_920066();
goto next_tmp_920116;
next_tmp_920116:
goto tmp_920115;
tmp_920115:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_920118:
return tmp_731862;
}
reg_t genfunc_tmp_920066 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_920057;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_916121();
goto next_tmp_920059;
next_tmp_920059:
goto tmp_920058;
tmp_920058:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_920065;
fail_tmp_920057:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_920061;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_916121();
goto next_tmp_920063;
next_tmp_920063:
goto tmp_920062;
tmp_920062:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_920065;
fail_tmp_920061:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_916121();
goto next_tmp_920041;
next_tmp_920041:
goto tmp_920040;
tmp_920040:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_920065:
return tmp_731876;
}
void genfunc_tmp_920019 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_919595();
goto next_tmp_919765;
next_tmp_919765:
goto tmp_919764;
tmp_919764:
}
{
tmp_731146 = genfunc_tmp_920016();
goto next_tmp_919768;
next_tmp_919768:
goto tmp_919767;
tmp_919767:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_920018:
}
reg_t genfunc_tmp_920016 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_919939;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_919639();
goto next_tmp_919941;
next_tmp_919941:
goto tmp_919940;
tmp_919940:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_920015;
fail_tmp_919939:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_919944 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_919944 >> 8) == 0)
field_imm = tmp_919944;
else goto fail_tmp_919943;
}
/* commit */
{
tmp_731665 = genfunc_tmp_919639();
goto next_tmp_919946;
next_tmp_919946:
goto tmp_919945;
tmp_919945:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_920015;
fail_tmp_919943:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_920006;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_919639();
goto next_tmp_920008;
next_tmp_920008:
goto tmp_920007;
tmp_920007:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_920015;
fail_tmp_920006:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_920011 = tmp_731085;
if ((tmp_920011 >> 8) == 0)
field_imm = tmp_920011;
else goto fail_tmp_920010;
}
/* commit */
{
tmp_731083 = genfunc_tmp_919639();
goto next_tmp_920013;
next_tmp_920013:
goto tmp_920012;
tmp_920012:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_920015;
fail_tmp_920010:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_919639();
goto next_tmp_920004;
next_tmp_920004:
goto tmp_920003;
tmp_920003:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_920015:
return tmp_731146;
}
void genfunc_tmp_919759 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_919595();
goto next_tmp_919474;
next_tmp_919474:
goto tmp_919473;
tmp_919473:
}
{
tmp_731146 = genfunc_tmp_919756();
goto next_tmp_919598;
next_tmp_919598:
goto tmp_919597;
tmp_919597:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_919758:
}
reg_t genfunc_tmp_919756 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_919595();
goto next_tmp_919733;
next_tmp_919733:
goto tmp_919732;
tmp_919732:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_919755:
return tmp_731146;
}
reg_t genfunc_tmp_919708 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_919677 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_919677 >> 8) == 0)
field_imm = tmp_919677;
else goto fail_tmp_919676;
}
/* commit */
{
tmp_731858 = genfunc_tmp_919639();
goto next_tmp_919679;
next_tmp_919679:
goto tmp_919678;
tmp_919678:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_919707;
fail_tmp_919676:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_919699 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_919699))
field_imm = inv_maskmask(8, tmp_919699);
else goto fail_tmp_919698;
}
/* commit */
{
tmp_731075 = genfunc_tmp_919639();
goto next_tmp_919701;
next_tmp_919701:
goto tmp_919700;
tmp_919700:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_919707;
fail_tmp_919698:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_919639();
goto next_tmp_919705;
next_tmp_919705:
goto tmp_919704;
tmp_919704:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_919707:
return tmp_731862;
}
reg_t genfunc_tmp_919639 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_919595();
goto next_tmp_919636;
next_tmp_919636:
goto tmp_919635;
tmp_919635:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_919638:
return tmp_731898;
}
reg_t genfunc_tmp_919595 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_919562 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_919562 >> 8) == 0)
field_imm = tmp_919562;
else goto fail_tmp_919561;
}
/* commit */
{
tmp_731858 = genfunc_tmp_919506();
goto next_tmp_919564;
next_tmp_919564:
goto tmp_919563;
tmp_919563:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_919594;
fail_tmp_919561:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_919586 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_919586))
field_imm = inv_maskmask(8, tmp_919586);
else goto fail_tmp_919585;
}
/* commit */
{
tmp_731075 = genfunc_tmp_919506();
goto next_tmp_919588;
next_tmp_919588:
goto tmp_919587;
tmp_919587:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_919594;
fail_tmp_919585:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_919506();
goto next_tmp_919592;
next_tmp_919592:
goto tmp_919591;
tmp_919591:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_919594:
return tmp_731142;
}
reg_t genfunc_tmp_919559 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_919528 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_919528 >> 8) == 0)
field_imm = tmp_919528;
else goto fail_tmp_919527;
}
/* commit */
{
tmp_731858 = genfunc_tmp_919506();
goto next_tmp_919530;
next_tmp_919530:
goto tmp_919529;
tmp_919529:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_919558;
fail_tmp_919527:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_919550 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_919550))
field_imm = inv_maskmask(8, tmp_919550);
else goto fail_tmp_919549;
}
/* commit */
{
tmp_731075 = genfunc_tmp_919506();
goto next_tmp_919552;
next_tmp_919552:
goto tmp_919551;
tmp_919551:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_919558;
fail_tmp_919549:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_919506();
goto next_tmp_919556;
next_tmp_919556:
goto tmp_919555;
tmp_919555:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_919558:
return tmp_731862;
}
reg_t genfunc_tmp_919506 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_919503;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + base);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_919505;
fail_tmp_919503:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_919504;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + base);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_919505;
fail_tmp_919504:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + base);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_919505:
return tmp_731876;
}
void genfunc_tmp_919468 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_919044();
goto next_tmp_919214;
next_tmp_919214:
goto tmp_919213;
tmp_919213:
}
{
tmp_731146 = genfunc_tmp_919465();
goto next_tmp_919217;
next_tmp_919217:
goto tmp_919216;
tmp_919216:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 14 */
}
done_tmp_919467:
}
reg_t genfunc_tmp_919465 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_919388;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_919088();
goto next_tmp_919390;
next_tmp_919390:
goto tmp_919389;
tmp_919389:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 7 */
}
goto done_tmp_919464;
fail_tmp_919388:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_919393 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_919393 >> 8) == 0)
field_imm = tmp_919393;
else goto fail_tmp_919392;
}
/* commit */
{
tmp_731665 = genfunc_tmp_919088();
goto next_tmp_919395;
next_tmp_919395:
goto tmp_919394;
tmp_919394:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 7 */
}
goto done_tmp_919464;
fail_tmp_919392:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_919455;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_919088();
goto next_tmp_919457;
next_tmp_919457:
goto tmp_919456;
tmp_919456:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 7 */
}
goto done_tmp_919464;
fail_tmp_919455:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_919460 = tmp_731085;
if ((tmp_919460 >> 8) == 0)
field_imm = tmp_919460;
else goto fail_tmp_919459;
}
/* commit */
{
tmp_731083 = genfunc_tmp_919088();
goto next_tmp_919462;
next_tmp_919462:
goto tmp_919461;
tmp_919461:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 7 */
}
goto done_tmp_919464;
fail_tmp_919459:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_919088();
goto next_tmp_919453;
next_tmp_919453:
goto tmp_919452;
tmp_919452:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 8 */
}
done_tmp_919464:
return tmp_731146;
}
void genfunc_tmp_919208 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_919044();
goto next_tmp_918914;
next_tmp_918914:
goto tmp_918913;
tmp_918913:
}
{
tmp_731146 = genfunc_tmp_919205();
goto next_tmp_919047;
next_tmp_919047:
goto tmp_919046;
tmp_919046:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_919207:
}
reg_t genfunc_tmp_919205 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_919044();
goto next_tmp_919182;
next_tmp_919182:
goto tmp_919181;
tmp_919181:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_919204:
return tmp_731146;
}
reg_t genfunc_tmp_919157 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_919126 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_919126 >> 8) == 0)
field_imm = tmp_919126;
else goto fail_tmp_919125;
}
/* commit */
{
tmp_731858 = genfunc_tmp_919088();
goto next_tmp_919128;
next_tmp_919128:
goto tmp_919127;
tmp_919127:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 7 */
}
goto done_tmp_919156;
fail_tmp_919125:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_919148 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_919148))
field_imm = inv_maskmask(8, tmp_919148);
else goto fail_tmp_919147;
}
/* commit */
{
tmp_731075 = genfunc_tmp_919088();
goto next_tmp_919150;
next_tmp_919150:
goto tmp_919149;
tmp_919149:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 7 */
}
goto done_tmp_919156;
fail_tmp_919147:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_919088();
goto next_tmp_919154;
next_tmp_919154:
goto tmp_919153;
tmp_919153:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 7 */
}
done_tmp_919156:
return tmp_731862;
}
reg_t genfunc_tmp_919088 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_919044();
goto next_tmp_919085;
next_tmp_919085:
goto tmp_919084;
tmp_919084:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_919087:
return tmp_731898;
}
reg_t genfunc_tmp_919044 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_919011 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_919011 >> 8) == 0)
field_imm = tmp_919011;
else goto fail_tmp_919010;
}
/* commit */
{
tmp_731858 = genfunc_tmp_918955();
goto next_tmp_919013;
next_tmp_919013:
goto tmp_919012;
tmp_919012:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_919043;
fail_tmp_919010:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_919035 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_919035))
field_imm = inv_maskmask(8, tmp_919035);
else goto fail_tmp_919034;
}
/* commit */
{
tmp_731075 = genfunc_tmp_918955();
goto next_tmp_919037;
next_tmp_919037:
goto tmp_919036;
tmp_919036:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_919043;
fail_tmp_919034:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_918955();
goto next_tmp_919041;
next_tmp_919041:
goto tmp_919040;
tmp_919040:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_919043:
return tmp_731142;
}
reg_t genfunc_tmp_919008 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_918977 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_918977 >> 8) == 0)
field_imm = tmp_918977;
else goto fail_tmp_918976;
}
/* commit */
{
tmp_731858 = genfunc_tmp_918955();
goto next_tmp_918979;
next_tmp_918979:
goto tmp_918978;
tmp_918978:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_919007;
fail_tmp_918976:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_918999 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_918999))
field_imm = inv_maskmask(8, tmp_918999);
else goto fail_tmp_918998;
}
/* commit */
{
tmp_731075 = genfunc_tmp_918955();
goto next_tmp_919001;
next_tmp_919001:
goto tmp_919000;
tmp_919000:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_919007;
fail_tmp_918998:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_918955();
goto next_tmp_919005;
next_tmp_919005:
goto tmp_919004;
tmp_919004:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_919007:
return tmp_731862;
}
reg_t genfunc_tmp_918955 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_918946;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_911285();
goto next_tmp_918948;
next_tmp_918948:
goto tmp_918947;
tmp_918947:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_918954;
fail_tmp_918946:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_918950;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_911285();
goto next_tmp_918952;
next_tmp_918952:
goto tmp_918951;
tmp_918951:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_918954;
fail_tmp_918950:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_911285();
goto next_tmp_918930;
next_tmp_918930:
goto tmp_918929;
tmp_918929:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_918954:
return tmp_731876;
}
void genfunc_tmp_918908 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_918484();
goto next_tmp_918654;
next_tmp_918654:
goto tmp_918653;
tmp_918653:
}
{
tmp_731146 = genfunc_tmp_918905();
goto next_tmp_918657;
next_tmp_918657:
goto tmp_918656;
tmp_918656:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_918907:
}
reg_t genfunc_tmp_918905 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_918828;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_918528();
goto next_tmp_918830;
next_tmp_918830:
goto tmp_918829;
tmp_918829:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 6 */
}
goto done_tmp_918904;
fail_tmp_918828:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_918833 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_918833 >> 8) == 0)
field_imm = tmp_918833;
else goto fail_tmp_918832;
}
/* commit */
{
tmp_731665 = genfunc_tmp_918528();
goto next_tmp_918835;
next_tmp_918835:
goto tmp_918834;
tmp_918834:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 6 */
}
goto done_tmp_918904;
fail_tmp_918832:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_918895;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_918528();
goto next_tmp_918897;
next_tmp_918897:
goto tmp_918896;
tmp_918896:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 6 */
}
goto done_tmp_918904;
fail_tmp_918895:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_918900 = tmp_731085;
if ((tmp_918900 >> 8) == 0)
field_imm = tmp_918900;
else goto fail_tmp_918899;
}
/* commit */
{
tmp_731083 = genfunc_tmp_918528();
goto next_tmp_918902;
next_tmp_918902:
goto tmp_918901;
tmp_918901:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 6 */
}
goto done_tmp_918904;
fail_tmp_918899:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_918528();
goto next_tmp_918893;
next_tmp_918893:
goto tmp_918892;
tmp_918892:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_918904:
return tmp_731146;
}
void genfunc_tmp_918648 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_918484();
goto next_tmp_918354;
next_tmp_918354:
goto tmp_918353;
tmp_918353:
}
{
tmp_731146 = genfunc_tmp_918645();
goto next_tmp_918487;
next_tmp_918487:
goto tmp_918486;
tmp_918486:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_918647:
}
reg_t genfunc_tmp_918645 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_918484();
goto next_tmp_918622;
next_tmp_918622:
goto tmp_918621;
tmp_918621:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_918644:
return tmp_731146;
}
reg_t genfunc_tmp_918597 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_918566 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_918566 >> 8) == 0)
field_imm = tmp_918566;
else goto fail_tmp_918565;
}
/* commit */
{
tmp_731858 = genfunc_tmp_918528();
goto next_tmp_918568;
next_tmp_918568:
goto tmp_918567;
tmp_918567:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 6 */
}
goto done_tmp_918596;
fail_tmp_918565:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_918588 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_918588))
field_imm = inv_maskmask(8, tmp_918588);
else goto fail_tmp_918587;
}
/* commit */
{
tmp_731075 = genfunc_tmp_918528();
goto next_tmp_918590;
next_tmp_918590:
goto tmp_918589;
tmp_918589:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 6 */
}
goto done_tmp_918596;
fail_tmp_918587:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_918528();
goto next_tmp_918594;
next_tmp_918594:
goto tmp_918593;
tmp_918593:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 6 */
}
done_tmp_918596:
return tmp_731862;
}
reg_t genfunc_tmp_918528 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_918484();
goto next_tmp_918525;
next_tmp_918525:
goto tmp_918524;
tmp_918524:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_918527:
return tmp_731898;
}
reg_t genfunc_tmp_918484 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_918451 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_918451 >> 8) == 0)
field_imm = tmp_918451;
else goto fail_tmp_918450;
}
/* commit */
{
tmp_731858 = genfunc_tmp_918395();
goto next_tmp_918453;
next_tmp_918453:
goto tmp_918452;
tmp_918452:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_918483;
fail_tmp_918450:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_918475 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_918475))
field_imm = inv_maskmask(8, tmp_918475);
else goto fail_tmp_918474;
}
/* commit */
{
tmp_731075 = genfunc_tmp_918395();
goto next_tmp_918477;
next_tmp_918477:
goto tmp_918476;
tmp_918476:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_918483;
fail_tmp_918474:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_918395();
goto next_tmp_918481;
next_tmp_918481:
goto tmp_918480;
tmp_918480:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_918483:
return tmp_731142;
}
reg_t genfunc_tmp_918448 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_918417 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_918417 >> 8) == 0)
field_imm = tmp_918417;
else goto fail_tmp_918416;
}
/* commit */
{
tmp_731858 = genfunc_tmp_918395();
goto next_tmp_918419;
next_tmp_918419:
goto tmp_918418;
tmp_918418:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_918447;
fail_tmp_918416:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_918439 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_918439))
field_imm = inv_maskmask(8, tmp_918439);
else goto fail_tmp_918438;
}
/* commit */
{
tmp_731075 = genfunc_tmp_918395();
goto next_tmp_918441;
next_tmp_918441:
goto tmp_918440;
tmp_918440:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_918447;
fail_tmp_918438:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_918395();
goto next_tmp_918445;
next_tmp_918445:
goto tmp_918444;
tmp_918444:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_918447:
return tmp_731862;
}
reg_t genfunc_tmp_918395 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_918386;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_910701();
goto next_tmp_918388;
next_tmp_918388:
goto tmp_918387;
tmp_918387:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_918394;
fail_tmp_918386:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_918390;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_910701();
goto next_tmp_918392;
next_tmp_918392:
goto tmp_918391;
tmp_918391:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_918394;
fail_tmp_918390:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_910701();
goto next_tmp_918370;
next_tmp_918370:
goto tmp_918369;
tmp_918369:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_918394:
return tmp_731876;
}
void genfunc_tmp_918348 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_917924();
goto next_tmp_918094;
next_tmp_918094:
goto tmp_918093;
tmp_918093:
}
{
tmp_731146 = genfunc_tmp_918345();
goto next_tmp_918097;
next_tmp_918097:
goto tmp_918096;
tmp_918096:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_918347:
}
reg_t genfunc_tmp_918345 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_918268;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_917968();
goto next_tmp_918270;
next_tmp_918270:
goto tmp_918269;
tmp_918269:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_918344;
fail_tmp_918268:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_918273 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_918273 >> 8) == 0)
field_imm = tmp_918273;
else goto fail_tmp_918272;
}
/* commit */
{
tmp_731665 = genfunc_tmp_917968();
goto next_tmp_918275;
next_tmp_918275:
goto tmp_918274;
tmp_918274:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_918344;
fail_tmp_918272:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_918335;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_917968();
goto next_tmp_918337;
next_tmp_918337:
goto tmp_918336;
tmp_918336:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_918344;
fail_tmp_918335:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_918340 = tmp_731085;
if ((tmp_918340 >> 8) == 0)
field_imm = tmp_918340;
else goto fail_tmp_918339;
}
/* commit */
{
tmp_731083 = genfunc_tmp_917968();
goto next_tmp_918342;
next_tmp_918342:
goto tmp_918341;
tmp_918341:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_918344;
fail_tmp_918339:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_917968();
goto next_tmp_918333;
next_tmp_918333:
goto tmp_918332;
tmp_918332:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_918344:
return tmp_731146;
}
void genfunc_tmp_918088 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_917924();
goto next_tmp_917798;
next_tmp_917798:
goto tmp_917797;
tmp_917797:
}
{
tmp_731146 = genfunc_tmp_918085();
goto next_tmp_917927;
next_tmp_917927:
goto tmp_917926;
tmp_917926:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_918087:
}
reg_t genfunc_tmp_918085 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_917924();
goto next_tmp_918062;
next_tmp_918062:
goto tmp_918061;
tmp_918061:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_918084:
return tmp_731146;
}
reg_t genfunc_tmp_918037 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_918006 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_918006 >> 8) == 0)
field_imm = tmp_918006;
else goto fail_tmp_918005;
}
/* commit */
{
tmp_731858 = genfunc_tmp_917968();
goto next_tmp_918008;
next_tmp_918008:
goto tmp_918007;
tmp_918007:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_918036;
fail_tmp_918005:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_918028 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_918028))
field_imm = inv_maskmask(8, tmp_918028);
else goto fail_tmp_918027;
}
/* commit */
{
tmp_731075 = genfunc_tmp_917968();
goto next_tmp_918030;
next_tmp_918030:
goto tmp_918029;
tmp_918029:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_918036;
fail_tmp_918027:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_917968();
goto next_tmp_918034;
next_tmp_918034:
goto tmp_918033;
tmp_918033:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_918036:
return tmp_731862;
}
reg_t genfunc_tmp_917968 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_917924();
goto next_tmp_917965;
next_tmp_917965:
goto tmp_917964;
tmp_917964:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_917967:
return tmp_731898;
}
reg_t genfunc_tmp_917924 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_917891 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_917891 >> 8) == 0)
field_imm = tmp_917891;
else goto fail_tmp_917890;
}
/* commit */
{
tmp_731858 = genfunc_tmp_917835();
goto next_tmp_917893;
next_tmp_917893:
goto tmp_917892;
tmp_917892:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_917923;
fail_tmp_917890:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_917915 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_917915))
field_imm = inv_maskmask(8, tmp_917915);
else goto fail_tmp_917914;
}
/* commit */
{
tmp_731075 = genfunc_tmp_917835();
goto next_tmp_917917;
next_tmp_917917:
goto tmp_917916;
tmp_917916:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_917923;
fail_tmp_917914:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_917835();
goto next_tmp_917921;
next_tmp_917921:
goto tmp_917920;
tmp_917920:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_917923:
return tmp_731142;
}
reg_t genfunc_tmp_917888 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_917857 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_917857 >> 8) == 0)
field_imm = tmp_917857;
else goto fail_tmp_917856;
}
/* commit */
{
tmp_731858 = genfunc_tmp_917835();
goto next_tmp_917859;
next_tmp_917859:
goto tmp_917858;
tmp_917858:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_917887;
fail_tmp_917856:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_917879 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_917879))
field_imm = inv_maskmask(8, tmp_917879);
else goto fail_tmp_917878;
}
/* commit */
{
tmp_731075 = genfunc_tmp_917835();
goto next_tmp_917881;
next_tmp_917881:
goto tmp_917880;
tmp_917880:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_917887;
fail_tmp_917878:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_917835();
goto next_tmp_917885;
next_tmp_917885:
goto tmp_917884;
tmp_917884:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_917887:
return tmp_731862;
}
reg_t genfunc_tmp_917835 (void) {
reg_t tmp_731876;
/* ADDQ_IMM */
{
word_5 tmp_731893;
word_5 field_rc;
word_5 tmp_731894;
word_5 field_ra;
word_64 tmp_731896;
word_8 field_imm;
tmp_731896 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_917820 = tmp_731896;
if ((tmp_917820 >> 8) == 0)
field_imm = tmp_917820;
else goto fail_tmp_917819;
}
/* commit */
tmp_731894 = ref_gpr_reg_for_reading(0 + rm);
tmp_731893 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731893;
field_ra = tmp_731894;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731894);
/* can fail: T   num insns: 1 */
}
goto done_tmp_917834;
fail_tmp_917819:
/* LDA */
{
word_5 tmp_731397;
word_5 field_ra;
word_5 tmp_731398;
word_5 field_rb;
word_64 tmp_731400;
word_16 field_memory_disp;
tmp_731400 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_917828 = tmp_731400;
if ((tmp_917828 >> 16) == 0xFFFFFFFFFFFF || (tmp_917828 >> 16) == 0)
field_memory_disp = (tmp_917828 & 0xFFFF);
else goto fail_tmp_917827;
}
/* commit */
tmp_731398 = ref_gpr_reg_for_reading(0 + rm);
tmp_731397 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731397;
field_rb = tmp_731398;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731398);
/* can fail: T   num insns: 1 */
}
goto done_tmp_917834;
fail_tmp_917827:
/* LDAH */
{
word_5 tmp_731393;
word_5 field_ra;
word_5 tmp_731394;
word_5 field_rb;
word_64 tmp_731396;
word_16 field_memory_disp;
tmp_731396 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_917832 = tmp_731396;
if ((tmp_917832 & 0xFFFF) == 0)
{
word_64 tmp_917833 = (tmp_917832 >> 16);
if ((tmp_917833 >> 16) == 0xFFFFFFFFFFFF || (tmp_917833 >> 16) == 0)
field_memory_disp = (tmp_917833 & 0xFFFF);
else goto fail_tmp_917831;
}
else goto fail_tmp_917831;
}
/* commit */
tmp_731394 = ref_gpr_reg_for_reading(0 + rm);
tmp_731393 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731393;
field_rb = tmp_731394;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731394);
/* can fail: T   num insns: 1 */
}
goto done_tmp_917834;
fail_tmp_917831:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731900 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731900, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_917834:
return tmp_731876;
}
void genfunc_tmp_917792 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_917368();
goto next_tmp_917538;
next_tmp_917538:
goto tmp_917537;
tmp_917537:
}
{
tmp_731146 = genfunc_tmp_917789();
goto next_tmp_917541;
next_tmp_917541:
goto tmp_917540;
tmp_917540:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_917791:
}
reg_t genfunc_tmp_917789 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_917712;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_917412();
goto next_tmp_917714;
next_tmp_917714:
goto tmp_917713;
tmp_917713:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_917788;
fail_tmp_917712:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_917717 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_917717 >> 8) == 0)
field_imm = tmp_917717;
else goto fail_tmp_917716;
}
/* commit */
{
tmp_731665 = genfunc_tmp_917412();
goto next_tmp_917719;
next_tmp_917719:
goto tmp_917718;
tmp_917718:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_917788;
fail_tmp_917716:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_917779;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_917412();
goto next_tmp_917781;
next_tmp_917781:
goto tmp_917780;
tmp_917780:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_917788;
fail_tmp_917779:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_917784 = tmp_731085;
if ((tmp_917784 >> 8) == 0)
field_imm = tmp_917784;
else goto fail_tmp_917783;
}
/* commit */
{
tmp_731083 = genfunc_tmp_917412();
goto next_tmp_917786;
next_tmp_917786:
goto tmp_917785;
tmp_917785:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_917788;
fail_tmp_917783:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_917412();
goto next_tmp_917777;
next_tmp_917777:
goto tmp_917776;
tmp_917776:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_917788:
return tmp_731146;
}
void genfunc_tmp_917532 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_917368();
goto next_tmp_917247;
next_tmp_917247:
goto tmp_917246;
tmp_917246:
}
{
tmp_731146 = genfunc_tmp_917529();
goto next_tmp_917371;
next_tmp_917371:
goto tmp_917370;
tmp_917370:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_917531:
}
reg_t genfunc_tmp_917529 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_917368();
goto next_tmp_917506;
next_tmp_917506:
goto tmp_917505;
tmp_917505:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_917528:
return tmp_731146;
}
reg_t genfunc_tmp_917481 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_917450 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_917450 >> 8) == 0)
field_imm = tmp_917450;
else goto fail_tmp_917449;
}
/* commit */
{
tmp_731858 = genfunc_tmp_917412();
goto next_tmp_917452;
next_tmp_917452:
goto tmp_917451;
tmp_917451:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_917480;
fail_tmp_917449:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_917472 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_917472))
field_imm = inv_maskmask(8, tmp_917472);
else goto fail_tmp_917471;
}
/* commit */
{
tmp_731075 = genfunc_tmp_917412();
goto next_tmp_917474;
next_tmp_917474:
goto tmp_917473;
tmp_917473:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_917480;
fail_tmp_917471:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_917412();
goto next_tmp_917478;
next_tmp_917478:
goto tmp_917477;
tmp_917477:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_917480:
return tmp_731862;
}
reg_t genfunc_tmp_917412 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_917368();
goto next_tmp_917409;
next_tmp_917409:
goto tmp_917408;
tmp_917408:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_917411:
return tmp_731898;
}
reg_t genfunc_tmp_917368 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_917335 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_917335 >> 8) == 0)
field_imm = tmp_917335;
else goto fail_tmp_917334;
}
/* commit */
{
tmp_731858 = genfunc_tmp_917279();
goto next_tmp_917337;
next_tmp_917337:
goto tmp_917336;
tmp_917336:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_917367;
fail_tmp_917334:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_917359 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_917359))
field_imm = inv_maskmask(8, tmp_917359);
else goto fail_tmp_917358;
}
/* commit */
{
tmp_731075 = genfunc_tmp_917279();
goto next_tmp_917361;
next_tmp_917361:
goto tmp_917360;
tmp_917360:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_917367;
fail_tmp_917358:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_917279();
goto next_tmp_917365;
next_tmp_917365:
goto tmp_917364;
tmp_917364:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_917367:
return tmp_731142;
}
reg_t genfunc_tmp_917332 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_917301 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_917301 >> 8) == 0)
field_imm = tmp_917301;
else goto fail_tmp_917300;
}
/* commit */
{
tmp_731858 = genfunc_tmp_917279();
goto next_tmp_917303;
next_tmp_917303:
goto tmp_917302;
tmp_917302:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_917331;
fail_tmp_917300:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_917323 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_917323))
field_imm = inv_maskmask(8, tmp_917323);
else goto fail_tmp_917322;
}
/* commit */
{
tmp_731075 = genfunc_tmp_917279();
goto next_tmp_917325;
next_tmp_917325:
goto tmp_917324;
tmp_917324:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_917331;
fail_tmp_917322:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_917279();
goto next_tmp_917329;
next_tmp_917329:
goto tmp_917328;
tmp_917328:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_917331:
return tmp_731862;
}
reg_t genfunc_tmp_917279 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_917276;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + 5);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_917278;
fail_tmp_917276:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_917277;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + 5);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_917278;
fail_tmp_917277:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731900 = ref_gpr_reg_for_reading(0 + 5);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_917278:
return tmp_731876;
}
void genfunc_tmp_917241 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_916817();
goto next_tmp_916987;
next_tmp_916987:
goto tmp_916986;
tmp_916986:
}
{
tmp_731146 = genfunc_tmp_917238();
goto next_tmp_916990;
next_tmp_916990:
goto tmp_916989;
tmp_916989:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 14 */
}
done_tmp_917240:
}
reg_t genfunc_tmp_917238 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_917161;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_916861();
goto next_tmp_917163;
next_tmp_917163:
goto tmp_917162;
tmp_917162:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 7 */
}
goto done_tmp_917237;
fail_tmp_917161:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_917166 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_917166 >> 8) == 0)
field_imm = tmp_917166;
else goto fail_tmp_917165;
}
/* commit */
{
tmp_731665 = genfunc_tmp_916861();
goto next_tmp_917168;
next_tmp_917168:
goto tmp_917167;
tmp_917167:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 7 */
}
goto done_tmp_917237;
fail_tmp_917165:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_917228;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_916861();
goto next_tmp_917230;
next_tmp_917230:
goto tmp_917229;
tmp_917229:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 7 */
}
goto done_tmp_917237;
fail_tmp_917228:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_917233 = tmp_731085;
if ((tmp_917233 >> 8) == 0)
field_imm = tmp_917233;
else goto fail_tmp_917232;
}
/* commit */
{
tmp_731083 = genfunc_tmp_916861();
goto next_tmp_917235;
next_tmp_917235:
goto tmp_917234;
tmp_917234:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 7 */
}
goto done_tmp_917237;
fail_tmp_917232:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_916861();
goto next_tmp_917226;
next_tmp_917226:
goto tmp_917225;
tmp_917225:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 8 */
}
done_tmp_917237:
return tmp_731146;
}
void genfunc_tmp_916981 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_916817();
goto next_tmp_916665;
next_tmp_916665:
goto tmp_916664;
tmp_916664:
}
{
tmp_731146 = genfunc_tmp_916978();
goto next_tmp_916820;
next_tmp_916820:
goto tmp_916819;
tmp_916819:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_916980:
}
reg_t genfunc_tmp_916978 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_916817();
goto next_tmp_916955;
next_tmp_916955:
goto tmp_916954;
tmp_916954:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_916977:
return tmp_731146;
}
reg_t genfunc_tmp_916930 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_916899 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_916899 >> 8) == 0)
field_imm = tmp_916899;
else goto fail_tmp_916898;
}
/* commit */
{
tmp_731858 = genfunc_tmp_916861();
goto next_tmp_916901;
next_tmp_916901:
goto tmp_916900;
tmp_916900:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 7 */
}
goto done_tmp_916929;
fail_tmp_916898:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_916921 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_916921))
field_imm = inv_maskmask(8, tmp_916921);
else goto fail_tmp_916920;
}
/* commit */
{
tmp_731075 = genfunc_tmp_916861();
goto next_tmp_916923;
next_tmp_916923:
goto tmp_916922;
tmp_916922:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 7 */
}
goto done_tmp_916929;
fail_tmp_916920:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_916861();
goto next_tmp_916927;
next_tmp_916927:
goto tmp_916926;
tmp_916926:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 7 */
}
done_tmp_916929:
return tmp_731862;
}
reg_t genfunc_tmp_916861 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_916817();
goto next_tmp_916858;
next_tmp_916858:
goto tmp_916857;
tmp_916857:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_916860:
return tmp_731898;
}
reg_t genfunc_tmp_916817 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_916784 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_916784 >> 8) == 0)
field_imm = tmp_916784;
else goto fail_tmp_916783;
}
/* commit */
{
tmp_731858 = genfunc_tmp_916728();
goto next_tmp_916786;
next_tmp_916786:
goto tmp_916785;
tmp_916785:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_916816;
fail_tmp_916783:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_916808 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_916808))
field_imm = inv_maskmask(8, tmp_916808);
else goto fail_tmp_916807;
}
/* commit */
{
tmp_731075 = genfunc_tmp_916728();
goto next_tmp_916810;
next_tmp_916810:
goto tmp_916809;
tmp_916809:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_916816;
fail_tmp_916807:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_916728();
goto next_tmp_916814;
next_tmp_916814:
goto tmp_916813;
tmp_916813:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_916816:
return tmp_731142;
}
reg_t genfunc_tmp_916781 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_916750 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_916750 >> 8) == 0)
field_imm = tmp_916750;
else goto fail_tmp_916749;
}
/* commit */
{
tmp_731858 = genfunc_tmp_916728();
goto next_tmp_916752;
next_tmp_916752:
goto tmp_916751;
tmp_916751:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_916780;
fail_tmp_916749:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_916772 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_916772))
field_imm = inv_maskmask(8, tmp_916772);
else goto fail_tmp_916771;
}
/* commit */
{
tmp_731075 = genfunc_tmp_916728();
goto next_tmp_916774;
next_tmp_916774:
goto tmp_916773;
tmp_916773:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_916780;
fail_tmp_916771:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_916728();
goto next_tmp_916778;
next_tmp_916778:
goto tmp_916777;
tmp_916777:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_916780:
return tmp_731862;
}
reg_t genfunc_tmp_916728 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_916719;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_916703();
goto next_tmp_916721;
next_tmp_916721:
goto tmp_916720;
tmp_916720:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_916727;
fail_tmp_916719:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_916723;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_916703();
goto next_tmp_916725;
next_tmp_916725:
goto tmp_916724;
tmp_916724:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_916727;
fail_tmp_916723:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_916703();
goto next_tmp_916681;
next_tmp_916681:
goto tmp_916680;
tmp_916680:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_916727:
return tmp_731876;
}
reg_t genfunc_tmp_916703 (void) {
reg_t tmp_731900;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + 5);
{
tmp_731900 = genfunc_tmp_911268();
goto next_tmp_916686;
next_tmp_916686:
goto tmp_916685;
tmp_916685:
}
tmp_731897 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_916702:
return tmp_731900;
}
void genfunc_tmp_916659 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_916235();
goto next_tmp_916405;
next_tmp_916405:
goto tmp_916404;
tmp_916404:
}
{
tmp_731146 = genfunc_tmp_916656();
goto next_tmp_916408;
next_tmp_916408:
goto tmp_916407;
tmp_916407:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_916658:
}
reg_t genfunc_tmp_916656 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_916579;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_916279();
goto next_tmp_916581;
next_tmp_916581:
goto tmp_916580;
tmp_916580:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 6 */
}
goto done_tmp_916655;
fail_tmp_916579:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_916584 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_916584 >> 8) == 0)
field_imm = tmp_916584;
else goto fail_tmp_916583;
}
/* commit */
{
tmp_731665 = genfunc_tmp_916279();
goto next_tmp_916586;
next_tmp_916586:
goto tmp_916585;
tmp_916585:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 6 */
}
goto done_tmp_916655;
fail_tmp_916583:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_916646;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_916279();
goto next_tmp_916648;
next_tmp_916648:
goto tmp_916647;
tmp_916647:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 6 */
}
goto done_tmp_916655;
fail_tmp_916646:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_916651 = tmp_731085;
if ((tmp_916651 >> 8) == 0)
field_imm = tmp_916651;
else goto fail_tmp_916650;
}
/* commit */
{
tmp_731083 = genfunc_tmp_916279();
goto next_tmp_916653;
next_tmp_916653:
goto tmp_916652;
tmp_916652:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 6 */
}
goto done_tmp_916655;
fail_tmp_916650:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_916279();
goto next_tmp_916644;
next_tmp_916644:
goto tmp_916643;
tmp_916643:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_916655:
return tmp_731146;
}
void genfunc_tmp_916399 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_916235();
goto next_tmp_916086;
next_tmp_916086:
goto tmp_916085;
tmp_916085:
}
{
tmp_731146 = genfunc_tmp_916396();
goto next_tmp_916238;
next_tmp_916238:
goto tmp_916237;
tmp_916237:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_916398:
}
reg_t genfunc_tmp_916396 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_916235();
goto next_tmp_916373;
next_tmp_916373:
goto tmp_916372;
tmp_916372:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_916395:
return tmp_731146;
}
reg_t genfunc_tmp_916348 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_916317 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_916317 >> 8) == 0)
field_imm = tmp_916317;
else goto fail_tmp_916316;
}
/* commit */
{
tmp_731858 = genfunc_tmp_916279();
goto next_tmp_916319;
next_tmp_916319:
goto tmp_916318;
tmp_916318:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 6 */
}
goto done_tmp_916347;
fail_tmp_916316:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_916339 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_916339))
field_imm = inv_maskmask(8, tmp_916339);
else goto fail_tmp_916338;
}
/* commit */
{
tmp_731075 = genfunc_tmp_916279();
goto next_tmp_916341;
next_tmp_916341:
goto tmp_916340;
tmp_916340:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 6 */
}
goto done_tmp_916347;
fail_tmp_916338:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_916279();
goto next_tmp_916345;
next_tmp_916345:
goto tmp_916344;
tmp_916344:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 6 */
}
done_tmp_916347:
return tmp_731862;
}
reg_t genfunc_tmp_916279 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_916235();
goto next_tmp_916276;
next_tmp_916276:
goto tmp_916275;
tmp_916275:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_916278:
return tmp_731898;
}
reg_t genfunc_tmp_916235 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_916202 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_916202 >> 8) == 0)
field_imm = tmp_916202;
else goto fail_tmp_916201;
}
/* commit */
{
tmp_731858 = genfunc_tmp_916146();
goto next_tmp_916204;
next_tmp_916204:
goto tmp_916203;
tmp_916203:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_916234;
fail_tmp_916201:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_916226 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_916226))
field_imm = inv_maskmask(8, tmp_916226);
else goto fail_tmp_916225;
}
/* commit */
{
tmp_731075 = genfunc_tmp_916146();
goto next_tmp_916228;
next_tmp_916228:
goto tmp_916227;
tmp_916227:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_916234;
fail_tmp_916225:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_916146();
goto next_tmp_916232;
next_tmp_916232:
goto tmp_916231;
tmp_916231:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_916234:
return tmp_731142;
}
reg_t genfunc_tmp_916199 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_916168 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_916168 >> 8) == 0)
field_imm = tmp_916168;
else goto fail_tmp_916167;
}
/* commit */
{
tmp_731858 = genfunc_tmp_916146();
goto next_tmp_916170;
next_tmp_916170:
goto tmp_916169;
tmp_916169:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_916198;
fail_tmp_916167:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_916190 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_916190))
field_imm = inv_maskmask(8, tmp_916190);
else goto fail_tmp_916189;
}
/* commit */
{
tmp_731075 = genfunc_tmp_916146();
goto next_tmp_916192;
next_tmp_916192:
goto tmp_916191;
tmp_916191:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_916198;
fail_tmp_916189:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_916146();
goto next_tmp_916196;
next_tmp_916196:
goto tmp_916195;
tmp_916195:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_916198:
return tmp_731862;
}
reg_t genfunc_tmp_916146 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_916137;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_916121();
goto next_tmp_916139;
next_tmp_916139:
goto tmp_916138;
tmp_916138:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_916145;
fail_tmp_916137:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_916141;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_916121();
goto next_tmp_916143;
next_tmp_916143:
goto tmp_916142;
tmp_916142:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_916145;
fail_tmp_916141:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_916121();
goto next_tmp_916102;
next_tmp_916102:
goto tmp_916101;
tmp_916101:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_916145:
return tmp_731876;
}
reg_t genfunc_tmp_916121 (void) {
reg_t tmp_731900;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + 5);
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_916120:
return tmp_731900;
}
void genfunc_tmp_916080 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_915656();
goto next_tmp_915826;
next_tmp_915826:
goto tmp_915825;
tmp_915825:
}
{
tmp_731146 = genfunc_tmp_916077();
goto next_tmp_915829;
next_tmp_915829:
goto tmp_915828;
tmp_915828:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_916079:
}
reg_t genfunc_tmp_916077 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_916000;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_915700();
goto next_tmp_916002;
next_tmp_916002:
goto tmp_916001;
tmp_916001:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_916076;
fail_tmp_916000:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_916005 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_916005 >> 8) == 0)
field_imm = tmp_916005;
else goto fail_tmp_916004;
}
/* commit */
{
tmp_731665 = genfunc_tmp_915700();
goto next_tmp_916007;
next_tmp_916007:
goto tmp_916006;
tmp_916006:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_916076;
fail_tmp_916004:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_916067;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_915700();
goto next_tmp_916069;
next_tmp_916069:
goto tmp_916068;
tmp_916068:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_916076;
fail_tmp_916067:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_916072 = tmp_731085;
if ((tmp_916072 >> 8) == 0)
field_imm = tmp_916072;
else goto fail_tmp_916071;
}
/* commit */
{
tmp_731083 = genfunc_tmp_915700();
goto next_tmp_916074;
next_tmp_916074:
goto tmp_916073;
tmp_916073:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_916076;
fail_tmp_916071:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_915700();
goto next_tmp_916065;
next_tmp_916065:
goto tmp_916064;
tmp_916064:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_916076:
return tmp_731146;
}
void genfunc_tmp_915820 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_915656();
goto next_tmp_915535;
next_tmp_915535:
goto tmp_915534;
tmp_915534:
}
{
tmp_731146 = genfunc_tmp_915817();
goto next_tmp_915659;
next_tmp_915659:
goto tmp_915658;
tmp_915658:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_915819:
}
reg_t genfunc_tmp_915817 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_915656();
goto next_tmp_915794;
next_tmp_915794:
goto tmp_915793;
tmp_915793:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_915816:
return tmp_731146;
}
reg_t genfunc_tmp_915769 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_915738 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_915738 >> 8) == 0)
field_imm = tmp_915738;
else goto fail_tmp_915737;
}
/* commit */
{
tmp_731858 = genfunc_tmp_915700();
goto next_tmp_915740;
next_tmp_915740:
goto tmp_915739;
tmp_915739:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_915768;
fail_tmp_915737:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_915760 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_915760))
field_imm = inv_maskmask(8, tmp_915760);
else goto fail_tmp_915759;
}
/* commit */
{
tmp_731075 = genfunc_tmp_915700();
goto next_tmp_915762;
next_tmp_915762:
goto tmp_915761;
tmp_915761:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_915768;
fail_tmp_915759:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_915700();
goto next_tmp_915766;
next_tmp_915766:
goto tmp_915765;
tmp_915765:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_915768:
return tmp_731862;
}
reg_t genfunc_tmp_915700 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_915656();
goto next_tmp_915697;
next_tmp_915697:
goto tmp_915696;
tmp_915696:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_915699:
return tmp_731898;
}
reg_t genfunc_tmp_915656 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_915623 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_915623 >> 8) == 0)
field_imm = tmp_915623;
else goto fail_tmp_915622;
}
/* commit */
{
tmp_731858 = genfunc_tmp_915567();
goto next_tmp_915625;
next_tmp_915625:
goto tmp_915624;
tmp_915624:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_915655;
fail_tmp_915622:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_915647 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_915647))
field_imm = inv_maskmask(8, tmp_915647);
else goto fail_tmp_915646;
}
/* commit */
{
tmp_731075 = genfunc_tmp_915567();
goto next_tmp_915649;
next_tmp_915649:
goto tmp_915648;
tmp_915648:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_915655;
fail_tmp_915646:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_915567();
goto next_tmp_915653;
next_tmp_915653:
goto tmp_915652;
tmp_915652:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_915655:
return tmp_731142;
}
reg_t genfunc_tmp_915620 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_915589 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_915589 >> 8) == 0)
field_imm = tmp_915589;
else goto fail_tmp_915588;
}
/* commit */
{
tmp_731858 = genfunc_tmp_915567();
goto next_tmp_915591;
next_tmp_915591:
goto tmp_915590;
tmp_915590:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_915619;
fail_tmp_915588:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_915611 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_915611))
field_imm = inv_maskmask(8, tmp_915611);
else goto fail_tmp_915610;
}
/* commit */
{
tmp_731075 = genfunc_tmp_915567();
goto next_tmp_915613;
next_tmp_915613:
goto tmp_915612;
tmp_915612:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_915619;
fail_tmp_915610:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_915567();
goto next_tmp_915617;
next_tmp_915617:
goto tmp_915616;
tmp_915616:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_915619:
return tmp_731862;
}
reg_t genfunc_tmp_915567 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_915564;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + base);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_915566;
fail_tmp_915564:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_915565;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + base);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_915566;
fail_tmp_915565:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731900 = ref_gpr_reg_for_reading(0 + base);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_915566:
return tmp_731876;
}
void genfunc_tmp_915529 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_915105();
goto next_tmp_915275;
next_tmp_915275:
goto tmp_915274;
tmp_915274:
}
{
tmp_731146 = genfunc_tmp_915526();
goto next_tmp_915278;
next_tmp_915278:
goto tmp_915277;
tmp_915277:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 14 */
}
done_tmp_915528:
}
reg_t genfunc_tmp_915526 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_915449;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_915149();
goto next_tmp_915451;
next_tmp_915451:
goto tmp_915450;
tmp_915450:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 7 */
}
goto done_tmp_915525;
fail_tmp_915449:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_915454 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_915454 >> 8) == 0)
field_imm = tmp_915454;
else goto fail_tmp_915453;
}
/* commit */
{
tmp_731665 = genfunc_tmp_915149();
goto next_tmp_915456;
next_tmp_915456:
goto tmp_915455;
tmp_915455:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 7 */
}
goto done_tmp_915525;
fail_tmp_915453:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_915516;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_915149();
goto next_tmp_915518;
next_tmp_915518:
goto tmp_915517;
tmp_915517:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 7 */
}
goto done_tmp_915525;
fail_tmp_915516:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_915521 = tmp_731085;
if ((tmp_915521 >> 8) == 0)
field_imm = tmp_915521;
else goto fail_tmp_915520;
}
/* commit */
{
tmp_731083 = genfunc_tmp_915149();
goto next_tmp_915523;
next_tmp_915523:
goto tmp_915522;
tmp_915522:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 7 */
}
goto done_tmp_915525;
fail_tmp_915520:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_915149();
goto next_tmp_915514;
next_tmp_915514:
goto tmp_915513;
tmp_915513:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 8 */
}
done_tmp_915525:
return tmp_731146;
}
void genfunc_tmp_915269 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_915105();
goto next_tmp_914975;
next_tmp_914975:
goto tmp_914974;
tmp_914974:
}
{
tmp_731146 = genfunc_tmp_915266();
goto next_tmp_915108;
next_tmp_915108:
goto tmp_915107;
tmp_915107:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_915268:
}
reg_t genfunc_tmp_915266 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_915105();
goto next_tmp_915243;
next_tmp_915243:
goto tmp_915242;
tmp_915242:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_915265:
return tmp_731146;
}
reg_t genfunc_tmp_915218 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_915187 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_915187 >> 8) == 0)
field_imm = tmp_915187;
else goto fail_tmp_915186;
}
/* commit */
{
tmp_731858 = genfunc_tmp_915149();
goto next_tmp_915189;
next_tmp_915189:
goto tmp_915188;
tmp_915188:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 7 */
}
goto done_tmp_915217;
fail_tmp_915186:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_915209 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_915209))
field_imm = inv_maskmask(8, tmp_915209);
else goto fail_tmp_915208;
}
/* commit */
{
tmp_731075 = genfunc_tmp_915149();
goto next_tmp_915211;
next_tmp_915211:
goto tmp_915210;
tmp_915210:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 7 */
}
goto done_tmp_915217;
fail_tmp_915208:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_915149();
goto next_tmp_915215;
next_tmp_915215:
goto tmp_915214;
tmp_915214:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 7 */
}
done_tmp_915217:
return tmp_731862;
}
reg_t genfunc_tmp_915149 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_915105();
goto next_tmp_915146;
next_tmp_915146:
goto tmp_915145;
tmp_915145:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_915148:
return tmp_731898;
}
reg_t genfunc_tmp_915105 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_915072 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_915072 >> 8) == 0)
field_imm = tmp_915072;
else goto fail_tmp_915071;
}
/* commit */
{
tmp_731858 = genfunc_tmp_915016();
goto next_tmp_915074;
next_tmp_915074:
goto tmp_915073;
tmp_915073:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_915104;
fail_tmp_915071:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_915096 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_915096))
field_imm = inv_maskmask(8, tmp_915096);
else goto fail_tmp_915095;
}
/* commit */
{
tmp_731075 = genfunc_tmp_915016();
goto next_tmp_915098;
next_tmp_915098:
goto tmp_915097;
tmp_915097:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_915104;
fail_tmp_915095:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_915016();
goto next_tmp_915102;
next_tmp_915102:
goto tmp_915101;
tmp_915101:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_915104:
return tmp_731142;
}
reg_t genfunc_tmp_915069 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_915038 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_915038 >> 8) == 0)
field_imm = tmp_915038;
else goto fail_tmp_915037;
}
/* commit */
{
tmp_731858 = genfunc_tmp_915016();
goto next_tmp_915040;
next_tmp_915040:
goto tmp_915039;
tmp_915039:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_915068;
fail_tmp_915037:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_915060 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_915060))
field_imm = inv_maskmask(8, tmp_915060);
else goto fail_tmp_915059;
}
/* commit */
{
tmp_731075 = genfunc_tmp_915016();
goto next_tmp_915062;
next_tmp_915062:
goto tmp_915061;
tmp_915061:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_915068;
fail_tmp_915059:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_915016();
goto next_tmp_915066;
next_tmp_915066:
goto tmp_915065;
tmp_915065:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_915068:
return tmp_731862;
}
reg_t genfunc_tmp_915016 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_915007;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_911285();
goto next_tmp_915009;
next_tmp_915009:
goto tmp_915008;
tmp_915008:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_915015;
fail_tmp_915007:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_915011;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_911285();
goto next_tmp_915013;
next_tmp_915013:
goto tmp_915012;
tmp_915012:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_915015;
fail_tmp_915011:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_911285();
goto next_tmp_914991;
next_tmp_914991:
goto tmp_914990;
tmp_914990:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_915015:
return tmp_731876;
}
void genfunc_tmp_914969 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_914545();
goto next_tmp_914715;
next_tmp_914715:
goto tmp_914714;
tmp_914714:
}
{
tmp_731146 = genfunc_tmp_914966();
goto next_tmp_914718;
next_tmp_914718:
goto tmp_914717;
tmp_914717:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_914968:
}
reg_t genfunc_tmp_914966 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_914889;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_914589();
goto next_tmp_914891;
next_tmp_914891:
goto tmp_914890;
tmp_914890:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 6 */
}
goto done_tmp_914965;
fail_tmp_914889:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_914894 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_914894 >> 8) == 0)
field_imm = tmp_914894;
else goto fail_tmp_914893;
}
/* commit */
{
tmp_731665 = genfunc_tmp_914589();
goto next_tmp_914896;
next_tmp_914896:
goto tmp_914895;
tmp_914895:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 6 */
}
goto done_tmp_914965;
fail_tmp_914893:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_914956;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_914589();
goto next_tmp_914958;
next_tmp_914958:
goto tmp_914957;
tmp_914957:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 6 */
}
goto done_tmp_914965;
fail_tmp_914956:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_914961 = tmp_731085;
if ((tmp_914961 >> 8) == 0)
field_imm = tmp_914961;
else goto fail_tmp_914960;
}
/* commit */
{
tmp_731083 = genfunc_tmp_914589();
goto next_tmp_914963;
next_tmp_914963:
goto tmp_914962;
tmp_914962:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 6 */
}
goto done_tmp_914965;
fail_tmp_914960:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_914589();
goto next_tmp_914954;
next_tmp_914954:
goto tmp_914953;
tmp_914953:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_914965:
return tmp_731146;
}
void genfunc_tmp_914709 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_914545();
goto next_tmp_914415;
next_tmp_914415:
goto tmp_914414;
tmp_914414:
}
{
tmp_731146 = genfunc_tmp_914706();
goto next_tmp_914548;
next_tmp_914548:
goto tmp_914547;
tmp_914547:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_914708:
}
reg_t genfunc_tmp_914706 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_914545();
goto next_tmp_914683;
next_tmp_914683:
goto tmp_914682;
tmp_914682:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_914705:
return tmp_731146;
}
reg_t genfunc_tmp_914658 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_914627 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_914627 >> 8) == 0)
field_imm = tmp_914627;
else goto fail_tmp_914626;
}
/* commit */
{
tmp_731858 = genfunc_tmp_914589();
goto next_tmp_914629;
next_tmp_914629:
goto tmp_914628;
tmp_914628:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 6 */
}
goto done_tmp_914657;
fail_tmp_914626:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_914649 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_914649))
field_imm = inv_maskmask(8, tmp_914649);
else goto fail_tmp_914648;
}
/* commit */
{
tmp_731075 = genfunc_tmp_914589();
goto next_tmp_914651;
next_tmp_914651:
goto tmp_914650;
tmp_914650:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 6 */
}
goto done_tmp_914657;
fail_tmp_914648:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_914589();
goto next_tmp_914655;
next_tmp_914655:
goto tmp_914654;
tmp_914654:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 6 */
}
done_tmp_914657:
return tmp_731862;
}
reg_t genfunc_tmp_914589 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_914545();
goto next_tmp_914586;
next_tmp_914586:
goto tmp_914585;
tmp_914585:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_914588:
return tmp_731898;
}
reg_t genfunc_tmp_914545 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_914512 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_914512 >> 8) == 0)
field_imm = tmp_914512;
else goto fail_tmp_914511;
}
/* commit */
{
tmp_731858 = genfunc_tmp_914456();
goto next_tmp_914514;
next_tmp_914514:
goto tmp_914513;
tmp_914513:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_914544;
fail_tmp_914511:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_914536 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_914536))
field_imm = inv_maskmask(8, tmp_914536);
else goto fail_tmp_914535;
}
/* commit */
{
tmp_731075 = genfunc_tmp_914456();
goto next_tmp_914538;
next_tmp_914538:
goto tmp_914537;
tmp_914537:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_914544;
fail_tmp_914535:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_914456();
goto next_tmp_914542;
next_tmp_914542:
goto tmp_914541;
tmp_914541:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_914544:
return tmp_731142;
}
reg_t genfunc_tmp_914509 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_914478 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_914478 >> 8) == 0)
field_imm = tmp_914478;
else goto fail_tmp_914477;
}
/* commit */
{
tmp_731858 = genfunc_tmp_914456();
goto next_tmp_914480;
next_tmp_914480:
goto tmp_914479;
tmp_914479:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_914508;
fail_tmp_914477:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_914500 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_914500))
field_imm = inv_maskmask(8, tmp_914500);
else goto fail_tmp_914499;
}
/* commit */
{
tmp_731075 = genfunc_tmp_914456();
goto next_tmp_914502;
next_tmp_914502:
goto tmp_914501;
tmp_914501:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_914508;
fail_tmp_914499:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_914456();
goto next_tmp_914506;
next_tmp_914506:
goto tmp_914505;
tmp_914505:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_914508:
return tmp_731862;
}
reg_t genfunc_tmp_914456 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_914447;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_910701();
goto next_tmp_914449;
next_tmp_914449:
goto tmp_914448;
tmp_914448:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_914455;
fail_tmp_914447:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_914451;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_910701();
goto next_tmp_914453;
next_tmp_914453:
goto tmp_914452;
tmp_914452:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_914455;
fail_tmp_914451:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_910701();
goto next_tmp_914431;
next_tmp_914431:
goto tmp_914430;
tmp_914430:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_914455:
return tmp_731876;
}
void genfunc_tmp_914409 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_913985();
goto next_tmp_914155;
next_tmp_914155:
goto tmp_914154;
tmp_914154:
}
{
tmp_731146 = genfunc_tmp_914406();
goto next_tmp_914158;
next_tmp_914158:
goto tmp_914157;
tmp_914157:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_914408:
}
reg_t genfunc_tmp_914406 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_914329;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_914029();
goto next_tmp_914331;
next_tmp_914331:
goto tmp_914330;
tmp_914330:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_914405;
fail_tmp_914329:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_914334 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_914334 >> 8) == 0)
field_imm = tmp_914334;
else goto fail_tmp_914333;
}
/* commit */
{
tmp_731665 = genfunc_tmp_914029();
goto next_tmp_914336;
next_tmp_914336:
goto tmp_914335;
tmp_914335:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_914405;
fail_tmp_914333:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_914396;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_914029();
goto next_tmp_914398;
next_tmp_914398:
goto tmp_914397;
tmp_914397:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_914405;
fail_tmp_914396:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_914401 = tmp_731085;
if ((tmp_914401 >> 8) == 0)
field_imm = tmp_914401;
else goto fail_tmp_914400;
}
/* commit */
{
tmp_731083 = genfunc_tmp_914029();
goto next_tmp_914403;
next_tmp_914403:
goto tmp_914402;
tmp_914402:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_914405;
fail_tmp_914400:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_914029();
goto next_tmp_914394;
next_tmp_914394:
goto tmp_914393;
tmp_914393:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_914405:
return tmp_731146;
}
void genfunc_tmp_914149 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_913985();
goto next_tmp_913859;
next_tmp_913859:
goto tmp_913858;
tmp_913858:
}
{
tmp_731146 = genfunc_tmp_914146();
goto next_tmp_913988;
next_tmp_913988:
goto tmp_913987;
tmp_913987:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_914148:
}
reg_t genfunc_tmp_914146 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_913985();
goto next_tmp_914123;
next_tmp_914123:
goto tmp_914122;
tmp_914122:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_914145:
return tmp_731146;
}
reg_t genfunc_tmp_914098 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_914067 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_914067 >> 8) == 0)
field_imm = tmp_914067;
else goto fail_tmp_914066;
}
/* commit */
{
tmp_731858 = genfunc_tmp_914029();
goto next_tmp_914069;
next_tmp_914069:
goto tmp_914068;
tmp_914068:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_914097;
fail_tmp_914066:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_914089 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_914089))
field_imm = inv_maskmask(8, tmp_914089);
else goto fail_tmp_914088;
}
/* commit */
{
tmp_731075 = genfunc_tmp_914029();
goto next_tmp_914091;
next_tmp_914091:
goto tmp_914090;
tmp_914090:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_914097;
fail_tmp_914088:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_914029();
goto next_tmp_914095;
next_tmp_914095:
goto tmp_914094;
tmp_914094:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_914097:
return tmp_731862;
}
reg_t genfunc_tmp_914029 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_913985();
goto next_tmp_914026;
next_tmp_914026:
goto tmp_914025;
tmp_914025:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_914028:
return tmp_731898;
}
reg_t genfunc_tmp_913985 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_913952 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_913952 >> 8) == 0)
field_imm = tmp_913952;
else goto fail_tmp_913951;
}
/* commit */
{
tmp_731858 = genfunc_tmp_913896();
goto next_tmp_913954;
next_tmp_913954:
goto tmp_913953;
tmp_913953:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_913984;
fail_tmp_913951:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_913976 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_913976))
field_imm = inv_maskmask(8, tmp_913976);
else goto fail_tmp_913975;
}
/* commit */
{
tmp_731075 = genfunc_tmp_913896();
goto next_tmp_913978;
next_tmp_913978:
goto tmp_913977;
tmp_913977:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_913984;
fail_tmp_913975:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_913896();
goto next_tmp_913982;
next_tmp_913982:
goto tmp_913981;
tmp_913981:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_913984:
return tmp_731142;
}
reg_t genfunc_tmp_913949 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_913918 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_913918 >> 8) == 0)
field_imm = tmp_913918;
else goto fail_tmp_913917;
}
/* commit */
{
tmp_731858 = genfunc_tmp_913896();
goto next_tmp_913920;
next_tmp_913920:
goto tmp_913919;
tmp_913919:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_913948;
fail_tmp_913917:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_913940 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_913940))
field_imm = inv_maskmask(8, tmp_913940);
else goto fail_tmp_913939;
}
/* commit */
{
tmp_731075 = genfunc_tmp_913896();
goto next_tmp_913942;
next_tmp_913942:
goto tmp_913941;
tmp_913941:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_913948;
fail_tmp_913939:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_913896();
goto next_tmp_913946;
next_tmp_913946:
goto tmp_913945;
tmp_913945:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_913948:
return tmp_731862;
}
reg_t genfunc_tmp_913896 (void) {
reg_t tmp_731876;
/* ADDQ_IMM */
{
word_5 tmp_731893;
word_5 field_rc;
word_5 tmp_731894;
word_5 field_ra;
word_64 tmp_731896;
word_8 field_imm;
tmp_731896 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_913881 = tmp_731896;
if ((tmp_913881 >> 8) == 0)
field_imm = tmp_913881;
else goto fail_tmp_913880;
}
/* commit */
tmp_731894 = ref_gpr_reg_for_reading(0 + rm);
tmp_731893 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731893;
field_ra = tmp_731894;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731894);
/* can fail: T   num insns: 1 */
}
goto done_tmp_913895;
fail_tmp_913880:
/* LDA */
{
word_5 tmp_731397;
word_5 field_ra;
word_5 tmp_731398;
word_5 field_rb;
word_64 tmp_731400;
word_16 field_memory_disp;
tmp_731400 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_913889 = tmp_731400;
if ((tmp_913889 >> 16) == 0xFFFFFFFFFFFF || (tmp_913889 >> 16) == 0)
field_memory_disp = (tmp_913889 & 0xFFFF);
else goto fail_tmp_913888;
}
/* commit */
tmp_731398 = ref_gpr_reg_for_reading(0 + rm);
tmp_731397 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731397;
field_rb = tmp_731398;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731398);
/* can fail: T   num insns: 1 */
}
goto done_tmp_913895;
fail_tmp_913888:
/* LDAH */
{
word_5 tmp_731393;
word_5 field_ra;
word_5 tmp_731394;
word_5 field_rb;
word_64 tmp_731396;
word_16 field_memory_disp;
tmp_731396 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_913893 = tmp_731396;
if ((tmp_913893 & 0xFFFF) == 0)
{
word_64 tmp_913894 = (tmp_913893 >> 16);
if ((tmp_913894 >> 16) == 0xFFFFFFFFFFFF || (tmp_913894 >> 16) == 0)
field_memory_disp = (tmp_913894 & 0xFFFF);
else goto fail_tmp_913892;
}
else goto fail_tmp_913892;
}
/* commit */
tmp_731394 = ref_gpr_reg_for_reading(0 + rm);
tmp_731393 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731393;
field_rb = tmp_731394;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731394);
/* can fail: T   num insns: 1 */
}
goto done_tmp_913895;
fail_tmp_913892:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731900 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731900, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_913895:
return tmp_731876;
}
void genfunc_tmp_913847 (void) {
/* STL */
{
word_5 field_rb;
word_64 tmp_731143;
word_16 field_memory_disp;
word_5 tmp_731145;
word_5 field_ra;
tmp_731143 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_913842 = tmp_731143;
if ((tmp_913842 >> 16) == 0xFFFFFFFFFFFF || (tmp_913842 >> 16) == 0)
field_memory_disp = (tmp_913842 & 0xFFFF);
else goto fail_tmp_913841;
}
/* commit */
{
tmp_731145 = genfunc_tmp_913839();
goto next_tmp_913844;
next_tmp_913844:
goto tmp_913843;
tmp_913843:
}
field_ra = tmp_731145;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731145);
/* can fail: T   num insns: 5 */
}
goto done_tmp_913846;
fail_tmp_913841:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
tmp_731142 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731142, ((word_64)disp32));
{
tmp_731146 = genfunc_tmp_913839();
goto next_tmp_913591;
next_tmp_913591:
goto tmp_913590;
tmp_913590:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_913846:
}
reg_t genfunc_tmp_913839 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_913762;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_913461();
goto next_tmp_913764;
next_tmp_913764:
goto tmp_913763;
tmp_913763:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 3 */
}
goto done_tmp_913838;
fail_tmp_913762:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_913767 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_913767 >> 8) == 0)
field_imm = tmp_913767;
else goto fail_tmp_913766;
}
/* commit */
{
tmp_731665 = genfunc_tmp_913461();
goto next_tmp_913769;
next_tmp_913769:
goto tmp_913768;
tmp_913768:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 3 */
}
goto done_tmp_913838;
fail_tmp_913766:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_913829;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_913461();
goto next_tmp_913831;
next_tmp_913831:
goto tmp_913830;
tmp_913830:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 3 */
}
goto done_tmp_913838;
fail_tmp_913829:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_913834 = tmp_731085;
if ((tmp_913834 >> 8) == 0)
field_imm = tmp_913834;
else goto fail_tmp_913833;
}
/* commit */
{
tmp_731083 = genfunc_tmp_913461();
goto next_tmp_913836;
next_tmp_913836:
goto tmp_913835;
tmp_913835:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 3 */
}
goto done_tmp_913838;
fail_tmp_913833:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_913461();
goto next_tmp_913827;
next_tmp_913827:
goto tmp_913826;
tmp_913826:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 4 */
}
done_tmp_913838:
return tmp_731146;
}
void genfunc_tmp_913585 (void) {
/* STL */
{
word_5 field_rb;
word_64 tmp_731143;
word_16 field_memory_disp;
word_5 tmp_731145;
word_5 field_ra;
tmp_731143 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_913580 = tmp_731143;
if ((tmp_913580 >> 16) == 0xFFFFFFFFFFFF || (tmp_913580 >> 16) == 0)
field_memory_disp = (tmp_913580 & 0xFFFF);
else goto fail_tmp_913579;
}
/* commit */
{
tmp_731145 = genfunc_tmp_913577();
goto next_tmp_913582;
next_tmp_913582:
goto tmp_913581;
tmp_913581:
}
field_ra = tmp_731145;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731145);
/* can fail: T   num insns: 3 */
}
goto done_tmp_913584;
fail_tmp_913579:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
tmp_731142 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731142, ((word_64)disp32));
{
tmp_731146 = genfunc_tmp_913577();
goto next_tmp_913421;
next_tmp_913421:
goto tmp_913420;
tmp_913420:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_913584:
}
reg_t genfunc_tmp_913577 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_731383;
word_16 field_memory_disp;
tmp_731383 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_913555 = tmp_731383;
if ((tmp_913555 >> 16) == 0xFFFFFFFFFFFF || (tmp_913555 >> 16) == 0)
field_memory_disp = (tmp_913555 & 0xFFFF);
else goto fail_tmp_913554;
}
/* commit */
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_913576;
fail_tmp_913554:
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
tmp_731382 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731382, ((word_64)disp32));
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_913576:
return tmp_731146;
}
reg_t genfunc_tmp_913530 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_913499 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_913499 >> 8) == 0)
field_imm = tmp_913499;
else goto fail_tmp_913498;
}
/* commit */
{
tmp_731858 = genfunc_tmp_913461();
goto next_tmp_913501;
next_tmp_913501:
goto tmp_913500;
tmp_913500:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_913529;
fail_tmp_913498:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_913521 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_913521))
field_imm = inv_maskmask(8, tmp_913521);
else goto fail_tmp_913520;
}
/* commit */
{
tmp_731075 = genfunc_tmp_913461();
goto next_tmp_913523;
next_tmp_913523:
goto tmp_913522;
tmp_913522:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_913529;
fail_tmp_913520:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_913461();
goto next_tmp_913527;
next_tmp_913527:
goto tmp_913526;
tmp_913526:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_913529:
return tmp_731862;
}
reg_t genfunc_tmp_913461 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_731383;
word_16 field_memory_disp;
tmp_731383 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_913459 = tmp_731383;
if ((tmp_913459 >> 16) == 0xFFFFFFFFFFFF || (tmp_913459 >> 16) == 0)
field_memory_disp = (tmp_913459 & 0xFFFF);
else goto fail_tmp_913458;
}
/* commit */
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_913460;
fail_tmp_913458:
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
tmp_731382 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731382, ((word_64)disp32));
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_913460:
return tmp_731898;
}
void genfunc_tmp_913415 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_912991();
goto next_tmp_913161;
next_tmp_913161:
goto tmp_913160;
tmp_913160:
}
{
tmp_731146 = genfunc_tmp_913412();
goto next_tmp_913164;
next_tmp_913164:
goto tmp_913163;
tmp_913163:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 12 */
}
done_tmp_913414:
}
reg_t genfunc_tmp_913412 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_913335;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_913035();
goto next_tmp_913337;
next_tmp_913337:
goto tmp_913336;
tmp_913336:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 6 */
}
goto done_tmp_913411;
fail_tmp_913335:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_913340 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_913340 >> 8) == 0)
field_imm = tmp_913340;
else goto fail_tmp_913339;
}
/* commit */
{
tmp_731665 = genfunc_tmp_913035();
goto next_tmp_913342;
next_tmp_913342:
goto tmp_913341;
tmp_913341:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 6 */
}
goto done_tmp_913411;
fail_tmp_913339:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_913402;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_913035();
goto next_tmp_913404;
next_tmp_913404:
goto tmp_913403;
tmp_913403:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 6 */
}
goto done_tmp_913411;
fail_tmp_913402:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_913407 = tmp_731085;
if ((tmp_913407 >> 8) == 0)
field_imm = tmp_913407;
else goto fail_tmp_913406;
}
/* commit */
{
tmp_731083 = genfunc_tmp_913035();
goto next_tmp_913409;
next_tmp_913409:
goto tmp_913408;
tmp_913408:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 6 */
}
goto done_tmp_913411;
fail_tmp_913406:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_913035();
goto next_tmp_913400;
next_tmp_913400:
goto tmp_913399;
tmp_913399:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_913411:
return tmp_731146;
}
void genfunc_tmp_913155 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_912991();
goto next_tmp_912861;
next_tmp_912861:
goto tmp_912860;
tmp_912860:
}
{
tmp_731146 = genfunc_tmp_913152();
goto next_tmp_912994;
next_tmp_912994:
goto tmp_912993;
tmp_912993:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_913154:
}
reg_t genfunc_tmp_913152 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_912991();
goto next_tmp_913129;
next_tmp_913129:
goto tmp_913128;
tmp_913128:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_913151:
return tmp_731146;
}
reg_t genfunc_tmp_913104 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_913073 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_913073 >> 8) == 0)
field_imm = tmp_913073;
else goto fail_tmp_913072;
}
/* commit */
{
tmp_731858 = genfunc_tmp_913035();
goto next_tmp_913075;
next_tmp_913075:
goto tmp_913074;
tmp_913074:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 6 */
}
goto done_tmp_913103;
fail_tmp_913072:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_913095 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_913095))
field_imm = inv_maskmask(8, tmp_913095);
else goto fail_tmp_913094;
}
/* commit */
{
tmp_731075 = genfunc_tmp_913035();
goto next_tmp_913097;
next_tmp_913097:
goto tmp_913096;
tmp_913096:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 6 */
}
goto done_tmp_913103;
fail_tmp_913094:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_913035();
goto next_tmp_913101;
next_tmp_913101:
goto tmp_913100;
tmp_913100:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 6 */
}
done_tmp_913103:
return tmp_731862;
}
reg_t genfunc_tmp_913035 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_912991();
goto next_tmp_913032;
next_tmp_913032:
goto tmp_913031;
tmp_913031:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_913034:
return tmp_731898;
}
reg_t genfunc_tmp_912991 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_912958 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_912958 >> 8) == 0)
field_imm = tmp_912958;
else goto fail_tmp_912957;
}
/* commit */
{
tmp_731858 = genfunc_tmp_912902();
goto next_tmp_912960;
next_tmp_912960:
goto tmp_912959;
tmp_912959:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_912990;
fail_tmp_912957:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_912982 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_912982))
field_imm = inv_maskmask(8, tmp_912982);
else goto fail_tmp_912981;
}
/* commit */
{
tmp_731075 = genfunc_tmp_912902();
goto next_tmp_912984;
next_tmp_912984:
goto tmp_912983;
tmp_912983:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_912990;
fail_tmp_912981:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_912902();
goto next_tmp_912988;
next_tmp_912988:
goto tmp_912987;
tmp_912987:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_912990:
return tmp_731142;
}
reg_t genfunc_tmp_912955 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_912924 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_912924 >> 8) == 0)
field_imm = tmp_912924;
else goto fail_tmp_912923;
}
/* commit */
{
tmp_731858 = genfunc_tmp_912902();
goto next_tmp_912926;
next_tmp_912926:
goto tmp_912925;
tmp_912925:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_912954;
fail_tmp_912923:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_912946 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_912946))
field_imm = inv_maskmask(8, tmp_912946);
else goto fail_tmp_912945;
}
/* commit */
{
tmp_731075 = genfunc_tmp_912902();
goto next_tmp_912948;
next_tmp_912948:
goto tmp_912947;
tmp_912947:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_912954;
fail_tmp_912945:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_912902();
goto next_tmp_912952;
next_tmp_912952:
goto tmp_912951;
tmp_912951:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_912954:
return tmp_731862;
}
reg_t genfunc_tmp_912902 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_912893;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_911268();
goto next_tmp_912895;
next_tmp_912895:
goto tmp_912894;
tmp_912894:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_912901;
fail_tmp_912893:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_912897;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_911268();
goto next_tmp_912899;
next_tmp_912899:
goto tmp_912898;
tmp_912898:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_912901;
fail_tmp_912897:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_911268();
goto next_tmp_912877;
next_tmp_912877:
goto tmp_912876;
tmp_912876:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_912901:
return tmp_731876;
}
void genfunc_tmp_912855 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_912431();
goto next_tmp_912601;
next_tmp_912601:
goto tmp_912600;
tmp_912600:
}
{
tmp_731146 = genfunc_tmp_912852();
goto next_tmp_912604;
next_tmp_912604:
goto tmp_912603;
tmp_912603:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_912854:
}
reg_t genfunc_tmp_912852 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_912775;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_912475();
goto next_tmp_912777;
next_tmp_912777:
goto tmp_912776;
tmp_912776:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_912851;
fail_tmp_912775:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_912780 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_912780 >> 8) == 0)
field_imm = tmp_912780;
else goto fail_tmp_912779;
}
/* commit */
{
tmp_731665 = genfunc_tmp_912475();
goto next_tmp_912782;
next_tmp_912782:
goto tmp_912781;
tmp_912781:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_912851;
fail_tmp_912779:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_912842;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_912475();
goto next_tmp_912844;
next_tmp_912844:
goto tmp_912843;
tmp_912843:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_912851;
fail_tmp_912842:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_912847 = tmp_731085;
if ((tmp_912847 >> 8) == 0)
field_imm = tmp_912847;
else goto fail_tmp_912846;
}
/* commit */
{
tmp_731083 = genfunc_tmp_912475();
goto next_tmp_912849;
next_tmp_912849:
goto tmp_912848;
tmp_912848:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_912851;
fail_tmp_912846:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_912475();
goto next_tmp_912840;
next_tmp_912840:
goto tmp_912839;
tmp_912839:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_912851:
return tmp_731146;
}
void genfunc_tmp_912595 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_912431();
goto next_tmp_912310;
next_tmp_912310:
goto tmp_912309;
tmp_912309:
}
{
tmp_731146 = genfunc_tmp_912592();
goto next_tmp_912434;
next_tmp_912434:
goto tmp_912433;
tmp_912433:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_912594:
}
reg_t genfunc_tmp_912592 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_912431();
goto next_tmp_912569;
next_tmp_912569:
goto tmp_912568;
tmp_912568:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_912591:
return tmp_731146;
}
reg_t genfunc_tmp_912544 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_912513 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_912513 >> 8) == 0)
field_imm = tmp_912513;
else goto fail_tmp_912512;
}
/* commit */
{
tmp_731858 = genfunc_tmp_912475();
goto next_tmp_912515;
next_tmp_912515:
goto tmp_912514;
tmp_912514:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_912543;
fail_tmp_912512:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_912535 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_912535))
field_imm = inv_maskmask(8, tmp_912535);
else goto fail_tmp_912534;
}
/* commit */
{
tmp_731075 = genfunc_tmp_912475();
goto next_tmp_912537;
next_tmp_912537:
goto tmp_912536;
tmp_912536:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_912543;
fail_tmp_912534:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_912475();
goto next_tmp_912541;
next_tmp_912541:
goto tmp_912540;
tmp_912540:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_912543:
return tmp_731862;
}
reg_t genfunc_tmp_912475 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_912431();
goto next_tmp_912472;
next_tmp_912472:
goto tmp_912471;
tmp_912471:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_912474:
return tmp_731898;
}
reg_t genfunc_tmp_912431 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_912398 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_912398 >> 8) == 0)
field_imm = tmp_912398;
else goto fail_tmp_912397;
}
/* commit */
{
tmp_731858 = genfunc_tmp_912342();
goto next_tmp_912400;
next_tmp_912400:
goto tmp_912399;
tmp_912399:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_912430;
fail_tmp_912397:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_912422 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_912422))
field_imm = inv_maskmask(8, tmp_912422);
else goto fail_tmp_912421;
}
/* commit */
{
tmp_731075 = genfunc_tmp_912342();
goto next_tmp_912424;
next_tmp_912424:
goto tmp_912423;
tmp_912423:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_912430;
fail_tmp_912421:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_912342();
goto next_tmp_912428;
next_tmp_912428:
goto tmp_912427;
tmp_912427:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_912430:
return tmp_731142;
}
reg_t genfunc_tmp_912395 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_912364 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_912364 >> 8) == 0)
field_imm = tmp_912364;
else goto fail_tmp_912363;
}
/* commit */
{
tmp_731858 = genfunc_tmp_912342();
goto next_tmp_912366;
next_tmp_912366:
goto tmp_912365;
tmp_912365:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_912394;
fail_tmp_912363:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_912386 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_912386))
field_imm = inv_maskmask(8, tmp_912386);
else goto fail_tmp_912385;
}
/* commit */
{
tmp_731075 = genfunc_tmp_912342();
goto next_tmp_912388;
next_tmp_912388:
goto tmp_912387;
tmp_912387:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_912394;
fail_tmp_912385:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_912342();
goto next_tmp_912392;
next_tmp_912392:
goto tmp_912391;
tmp_912391:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_912394:
return tmp_731862;
}
reg_t genfunc_tmp_912342 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_912339;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + index);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_912341;
fail_tmp_912339:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_912340;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + index);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_912341;
fail_tmp_912340:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_912341:
return tmp_731876;
}
void genfunc_tmp_912304 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_911880();
goto next_tmp_912050;
next_tmp_912050:
goto tmp_912049;
tmp_912049:
}
{
tmp_731146 = genfunc_tmp_912301();
goto next_tmp_912053;
next_tmp_912053:
goto tmp_912052;
tmp_912052:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_912303:
}
reg_t genfunc_tmp_912301 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_912224;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_911924();
goto next_tmp_912226;
next_tmp_912226:
goto tmp_912225;
tmp_912225:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 3 */
}
goto done_tmp_912300;
fail_tmp_912224:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_912229 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_912229 >> 8) == 0)
field_imm = tmp_912229;
else goto fail_tmp_912228;
}
/* commit */
{
tmp_731665 = genfunc_tmp_911924();
goto next_tmp_912231;
next_tmp_912231:
goto tmp_912230;
tmp_912230:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 3 */
}
goto done_tmp_912300;
fail_tmp_912228:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_912291;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_911924();
goto next_tmp_912293;
next_tmp_912293:
goto tmp_912292;
tmp_912292:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 3 */
}
goto done_tmp_912300;
fail_tmp_912291:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_912296 = tmp_731085;
if ((tmp_912296 >> 8) == 0)
field_imm = tmp_912296;
else goto fail_tmp_912295;
}
/* commit */
{
tmp_731083 = genfunc_tmp_911924();
goto next_tmp_912298;
next_tmp_912298:
goto tmp_912297;
tmp_912297:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 3 */
}
goto done_tmp_912300;
fail_tmp_912295:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_911924();
goto next_tmp_912289;
next_tmp_912289:
goto tmp_912288;
tmp_912288:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 4 */
}
done_tmp_912300:
return tmp_731146;
}
void genfunc_tmp_912044 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_911880();
goto next_tmp_911804;
next_tmp_911804:
goto tmp_911803;
tmp_911803:
}
{
tmp_731146 = genfunc_tmp_912041();
goto next_tmp_911883;
next_tmp_911883:
goto tmp_911882;
tmp_911882:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_912043:
}
reg_t genfunc_tmp_912041 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_911880();
goto next_tmp_912018;
next_tmp_912018:
goto tmp_912017;
tmp_912017:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_912040:
return tmp_731146;
}
reg_t genfunc_tmp_911993 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_911962 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_911962 >> 8) == 0)
field_imm = tmp_911962;
else goto fail_tmp_911961;
}
/* commit */
{
tmp_731858 = genfunc_tmp_911924();
goto next_tmp_911964;
next_tmp_911964:
goto tmp_911963;
tmp_911963:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_911992;
fail_tmp_911961:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_911984 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_911984))
field_imm = inv_maskmask(8, tmp_911984);
else goto fail_tmp_911983;
}
/* commit */
{
tmp_731075 = genfunc_tmp_911924();
goto next_tmp_911986;
next_tmp_911986:
goto tmp_911985;
tmp_911985:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_911992;
fail_tmp_911983:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_911924();
goto next_tmp_911990;
next_tmp_911990:
goto tmp_911989;
tmp_911989:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_911992:
return tmp_731862;
}
reg_t genfunc_tmp_911924 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_911880();
goto next_tmp_911921;
next_tmp_911921:
goto tmp_911920;
tmp_911920:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_911923:
return tmp_731898;
}
reg_t genfunc_tmp_911880 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_911856 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_911856 >> 8) == 0)
field_imm = tmp_911856;
else goto fail_tmp_911855;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + base);
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_911879;
fail_tmp_911855:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_911877 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_911877))
field_imm = inv_maskmask(8, tmp_911877);
else goto fail_tmp_911876;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + base);
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_911879;
fail_tmp_911876:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + base);
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_911879:
return tmp_731142;
}
reg_t genfunc_tmp_911853 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_911831 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_911831 >> 8) == 0)
field_imm = tmp_911831;
else goto fail_tmp_911830;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + base);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_911852;
fail_tmp_911830:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_911850 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_911850))
field_imm = inv_maskmask(8, tmp_911850);
else goto fail_tmp_911849;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + base);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_911852;
fail_tmp_911849:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + base);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_911852:
return tmp_731862;
}
void genfunc_tmp_911798 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_911374();
goto next_tmp_911544;
next_tmp_911544:
goto tmp_911543;
tmp_911543:
}
{
tmp_731146 = genfunc_tmp_911795();
goto next_tmp_911547;
next_tmp_911547:
goto tmp_911546;
tmp_911546:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 10 */
}
done_tmp_911797:
}
reg_t genfunc_tmp_911795 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_911718;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_911418();
goto next_tmp_911720;
next_tmp_911720:
goto tmp_911719;
tmp_911719:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 5 */
}
goto done_tmp_911794;
fail_tmp_911718:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_911723 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_911723 >> 8) == 0)
field_imm = tmp_911723;
else goto fail_tmp_911722;
}
/* commit */
{
tmp_731665 = genfunc_tmp_911418();
goto next_tmp_911725;
next_tmp_911725:
goto tmp_911724;
tmp_911724:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 5 */
}
goto done_tmp_911794;
fail_tmp_911722:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_911785;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_911418();
goto next_tmp_911787;
next_tmp_911787:
goto tmp_911786;
tmp_911786:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 5 */
}
goto done_tmp_911794;
fail_tmp_911785:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_911790 = tmp_731085;
if ((tmp_911790 >> 8) == 0)
field_imm = tmp_911790;
else goto fail_tmp_911789;
}
/* commit */
{
tmp_731083 = genfunc_tmp_911418();
goto next_tmp_911792;
next_tmp_911792:
goto tmp_911791;
tmp_911791:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 5 */
}
goto done_tmp_911794;
fail_tmp_911789:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_911418();
goto next_tmp_911783;
next_tmp_911783:
goto tmp_911782;
tmp_911782:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_911794:
return tmp_731146;
}
void genfunc_tmp_911538 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_911374();
goto next_tmp_911220;
next_tmp_911220:
goto tmp_911219;
tmp_911219:
}
{
tmp_731146 = genfunc_tmp_911535();
goto next_tmp_911377;
next_tmp_911377:
goto tmp_911376;
tmp_911376:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_911537:
}
reg_t genfunc_tmp_911535 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_911374();
goto next_tmp_911512;
next_tmp_911512:
goto tmp_911511;
tmp_911511:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_911534:
return tmp_731146;
}
reg_t genfunc_tmp_911487 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_911456 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_911456 >> 8) == 0)
field_imm = tmp_911456;
else goto fail_tmp_911455;
}
/* commit */
{
tmp_731858 = genfunc_tmp_911418();
goto next_tmp_911458;
next_tmp_911458:
goto tmp_911457;
tmp_911457:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_911486;
fail_tmp_911455:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_911478 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_911478))
field_imm = inv_maskmask(8, tmp_911478);
else goto fail_tmp_911477;
}
/* commit */
{
tmp_731075 = genfunc_tmp_911418();
goto next_tmp_911480;
next_tmp_911480:
goto tmp_911479;
tmp_911479:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_911486;
fail_tmp_911477:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_911418();
goto next_tmp_911484;
next_tmp_911484:
goto tmp_911483;
tmp_911483:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_911486:
return tmp_731862;
}
reg_t genfunc_tmp_911418 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_911374();
goto next_tmp_911415;
next_tmp_911415:
goto tmp_911414;
tmp_911414:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_911417:
return tmp_731898;
}
reg_t genfunc_tmp_911374 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_911341 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_911341 >> 8) == 0)
field_imm = tmp_911341;
else goto fail_tmp_911340;
}
/* commit */
{
tmp_731858 = genfunc_tmp_911285();
goto next_tmp_911343;
next_tmp_911343:
goto tmp_911342;
tmp_911342:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_911373;
fail_tmp_911340:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_911365 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_911365))
field_imm = inv_maskmask(8, tmp_911365);
else goto fail_tmp_911364;
}
/* commit */
{
tmp_731075 = genfunc_tmp_911285();
goto next_tmp_911367;
next_tmp_911367:
goto tmp_911366;
tmp_911366:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_911373;
fail_tmp_911364:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_911285();
goto next_tmp_911371;
next_tmp_911371:
goto tmp_911370;
tmp_911370:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_911373:
return tmp_731142;
}
reg_t genfunc_tmp_911338 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_911307 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_911307 >> 8) == 0)
field_imm = tmp_911307;
else goto fail_tmp_911306;
}
/* commit */
{
tmp_731858 = genfunc_tmp_911285();
goto next_tmp_911309;
next_tmp_911309:
goto tmp_911308;
tmp_911308:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_911337;
fail_tmp_911306:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_911329 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_911329))
field_imm = inv_maskmask(8, tmp_911329);
else goto fail_tmp_911328;
}
/* commit */
{
tmp_731075 = genfunc_tmp_911285();
goto next_tmp_911331;
next_tmp_911331:
goto tmp_911330;
tmp_911330:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_911337;
fail_tmp_911328:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_911285();
goto next_tmp_911335;
next_tmp_911335:
goto tmp_911334;
tmp_911334:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_911337:
return tmp_731862;
}
reg_t genfunc_tmp_911285 (void) {
reg_t tmp_731876;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + base);
{
tmp_731900 = genfunc_tmp_911268();
goto next_tmp_911236;
next_tmp_911236:
goto tmp_911235;
tmp_911235:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_911284:
return tmp_731876;
}
reg_t genfunc_tmp_911268 (void) {
reg_t tmp_731900;
/* EXTQH */
{
word_5 tmp_731618;
word_5 field_rc;
word_5 tmp_731619;
word_5 field_ra;
word_5 field_rb;
if (64 != ((word_64)scale)) goto fail_tmp_911249;
field_rb = 31;
/* commit */
tmp_731619 = ref_gpr_reg_for_reading(0 + index);
tmp_731618 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731618;
field_ra = tmp_731619;
emit(COMPOSE_EXTQH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731619);
/* can fail: T   num insns: 1 */
}
goto done_tmp_911267;
fail_tmp_911249:
/* EXTQH_IMM */
{
word_5 tmp_731614;
word_5 field_rc;
word_5 tmp_731615;
word_5 field_ra;
word_64 tmp_731617;
word_8 field_imm;
tmp_731617 = ((word_64)scale);
{
word_64 tmp_911251 = ((64 - tmp_731617) & 0xFFFFFFFFFFFFFFFF);
if (tmp_911251 % 8 == 0)
{
word_64 tmp_911252 = (tmp_911251 / 8);
if ((tmp_911252 & 7) == tmp_911252)
{
word_64 tmp_911253 = tmp_911252;
if ((tmp_911253 >> 8) == 0)
field_imm = tmp_911253;
else goto fail_tmp_911250;
}
else goto fail_tmp_911250;
}
else goto fail_tmp_911250;
}
/* commit */
tmp_731615 = ref_gpr_reg_for_reading(0 + index);
tmp_731614 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731614;
field_ra = tmp_731615;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731615);
/* can fail: T   num insns: 1 */
}
goto done_tmp_911267;
fail_tmp_911250:
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 tmp_731241;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_911259;
field_rb = 31;
/* commit */
tmp_731241 = ref_gpr_reg_for_reading(0 + index);
tmp_731240 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_ra = tmp_731241;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731241);
/* can fail: T   num insns: 1 */
}
goto done_tmp_911267;
fail_tmp_911259:
/* S4ADDQ_IMM */
{
word_5 tmp_731236;
word_5 field_rc;
word_5 tmp_731237;
word_5 field_ra;
word_64 tmp_731239;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_911260;
tmp_731239 = 0;
field_imm = 0;
/* commit */
tmp_731237 = ref_gpr_reg_for_reading(0 + index);
tmp_731236 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731236;
field_ra = tmp_731237;
emit(COMPOSE_S4ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731237);
/* can fail: T   num insns: 1 */
}
goto done_tmp_911267;
fail_tmp_911260:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 tmp_731209;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_911262;
field_rb = 31;
/* commit */
tmp_731209 = ref_gpr_reg_for_reading(0 + index);
tmp_731208 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_ra = tmp_731209;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731209);
/* can fail: T   num insns: 1 */
}
goto done_tmp_911267;
fail_tmp_911262:
/* S8ADDQ_IMM */
{
word_5 tmp_731204;
word_5 field_rc;
word_5 tmp_731205;
word_5 field_ra;
word_64 tmp_731207;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_911263;
tmp_731207 = 0;
field_imm = 0;
/* commit */
tmp_731205 = ref_gpr_reg_for_reading(0 + index);
tmp_731204 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731204;
field_ra = tmp_731205;
emit(COMPOSE_S8ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731205);
/* can fail: T   num insns: 1 */
}
goto done_tmp_911267;
fail_tmp_911263:
/* SLL */
{
word_5 tmp_731176;
word_5 field_rc;
word_5 tmp_731177;
word_5 field_ra;
word_5 field_rb;
if (0 != ((word_64)scale)) goto fail_tmp_911264;
field_rb = 31;
/* commit */
tmp_731177 = ref_gpr_reg_for_reading(0 + index);
tmp_731176 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731176;
field_ra = tmp_731177;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731177);
/* can fail: T   num insns: 1 */
}
goto done_tmp_911267;
fail_tmp_911264:
/* SLL_IMM */
{
word_5 tmp_731172;
word_5 field_rc;
word_5 tmp_731173;
word_5 field_ra;
word_64 tmp_731175;
word_8 field_imm;
tmp_731175 = ((word_64)scale);
field_imm = tmp_731175;
/* commit */
tmp_731173 = ref_gpr_reg_for_reading(0 + index);
tmp_731172 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731172;
field_ra = tmp_731173;
emit(COMPOSE_SLL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731173);
/* can fail: NIL   num insns: 1 */
}
done_tmp_911267:
return tmp_731900;
}
void genfunc_tmp_911214 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_910790();
goto next_tmp_910960;
next_tmp_910960:
goto tmp_910959;
tmp_910959:
}
{
tmp_731146 = genfunc_tmp_911211();
goto next_tmp_910963;
next_tmp_910963:
goto tmp_910962;
tmp_910962:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_911213:
}
reg_t genfunc_tmp_911211 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_911134;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_910834();
goto next_tmp_911136;
next_tmp_911136:
goto tmp_911135;
tmp_911135:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 4 */
}
goto done_tmp_911210;
fail_tmp_911134:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_911139 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_911139 >> 8) == 0)
field_imm = tmp_911139;
else goto fail_tmp_911138;
}
/* commit */
{
tmp_731665 = genfunc_tmp_910834();
goto next_tmp_911141;
next_tmp_911141:
goto tmp_911140;
tmp_911140:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 4 */
}
goto done_tmp_911210;
fail_tmp_911138:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_911201;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_910834();
goto next_tmp_911203;
next_tmp_911203:
goto tmp_911202;
tmp_911202:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 4 */
}
goto done_tmp_911210;
fail_tmp_911201:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_911206 = tmp_731085;
if ((tmp_911206 >> 8) == 0)
field_imm = tmp_911206;
else goto fail_tmp_911205;
}
/* commit */
{
tmp_731083 = genfunc_tmp_910834();
goto next_tmp_911208;
next_tmp_911208:
goto tmp_911207;
tmp_911207:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 4 */
}
goto done_tmp_911210;
fail_tmp_911205:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_910834();
goto next_tmp_911199;
next_tmp_911199:
goto tmp_911198;
tmp_911198:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_911210:
return tmp_731146;
}
void genfunc_tmp_910954 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_910790();
goto next_tmp_910671;
next_tmp_910671:
goto tmp_910670;
tmp_910670:
}
{
tmp_731146 = genfunc_tmp_910951();
goto next_tmp_910793;
next_tmp_910793:
goto tmp_910792;
tmp_910792:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_910953:
}
reg_t genfunc_tmp_910951 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_910790();
goto next_tmp_910928;
next_tmp_910928:
goto tmp_910927;
tmp_910927:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 3 */
}
done_tmp_910950:
return tmp_731146;
}
reg_t genfunc_tmp_910903 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_910872 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_910872 >> 8) == 0)
field_imm = tmp_910872;
else goto fail_tmp_910871;
}
/* commit */
{
tmp_731858 = genfunc_tmp_910834();
goto next_tmp_910874;
next_tmp_910874:
goto tmp_910873;
tmp_910873:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_910902;
fail_tmp_910871:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_910894 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_910894))
field_imm = inv_maskmask(8, tmp_910894);
else goto fail_tmp_910893;
}
/* commit */
{
tmp_731075 = genfunc_tmp_910834();
goto next_tmp_910896;
next_tmp_910896:
goto tmp_910895;
tmp_910895:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_910902;
fail_tmp_910893:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_910834();
goto next_tmp_910900;
next_tmp_910900:
goto tmp_910899;
tmp_910899:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_910902:
return tmp_731862;
}
reg_t genfunc_tmp_910834 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_910790();
goto next_tmp_910831;
next_tmp_910831:
goto tmp_910830;
tmp_910830:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 3 */
}
done_tmp_910833:
return tmp_731898;
}
reg_t genfunc_tmp_910790 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_910757 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_910757 >> 8) == 0)
field_imm = tmp_910757;
else goto fail_tmp_910756;
}
/* commit */
{
tmp_731858 = genfunc_tmp_910701();
goto next_tmp_910759;
next_tmp_910759:
goto tmp_910758;
tmp_910758:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_910789;
fail_tmp_910756:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_910781 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_910781))
field_imm = inv_maskmask(8, tmp_910781);
else goto fail_tmp_910780;
}
/* commit */
{
tmp_731075 = genfunc_tmp_910701();
goto next_tmp_910783;
next_tmp_910783:
goto tmp_910782;
tmp_910782:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_910789;
fail_tmp_910780:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_910701();
goto next_tmp_910787;
next_tmp_910787:
goto tmp_910786;
tmp_910786:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_910789:
return tmp_731142;
}
reg_t genfunc_tmp_910754 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_910723 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_910723 >> 8) == 0)
field_imm = tmp_910723;
else goto fail_tmp_910722;
}
/* commit */
{
tmp_731858 = genfunc_tmp_910701();
goto next_tmp_910725;
next_tmp_910725:
goto tmp_910724;
tmp_910724:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_910753;
fail_tmp_910722:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_910745 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_910745))
field_imm = inv_maskmask(8, tmp_910745);
else goto fail_tmp_910744;
}
/* commit */
{
tmp_731075 = genfunc_tmp_910701();
goto next_tmp_910747;
next_tmp_910747:
goto tmp_910746;
tmp_910746:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_910753;
fail_tmp_910744:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_910701();
goto next_tmp_910751;
next_tmp_910751:
goto tmp_910750;
tmp_910750:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_910753:
return tmp_731862;
}
reg_t genfunc_tmp_910701 (void) {
reg_t tmp_731876;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + base);
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_910700:
return tmp_731876;
}
void genfunc_tmp_910665 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_910241();
goto next_tmp_910411;
next_tmp_910411:
goto tmp_910410;
tmp_910410:
}
{
tmp_731146 = genfunc_tmp_910662();
goto next_tmp_910414;
next_tmp_910414:
goto tmp_910413;
tmp_910413:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_910664:
}
reg_t genfunc_tmp_910662 (void) {
reg_t tmp_731146;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_910585;
field_rb = 31;
/* commit */
{
tmp_731669 = genfunc_tmp_910285();
goto next_tmp_910587;
next_tmp_910587:
goto tmp_910586;
tmp_910586:
}
tmp_731668 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 3 */
}
goto done_tmp_910661;
fail_tmp_910585:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_910590 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_910590 >> 8) == 0)
field_imm = tmp_910590;
else goto fail_tmp_910589;
}
/* commit */
{
tmp_731665 = genfunc_tmp_910285();
goto next_tmp_910592;
next_tmp_910592:
goto tmp_910591;
tmp_910591:
}
tmp_731664 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 3 */
}
goto done_tmp_910661;
fail_tmp_910589:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8)) goto fail_tmp_910652;
field_rb = 31;
/* commit */
{
tmp_731087 = genfunc_tmp_910285();
goto next_tmp_910654;
next_tmp_910654:
goto tmp_910653;
tmp_910653:
}
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 3 */
}
goto done_tmp_910661;
fail_tmp_910652:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8);
{
word_64 tmp_910657 = tmp_731085;
if ((tmp_910657 >> 8) == 0)
field_imm = tmp_910657;
else goto fail_tmp_910656;
}
/* commit */
{
tmp_731083 = genfunc_tmp_910285();
goto next_tmp_910659;
next_tmp_910659:
goto tmp_910658;
tmp_910658:
}
tmp_731082 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 3 */
}
goto done_tmp_910661;
fail_tmp_910656:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_910285();
goto next_tmp_910650;
next_tmp_910650:
goto tmp_910649;
tmp_910649:
}
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm8 & 0x80) ? ((word_64)imm8 | 0xFFFFFFFFFFFFFF00) : (word_64)imm8));
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 4 */
}
done_tmp_910661:
return tmp_731146;
}
void genfunc_tmp_910405 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_910241();
goto next_tmp_910165;
next_tmp_910165:
goto tmp_910164;
tmp_910164:
}
{
tmp_731146 = genfunc_tmp_910402();
goto next_tmp_910244;
next_tmp_910244:
goto tmp_910243;
tmp_910243:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_910404:
}
reg_t genfunc_tmp_910402 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_910241();
goto next_tmp_910379;
next_tmp_910379:
goto tmp_910378;
tmp_910378:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_910401:
return tmp_731146;
}
reg_t genfunc_tmp_910354 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_910323 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_910323 >> 8) == 0)
field_imm = tmp_910323;
else goto fail_tmp_910322;
}
/* commit */
{
tmp_731858 = genfunc_tmp_910285();
goto next_tmp_910325;
next_tmp_910325:
goto tmp_910324;
tmp_910324:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_910353;
fail_tmp_910322:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_910345 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_910345))
field_imm = inv_maskmask(8, tmp_910345);
else goto fail_tmp_910344;
}
/* commit */
{
tmp_731075 = genfunc_tmp_910285();
goto next_tmp_910347;
next_tmp_910347:
goto tmp_910346;
tmp_910346:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_910353;
fail_tmp_910344:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_910285();
goto next_tmp_910351;
next_tmp_910351:
goto tmp_910350;
tmp_910350:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_910353:
return tmp_731862;
}
reg_t genfunc_tmp_910285 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_910241();
goto next_tmp_910282;
next_tmp_910282:
goto tmp_910281;
tmp_910281:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_910284:
return tmp_731898;
}
reg_t genfunc_tmp_910241 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_910217 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_910217 >> 8) == 0)
field_imm = tmp_910217;
else goto fail_tmp_910216;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + rm);
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_910240;
fail_tmp_910216:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_910238 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_910238))
field_imm = inv_maskmask(8, tmp_910238);
else goto fail_tmp_910237;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + rm);
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_910240;
fail_tmp_910237:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + rm);
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_910240:
return tmp_731142;
}
reg_t genfunc_tmp_910214 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_910192 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_910192 >> 8) == 0)
field_imm = tmp_910192;
else goto fail_tmp_910191;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + rm);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_910213;
fail_tmp_910191:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_910211 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_910211))
field_imm = inv_maskmask(8, tmp_910211);
else goto fail_tmp_910210;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + rm);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_910213;
fail_tmp_910210:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + rm);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_910213:
return tmp_731862;
}
