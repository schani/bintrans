#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compiler_tmp_940525 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_940515 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_940520 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_940524 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_940511 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_940500 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_940510 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_940505 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_940508 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_940496 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_940492 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_940491 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_940525 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 6 6 T)
*/
{
{
reg_t tmp_940527, tmp_940528, tmp_940526;
rhs_func(&tmp_940527, -1, env);
emit(COMPOSE_SLL_IMM(tmp_940527, 63, tmp_940527));
emit(COMPOSE_SRL_IMM(tmp_940527, 57, tmp_940527));
tmp_940528 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_940528, -1);
emit(COMPOSE_SLL_IMM(tmp_940528, 63, tmp_940528));
emit(COMPOSE_SRL_IMM(tmp_940528, 57, tmp_940528));
tmp_940526 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_940526, tmp_940528, tmp_940526));
unref_integer_reg(tmp_940528);
emit(COMPOSE_BIS(tmp_940526, tmp_940527, tmp_940526));
unref_integer_reg(tmp_940527);
unref_integer_reg(tmp_940526);
}
}

void compiler_tmp_940515 (reg_t *target, int foreign_target, void **env)
/*
(IF (= (REGISTER NIL GPR (FIELD REG NIL NIL)) (INTEGER 0)) (INTEGER 1)
 (INTEGER 0))
*/
{
{
label_t tmp_940517 = alloc_label(), tmp_940518 = alloc_label(), tmp_940519 = alloc_label();
reg_t tmp_940516;
compiler_tmp_940520(tmp_940517, tmp_940518, env);

tmp_940516 = ref_integer_reg_for_writing(-1);
emit_label(tmp_940517);
push_alloc();
compiler_tmp_940510(&tmp_940516, tmp_940516 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_940519);
emit_label(tmp_940518);
push_alloc();
compiler_tmp_940491(&tmp_940516, tmp_940516 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_940519);
free_label(tmp_940517);
free_label(tmp_940518);
free_label(tmp_940519);
if (foreign_target == -1)
*target = tmp_940516;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_940516, *target));
unref_integer_reg(tmp_940516);
}

}
}

void compiler_tmp_940520 (label_t true_label, label_t false_label, void **env)
/*
(= (REGISTER NIL GPR (FIELD REG NIL NIL)) (INTEGER 0))
*/
{
{
reg_t tmp_940521, tmp_940522, tmp_940523;
compiler_tmp_940508(&tmp_940521, -1, env);
compiler_tmp_940524(&tmp_940522, -1, env);
tmp_940523 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_CMPEQ(tmp_940521, tmp_940522, tmp_940523));
unref_integer_reg(tmp_940521);
unref_integer_reg(tmp_940522);
emit_branch(COMPOSE_BEQ(tmp_940523, 0), false_label);
unref_integer_reg(tmp_940523);
emit_branch(COMPOSE_BR(31, 0), true_label);
}
}

void compiler_tmp_940524 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_940511 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 7 7 T)
*/
{
{
reg_t tmp_940513, tmp_940514, tmp_940512;
rhs_func(&tmp_940513, -1, env);
emit(COMPOSE_SLL_IMM(tmp_940513, 63, tmp_940513));
emit(COMPOSE_SRL_IMM(tmp_940513, 56, tmp_940513));
tmp_940514 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_940514, -1);
emit(COMPOSE_SLL_IMM(tmp_940514, 63, tmp_940514));
emit(COMPOSE_SRL_IMM(tmp_940514, 56, tmp_940514));
tmp_940512 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_940512, tmp_940514, tmp_940512));
unref_integer_reg(tmp_940514);
emit(COMPOSE_BIS(tmp_940512, tmp_940513, tmp_940512));
unref_integer_reg(tmp_940513);
unref_integer_reg(tmp_940512);
}
}

void compiler_tmp_940500 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (BIT-SET-P (REGISTER NIL GPR (FIELD REG NIL NIL))
  (- (INTEGER 32) (INTEGER 1)))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_940502 = alloc_label(), tmp_940503 = alloc_label(), tmp_940504 = alloc_label();
reg_t tmp_940501;
compiler_tmp_940505(tmp_940502, tmp_940503, env);

tmp_940501 = ref_integer_reg_for_writing(-1);
emit_label(tmp_940502);
push_alloc();
compiler_tmp_940510(&tmp_940501, tmp_940501 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_940504);
emit_label(tmp_940503);
push_alloc();
compiler_tmp_940491(&tmp_940501, tmp_940501 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_940504);
free_label(tmp_940502);
free_label(tmp_940503);
free_label(tmp_940504);
if (foreign_target == -1)
*target = tmp_940501;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_940501, *target));
unref_integer_reg(tmp_940501);
}

}
}

void compiler_tmp_940510 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 1)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 1);
}

void compiler_tmp_940505 (label_t true_label, label_t false_label, void **env)
/*
(BIT-SET-P (REGISTER NIL GPR (FIELD REG NIL NIL)) (- (INTEGER 32) (INTEGER 1)))
*/
{
{
reg_t tmp_940506, tmp_940507;
compiler_tmp_940508(&tmp_940506, -1, env);
tmp_940507 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_SRL_IMM(tmp_940506, (32 - 1), tmp_940507));
unref_integer_reg(tmp_940506);
emit_branch(COMPOSE_BLBS(tmp_940507, 0), true_label);
unref_integer_reg(tmp_940507);
emit_branch(COMPOSE_BR(31, 0), false_label);
}
}

void compiler_tmp_940508 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD REG NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + reg));
else {
reg_t tmp_940509 = ref_integer_reg_for_reading((0 + reg));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_940509, *target));
unref_integer_reg(tmp_940509);
}
}

void compiler_tmp_940496 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 11 11 T)
*/
{
{
reg_t tmp_940498, tmp_940499, tmp_940497;
rhs_func(&tmp_940498, -1, env);
emit(COMPOSE_SLL_IMM(tmp_940498, 63, tmp_940498));
emit(COMPOSE_SRL_IMM(tmp_940498, 52, tmp_940498));
tmp_940499 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_940499, -1);
emit(COMPOSE_SLL_IMM(tmp_940499, 63, tmp_940499));
emit(COMPOSE_SRL_IMM(tmp_940499, 52, tmp_940499));
tmp_940497 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_940497, tmp_940499, tmp_940497));
unref_integer_reg(tmp_940499);
emit(COMPOSE_BIS(tmp_940497, tmp_940498, tmp_940497));
unref_integer_reg(tmp_940498);
unref_integer_reg(tmp_940497);
}
}

void compiler_tmp_940492 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 0 0 T)
*/
{
{
reg_t tmp_940494, tmp_940495, tmp_940493;
rhs_func(&tmp_940494, -1, env);
emit(COMPOSE_SLL_IMM(tmp_940494, 63, tmp_940494));
emit(COMPOSE_SRL_IMM(tmp_940494, 63, tmp_940494));
tmp_940495 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_940495, -1);
emit(COMPOSE_SLL_IMM(tmp_940495, 63, tmp_940495));
emit(COMPOSE_SRL_IMM(tmp_940495, 63, tmp_940495));
tmp_940493 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_940493, tmp_940495, tmp_940493));
unref_integer_reg(tmp_940495);
emit(COMPOSE_BIS(tmp_940493, tmp_940494, tmp_940493));
unref_integer_reg(tmp_940494);
unref_integer_reg(tmp_940493);
}
}

void compiler_tmp_940491 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compile_xor_r32_rm32_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_933394();
goto next_tmp_933090;
next_tmp_933090:
goto finish_tmp_933089;
finish_tmp_933089:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_933744();
goto next_tmp_933397;
next_tmp_933397:
goto finish_tmp_933396;
finish_tmp_933396:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_934129();
goto next_tmp_933747;
next_tmp_933747:
goto finish_tmp_933746;
finish_tmp_933746:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_934436();
goto next_tmp_934132;
next_tmp_934132:
goto finish_tmp_934131;
finish_tmp_934131:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_934788();
goto next_tmp_934439;
next_tmp_934439:
goto finish_tmp_934438;
finish_tmp_934438:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_935149();
goto next_tmp_934791;
next_tmp_934791:
goto finish_tmp_934790;
finish_tmp_934790:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_935378();
goto next_tmp_935152;
next_tmp_935152:
goto finish_tmp_935151;
finish_tmp_935151:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; }))
{
genfunc_tmp_935378();
goto next_tmp_935381;
next_tmp_935381:
goto finish_tmp_935380;
finish_tmp_935380:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_935738();
goto next_tmp_935384;
next_tmp_935384:
goto finish_tmp_935383;
finish_tmp_935383:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_936099();
goto next_tmp_935741;
next_tmp_935741:
goto finish_tmp_935740;
finish_tmp_935740:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_936460();
goto next_tmp_936102;
next_tmp_936102:
goto finish_tmp_936101;
finish_tmp_936101:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_936812();
goto next_tmp_936463;
next_tmp_936463:
goto finish_tmp_936462;
finish_tmp_936462:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_937192();
goto next_tmp_936815;
next_tmp_936815:
goto finish_tmp_936814;
finish_tmp_936814:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_937575();
goto next_tmp_937195;
next_tmp_937195:
goto finish_tmp_937194;
finish_tmp_937194:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_937927();
goto next_tmp_937578;
next_tmp_937578:
goto finish_tmp_937577;
finish_tmp_937577:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_938284();
goto next_tmp_937930;
next_tmp_937930:
goto finish_tmp_937929;
finish_tmp_937929:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_938645();
goto next_tmp_938287;
next_tmp_938287:
goto finish_tmp_938286;
finish_tmp_938286:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_939006();
goto next_tmp_938648;
next_tmp_938648:
goto finish_tmp_938647;
finish_tmp_938647:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_939358();
goto next_tmp_939009;
next_tmp_939009:
goto finish_tmp_939008;
finish_tmp_939008:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_939719();
goto next_tmp_939361;
next_tmp_939361:
goto finish_tmp_939360;
finish_tmp_939360:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_940080();
goto next_tmp_939722;
next_tmp_939722:
goto finish_tmp_939721;
finish_tmp_939721:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_940432();
goto next_tmp_940083;
next_tmp_940083:
goto finish_tmp_940082;
finish_tmp_940082:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 3; }))
{
genfunc_tmp_940489();
goto next_tmp_940435;
next_tmp_940435:
goto finish_tmp_940434;
finish_tmp_940434:
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_940491;
killed |= 0x1;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_940492(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_940491;
killed |= 0x800;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_940496(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_940500;
killed |= 0x80;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_940511(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_940515;
killed |= 0x40;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_940525(rhs_func, env);
}
}
}
void genfunc_tmp_940489 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
tmp_731089 = ref_gpr_reg_for_reading(0 + rm);
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 1 */
}
done_tmp_940488:
}
reg_t genfunc_tmp_940457 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
tmp_731089 = ref_gpr_reg_for_reading(0 + rm);
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 1 */
}
done_tmp_940456:
return tmp_731898;
}
void genfunc_tmp_940432 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_940394();
goto next_tmp_940429;
next_tmp_940429:
goto tmp_940428;
tmp_940428:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_940431:
}
reg_t genfunc_tmp_940397 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_940394();
goto next_tmp_940105;
next_tmp_940105:
goto tmp_940104;
tmp_940104:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_940396:
return tmp_731898;
}
reg_t genfunc_tmp_940394 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_940303();
goto next_tmp_940391;
next_tmp_940391:
goto tmp_940390;
tmp_940390:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_940393:
return tmp_731089;
}
reg_t genfunc_tmp_940359 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_940303();
goto next_tmp_940182;
next_tmp_940182:
goto tmp_940181;
tmp_940181:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_940358:
return tmp_731906;
}
reg_t genfunc_tmp_940303 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_940270 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_940270 >> 8) == 0)
field_imm = tmp_940270;
else goto fail_tmp_940269;
}
/* commit */
{
tmp_731858 = genfunc_tmp_940214();
goto next_tmp_940272;
next_tmp_940272:
goto tmp_940271;
tmp_940271:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_940302;
fail_tmp_940269:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_940294 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_940294))
field_imm = inv_maskmask(8, tmp_940294);
else goto fail_tmp_940293;
}
/* commit */
{
tmp_731075 = genfunc_tmp_940214();
goto next_tmp_940296;
next_tmp_940296:
goto tmp_940295;
tmp_940295:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_940302;
fail_tmp_940293:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_940214();
goto next_tmp_940300;
next_tmp_940300:
goto tmp_940299;
tmp_940299:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_940302:
return tmp_731382;
}
reg_t genfunc_tmp_940267 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_940236 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_940236 >> 8) == 0)
field_imm = tmp_940236;
else goto fail_tmp_940235;
}
/* commit */
{
tmp_731858 = genfunc_tmp_940214();
goto next_tmp_940238;
next_tmp_940238:
goto tmp_940237;
tmp_940237:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_940266;
fail_tmp_940235:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_940258 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_940258))
field_imm = inv_maskmask(8, tmp_940258);
else goto fail_tmp_940257;
}
/* commit */
{
tmp_731075 = genfunc_tmp_940214();
goto next_tmp_940260;
next_tmp_940260:
goto tmp_940259;
tmp_940259:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_940266;
fail_tmp_940257:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_940214();
goto next_tmp_940264;
next_tmp_940264:
goto tmp_940263;
tmp_940263:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_940266:
return tmp_731862;
}
reg_t genfunc_tmp_940214 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_940211;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + 5);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_940213;
fail_tmp_940211:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_940212;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + 5);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_940213;
fail_tmp_940212:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + 5);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_940213:
return tmp_731876;
}
void genfunc_tmp_940080 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_940042();
goto next_tmp_940077;
next_tmp_940077:
goto tmp_940076;
tmp_940076:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_940079:
}
reg_t genfunc_tmp_940045 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_940042();
goto next_tmp_939744;
next_tmp_939744:
goto tmp_939743;
tmp_939743:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_940044:
return tmp_731898;
}
reg_t genfunc_tmp_940042 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_939951();
goto next_tmp_940039;
next_tmp_940039:
goto tmp_940038;
tmp_940038:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_940041:
return tmp_731089;
}
reg_t genfunc_tmp_940007 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_939951();
goto next_tmp_939821;
next_tmp_939821:
goto tmp_939820;
tmp_939820:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_940006:
return tmp_731906;
}
reg_t genfunc_tmp_939951 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_939918 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_939918 >> 8) == 0)
field_imm = tmp_939918;
else goto fail_tmp_939917;
}
/* commit */
{
tmp_731858 = genfunc_tmp_939862();
goto next_tmp_939920;
next_tmp_939920:
goto tmp_939919;
tmp_939919:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_939950;
fail_tmp_939917:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_939942 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_939942))
field_imm = inv_maskmask(8, tmp_939942);
else goto fail_tmp_939941;
}
/* commit */
{
tmp_731075 = genfunc_tmp_939862();
goto next_tmp_939944;
next_tmp_939944:
goto tmp_939943;
tmp_939943:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_939950;
fail_tmp_939941:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_939862();
goto next_tmp_939948;
next_tmp_939948:
goto tmp_939947;
tmp_939947:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_939950:
return tmp_731382;
}
reg_t genfunc_tmp_939915 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_939884 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_939884 >> 8) == 0)
field_imm = tmp_939884;
else goto fail_tmp_939883;
}
/* commit */
{
tmp_731858 = genfunc_tmp_939862();
goto next_tmp_939886;
next_tmp_939886:
goto tmp_939885;
tmp_939885:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_939914;
fail_tmp_939883:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_939906 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_939906))
field_imm = inv_maskmask(8, tmp_939906);
else goto fail_tmp_939905;
}
/* commit */
{
tmp_731075 = genfunc_tmp_939862();
goto next_tmp_939908;
next_tmp_939908:
goto tmp_939907;
tmp_939907:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_939914;
fail_tmp_939905:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_939862();
goto next_tmp_939912;
next_tmp_939912:
goto tmp_939911;
tmp_939911:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_939914:
return tmp_731862;
}
reg_t genfunc_tmp_939862 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_939853;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_937332();
goto next_tmp_939855;
next_tmp_939855:
goto tmp_939854;
tmp_939854:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_939861;
fail_tmp_939853:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_939857;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_937332();
goto next_tmp_939859;
next_tmp_939859:
goto tmp_939858;
tmp_939858:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_939861;
fail_tmp_939857:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_937332();
goto next_tmp_939837;
next_tmp_939837:
goto tmp_939836;
tmp_939836:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_939861:
return tmp_731876;
}
void genfunc_tmp_939719 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_939681();
goto next_tmp_939716;
next_tmp_939716:
goto tmp_939715;
tmp_939715:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_939718:
}
reg_t genfunc_tmp_939684 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_939681();
goto next_tmp_939383;
next_tmp_939383:
goto tmp_939382;
tmp_939382:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_939683:
return tmp_731898;
}
reg_t genfunc_tmp_939681 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_939590();
goto next_tmp_939678;
next_tmp_939678:
goto tmp_939677;
tmp_939677:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_939680:
return tmp_731089;
}
reg_t genfunc_tmp_939646 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_939590();
goto next_tmp_939460;
next_tmp_939460:
goto tmp_939459;
tmp_939459:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_939645:
return tmp_731906;
}
reg_t genfunc_tmp_939590 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_939557 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_939557 >> 8) == 0)
field_imm = tmp_939557;
else goto fail_tmp_939556;
}
/* commit */
{
tmp_731858 = genfunc_tmp_939501();
goto next_tmp_939559;
next_tmp_939559:
goto tmp_939558;
tmp_939558:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_939589;
fail_tmp_939556:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_939581 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_939581))
field_imm = inv_maskmask(8, tmp_939581);
else goto fail_tmp_939580;
}
/* commit */
{
tmp_731075 = genfunc_tmp_939501();
goto next_tmp_939583;
next_tmp_939583:
goto tmp_939582;
tmp_939582:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_939589;
fail_tmp_939580:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_939501();
goto next_tmp_939587;
next_tmp_939587:
goto tmp_939586;
tmp_939586:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_939589:
return tmp_731382;
}
reg_t genfunc_tmp_939554 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_939523 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_939523 >> 8) == 0)
field_imm = tmp_939523;
else goto fail_tmp_939522;
}
/* commit */
{
tmp_731858 = genfunc_tmp_939501();
goto next_tmp_939525;
next_tmp_939525:
goto tmp_939524;
tmp_939524:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_939553;
fail_tmp_939522:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_939545 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_939545))
field_imm = inv_maskmask(8, tmp_939545);
else goto fail_tmp_939544;
}
/* commit */
{
tmp_731075 = genfunc_tmp_939501();
goto next_tmp_939547;
next_tmp_939547:
goto tmp_939546;
tmp_939546:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_939553;
fail_tmp_939544:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_939501();
goto next_tmp_939551;
next_tmp_939551:
goto tmp_939550;
tmp_939550:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_939553:
return tmp_731862;
}
reg_t genfunc_tmp_939501 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_939492;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_936949();
goto next_tmp_939494;
next_tmp_939494:
goto tmp_939493;
tmp_939493:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_939500;
fail_tmp_939492:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_939496;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_936949();
goto next_tmp_939498;
next_tmp_939498:
goto tmp_939497;
tmp_939497:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_939500;
fail_tmp_939496:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_936949();
goto next_tmp_939476;
next_tmp_939476:
goto tmp_939475;
tmp_939475:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_939500:
return tmp_731876;
}
void genfunc_tmp_939358 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_939320();
goto next_tmp_939355;
next_tmp_939355:
goto tmp_939354;
tmp_939354:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_939357:
}
reg_t genfunc_tmp_939323 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_939320();
goto next_tmp_939031;
next_tmp_939031:
goto tmp_939030;
tmp_939030:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_939322:
return tmp_731898;
}
reg_t genfunc_tmp_939320 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_939229();
goto next_tmp_939317;
next_tmp_939317:
goto tmp_939316;
tmp_939316:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_939319:
return tmp_731089;
}
reg_t genfunc_tmp_939285 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_939229();
goto next_tmp_939108;
next_tmp_939108:
goto tmp_939107;
tmp_939107:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_939284:
return tmp_731906;
}
reg_t genfunc_tmp_939229 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_939196 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_939196 >> 8) == 0)
field_imm = tmp_939196;
else goto fail_tmp_939195;
}
/* commit */
{
tmp_731858 = genfunc_tmp_939140();
goto next_tmp_939198;
next_tmp_939198:
goto tmp_939197;
tmp_939197:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_939228;
fail_tmp_939195:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_939220 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_939220))
field_imm = inv_maskmask(8, tmp_939220);
else goto fail_tmp_939219;
}
/* commit */
{
tmp_731075 = genfunc_tmp_939140();
goto next_tmp_939222;
next_tmp_939222:
goto tmp_939221;
tmp_939221:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_939228;
fail_tmp_939219:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_939140();
goto next_tmp_939226;
next_tmp_939226:
goto tmp_939225;
tmp_939225:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_939228:
return tmp_731382;
}
reg_t genfunc_tmp_939193 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_939162 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_939162 >> 8) == 0)
field_imm = tmp_939162;
else goto fail_tmp_939161;
}
/* commit */
{
tmp_731858 = genfunc_tmp_939140();
goto next_tmp_939164;
next_tmp_939164:
goto tmp_939163;
tmp_939163:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_939192;
fail_tmp_939161:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_939184 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_939184))
field_imm = inv_maskmask(8, tmp_939184);
else goto fail_tmp_939183;
}
/* commit */
{
tmp_731075 = genfunc_tmp_939140();
goto next_tmp_939186;
next_tmp_939186:
goto tmp_939185;
tmp_939185:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_939192;
fail_tmp_939183:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_939140();
goto next_tmp_939190;
next_tmp_939190:
goto tmp_939189;
tmp_939189:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_939192:
return tmp_731862;
}
reg_t genfunc_tmp_939140 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_939137;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + base);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_939139;
fail_tmp_939137:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_939138;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + base);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_939139;
fail_tmp_939138:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + base);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_939139:
return tmp_731876;
}
void genfunc_tmp_939006 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_938968();
goto next_tmp_939003;
next_tmp_939003:
goto tmp_939002;
tmp_939002:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_939005:
}
reg_t genfunc_tmp_938971 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_938968();
goto next_tmp_938670;
next_tmp_938670:
goto tmp_938669;
tmp_938669:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_938970:
return tmp_731898;
}
reg_t genfunc_tmp_938968 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_938877();
goto next_tmp_938965;
next_tmp_938965:
goto tmp_938964;
tmp_938964:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_938967:
return tmp_731089;
}
reg_t genfunc_tmp_938933 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_938877();
goto next_tmp_938747;
next_tmp_938747:
goto tmp_938746;
tmp_938746:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_938932:
return tmp_731906;
}
reg_t genfunc_tmp_938877 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_938844 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_938844 >> 8) == 0)
field_imm = tmp_938844;
else goto fail_tmp_938843;
}
/* commit */
{
tmp_731858 = genfunc_tmp_938788();
goto next_tmp_938846;
next_tmp_938846:
goto tmp_938845;
tmp_938845:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_938876;
fail_tmp_938843:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_938868 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_938868))
field_imm = inv_maskmask(8, tmp_938868);
else goto fail_tmp_938867;
}
/* commit */
{
tmp_731075 = genfunc_tmp_938788();
goto next_tmp_938870;
next_tmp_938870:
goto tmp_938869;
tmp_938869:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_938876;
fail_tmp_938867:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_938788();
goto next_tmp_938874;
next_tmp_938874:
goto tmp_938873;
tmp_938873:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_938876:
return tmp_731382;
}
reg_t genfunc_tmp_938841 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_938810 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_938810 >> 8) == 0)
field_imm = tmp_938810;
else goto fail_tmp_938809;
}
/* commit */
{
tmp_731858 = genfunc_tmp_938788();
goto next_tmp_938812;
next_tmp_938812:
goto tmp_938811;
tmp_938811:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_938840;
fail_tmp_938809:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_938832 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_938832))
field_imm = inv_maskmask(8, tmp_938832);
else goto fail_tmp_938831;
}
/* commit */
{
tmp_731075 = genfunc_tmp_938788();
goto next_tmp_938834;
next_tmp_938834:
goto tmp_938833;
tmp_938833:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_938840;
fail_tmp_938831:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_938788();
goto next_tmp_938838;
next_tmp_938838:
goto tmp_938837;
tmp_938837:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_938840:
return tmp_731862;
}
reg_t genfunc_tmp_938788 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_938779;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_933911();
goto next_tmp_938781;
next_tmp_938781:
goto tmp_938780;
tmp_938780:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_938787;
fail_tmp_938779:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_938783;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_933911();
goto next_tmp_938785;
next_tmp_938785:
goto tmp_938784;
tmp_938784:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_938787;
fail_tmp_938783:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_933911();
goto next_tmp_938763;
next_tmp_938763:
goto tmp_938762;
tmp_938762:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_938787:
return tmp_731876;
}
void genfunc_tmp_938645 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_938607();
goto next_tmp_938642;
next_tmp_938642:
goto tmp_938641;
tmp_938641:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_938644:
}
reg_t genfunc_tmp_938610 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_938607();
goto next_tmp_938309;
next_tmp_938309:
goto tmp_938308;
tmp_938308:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_938609:
return tmp_731898;
}
reg_t genfunc_tmp_938607 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_938516();
goto next_tmp_938604;
next_tmp_938604:
goto tmp_938603;
tmp_938603:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_938606:
return tmp_731089;
}
reg_t genfunc_tmp_938572 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_938516();
goto next_tmp_938386;
next_tmp_938386:
goto tmp_938385;
tmp_938385:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_938571:
return tmp_731906;
}
reg_t genfunc_tmp_938516 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_938483 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_938483 >> 8) == 0)
field_imm = tmp_938483;
else goto fail_tmp_938482;
}
/* commit */
{
tmp_731858 = genfunc_tmp_938427();
goto next_tmp_938485;
next_tmp_938485:
goto tmp_938484;
tmp_938484:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_938515;
fail_tmp_938482:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_938507 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_938507))
field_imm = inv_maskmask(8, tmp_938507);
else goto fail_tmp_938506;
}
/* commit */
{
tmp_731075 = genfunc_tmp_938427();
goto next_tmp_938509;
next_tmp_938509:
goto tmp_938508;
tmp_938508:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_938515;
fail_tmp_938506:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_938427();
goto next_tmp_938513;
next_tmp_938513:
goto tmp_938512;
tmp_938512:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_938515:
return tmp_731382;
}
reg_t genfunc_tmp_938480 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_938449 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_938449 >> 8) == 0)
field_imm = tmp_938449;
else goto fail_tmp_938448;
}
/* commit */
{
tmp_731858 = genfunc_tmp_938427();
goto next_tmp_938451;
next_tmp_938451:
goto tmp_938450;
tmp_938450:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_938479;
fail_tmp_938448:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_938471 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_938471))
field_imm = inv_maskmask(8, tmp_938471);
else goto fail_tmp_938470;
}
/* commit */
{
tmp_731075 = genfunc_tmp_938427();
goto next_tmp_938473;
next_tmp_938473:
goto tmp_938472;
tmp_938472:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_938479;
fail_tmp_938470:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_938427();
goto next_tmp_938477;
next_tmp_938477:
goto tmp_938476;
tmp_938476:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_938479:
return tmp_731862;
}
reg_t genfunc_tmp_938427 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_938418;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_933526();
goto next_tmp_938420;
next_tmp_938420:
goto tmp_938419;
tmp_938419:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_938426;
fail_tmp_938418:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_938422;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_933526();
goto next_tmp_938424;
next_tmp_938424:
goto tmp_938423;
tmp_938423:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_938426;
fail_tmp_938422:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_933526();
goto next_tmp_938402;
next_tmp_938402:
goto tmp_938401;
tmp_938401:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_938426:
return tmp_731876;
}
void genfunc_tmp_938284 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_938246();
goto next_tmp_938281;
next_tmp_938281:
goto tmp_938280;
tmp_938280:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_938283:
}
reg_t genfunc_tmp_938249 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_938246();
goto next_tmp_937952;
next_tmp_937952:
goto tmp_937951;
tmp_937951:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_938248:
return tmp_731898;
}
reg_t genfunc_tmp_938246 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_938155();
goto next_tmp_938243;
next_tmp_938243:
goto tmp_938242;
tmp_938242:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_938245:
return tmp_731089;
}
reg_t genfunc_tmp_938211 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_938155();
goto next_tmp_938029;
next_tmp_938029:
goto tmp_938028;
tmp_938028:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_938210:
return tmp_731906;
}
reg_t genfunc_tmp_938155 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_938122 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_938122 >> 8) == 0)
field_imm = tmp_938122;
else goto fail_tmp_938121;
}
/* commit */
{
tmp_731858 = genfunc_tmp_938066();
goto next_tmp_938124;
next_tmp_938124:
goto tmp_938123;
tmp_938123:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_938154;
fail_tmp_938121:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_938146 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_938146))
field_imm = inv_maskmask(8, tmp_938146);
else goto fail_tmp_938145;
}
/* commit */
{
tmp_731075 = genfunc_tmp_938066();
goto next_tmp_938148;
next_tmp_938148:
goto tmp_938147;
tmp_938147:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_938154;
fail_tmp_938145:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_938066();
goto next_tmp_938152;
next_tmp_938152:
goto tmp_938151;
tmp_938151:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_938154:
return tmp_731382;
}
reg_t genfunc_tmp_938119 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_938088 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_938088 >> 8) == 0)
field_imm = tmp_938088;
else goto fail_tmp_938087;
}
/* commit */
{
tmp_731858 = genfunc_tmp_938066();
goto next_tmp_938090;
next_tmp_938090:
goto tmp_938089;
tmp_938089:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_938118;
fail_tmp_938087:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_938110 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_938110))
field_imm = inv_maskmask(8, tmp_938110);
else goto fail_tmp_938109;
}
/* commit */
{
tmp_731075 = genfunc_tmp_938066();
goto next_tmp_938112;
next_tmp_938112:
goto tmp_938111;
tmp_938111:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_938118;
fail_tmp_938109:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_938066();
goto next_tmp_938116;
next_tmp_938116:
goto tmp_938115;
tmp_938115:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_938118:
return tmp_731862;
}
reg_t genfunc_tmp_938066 (void) {
reg_t tmp_731876;
/* ADDQ_IMM */
{
word_5 tmp_731893;
word_5 field_rc;
word_5 tmp_731894;
word_5 field_ra;
word_64 tmp_731896;
word_8 field_imm;
tmp_731896 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_938051 = tmp_731896;
if ((tmp_938051 >> 8) == 0)
field_imm = tmp_938051;
else goto fail_tmp_938050;
}
/* commit */
tmp_731894 = ref_gpr_reg_for_reading(0 + rm);
tmp_731893 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731893;
field_ra = tmp_731894;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731894);
/* can fail: T   num insns: 1 */
}
goto done_tmp_938065;
fail_tmp_938050:
/* LDA */
{
word_5 tmp_731397;
word_5 field_ra;
word_5 tmp_731398;
word_5 field_rb;
word_64 tmp_731400;
word_16 field_memory_disp;
tmp_731400 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_938059 = tmp_731400;
if ((tmp_938059 >> 16) == 0xFFFFFFFFFFFF || (tmp_938059 >> 16) == 0)
field_memory_disp = (tmp_938059 & 0xFFFF);
else goto fail_tmp_938058;
}
/* commit */
tmp_731398 = ref_gpr_reg_for_reading(0 + rm);
tmp_731397 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731397;
field_rb = tmp_731398;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731398);
/* can fail: T   num insns: 1 */
}
goto done_tmp_938065;
fail_tmp_938058:
/* LDAH */
{
word_5 tmp_731393;
word_5 field_ra;
word_5 tmp_731394;
word_5 field_rb;
word_64 tmp_731396;
word_16 field_memory_disp;
tmp_731396 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_938063 = tmp_731396;
if ((tmp_938063 & 0xFFFF) == 0)
{
word_64 tmp_938064 = (tmp_938063 >> 16);
if ((tmp_938064 >> 16) == 0xFFFFFFFFFFFF || (tmp_938064 >> 16) == 0)
field_memory_disp = (tmp_938064 & 0xFFFF);
else goto fail_tmp_938062;
}
else goto fail_tmp_938062;
}
/* commit */
tmp_731394 = ref_gpr_reg_for_reading(0 + rm);
tmp_731393 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731393;
field_rb = tmp_731394;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731394);
/* can fail: T   num insns: 1 */
}
goto done_tmp_938065;
fail_tmp_938062:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731900 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731900, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_938065:
return tmp_731876;
}
void genfunc_tmp_937927 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_937889();
goto next_tmp_937924;
next_tmp_937924:
goto tmp_937923;
tmp_937923:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_937926:
}
reg_t genfunc_tmp_937892 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_937889();
goto next_tmp_937600;
next_tmp_937600:
goto tmp_937599;
tmp_937599:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_937891:
return tmp_731898;
}
reg_t genfunc_tmp_937889 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_937798();
goto next_tmp_937886;
next_tmp_937886:
goto tmp_937885;
tmp_937885:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_937888:
return tmp_731089;
}
reg_t genfunc_tmp_937854 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_937798();
goto next_tmp_937677;
next_tmp_937677:
goto tmp_937676;
tmp_937676:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_937853:
return tmp_731906;
}
reg_t genfunc_tmp_937798 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_937765 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_937765 >> 8) == 0)
field_imm = tmp_937765;
else goto fail_tmp_937764;
}
/* commit */
{
tmp_731858 = genfunc_tmp_937709();
goto next_tmp_937767;
next_tmp_937767:
goto tmp_937766;
tmp_937766:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_937797;
fail_tmp_937764:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_937789 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_937789))
field_imm = inv_maskmask(8, tmp_937789);
else goto fail_tmp_937788;
}
/* commit */
{
tmp_731075 = genfunc_tmp_937709();
goto next_tmp_937791;
next_tmp_937791:
goto tmp_937790;
tmp_937790:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_937797;
fail_tmp_937788:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_937709();
goto next_tmp_937795;
next_tmp_937795:
goto tmp_937794;
tmp_937794:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_937797:
return tmp_731382;
}
reg_t genfunc_tmp_937762 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_937731 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_937731 >> 8) == 0)
field_imm = tmp_937731;
else goto fail_tmp_937730;
}
/* commit */
{
tmp_731858 = genfunc_tmp_937709();
goto next_tmp_937733;
next_tmp_937733:
goto tmp_937732;
tmp_937732:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_937761;
fail_tmp_937730:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_937753 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_937753))
field_imm = inv_maskmask(8, tmp_937753);
else goto fail_tmp_937752;
}
/* commit */
{
tmp_731075 = genfunc_tmp_937709();
goto next_tmp_937755;
next_tmp_937755:
goto tmp_937754;
tmp_937754:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_937761;
fail_tmp_937752:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_937709();
goto next_tmp_937759;
next_tmp_937759:
goto tmp_937758;
tmp_937758:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_937761:
return tmp_731862;
}
reg_t genfunc_tmp_937709 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_937706;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + 5);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_937708;
fail_tmp_937706:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_937707;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + 5);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_937708;
fail_tmp_937707:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731900 = ref_gpr_reg_for_reading(0 + 5);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_937708:
return tmp_731876;
}
void genfunc_tmp_937575 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_937537();
goto next_tmp_937572;
next_tmp_937572:
goto tmp_937571;
tmp_937571:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_937574:
}
reg_t genfunc_tmp_937540 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_937537();
goto next_tmp_937217;
next_tmp_937217:
goto tmp_937216;
tmp_937216:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_937539:
return tmp_731898;
}
reg_t genfunc_tmp_937537 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_937446();
goto next_tmp_937534;
next_tmp_937534:
goto tmp_937533;
tmp_937533:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_937536:
return tmp_731089;
}
reg_t genfunc_tmp_937502 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_937446();
goto next_tmp_937294;
next_tmp_937294:
goto tmp_937293;
tmp_937293:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_937501:
return tmp_731906;
}
reg_t genfunc_tmp_937446 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_937413 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_937413 >> 8) == 0)
field_imm = tmp_937413;
else goto fail_tmp_937412;
}
/* commit */
{
tmp_731858 = genfunc_tmp_937357();
goto next_tmp_937415;
next_tmp_937415:
goto tmp_937414;
tmp_937414:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_937445;
fail_tmp_937412:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_937437 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_937437))
field_imm = inv_maskmask(8, tmp_937437);
else goto fail_tmp_937436;
}
/* commit */
{
tmp_731075 = genfunc_tmp_937357();
goto next_tmp_937439;
next_tmp_937439:
goto tmp_937438;
tmp_937438:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_937445;
fail_tmp_937436:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_937357();
goto next_tmp_937443;
next_tmp_937443:
goto tmp_937442;
tmp_937442:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_937445:
return tmp_731382;
}
reg_t genfunc_tmp_937410 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_937379 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_937379 >> 8) == 0)
field_imm = tmp_937379;
else goto fail_tmp_937378;
}
/* commit */
{
tmp_731858 = genfunc_tmp_937357();
goto next_tmp_937381;
next_tmp_937381:
goto tmp_937380;
tmp_937380:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_937409;
fail_tmp_937378:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_937401 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_937401))
field_imm = inv_maskmask(8, tmp_937401);
else goto fail_tmp_937400;
}
/* commit */
{
tmp_731075 = genfunc_tmp_937357();
goto next_tmp_937403;
next_tmp_937403:
goto tmp_937402;
tmp_937402:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_937409;
fail_tmp_937400:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_937357();
goto next_tmp_937407;
next_tmp_937407:
goto tmp_937406;
tmp_937406:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_937409:
return tmp_731862;
}
reg_t genfunc_tmp_937357 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_937348;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_937332();
goto next_tmp_937350;
next_tmp_937350:
goto tmp_937349;
tmp_937349:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_937356;
fail_tmp_937348:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_937352;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_937332();
goto next_tmp_937354;
next_tmp_937354:
goto tmp_937353;
tmp_937353:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_937356;
fail_tmp_937352:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_937332();
goto next_tmp_937310;
next_tmp_937310:
goto tmp_937309;
tmp_937309:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_937356:
return tmp_731876;
}
reg_t genfunc_tmp_937332 (void) {
reg_t tmp_731900;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + 5);
{
tmp_731900 = genfunc_tmp_933894();
goto next_tmp_937315;
next_tmp_937315:
goto tmp_937314;
tmp_937314:
}
tmp_731897 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_937331:
return tmp_731900;
}
void genfunc_tmp_937192 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_937154();
goto next_tmp_937189;
next_tmp_937189:
goto tmp_937188;
tmp_937188:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_937191:
}
reg_t genfunc_tmp_937157 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_937154();
goto next_tmp_936837;
next_tmp_936837:
goto tmp_936836;
tmp_936836:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_937156:
return tmp_731898;
}
reg_t genfunc_tmp_937154 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_937063();
goto next_tmp_937151;
next_tmp_937151:
goto tmp_937150;
tmp_937150:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_937153:
return tmp_731089;
}
reg_t genfunc_tmp_937119 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_937063();
goto next_tmp_936914;
next_tmp_936914:
goto tmp_936913;
tmp_936913:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_937118:
return tmp_731906;
}
reg_t genfunc_tmp_937063 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_937030 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_937030 >> 8) == 0)
field_imm = tmp_937030;
else goto fail_tmp_937029;
}
/* commit */
{
tmp_731858 = genfunc_tmp_936974();
goto next_tmp_937032;
next_tmp_937032:
goto tmp_937031;
tmp_937031:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_937062;
fail_tmp_937029:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_937054 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_937054))
field_imm = inv_maskmask(8, tmp_937054);
else goto fail_tmp_937053;
}
/* commit */
{
tmp_731075 = genfunc_tmp_936974();
goto next_tmp_937056;
next_tmp_937056:
goto tmp_937055;
tmp_937055:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_937062;
fail_tmp_937053:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_936974();
goto next_tmp_937060;
next_tmp_937060:
goto tmp_937059;
tmp_937059:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_937062:
return tmp_731382;
}
reg_t genfunc_tmp_937027 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_936996 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_936996 >> 8) == 0)
field_imm = tmp_936996;
else goto fail_tmp_936995;
}
/* commit */
{
tmp_731858 = genfunc_tmp_936974();
goto next_tmp_936998;
next_tmp_936998:
goto tmp_936997;
tmp_936997:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_937026;
fail_tmp_936995:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_937018 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_937018))
field_imm = inv_maskmask(8, tmp_937018);
else goto fail_tmp_937017;
}
/* commit */
{
tmp_731075 = genfunc_tmp_936974();
goto next_tmp_937020;
next_tmp_937020:
goto tmp_937019;
tmp_937019:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_937026;
fail_tmp_937017:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_936974();
goto next_tmp_937024;
next_tmp_937024:
goto tmp_937023;
tmp_937023:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_937026:
return tmp_731862;
}
reg_t genfunc_tmp_936974 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_936965;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_936949();
goto next_tmp_936967;
next_tmp_936967:
goto tmp_936966;
tmp_936966:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_936973;
fail_tmp_936965:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_936969;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_936949();
goto next_tmp_936971;
next_tmp_936971:
goto tmp_936970;
tmp_936970:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_936973;
fail_tmp_936969:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_936949();
goto next_tmp_936930;
next_tmp_936930:
goto tmp_936929;
tmp_936929:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_936973:
return tmp_731876;
}
reg_t genfunc_tmp_936949 (void) {
reg_t tmp_731900;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + 5);
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_936948:
return tmp_731900;
}
void genfunc_tmp_936812 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_936774();
goto next_tmp_936809;
next_tmp_936809:
goto tmp_936808;
tmp_936808:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_936811:
}
reg_t genfunc_tmp_936777 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_936774();
goto next_tmp_936485;
next_tmp_936485:
goto tmp_936484;
tmp_936484:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_936776:
return tmp_731898;
}
reg_t genfunc_tmp_936774 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_936683();
goto next_tmp_936771;
next_tmp_936771:
goto tmp_936770;
tmp_936770:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_936773:
return tmp_731089;
}
reg_t genfunc_tmp_936739 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_936683();
goto next_tmp_936562;
next_tmp_936562:
goto tmp_936561;
tmp_936561:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_936738:
return tmp_731906;
}
reg_t genfunc_tmp_936683 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_936650 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_936650 >> 8) == 0)
field_imm = tmp_936650;
else goto fail_tmp_936649;
}
/* commit */
{
tmp_731858 = genfunc_tmp_936594();
goto next_tmp_936652;
next_tmp_936652:
goto tmp_936651;
tmp_936651:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_936682;
fail_tmp_936649:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_936674 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_936674))
field_imm = inv_maskmask(8, tmp_936674);
else goto fail_tmp_936673;
}
/* commit */
{
tmp_731075 = genfunc_tmp_936594();
goto next_tmp_936676;
next_tmp_936676:
goto tmp_936675;
tmp_936675:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_936682;
fail_tmp_936673:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_936594();
goto next_tmp_936680;
next_tmp_936680:
goto tmp_936679;
tmp_936679:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_936682:
return tmp_731382;
}
reg_t genfunc_tmp_936647 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_936616 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_936616 >> 8) == 0)
field_imm = tmp_936616;
else goto fail_tmp_936615;
}
/* commit */
{
tmp_731858 = genfunc_tmp_936594();
goto next_tmp_936618;
next_tmp_936618:
goto tmp_936617;
tmp_936617:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_936646;
fail_tmp_936615:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_936638 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_936638))
field_imm = inv_maskmask(8, tmp_936638);
else goto fail_tmp_936637;
}
/* commit */
{
tmp_731075 = genfunc_tmp_936594();
goto next_tmp_936640;
next_tmp_936640:
goto tmp_936639;
tmp_936639:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_936646;
fail_tmp_936637:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_936594();
goto next_tmp_936644;
next_tmp_936644:
goto tmp_936643;
tmp_936643:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_936646:
return tmp_731862;
}
reg_t genfunc_tmp_936594 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_936591;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + base);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_936593;
fail_tmp_936591:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_936592;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + base);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_936593;
fail_tmp_936592:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731900 = ref_gpr_reg_for_reading(0 + base);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_936593:
return tmp_731876;
}
void genfunc_tmp_936460 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_936422();
goto next_tmp_936457;
next_tmp_936457:
goto tmp_936456;
tmp_936456:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_936459:
}
reg_t genfunc_tmp_936425 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_936422();
goto next_tmp_936124;
next_tmp_936124:
goto tmp_936123;
tmp_936123:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_936424:
return tmp_731898;
}
reg_t genfunc_tmp_936422 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_936331();
goto next_tmp_936419;
next_tmp_936419:
goto tmp_936418;
tmp_936418:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_936421:
return tmp_731089;
}
reg_t genfunc_tmp_936387 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_936331();
goto next_tmp_936201;
next_tmp_936201:
goto tmp_936200;
tmp_936200:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_936386:
return tmp_731906;
}
reg_t genfunc_tmp_936331 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_936298 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_936298 >> 8) == 0)
field_imm = tmp_936298;
else goto fail_tmp_936297;
}
/* commit */
{
tmp_731858 = genfunc_tmp_936242();
goto next_tmp_936300;
next_tmp_936300:
goto tmp_936299;
tmp_936299:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_936330;
fail_tmp_936297:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_936322 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_936322))
field_imm = inv_maskmask(8, tmp_936322);
else goto fail_tmp_936321;
}
/* commit */
{
tmp_731075 = genfunc_tmp_936242();
goto next_tmp_936324;
next_tmp_936324:
goto tmp_936323;
tmp_936323:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_936330;
fail_tmp_936321:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_936242();
goto next_tmp_936328;
next_tmp_936328:
goto tmp_936327;
tmp_936327:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_936330:
return tmp_731382;
}
reg_t genfunc_tmp_936295 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_936264 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_936264 >> 8) == 0)
field_imm = tmp_936264;
else goto fail_tmp_936263;
}
/* commit */
{
tmp_731858 = genfunc_tmp_936242();
goto next_tmp_936266;
next_tmp_936266:
goto tmp_936265;
tmp_936265:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_936294;
fail_tmp_936263:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_936286 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_936286))
field_imm = inv_maskmask(8, tmp_936286);
else goto fail_tmp_936285;
}
/* commit */
{
tmp_731075 = genfunc_tmp_936242();
goto next_tmp_936288;
next_tmp_936288:
goto tmp_936287;
tmp_936287:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_936294;
fail_tmp_936285:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_936242();
goto next_tmp_936292;
next_tmp_936292:
goto tmp_936291;
tmp_936291:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_936294:
return tmp_731862;
}
reg_t genfunc_tmp_936242 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_936233;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_933911();
goto next_tmp_936235;
next_tmp_936235:
goto tmp_936234;
tmp_936234:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_936241;
fail_tmp_936233:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_936237;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_933911();
goto next_tmp_936239;
next_tmp_936239:
goto tmp_936238;
tmp_936238:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_936241;
fail_tmp_936237:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_933911();
goto next_tmp_936217;
next_tmp_936217:
goto tmp_936216;
tmp_936216:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_936241:
return tmp_731876;
}
void genfunc_tmp_936099 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_936061();
goto next_tmp_936096;
next_tmp_936096:
goto tmp_936095;
tmp_936095:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_936098:
}
reg_t genfunc_tmp_936064 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_936061();
goto next_tmp_935763;
next_tmp_935763:
goto tmp_935762;
tmp_935762:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_936063:
return tmp_731898;
}
reg_t genfunc_tmp_936061 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_935970();
goto next_tmp_936058;
next_tmp_936058:
goto tmp_936057;
tmp_936057:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_936060:
return tmp_731089;
}
reg_t genfunc_tmp_936026 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_935970();
goto next_tmp_935840;
next_tmp_935840:
goto tmp_935839;
tmp_935839:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_936025:
return tmp_731906;
}
reg_t genfunc_tmp_935970 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_935937 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_935937 >> 8) == 0)
field_imm = tmp_935937;
else goto fail_tmp_935936;
}
/* commit */
{
tmp_731858 = genfunc_tmp_935881();
goto next_tmp_935939;
next_tmp_935939:
goto tmp_935938;
tmp_935938:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_935969;
fail_tmp_935936:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_935961 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_935961))
field_imm = inv_maskmask(8, tmp_935961);
else goto fail_tmp_935960;
}
/* commit */
{
tmp_731075 = genfunc_tmp_935881();
goto next_tmp_935963;
next_tmp_935963:
goto tmp_935962;
tmp_935962:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_935969;
fail_tmp_935960:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_935881();
goto next_tmp_935967;
next_tmp_935967:
goto tmp_935966;
tmp_935966:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_935969:
return tmp_731382;
}
reg_t genfunc_tmp_935934 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_935903 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_935903 >> 8) == 0)
field_imm = tmp_935903;
else goto fail_tmp_935902;
}
/* commit */
{
tmp_731858 = genfunc_tmp_935881();
goto next_tmp_935905;
next_tmp_935905:
goto tmp_935904;
tmp_935904:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_935933;
fail_tmp_935902:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_935925 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_935925))
field_imm = inv_maskmask(8, tmp_935925);
else goto fail_tmp_935924;
}
/* commit */
{
tmp_731075 = genfunc_tmp_935881();
goto next_tmp_935927;
next_tmp_935927:
goto tmp_935926;
tmp_935926:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_935933;
fail_tmp_935924:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_935881();
goto next_tmp_935931;
next_tmp_935931:
goto tmp_935930;
tmp_935930:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_935933:
return tmp_731862;
}
reg_t genfunc_tmp_935881 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_935872;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_933526();
goto next_tmp_935874;
next_tmp_935874:
goto tmp_935873;
tmp_935873:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_935880;
fail_tmp_935872:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_935876;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_933526();
goto next_tmp_935878;
next_tmp_935878:
goto tmp_935877;
tmp_935877:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_935880;
fail_tmp_935876:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_933526();
goto next_tmp_935856;
next_tmp_935856:
goto tmp_935855;
tmp_935855:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_935880:
return tmp_731876;
}
void genfunc_tmp_935738 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_935700();
goto next_tmp_935735;
next_tmp_935735:
goto tmp_935734;
tmp_935734:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_935737:
}
reg_t genfunc_tmp_935703 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_935700();
goto next_tmp_935406;
next_tmp_935406:
goto tmp_935405;
tmp_935405:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_935702:
return tmp_731898;
}
reg_t genfunc_tmp_935700 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_935609();
goto next_tmp_935697;
next_tmp_935697:
goto tmp_935696;
tmp_935696:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_935699:
return tmp_731089;
}
reg_t genfunc_tmp_935665 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_935609();
goto next_tmp_935483;
next_tmp_935483:
goto tmp_935482;
tmp_935482:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_935664:
return tmp_731906;
}
reg_t genfunc_tmp_935609 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_935576 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_935576 >> 8) == 0)
field_imm = tmp_935576;
else goto fail_tmp_935575;
}
/* commit */
{
tmp_731858 = genfunc_tmp_935520();
goto next_tmp_935578;
next_tmp_935578:
goto tmp_935577;
tmp_935577:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_935608;
fail_tmp_935575:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_935600 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_935600))
field_imm = inv_maskmask(8, tmp_935600);
else goto fail_tmp_935599;
}
/* commit */
{
tmp_731075 = genfunc_tmp_935520();
goto next_tmp_935602;
next_tmp_935602:
goto tmp_935601;
tmp_935601:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_935608;
fail_tmp_935599:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_935520();
goto next_tmp_935606;
next_tmp_935606:
goto tmp_935605;
tmp_935605:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_935608:
return tmp_731382;
}
reg_t genfunc_tmp_935573 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_935542 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_935542 >> 8) == 0)
field_imm = tmp_935542;
else goto fail_tmp_935541;
}
/* commit */
{
tmp_731858 = genfunc_tmp_935520();
goto next_tmp_935544;
next_tmp_935544:
goto tmp_935543;
tmp_935543:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_935572;
fail_tmp_935541:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_935564 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_935564))
field_imm = inv_maskmask(8, tmp_935564);
else goto fail_tmp_935563;
}
/* commit */
{
tmp_731075 = genfunc_tmp_935520();
goto next_tmp_935566;
next_tmp_935566:
goto tmp_935565;
tmp_935565:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_935572;
fail_tmp_935563:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_935520();
goto next_tmp_935570;
next_tmp_935570:
goto tmp_935569;
tmp_935569:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_935572:
return tmp_731862;
}
reg_t genfunc_tmp_935520 (void) {
reg_t tmp_731876;
/* ADDQ_IMM */
{
word_5 tmp_731893;
word_5 field_rc;
word_5 tmp_731894;
word_5 field_ra;
word_64 tmp_731896;
word_8 field_imm;
tmp_731896 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_935505 = tmp_731896;
if ((tmp_935505 >> 8) == 0)
field_imm = tmp_935505;
else goto fail_tmp_935504;
}
/* commit */
tmp_731894 = ref_gpr_reg_for_reading(0 + rm);
tmp_731893 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731893;
field_ra = tmp_731894;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731894);
/* can fail: T   num insns: 1 */
}
goto done_tmp_935519;
fail_tmp_935504:
/* LDA */
{
word_5 tmp_731397;
word_5 field_ra;
word_5 tmp_731398;
word_5 field_rb;
word_64 tmp_731400;
word_16 field_memory_disp;
tmp_731400 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_935513 = tmp_731400;
if ((tmp_935513 >> 16) == 0xFFFFFFFFFFFF || (tmp_935513 >> 16) == 0)
field_memory_disp = (tmp_935513 & 0xFFFF);
else goto fail_tmp_935512;
}
/* commit */
tmp_731398 = ref_gpr_reg_for_reading(0 + rm);
tmp_731397 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731397;
field_rb = tmp_731398;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731398);
/* can fail: T   num insns: 1 */
}
goto done_tmp_935519;
fail_tmp_935512:
/* LDAH */
{
word_5 tmp_731393;
word_5 field_ra;
word_5 tmp_731394;
word_5 field_rb;
word_64 tmp_731396;
word_16 field_memory_disp;
tmp_731396 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_935517 = tmp_731396;
if ((tmp_935517 & 0xFFFF) == 0)
{
word_64 tmp_935518 = (tmp_935517 >> 16);
if ((tmp_935518 >> 16) == 0xFFFFFFFFFFFF || (tmp_935518 >> 16) == 0)
field_memory_disp = (tmp_935518 & 0xFFFF);
else goto fail_tmp_935516;
}
else goto fail_tmp_935516;
}
/* commit */
tmp_731394 = ref_gpr_reg_for_reading(0 + rm);
tmp_731393 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731393;
field_rb = tmp_731394;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731394);
/* can fail: T   num insns: 1 */
}
goto done_tmp_935519;
fail_tmp_935516:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731900 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731900, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_935519:
return tmp_731876;
}
void genfunc_tmp_935378 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_935340();
goto next_tmp_935375;
next_tmp_935375:
goto tmp_935374;
tmp_935374:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 3 */
}
done_tmp_935377:
}
reg_t genfunc_tmp_935343 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_935340();
goto next_tmp_935174;
next_tmp_935174:
goto tmp_935173;
tmp_935173:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 3 */
}
done_tmp_935342:
return tmp_731898;
}
reg_t genfunc_tmp_935340 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_731383;
word_16 field_memory_disp;
tmp_731383 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_935338 = tmp_731383;
if ((tmp_935338 >> 16) == 0xFFFFFFFFFFFF || (tmp_935338 >> 16) == 0)
field_memory_disp = (tmp_935338 & 0xFFFF);
else goto fail_tmp_935337;
}
/* commit */
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_935339;
fail_tmp_935337:
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
tmp_731382 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731382, ((word_64)disp32));
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_935339:
return tmp_731089;
}
reg_t genfunc_tmp_935306 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_731383;
word_16 field_memory_disp;
tmp_731383 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_935251 = tmp_731383;
if ((tmp_935251 >> 16) == 0xFFFFFFFFFFFF || (tmp_935251 >> 16) == 0)
field_memory_disp = (tmp_935251 & 0xFFFF);
else goto fail_tmp_935250;
}
/* commit */
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_935305;
fail_tmp_935250:
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
tmp_731382 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731382, ((word_64)disp32));
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_935305:
return tmp_731906;
}
void genfunc_tmp_935149 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_935111();
goto next_tmp_935146;
next_tmp_935146:
goto tmp_935145;
tmp_935145:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_935148:
}
reg_t genfunc_tmp_935114 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_935111();
goto next_tmp_934813;
next_tmp_934813:
goto tmp_934812;
tmp_934812:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_935113:
return tmp_731898;
}
reg_t genfunc_tmp_935111 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_935020();
goto next_tmp_935108;
next_tmp_935108:
goto tmp_935107;
tmp_935107:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_935110:
return tmp_731089;
}
reg_t genfunc_tmp_935076 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_935020();
goto next_tmp_934890;
next_tmp_934890:
goto tmp_934889;
tmp_934889:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_935075:
return tmp_731906;
}
reg_t genfunc_tmp_935020 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_934987 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_934987 >> 8) == 0)
field_imm = tmp_934987;
else goto fail_tmp_934986;
}
/* commit */
{
tmp_731858 = genfunc_tmp_934931();
goto next_tmp_934989;
next_tmp_934989:
goto tmp_934988;
tmp_934988:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_935019;
fail_tmp_934986:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_935011 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_935011))
field_imm = inv_maskmask(8, tmp_935011);
else goto fail_tmp_935010;
}
/* commit */
{
tmp_731075 = genfunc_tmp_934931();
goto next_tmp_935013;
next_tmp_935013:
goto tmp_935012;
tmp_935012:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_935019;
fail_tmp_935010:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_934931();
goto next_tmp_935017;
next_tmp_935017:
goto tmp_935016;
tmp_935016:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_935019:
return tmp_731382;
}
reg_t genfunc_tmp_934984 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_934953 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_934953 >> 8) == 0)
field_imm = tmp_934953;
else goto fail_tmp_934952;
}
/* commit */
{
tmp_731858 = genfunc_tmp_934931();
goto next_tmp_934955;
next_tmp_934955:
goto tmp_934954;
tmp_934954:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_934983;
fail_tmp_934952:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_934975 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_934975))
field_imm = inv_maskmask(8, tmp_934975);
else goto fail_tmp_934974;
}
/* commit */
{
tmp_731075 = genfunc_tmp_934931();
goto next_tmp_934977;
next_tmp_934977:
goto tmp_934976;
tmp_934976:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_934983;
fail_tmp_934974:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_934931();
goto next_tmp_934981;
next_tmp_934981:
goto tmp_934980;
tmp_934980:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_934983:
return tmp_731862;
}
reg_t genfunc_tmp_934931 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_934922;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_933894();
goto next_tmp_934924;
next_tmp_934924:
goto tmp_934923;
tmp_934923:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_934930;
fail_tmp_934922:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_934926;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_933894();
goto next_tmp_934928;
next_tmp_934928:
goto tmp_934927;
tmp_934927:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_934930;
fail_tmp_934926:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_933894();
goto next_tmp_934906;
next_tmp_934906:
goto tmp_934905;
tmp_934905:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_934930:
return tmp_731876;
}
void genfunc_tmp_934788 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_934750();
goto next_tmp_934785;
next_tmp_934785:
goto tmp_934784;
tmp_934784:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_934787:
}
reg_t genfunc_tmp_934753 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_934750();
goto next_tmp_934461;
next_tmp_934461:
goto tmp_934460;
tmp_934460:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_934752:
return tmp_731898;
}
reg_t genfunc_tmp_934750 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_934659();
goto next_tmp_934747;
next_tmp_934747:
goto tmp_934746;
tmp_934746:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_934749:
return tmp_731089;
}
reg_t genfunc_tmp_934715 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_934659();
goto next_tmp_934538;
next_tmp_934538:
goto tmp_934537;
tmp_934537:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_934714:
return tmp_731906;
}
reg_t genfunc_tmp_934659 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_934626 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_934626 >> 8) == 0)
field_imm = tmp_934626;
else goto fail_tmp_934625;
}
/* commit */
{
tmp_731858 = genfunc_tmp_934570();
goto next_tmp_934628;
next_tmp_934628:
goto tmp_934627;
tmp_934627:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_934658;
fail_tmp_934625:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_934650 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_934650))
field_imm = inv_maskmask(8, tmp_934650);
else goto fail_tmp_934649;
}
/* commit */
{
tmp_731075 = genfunc_tmp_934570();
goto next_tmp_934652;
next_tmp_934652:
goto tmp_934651;
tmp_934651:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_934658;
fail_tmp_934649:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_934570();
goto next_tmp_934656;
next_tmp_934656:
goto tmp_934655;
tmp_934655:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_934658:
return tmp_731382;
}
reg_t genfunc_tmp_934623 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_934592 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_934592 >> 8) == 0)
field_imm = tmp_934592;
else goto fail_tmp_934591;
}
/* commit */
{
tmp_731858 = genfunc_tmp_934570();
goto next_tmp_934594;
next_tmp_934594:
goto tmp_934593;
tmp_934593:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_934622;
fail_tmp_934591:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_934614 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_934614))
field_imm = inv_maskmask(8, tmp_934614);
else goto fail_tmp_934613;
}
/* commit */
{
tmp_731075 = genfunc_tmp_934570();
goto next_tmp_934616;
next_tmp_934616:
goto tmp_934615;
tmp_934615:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_934622;
fail_tmp_934613:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_934570();
goto next_tmp_934620;
next_tmp_934620:
goto tmp_934619;
tmp_934619:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_934622:
return tmp_731862;
}
reg_t genfunc_tmp_934570 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_934567;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + index);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_934569;
fail_tmp_934567:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_934568;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + index);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_934569;
fail_tmp_934568:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_934569:
return tmp_731876;
}
void genfunc_tmp_934436 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_934398();
goto next_tmp_934433;
next_tmp_934433:
goto tmp_934432;
tmp_934432:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 3 */
}
done_tmp_934435:
}
reg_t genfunc_tmp_934401 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_934398();
goto next_tmp_934154;
next_tmp_934154:
goto tmp_934153;
tmp_934153:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 3 */
}
done_tmp_934400:
return tmp_731898;
}
reg_t genfunc_tmp_934398 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_934307();
goto next_tmp_934395;
next_tmp_934395:
goto tmp_934394;
tmp_934394:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_934397:
return tmp_731089;
}
reg_t genfunc_tmp_934363 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_934307();
goto next_tmp_934231;
next_tmp_934231:
goto tmp_934230;
tmp_934230:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_934362:
return tmp_731906;
}
reg_t genfunc_tmp_934307 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_934283 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_934283 >> 8) == 0)
field_imm = tmp_934283;
else goto fail_tmp_934282;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + base);
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_934306;
fail_tmp_934282:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_934304 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_934304))
field_imm = inv_maskmask(8, tmp_934304);
else goto fail_tmp_934303;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + base);
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_934306;
fail_tmp_934303:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + base);
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_934306:
return tmp_731382;
}
reg_t genfunc_tmp_934280 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_934258 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_934258 >> 8) == 0)
field_imm = tmp_934258;
else goto fail_tmp_934257;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + base);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_934279;
fail_tmp_934257:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_934277 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_934277))
field_imm = inv_maskmask(8, tmp_934277);
else goto fail_tmp_934276;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + base);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_934279;
fail_tmp_934276:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + base);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_934279:
return tmp_731862;
}
void genfunc_tmp_934129 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_934091();
goto next_tmp_934126;
next_tmp_934126:
goto tmp_934125;
tmp_934125:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_934128:
}
reg_t genfunc_tmp_934094 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_934091();
goto next_tmp_933769;
next_tmp_933769:
goto tmp_933768;
tmp_933768:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_934093:
return tmp_731898;
}
reg_t genfunc_tmp_934091 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_934000();
goto next_tmp_934088;
next_tmp_934088:
goto tmp_934087;
tmp_934087:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_934090:
return tmp_731089;
}
reg_t genfunc_tmp_934056 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_934000();
goto next_tmp_933846;
next_tmp_933846:
goto tmp_933845;
tmp_933845:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_934055:
return tmp_731906;
}
reg_t genfunc_tmp_934000 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_933967 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_933967 >> 8) == 0)
field_imm = tmp_933967;
else goto fail_tmp_933966;
}
/* commit */
{
tmp_731858 = genfunc_tmp_933911();
goto next_tmp_933969;
next_tmp_933969:
goto tmp_933968;
tmp_933968:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_933999;
fail_tmp_933966:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_933991 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_933991))
field_imm = inv_maskmask(8, tmp_933991);
else goto fail_tmp_933990;
}
/* commit */
{
tmp_731075 = genfunc_tmp_933911();
goto next_tmp_933993;
next_tmp_933993:
goto tmp_933992;
tmp_933992:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_933999;
fail_tmp_933990:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_933911();
goto next_tmp_933997;
next_tmp_933997:
goto tmp_933996;
tmp_933996:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_933999:
return tmp_731382;
}
reg_t genfunc_tmp_933964 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_933933 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_933933 >> 8) == 0)
field_imm = tmp_933933;
else goto fail_tmp_933932;
}
/* commit */
{
tmp_731858 = genfunc_tmp_933911();
goto next_tmp_933935;
next_tmp_933935:
goto tmp_933934;
tmp_933934:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_933963;
fail_tmp_933932:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_933955 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_933955))
field_imm = inv_maskmask(8, tmp_933955);
else goto fail_tmp_933954;
}
/* commit */
{
tmp_731075 = genfunc_tmp_933911();
goto next_tmp_933957;
next_tmp_933957:
goto tmp_933956;
tmp_933956:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_933963;
fail_tmp_933954:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_933911();
goto next_tmp_933961;
next_tmp_933961:
goto tmp_933960;
tmp_933960:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_933963:
return tmp_731862;
}
reg_t genfunc_tmp_933911 (void) {
reg_t tmp_731876;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + base);
{
tmp_731900 = genfunc_tmp_933894();
goto next_tmp_933862;
next_tmp_933862:
goto tmp_933861;
tmp_933861:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_933910:
return tmp_731876;
}
reg_t genfunc_tmp_933894 (void) {
reg_t tmp_731900;
/* EXTQH */
{
word_5 tmp_731618;
word_5 field_rc;
word_5 tmp_731619;
word_5 field_ra;
word_5 field_rb;
if (64 != ((word_64)scale)) goto fail_tmp_933875;
field_rb = 31;
/* commit */
tmp_731619 = ref_gpr_reg_for_reading(0 + index);
tmp_731618 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731618;
field_ra = tmp_731619;
emit(COMPOSE_EXTQH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731619);
/* can fail: T   num insns: 1 */
}
goto done_tmp_933893;
fail_tmp_933875:
/* EXTQH_IMM */
{
word_5 tmp_731614;
word_5 field_rc;
word_5 tmp_731615;
word_5 field_ra;
word_64 tmp_731617;
word_8 field_imm;
tmp_731617 = ((word_64)scale);
{
word_64 tmp_933877 = ((64 - tmp_731617) & 0xFFFFFFFFFFFFFFFF);
if (tmp_933877 % 8 == 0)
{
word_64 tmp_933878 = (tmp_933877 / 8);
if ((tmp_933878 & 7) == tmp_933878)
{
word_64 tmp_933879 = tmp_933878;
if ((tmp_933879 >> 8) == 0)
field_imm = tmp_933879;
else goto fail_tmp_933876;
}
else goto fail_tmp_933876;
}
else goto fail_tmp_933876;
}
/* commit */
tmp_731615 = ref_gpr_reg_for_reading(0 + index);
tmp_731614 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731614;
field_ra = tmp_731615;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731615);
/* can fail: T   num insns: 1 */
}
goto done_tmp_933893;
fail_tmp_933876:
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 tmp_731241;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_933885;
field_rb = 31;
/* commit */
tmp_731241 = ref_gpr_reg_for_reading(0 + index);
tmp_731240 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_ra = tmp_731241;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731241);
/* can fail: T   num insns: 1 */
}
goto done_tmp_933893;
fail_tmp_933885:
/* S4ADDQ_IMM */
{
word_5 tmp_731236;
word_5 field_rc;
word_5 tmp_731237;
word_5 field_ra;
word_64 tmp_731239;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_933886;
tmp_731239 = 0;
field_imm = 0;
/* commit */
tmp_731237 = ref_gpr_reg_for_reading(0 + index);
tmp_731236 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731236;
field_ra = tmp_731237;
emit(COMPOSE_S4ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731237);
/* can fail: T   num insns: 1 */
}
goto done_tmp_933893;
fail_tmp_933886:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 tmp_731209;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_933888;
field_rb = 31;
/* commit */
tmp_731209 = ref_gpr_reg_for_reading(0 + index);
tmp_731208 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_ra = tmp_731209;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731209);
/* can fail: T   num insns: 1 */
}
goto done_tmp_933893;
fail_tmp_933888:
/* S8ADDQ_IMM */
{
word_5 tmp_731204;
word_5 field_rc;
word_5 tmp_731205;
word_5 field_ra;
word_64 tmp_731207;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_933889;
tmp_731207 = 0;
field_imm = 0;
/* commit */
tmp_731205 = ref_gpr_reg_for_reading(0 + index);
tmp_731204 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731204;
field_ra = tmp_731205;
emit(COMPOSE_S8ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731205);
/* can fail: T   num insns: 1 */
}
goto done_tmp_933893;
fail_tmp_933889:
/* SLL */
{
word_5 tmp_731176;
word_5 field_rc;
word_5 tmp_731177;
word_5 field_ra;
word_5 field_rb;
if (0 != ((word_64)scale)) goto fail_tmp_933890;
field_rb = 31;
/* commit */
tmp_731177 = ref_gpr_reg_for_reading(0 + index);
tmp_731176 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731176;
field_ra = tmp_731177;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731177);
/* can fail: T   num insns: 1 */
}
goto done_tmp_933893;
fail_tmp_933890:
/* SLL_IMM */
{
word_5 tmp_731172;
word_5 field_rc;
word_5 tmp_731173;
word_5 field_ra;
word_64 tmp_731175;
word_8 field_imm;
tmp_731175 = ((word_64)scale);
field_imm = tmp_731175;
/* commit */
tmp_731173 = ref_gpr_reg_for_reading(0 + index);
tmp_731172 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731172;
field_ra = tmp_731173;
emit(COMPOSE_SLL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731173);
/* can fail: NIL   num insns: 1 */
}
done_tmp_933893:
return tmp_731900;
}
void genfunc_tmp_933744 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_933706();
goto next_tmp_933741;
next_tmp_933741:
goto tmp_933740;
tmp_933740:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 4 */
}
done_tmp_933743:
}
reg_t genfunc_tmp_933709 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_933706();
goto next_tmp_933419;
next_tmp_933419:
goto tmp_933418;
tmp_933418:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 4 */
}
done_tmp_933708:
return tmp_731898;
}
reg_t genfunc_tmp_933706 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_933615();
goto next_tmp_933703;
next_tmp_933703:
goto tmp_933702;
tmp_933702:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 3 */
}
done_tmp_933705:
return tmp_731089;
}
reg_t genfunc_tmp_933671 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_933615();
goto next_tmp_933496;
next_tmp_933496:
goto tmp_933495;
tmp_933495:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 3 */
}
done_tmp_933670:
return tmp_731906;
}
reg_t genfunc_tmp_933615 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_933582 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_933582 >> 8) == 0)
field_imm = tmp_933582;
else goto fail_tmp_933581;
}
/* commit */
{
tmp_731858 = genfunc_tmp_933526();
goto next_tmp_933584;
next_tmp_933584:
goto tmp_933583;
tmp_933583:
}
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_933614;
fail_tmp_933581:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_933606 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_933606))
field_imm = inv_maskmask(8, tmp_933606);
else goto fail_tmp_933605;
}
/* commit */
{
tmp_731075 = genfunc_tmp_933526();
goto next_tmp_933608;
next_tmp_933608:
goto tmp_933607;
tmp_933607:
}
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_933614;
fail_tmp_933605:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_933526();
goto next_tmp_933612;
next_tmp_933612:
goto tmp_933611;
tmp_933611:
}
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_933614:
return tmp_731382;
}
reg_t genfunc_tmp_933579 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_933548 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_933548 >> 8) == 0)
field_imm = tmp_933548;
else goto fail_tmp_933547;
}
/* commit */
{
tmp_731858 = genfunc_tmp_933526();
goto next_tmp_933550;
next_tmp_933550:
goto tmp_933549;
tmp_933549:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_933578;
fail_tmp_933547:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_933570 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_933570))
field_imm = inv_maskmask(8, tmp_933570);
else goto fail_tmp_933569;
}
/* commit */
{
tmp_731075 = genfunc_tmp_933526();
goto next_tmp_933572;
next_tmp_933572:
goto tmp_933571;
tmp_933571:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_933578;
fail_tmp_933569:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_933526();
goto next_tmp_933576;
next_tmp_933576:
goto tmp_933575;
tmp_933575:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_933578:
return tmp_731862;
}
reg_t genfunc_tmp_933526 (void) {
reg_t tmp_731876;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + base);
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_933525:
return tmp_731876;
}
void genfunc_tmp_933394 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_933356();
goto next_tmp_933391;
next_tmp_933391:
goto tmp_933390;
tmp_933390:
}
tmp_731086 = ref_gpr_reg_for_writing(0 + reg);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 3 */
}
done_tmp_933393:
}
reg_t genfunc_tmp_933359 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + reg);
{
tmp_731089 = genfunc_tmp_933356();
goto next_tmp_933112;
next_tmp_933112:
goto tmp_933111;
tmp_933111:
}
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 3 */
}
done_tmp_933358:
return tmp_731898;
}
reg_t genfunc_tmp_933356 (void) {
reg_t tmp_731089;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_933265();
goto next_tmp_933353;
next_tmp_933353:
goto tmp_933352;
tmp_933352:
}
tmp_731381 = tmp_731089 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_933355:
return tmp_731089;
}
reg_t genfunc_tmp_933321 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_933265();
goto next_tmp_933189;
next_tmp_933189:
goto tmp_933188;
tmp_933188:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_933320:
return tmp_731906;
}
reg_t genfunc_tmp_933265 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_933241 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_933241 >> 8) == 0)
field_imm = tmp_933241;
else goto fail_tmp_933240;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + rm);
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_933264;
fail_tmp_933240:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_933262 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_933262))
field_imm = inv_maskmask(8, tmp_933262);
else goto fail_tmp_933261;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + rm);
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_933264;
fail_tmp_933261:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + rm);
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_933264:
return tmp_731382;
}
reg_t genfunc_tmp_933238 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_933216 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_933216 >> 8) == 0)
field_imm = tmp_933216;
else goto fail_tmp_933215;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + rm);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_933237;
fail_tmp_933215:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_933235 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_933235))
field_imm = inv_maskmask(8, tmp_933235);
else goto fail_tmp_933234;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + rm);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_933237;
fail_tmp_933234:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + rm);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_933237:
return tmp_731862;
}
