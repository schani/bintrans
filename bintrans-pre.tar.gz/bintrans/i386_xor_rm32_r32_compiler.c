#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compiler_tmp_933085 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_933076 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933081 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_933072 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_933022 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933071 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933027 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_933030 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933031 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933034 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933064 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933068 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933065 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933056 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933061 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933057 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933060 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933035 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933038 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933048 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933055 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933049 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933054 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933052 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933041 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933044 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933046 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933045 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933042 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933036 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933018 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_933014 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_933013 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_933085 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 6 6 T)
*/
{
{
reg_t tmp_933087, tmp_933088, tmp_933086;
rhs_func(&tmp_933087, -1, env);
emit(COMPOSE_SLL_IMM(tmp_933087, 63, tmp_933087));
emit(COMPOSE_SRL_IMM(tmp_933087, 57, tmp_933087));
tmp_933088 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_933088, -1);
emit(COMPOSE_SLL_IMM(tmp_933088, 63, tmp_933088));
emit(COMPOSE_SRL_IMM(tmp_933088, 57, tmp_933088));
tmp_933086 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_933086, tmp_933088, tmp_933086));
unref_integer_reg(tmp_933088);
emit(COMPOSE_BIS(tmp_933086, tmp_933087, tmp_933086));
unref_integer_reg(tmp_933087);
unref_integer_reg(tmp_933086);
}
}

void compiler_tmp_933076 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (=
  (CASE
   ((0 1 2)
    (MEM
     (CASE
      ((0)
       (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
        ((4)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))
        ((5) (FIELD DISP32 NIL NIL))))
      ((1)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
        ((4)
         (+ (SEX (FIELD DISP8 NIL NIL))
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0))))))))
      ((2)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
        ((4)
         (+ (FIELD DISP32 NIL NIL)
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0)))))))))))
   ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
  (INTEGER 0))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_933078 = alloc_label(), tmp_933079 = alloc_label(), tmp_933080 = alloc_label();
reg_t tmp_933077;
compiler_tmp_933081(tmp_933078, tmp_933079, env);

tmp_933077 = ref_integer_reg_for_writing(-1);
emit_label(tmp_933078);
push_alloc();
compiler_tmp_933071(&tmp_933077, tmp_933077 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_933080);
emit_label(tmp_933079);
push_alloc();
compiler_tmp_933013(&tmp_933077, tmp_933077 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_933080);
free_label(tmp_933078);
free_label(tmp_933079);
free_label(tmp_933080);
if (foreign_target == -1)
*target = tmp_933077;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_933077, *target));
unref_integer_reg(tmp_933077);
}

}
}

void compiler_tmp_933081 (label_t true_label, label_t false_label, void **env)
/*
(=
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (INTEGER 0))
*/
{
{
reg_t tmp_933082, tmp_933083, tmp_933084;
compiler_tmp_933030(&tmp_933082, -1, env);
compiler_tmp_933055(&tmp_933083, -1, env);
tmp_933084 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_CMPEQ(tmp_933082, tmp_933083, tmp_933084));
unref_integer_reg(tmp_933082);
unref_integer_reg(tmp_933083);
emit_branch(COMPOSE_BEQ(tmp_933084, 0), false_label);
unref_integer_reg(tmp_933084);
emit_branch(COMPOSE_BR(31, 0), true_label);
}
}

void compiler_tmp_933072 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 7 7 T)
*/
{
{
reg_t tmp_933074, tmp_933075, tmp_933073;
rhs_func(&tmp_933074, -1, env);
emit(COMPOSE_SLL_IMM(tmp_933074, 63, tmp_933074));
emit(COMPOSE_SRL_IMM(tmp_933074, 56, tmp_933074));
tmp_933075 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_933075, -1);
emit(COMPOSE_SLL_IMM(tmp_933075, 63, tmp_933075));
emit(COMPOSE_SRL_IMM(tmp_933075, 56, tmp_933075));
tmp_933073 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_933073, tmp_933075, tmp_933073));
unref_integer_reg(tmp_933075);
emit(COMPOSE_BIS(tmp_933073, tmp_933074, tmp_933073));
unref_integer_reg(tmp_933074);
unref_integer_reg(tmp_933073);
}
}

void compiler_tmp_933022 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (BIT-SET-P
  (CASE
   ((0 1 2)
    (MEM
     (CASE
      ((0)
       (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
        ((4)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))
        ((5) (FIELD DISP32 NIL NIL))))
      ((1)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
        ((4)
         (+ (SEX (FIELD DISP8 NIL NIL))
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0))))))))
      ((2)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
        ((4)
         (+ (FIELD DISP32 NIL NIL)
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0)))))))))))
   ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
  (- (INTEGER 32) (INTEGER 1)))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_933024 = alloc_label(), tmp_933025 = alloc_label(), tmp_933026 = alloc_label();
reg_t tmp_933023;
compiler_tmp_933027(tmp_933024, tmp_933025, env);

tmp_933023 = ref_integer_reg_for_writing(-1);
emit_label(tmp_933024);
push_alloc();
compiler_tmp_933071(&tmp_933023, tmp_933023 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_933026);
emit_label(tmp_933025);
push_alloc();
compiler_tmp_933013(&tmp_933023, tmp_933023 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_933026);
free_label(tmp_933024);
free_label(tmp_933025);
free_label(tmp_933026);
if (foreign_target == -1)
*target = tmp_933023;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_933023, *target));
unref_integer_reg(tmp_933023);
}

}
}

void compiler_tmp_933071 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 1)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 1);
}

void compiler_tmp_933027 (label_t true_label, label_t false_label, void **env)
/*
(BIT-SET-P
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (- (INTEGER 32) (INTEGER 1)))
*/
{
{
reg_t tmp_933028, tmp_933029;
compiler_tmp_933030(&tmp_933028, -1, env);
tmp_933029 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_SRL_IMM(tmp_933028, (32 - 1), tmp_933029));
unref_integer_reg(tmp_933028);
emit_branch(COMPOSE_BLBS(tmp_933029, 0), true_label);
unref_integer_reg(tmp_933029);
emit_branch(COMPOSE_BR(31, 0), false_label);
}
}

void compiler_tmp_933030 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2)
  (MEM
   (CASE
    ((0)
     (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
      ((4)
       (+
        (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
         ((5)
          (CASE ((0) (FIELD DISP32 NIL NIL))
           ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
        (CASE
         ((0 1 2 3 5 6 7)
          (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
           (ZEX (FIELD SCALE NIL NIL))))
         ((4) (INTEGER 0)))))
      ((5) (FIELD DISP32 NIL NIL))))
    ((1)
     (CASE
      ((0 1 2 3 5 6 7)
       (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
      ((4)
       (+ (SEX (FIELD DISP8 NIL NIL))
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0))))))))
    ((2)
     (CASE
      ((0 1 2 3 5 6 7)
       (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
      ((4)
       (+ (FIELD DISP32 NIL NIL)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))))))))
 ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
*/
{
switch (mod) {
case 0:
case 1:
case 2:
compiler_tmp_933031(&(*target), foreign_target, env);
break;
case 3:
compiler_tmp_933036(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_933031 (reg_t *target, int foreign_target, void **env)
/*
(MEM
 (CASE
  ((0)
   (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
    ((4)
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0)))))
    ((5) (FIELD DISP32 NIL NIL))))
  ((1)
   (CASE
    ((0 1 2 3 5 6 7)
     (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
    ((4)
     (+ (SEX (FIELD DISP8 NIL NIL))
      (+
       (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
        ((5)
         (CASE ((0) (FIELD DISP32 NIL NIL))
          ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
       (CASE
        ((0 1 2 3 5 6 7)
         (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
          (ZEX (FIELD SCALE NIL NIL))))
        ((4) (INTEGER 0))))))))
  ((2)
   (CASE
    ((0 1 2 3 5 6 7)
     (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
    ((4)
     (+ (FIELD DISP32 NIL NIL)
      (+
       (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
        ((5)
         (CASE ((0) (FIELD DISP32 NIL NIL))
          ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
       (CASE
        ((0 1 2 3 5 6 7)
         (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
          (ZEX (FIELD SCALE NIL NIL))))
        ((4) (INTEGER 0))))))))))
*/
{
{
reg_t tmp_933032, tmp_933033;
compiler_tmp_933034(&tmp_933032, -1, env);
#ifdef EMU_I386
tmp_933033 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ZAPNOT_IMM(tmp_933032, 15, tmp_933033));
unref_integer_reg(tmp_933032);
#else
tmp_933033 = tmp_933032;
#endif
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_mem_32(*target, tmp_933033);
unref_integer_reg(tmp_933033);
}
}

void compiler_tmp_933034 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0)
  (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
   ((4)
    (+
     (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
      ((5)
       (CASE ((0) (FIELD DISP32 NIL NIL))
        ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
     (CASE
      ((0 1 2 3 5 6 7)
       (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
        (ZEX (FIELD SCALE NIL NIL))))
      ((4) (INTEGER 0)))))
   ((5) (FIELD DISP32 NIL NIL))))
 ((1)
  (CASE
   ((0 1 2 3 5 6 7)
    (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
   ((4)
    (+ (SEX (FIELD DISP8 NIL NIL))
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0))))))))
 ((2)
  (CASE
   ((0 1 2 3 5 6 7)
    (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
   ((4)
    (+ (FIELD DISP32 NIL NIL)
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0)))))))))
*/
{
switch (mod) {
case 0:
compiler_tmp_933035(&(*target), foreign_target, env);
break;
case 1:
compiler_tmp_933056(&(*target), foreign_target, env);
break;
case 2:
compiler_tmp_933064(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_933064 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
 ((4)
  (+ (FIELD DISP32 NIL NIL)
   (+
    (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
     ((5)
      (CASE ((0) (FIELD DISP32 NIL NIL))
       ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
    (CASE
     ((0 1 2 3 5 6 7)
      (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
       (ZEX (FIELD SCALE NIL NIL))))
     ((4) (INTEGER 0)))))))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_933065(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_933068(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_933068 (reg_t *target, int foreign_target, void **env)
/*
(+ (FIELD DISP32 NIL NIL)
 (+
  (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
   ((5)
    (CASE ((0) (FIELD DISP32 NIL NIL))
     ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
  (CASE
   ((0 1 2 3 5 6 7)
    (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
     (ZEX (FIELD SCALE NIL NIL))))
   ((4) (INTEGER 0)))))
*/
{
{
reg_t tmp_933069, tmp_933070;
compiler_tmp_933045(&tmp_933069, -1, env);
compiler_tmp_933038(&tmp_933070, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_933069, tmp_933070, *target));
unref_integer_reg(tmp_933069);
unref_integer_reg(tmp_933070);
}
}

void compiler_tmp_933065 (reg_t *target, int foreign_target, void **env)
/*
(+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL))
*/
{
{
reg_t tmp_933066, tmp_933067;
compiler_tmp_933036(&tmp_933066, -1, env);
compiler_tmp_933045(&tmp_933067, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_933066, tmp_933067, *target));
unref_integer_reg(tmp_933066);
unref_integer_reg(tmp_933067);
}
}

void compiler_tmp_933056 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
 ((4)
  (+ (SEX (FIELD DISP8 NIL NIL))
   (+
    (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
     ((5)
      (CASE ((0) (FIELD DISP32 NIL NIL))
       ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
    (CASE
     ((0 1 2 3 5 6 7)
      (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
       (ZEX (FIELD SCALE NIL NIL))))
     ((4) (INTEGER 0)))))))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_933057(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_933061(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_933061 (reg_t *target, int foreign_target, void **env)
/*
(+ (SEX (FIELD DISP8 NIL NIL))
 (+
  (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
   ((5)
    (CASE ((0) (FIELD DISP32 NIL NIL))
     ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
  (CASE
   ((0 1 2 3 5 6 7)
    (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
     (ZEX (FIELD SCALE NIL NIL))))
   ((4) (INTEGER 0)))))
*/
{
{
reg_t tmp_933062, tmp_933063;
compiler_tmp_933060(&tmp_933062, -1, env);
compiler_tmp_933038(&tmp_933063, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_933062, tmp_933063, *target));
unref_integer_reg(tmp_933062);
unref_integer_reg(tmp_933063);
}
}

void compiler_tmp_933057 (reg_t *target, int foreign_target, void **env)
/*
(+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL)))
*/
{
{
reg_t tmp_933058, tmp_933059;
compiler_tmp_933036(&tmp_933058, -1, env);
compiler_tmp_933060(&tmp_933059, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_933058, tmp_933059, *target));
unref_integer_reg(tmp_933058);
unref_integer_reg(tmp_933059);
}
}

void compiler_tmp_933060 (reg_t *target, int foreign_target, void **env)
/*
(SEX (FIELD DISP8 NIL NIL))
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
}

void compiler_tmp_933035 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
 ((4)
  (+
   (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
    ((5)
     (CASE ((0) (FIELD DISP32 NIL NIL))
      ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
   (CASE
    ((0 1 2 3 5 6 7)
     (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
      (ZEX (FIELD SCALE NIL NIL))))
    ((4) (INTEGER 0)))))
 ((5) (FIELD DISP32 NIL NIL)))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 6:
case 7:
compiler_tmp_933036(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_933038(&(*target), foreign_target, env);
break;
case 5:
compiler_tmp_933045(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_933038 (reg_t *target, int foreign_target, void **env)
/*
(+
 (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
  ((5)
   (CASE ((0) (FIELD DISP32 NIL NIL))
    ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
 (CASE
  ((0 1 2 3 5 6 7)
   (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
    (ZEX (FIELD SCALE NIL NIL))))
  ((4) (INTEGER 0))))
*/
{
{
reg_t tmp_933039, tmp_933040;
compiler_tmp_933041(&tmp_933039, -1, env);
compiler_tmp_933048(&tmp_933040, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_933039, tmp_933040, *target));
unref_integer_reg(tmp_933039);
unref_integer_reg(tmp_933040);
}
}

void compiler_tmp_933048 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
   (ZEX (FIELD SCALE NIL NIL))))
 ((4) (INTEGER 0)))
*/
{
switch (index) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_933049(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_933055(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_933055 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_933049 (reg_t *target, int foreign_target, void **env)
/*
(SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL)) (ZEX (FIELD SCALE NIL NIL)))
*/
{
{
reg_t tmp_933050, tmp_933051;
compiler_tmp_933052(&tmp_933050, -1, env);
compiler_tmp_933054(&tmp_933051, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_SLL(tmp_933050, tmp_933051, *target));
unref_integer_reg(tmp_933050);
unref_integer_reg(tmp_933051);
emit(COMPOSE_ADDL((*target), 31, (*target)));
}
}

void compiler_tmp_933054 (reg_t *target, int foreign_target, void **env)
/*
(ZEX (FIELD SCALE NIL NIL))
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, scale);
}

void compiler_tmp_933052 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD INDEX NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + index));
else {
reg_t tmp_933053 = ref_integer_reg_for_reading((0 + index));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_933053, *target));
unref_integer_reg(tmp_933053);
}
}

void compiler_tmp_933041 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
 ((5)
  (CASE ((0) (FIELD DISP32 NIL NIL))
   ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
*/
{
switch (base) {
case 0:
case 1:
case 2:
case 3:
case 4:
case 6:
case 7:
compiler_tmp_933042(&(*target), foreign_target, env);
break;
case 5:
compiler_tmp_933044(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_933044 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0) (FIELD DISP32 NIL NIL)) ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))
*/
{
switch (mod) {
case 0:
compiler_tmp_933045(&(*target), foreign_target, env);
break;
case 1:
case 2:
case 3:
compiler_tmp_933046(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_933046 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER EBP GPR (INTEGER 5))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading(5);
else {
reg_t tmp_933047 = ref_integer_reg_for_reading(5);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_933047, *target));
unref_integer_reg(tmp_933047);
}
}

void compiler_tmp_933045 (reg_t *target, int foreign_target, void **env)
/*
(FIELD DISP32 NIL NIL)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, disp32);
}

void compiler_tmp_933042 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD BASE NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + base));
else {
reg_t tmp_933043 = ref_integer_reg_for_reading((0 + base));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_933043, *target));
unref_integer_reg(tmp_933043);
}
}

void compiler_tmp_933036 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD RM NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + rm));
else {
reg_t tmp_933037 = ref_integer_reg_for_reading((0 + rm));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_933037, *target));
unref_integer_reg(tmp_933037);
}
}

void compiler_tmp_933018 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 11 11 T)
*/
{
{
reg_t tmp_933020, tmp_933021, tmp_933019;
rhs_func(&tmp_933020, -1, env);
emit(COMPOSE_SLL_IMM(tmp_933020, 63, tmp_933020));
emit(COMPOSE_SRL_IMM(tmp_933020, 52, tmp_933020));
tmp_933021 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_933021, -1);
emit(COMPOSE_SLL_IMM(tmp_933021, 63, tmp_933021));
emit(COMPOSE_SRL_IMM(tmp_933021, 52, tmp_933021));
tmp_933019 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_933019, tmp_933021, tmp_933019));
unref_integer_reg(tmp_933021);
emit(COMPOSE_BIS(tmp_933019, tmp_933020, tmp_933019));
unref_integer_reg(tmp_933020);
unref_integer_reg(tmp_933019);
}
}

void compiler_tmp_933014 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 0 0 T)
*/
{
{
reg_t tmp_933016, tmp_933017, tmp_933015;
rhs_func(&tmp_933016, -1, env);
emit(COMPOSE_SLL_IMM(tmp_933016, 63, tmp_933016));
emit(COMPOSE_SRL_IMM(tmp_933016, 63, tmp_933016));
tmp_933017 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_933017, -1);
emit(COMPOSE_SLL_IMM(tmp_933017, 63, tmp_933017));
emit(COMPOSE_SRL_IMM(tmp_933017, 63, tmp_933017));
tmp_933015 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_933015, tmp_933017, tmp_933015));
unref_integer_reg(tmp_933017);
emit(COMPOSE_BIS(tmp_933015, tmp_933016, tmp_933015));
unref_integer_reg(tmp_933016);
unref_integer_reg(tmp_933015);
}
}

void compiler_tmp_933013 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compile_xor_rm32_r32_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_922334();
goto next_tmp_921851;
next_tmp_921851:
goto finish_tmp_921850;
finish_tmp_921850:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_922863();
goto next_tmp_922337;
next_tmp_922337:
goto finish_tmp_922336;
finish_tmp_922336:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_923427();
goto next_tmp_922866;
next_tmp_922866:
goto finish_tmp_922865;
finish_tmp_922865:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_923913();
goto next_tmp_923430;
next_tmp_923430:
goto finish_tmp_923429;
finish_tmp_923429:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_924444();
goto next_tmp_923916;
next_tmp_923916:
goto finish_tmp_923915;
finish_tmp_923915:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_924984();
goto next_tmp_924447;
next_tmp_924447:
goto finish_tmp_924446;
finish_tmp_924446:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_925394();
goto next_tmp_924987;
next_tmp_924987:
goto finish_tmp_924986;
finish_tmp_924986:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; }))
{
genfunc_tmp_925394();
goto next_tmp_925397;
next_tmp_925397:
goto finish_tmp_925396;
finish_tmp_925396:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_925933();
goto next_tmp_925400;
next_tmp_925400:
goto finish_tmp_925399;
finish_tmp_925399:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_926473();
goto next_tmp_925936;
next_tmp_925936:
goto finish_tmp_925935;
finish_tmp_925935:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_927013();
goto next_tmp_926476;
next_tmp_926476:
goto finish_tmp_926475;
finish_tmp_926475:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_927544();
goto next_tmp_927016;
next_tmp_927016:
goto finish_tmp_927015;
finish_tmp_927015:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_928103();
goto next_tmp_927547;
next_tmp_927547:
goto finish_tmp_927546;
finish_tmp_927546:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_928665();
goto next_tmp_928106;
next_tmp_928106:
goto finish_tmp_928105;
finish_tmp_928105:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_929196();
goto next_tmp_928668;
next_tmp_928668:
goto finish_tmp_928667;
finish_tmp_928667:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_929732();
goto next_tmp_929199;
next_tmp_929199:
goto finish_tmp_929198;
finish_tmp_929198:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_930272();
goto next_tmp_929735;
next_tmp_929735:
goto finish_tmp_929734;
finish_tmp_929734:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_930812();
goto next_tmp_930275;
next_tmp_930275:
goto finish_tmp_930274;
finish_tmp_930274:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_931343();
goto next_tmp_930815;
next_tmp_930815:
goto finish_tmp_930814;
finish_tmp_930814:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_931883();
goto next_tmp_931346;
next_tmp_931346:
goto finish_tmp_931345;
finish_tmp_931345:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_932423();
goto next_tmp_931886;
next_tmp_931886:
goto finish_tmp_931885;
finish_tmp_931885:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_932954();
goto next_tmp_932426;
next_tmp_932426:
goto finish_tmp_932425;
finish_tmp_932425:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 3; })&& ({ word_2 tmp = mod; 0 || tmp == 3; }))
{
genfunc_tmp_933011();
goto next_tmp_932957;
next_tmp_932957:
goto finish_tmp_932956;
finish_tmp_932956:
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_933013;
killed |= 0x1;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_933014(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_933013;
killed |= 0x800;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_933018(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_933022;
killed |= 0x80;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_933072(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_933076;
killed |= 0x40;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_933085(rhs_func, env);
}
}
}
void genfunc_tmp_933011 (void) {
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + rm);
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 1 */
}
done_tmp_933010:
}
reg_t genfunc_tmp_932979 (void) {
reg_t tmp_731898;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + rm);
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 1 */
}
done_tmp_932978:
return tmp_731898;
}
void genfunc_tmp_932954 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_932550();
goto next_tmp_932429;
next_tmp_932429:
goto tmp_932428;
tmp_932428:
}
{
tmp_731146 = genfunc_tmp_932951();
goto next_tmp_932553;
next_tmp_932553:
goto tmp_932552;
tmp_932552:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 9 */
}
done_tmp_932953:
}
reg_t genfunc_tmp_932951 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_932948();
goto next_tmp_932780;
next_tmp_932780:
goto tmp_932779;
tmp_932779:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_932950:
return tmp_731146;
}
reg_t genfunc_tmp_932948 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_932550();
goto next_tmp_932945;
next_tmp_932945:
goto tmp_932944;
tmp_932944:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_932947:
return tmp_731087;
}
reg_t genfunc_tmp_932913 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_932550();
goto next_tmp_932857;
next_tmp_932857:
goto tmp_932856;
tmp_932856:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_932912:
return tmp_731906;
}
reg_t genfunc_tmp_932550 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_932517 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_932517 >> 8) == 0)
field_imm = tmp_932517;
else goto fail_tmp_932516;
}
/* commit */
{
tmp_731858 = genfunc_tmp_932461();
goto next_tmp_932519;
next_tmp_932519:
goto tmp_932518;
tmp_932518:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_932549;
fail_tmp_932516:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_932541 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_932541))
field_imm = inv_maskmask(8, tmp_932541);
else goto fail_tmp_932540;
}
/* commit */
{
tmp_731075 = genfunc_tmp_932461();
goto next_tmp_932543;
next_tmp_932543:
goto tmp_932542;
tmp_932542:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_932549;
fail_tmp_932540:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_932461();
goto next_tmp_932547;
next_tmp_932547:
goto tmp_932546;
tmp_932546:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_932549:
return tmp_731142;
}
reg_t genfunc_tmp_932514 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_932483 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_932483 >> 8) == 0)
field_imm = tmp_932483;
else goto fail_tmp_932482;
}
/* commit */
{
tmp_731858 = genfunc_tmp_932461();
goto next_tmp_932485;
next_tmp_932485:
goto tmp_932484;
tmp_932484:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_932513;
fail_tmp_932482:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_932505 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_932505))
field_imm = inv_maskmask(8, tmp_932505);
else goto fail_tmp_932504;
}
/* commit */
{
tmp_731075 = genfunc_tmp_932461();
goto next_tmp_932507;
next_tmp_932507:
goto tmp_932506;
tmp_932506:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_932513;
fail_tmp_932504:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_932461();
goto next_tmp_932511;
next_tmp_932511:
goto tmp_932510;
tmp_932510:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_932513:
return tmp_731862;
}
reg_t genfunc_tmp_932461 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_932458;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + 5);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_932460;
fail_tmp_932458:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_932459;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + 5);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_932460;
fail_tmp_932459:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + 5);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_932460:
return tmp_731876;
}
void genfunc_tmp_932423 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_932019();
goto next_tmp_931889;
next_tmp_931889:
goto tmp_931888;
tmp_931888:
}
{
tmp_731146 = genfunc_tmp_932420();
goto next_tmp_932022;
next_tmp_932022:
goto tmp_932021;
tmp_932021:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 13 */
}
done_tmp_932422:
}
reg_t genfunc_tmp_932420 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_932417();
goto next_tmp_932249;
next_tmp_932249:
goto tmp_932248;
tmp_932248:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_932419:
return tmp_731146;
}
reg_t genfunc_tmp_932417 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_932019();
goto next_tmp_932414;
next_tmp_932414:
goto tmp_932413;
tmp_932413:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_932416:
return tmp_731087;
}
reg_t genfunc_tmp_932382 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_932019();
goto next_tmp_932326;
next_tmp_932326:
goto tmp_932325;
tmp_932325:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_932381:
return tmp_731906;
}
reg_t genfunc_tmp_932019 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_931986 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_931986 >> 8) == 0)
field_imm = tmp_931986;
else goto fail_tmp_931985;
}
/* commit */
{
tmp_731858 = genfunc_tmp_931930();
goto next_tmp_931988;
next_tmp_931988:
goto tmp_931987;
tmp_931987:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_932018;
fail_tmp_931985:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_932010 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_932010))
field_imm = inv_maskmask(8, tmp_932010);
else goto fail_tmp_932009;
}
/* commit */
{
tmp_731075 = genfunc_tmp_931930();
goto next_tmp_932012;
next_tmp_932012:
goto tmp_932011;
tmp_932011:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_932018;
fail_tmp_932009:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_931930();
goto next_tmp_932016;
next_tmp_932016:
goto tmp_932015;
tmp_932015:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_932018:
return tmp_731142;
}
reg_t genfunc_tmp_931983 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_931952 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_931952 >> 8) == 0)
field_imm = tmp_931952;
else goto fail_tmp_931951;
}
/* commit */
{
tmp_731858 = genfunc_tmp_931930();
goto next_tmp_931954;
next_tmp_931954:
goto tmp_931953;
tmp_931953:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_931982;
fail_tmp_931951:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_931974 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_931974))
field_imm = inv_maskmask(8, tmp_931974);
else goto fail_tmp_931973;
}
/* commit */
{
tmp_731075 = genfunc_tmp_931930();
goto next_tmp_931976;
next_tmp_931976:
goto tmp_931975;
tmp_931975:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_931982;
fail_tmp_931973:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_931930();
goto next_tmp_931980;
next_tmp_931980:
goto tmp_931979;
tmp_931979:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_931982:
return tmp_731862;
}
reg_t genfunc_tmp_931930 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_931921;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_928147();
goto next_tmp_931923;
next_tmp_931923:
goto tmp_931922;
tmp_931922:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_931929;
fail_tmp_931921:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_931925;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_928147();
goto next_tmp_931927;
next_tmp_931927:
goto tmp_931926;
tmp_931926:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_931929;
fail_tmp_931925:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_928147();
goto next_tmp_931905;
next_tmp_931905:
goto tmp_931904;
tmp_931904:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_931929:
return tmp_731876;
}
void genfunc_tmp_931883 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_931479();
goto next_tmp_931349;
next_tmp_931349:
goto tmp_931348;
tmp_931348:
}
{
tmp_731146 = genfunc_tmp_931880();
goto next_tmp_931482;
next_tmp_931482:
goto tmp_931481;
tmp_931481:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 11 */
}
done_tmp_931882:
}
reg_t genfunc_tmp_931880 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_931877();
goto next_tmp_931709;
next_tmp_931709:
goto tmp_931708;
tmp_931708:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_931879:
return tmp_731146;
}
reg_t genfunc_tmp_931877 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_931479();
goto next_tmp_931874;
next_tmp_931874:
goto tmp_931873;
tmp_931873:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_931876:
return tmp_731087;
}
reg_t genfunc_tmp_931842 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_931479();
goto next_tmp_931786;
next_tmp_931786:
goto tmp_931785;
tmp_931785:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_931841:
return tmp_731906;
}
reg_t genfunc_tmp_931479 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_931446 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_931446 >> 8) == 0)
field_imm = tmp_931446;
else goto fail_tmp_931445;
}
/* commit */
{
tmp_731858 = genfunc_tmp_931390();
goto next_tmp_931448;
next_tmp_931448:
goto tmp_931447;
tmp_931447:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_931478;
fail_tmp_931445:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_931470 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_931470))
field_imm = inv_maskmask(8, tmp_931470);
else goto fail_tmp_931469;
}
/* commit */
{
tmp_731075 = genfunc_tmp_931390();
goto next_tmp_931472;
next_tmp_931472:
goto tmp_931471;
tmp_931471:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_931478;
fail_tmp_931469:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_931390();
goto next_tmp_931476;
next_tmp_931476:
goto tmp_931475;
tmp_931475:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_931478:
return tmp_731142;
}
reg_t genfunc_tmp_931443 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_931412 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_931412 >> 8) == 0)
field_imm = tmp_931412;
else goto fail_tmp_931411;
}
/* commit */
{
tmp_731858 = genfunc_tmp_931390();
goto next_tmp_931414;
next_tmp_931414:
goto tmp_931413;
tmp_931413:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_931442;
fail_tmp_931411:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_931434 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_931434))
field_imm = inv_maskmask(8, tmp_931434);
else goto fail_tmp_931433;
}
/* commit */
{
tmp_731075 = genfunc_tmp_931390();
goto next_tmp_931436;
next_tmp_931436:
goto tmp_931435;
tmp_931435:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_931442;
fail_tmp_931433:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_931390();
goto next_tmp_931440;
next_tmp_931440:
goto tmp_931439;
tmp_931439:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_931442:
return tmp_731862;
}
reg_t genfunc_tmp_931390 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_931381;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_927585();
goto next_tmp_931383;
next_tmp_931383:
goto tmp_931382;
tmp_931382:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_931389;
fail_tmp_931381:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_931385;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_927585();
goto next_tmp_931387;
next_tmp_931387:
goto tmp_931386;
tmp_931386:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_931389;
fail_tmp_931385:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_927585();
goto next_tmp_931365;
next_tmp_931365:
goto tmp_931364;
tmp_931364:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_931389:
return tmp_731876;
}
void genfunc_tmp_931343 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_930939();
goto next_tmp_930818;
next_tmp_930818:
goto tmp_930817;
tmp_930817:
}
{
tmp_731146 = genfunc_tmp_931340();
goto next_tmp_930942;
next_tmp_930942:
goto tmp_930941;
tmp_930941:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 9 */
}
done_tmp_931342:
}
reg_t genfunc_tmp_931340 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_931337();
goto next_tmp_931169;
next_tmp_931169:
goto tmp_931168;
tmp_931168:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_931339:
return tmp_731146;
}
reg_t genfunc_tmp_931337 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_930939();
goto next_tmp_931334;
next_tmp_931334:
goto tmp_931333;
tmp_931333:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_931336:
return tmp_731087;
}
reg_t genfunc_tmp_931302 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_930939();
goto next_tmp_931246;
next_tmp_931246:
goto tmp_931245;
tmp_931245:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_931301:
return tmp_731906;
}
reg_t genfunc_tmp_930939 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_930906 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_930906 >> 8) == 0)
field_imm = tmp_930906;
else goto fail_tmp_930905;
}
/* commit */
{
tmp_731858 = genfunc_tmp_930850();
goto next_tmp_930908;
next_tmp_930908:
goto tmp_930907;
tmp_930907:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_930938;
fail_tmp_930905:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_930930 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_930930))
field_imm = inv_maskmask(8, tmp_930930);
else goto fail_tmp_930929;
}
/* commit */
{
tmp_731075 = genfunc_tmp_930850();
goto next_tmp_930932;
next_tmp_930932:
goto tmp_930931;
tmp_930931:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_930938;
fail_tmp_930929:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_930850();
goto next_tmp_930936;
next_tmp_930936:
goto tmp_930935;
tmp_930935:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_930938:
return tmp_731142;
}
reg_t genfunc_tmp_930903 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_930872 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_930872 >> 8) == 0)
field_imm = tmp_930872;
else goto fail_tmp_930871;
}
/* commit */
{
tmp_731858 = genfunc_tmp_930850();
goto next_tmp_930874;
next_tmp_930874:
goto tmp_930873;
tmp_930873:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_930902;
fail_tmp_930871:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_930894 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_930894))
field_imm = inv_maskmask(8, tmp_930894);
else goto fail_tmp_930893;
}
/* commit */
{
tmp_731075 = genfunc_tmp_930850();
goto next_tmp_930896;
next_tmp_930896:
goto tmp_930895;
tmp_930895:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_930902;
fail_tmp_930893:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_930850();
goto next_tmp_930900;
next_tmp_930900:
goto tmp_930899;
tmp_930899:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_930902:
return tmp_731862;
}
reg_t genfunc_tmp_930850 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_930847;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + base);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_930849;
fail_tmp_930847:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_930848;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + base);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_930849;
fail_tmp_930848:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + base);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_930849:
return tmp_731876;
}
void genfunc_tmp_930812 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_930408();
goto next_tmp_930278;
next_tmp_930278:
goto tmp_930277;
tmp_930277:
}
{
tmp_731146 = genfunc_tmp_930809();
goto next_tmp_930411;
next_tmp_930411:
goto tmp_930410;
tmp_930410:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 13 */
}
done_tmp_930811:
}
reg_t genfunc_tmp_930809 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_930806();
goto next_tmp_930638;
next_tmp_930638:
goto tmp_930637;
tmp_930637:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_930808:
return tmp_731146;
}
reg_t genfunc_tmp_930806 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_930408();
goto next_tmp_930803;
next_tmp_930803:
goto tmp_930802;
tmp_930802:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_930805:
return tmp_731087;
}
reg_t genfunc_tmp_930771 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_930408();
goto next_tmp_930715;
next_tmp_930715:
goto tmp_930714;
tmp_930714:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_930770:
return tmp_731906;
}
reg_t genfunc_tmp_930408 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_930375 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_930375 >> 8) == 0)
field_imm = tmp_930375;
else goto fail_tmp_930374;
}
/* commit */
{
tmp_731858 = genfunc_tmp_930319();
goto next_tmp_930377;
next_tmp_930377:
goto tmp_930376;
tmp_930376:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_930407;
fail_tmp_930374:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_930399 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_930399))
field_imm = inv_maskmask(8, tmp_930399);
else goto fail_tmp_930398;
}
/* commit */
{
tmp_731075 = genfunc_tmp_930319();
goto next_tmp_930401;
next_tmp_930401:
goto tmp_930400;
tmp_930400:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_930407;
fail_tmp_930398:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_930319();
goto next_tmp_930405;
next_tmp_930405:
goto tmp_930404;
tmp_930404:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_930407:
return tmp_731142;
}
reg_t genfunc_tmp_930372 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_930341 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_930341 >> 8) == 0)
field_imm = tmp_930341;
else goto fail_tmp_930340;
}
/* commit */
{
tmp_731858 = genfunc_tmp_930319();
goto next_tmp_930343;
next_tmp_930343:
goto tmp_930342;
tmp_930342:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_930371;
fail_tmp_930340:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_930363 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_930363))
field_imm = inv_maskmask(8, tmp_930363);
else goto fail_tmp_930362;
}
/* commit */
{
tmp_731075 = genfunc_tmp_930319();
goto next_tmp_930365;
next_tmp_930365:
goto tmp_930364;
tmp_930364:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_930371;
fail_tmp_930362:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_930319();
goto next_tmp_930369;
next_tmp_930369:
goto tmp_930368;
tmp_930368:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_930371:
return tmp_731862;
}
reg_t genfunc_tmp_930319 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_930310;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_922934();
goto next_tmp_930312;
next_tmp_930312:
goto tmp_930311;
tmp_930311:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_930318;
fail_tmp_930310:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_930314;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_922934();
goto next_tmp_930316;
next_tmp_930316:
goto tmp_930315;
tmp_930315:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_930318;
fail_tmp_930314:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_922934();
goto next_tmp_930294;
next_tmp_930294:
goto tmp_930293;
tmp_930293:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_930318:
return tmp_731876;
}
void genfunc_tmp_930272 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_929868();
goto next_tmp_929738;
next_tmp_929738:
goto tmp_929737;
tmp_929737:
}
{
tmp_731146 = genfunc_tmp_930269();
goto next_tmp_929871;
next_tmp_929871:
goto tmp_929870;
tmp_929870:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 11 */
}
done_tmp_930271:
}
reg_t genfunc_tmp_930269 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_930266();
goto next_tmp_930098;
next_tmp_930098:
goto tmp_930097;
tmp_930097:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_930268:
return tmp_731146;
}
reg_t genfunc_tmp_930266 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_929868();
goto next_tmp_930263;
next_tmp_930263:
goto tmp_930262;
tmp_930262:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_930265:
return tmp_731087;
}
reg_t genfunc_tmp_930231 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_929868();
goto next_tmp_930175;
next_tmp_930175:
goto tmp_930174;
tmp_930174:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_930230:
return tmp_731906;
}
reg_t genfunc_tmp_929868 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_929835 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_929835 >> 8) == 0)
field_imm = tmp_929835;
else goto fail_tmp_929834;
}
/* commit */
{
tmp_731858 = genfunc_tmp_929779();
goto next_tmp_929837;
next_tmp_929837:
goto tmp_929836;
tmp_929836:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_929867;
fail_tmp_929834:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_929859 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_929859))
field_imm = inv_maskmask(8, tmp_929859);
else goto fail_tmp_929858;
}
/* commit */
{
tmp_731075 = genfunc_tmp_929779();
goto next_tmp_929861;
next_tmp_929861:
goto tmp_929860;
tmp_929860:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_929867;
fail_tmp_929858:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_929779();
goto next_tmp_929865;
next_tmp_929865:
goto tmp_929864;
tmp_929864:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_929867:
return tmp_731142;
}
reg_t genfunc_tmp_929832 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_929801 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_929801 >> 8) == 0)
field_imm = tmp_929801;
else goto fail_tmp_929800;
}
/* commit */
{
tmp_731858 = genfunc_tmp_929779();
goto next_tmp_929803;
next_tmp_929803:
goto tmp_929802;
tmp_929802:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_929831;
fail_tmp_929800:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_929823 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_929823))
field_imm = inv_maskmask(8, tmp_929823);
else goto fail_tmp_929822;
}
/* commit */
{
tmp_731075 = genfunc_tmp_929779();
goto next_tmp_929825;
next_tmp_929825:
goto tmp_929824;
tmp_929824:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_929831;
fail_tmp_929822:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_929779();
goto next_tmp_929829;
next_tmp_929829:
goto tmp_929828;
tmp_929828:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_929831:
return tmp_731862;
}
reg_t genfunc_tmp_929779 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_929770;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_922370();
goto next_tmp_929772;
next_tmp_929772:
goto tmp_929771;
tmp_929771:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_929778;
fail_tmp_929770:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_929774;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_922370();
goto next_tmp_929776;
next_tmp_929776:
goto tmp_929775;
tmp_929775:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_929778;
fail_tmp_929774:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_922370();
goto next_tmp_929754;
next_tmp_929754:
goto tmp_929753;
tmp_929753:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_929778:
return tmp_731876;
}
void genfunc_tmp_929732 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_929328();
goto next_tmp_929202;
next_tmp_929202:
goto tmp_929201;
tmp_929201:
}
{
tmp_731146 = genfunc_tmp_929729();
goto next_tmp_929331;
next_tmp_929331:
goto tmp_929330;
tmp_929330:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 9 */
}
done_tmp_929731:
}
reg_t genfunc_tmp_929729 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_929726();
goto next_tmp_929558;
next_tmp_929558:
goto tmp_929557;
tmp_929557:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_929728:
return tmp_731146;
}
reg_t genfunc_tmp_929726 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_929328();
goto next_tmp_929723;
next_tmp_929723:
goto tmp_929722;
tmp_929722:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_929725:
return tmp_731087;
}
reg_t genfunc_tmp_929691 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_929328();
goto next_tmp_929635;
next_tmp_929635:
goto tmp_929634;
tmp_929634:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_929690:
return tmp_731906;
}
reg_t genfunc_tmp_929328 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_929295 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_929295 >> 8) == 0)
field_imm = tmp_929295;
else goto fail_tmp_929294;
}
/* commit */
{
tmp_731858 = genfunc_tmp_929239();
goto next_tmp_929297;
next_tmp_929297:
goto tmp_929296;
tmp_929296:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_929327;
fail_tmp_929294:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_929319 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_929319))
field_imm = inv_maskmask(8, tmp_929319);
else goto fail_tmp_929318;
}
/* commit */
{
tmp_731075 = genfunc_tmp_929239();
goto next_tmp_929321;
next_tmp_929321:
goto tmp_929320;
tmp_929320:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_929327;
fail_tmp_929318:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_929239();
goto next_tmp_929325;
next_tmp_929325:
goto tmp_929324;
tmp_929324:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_929327:
return tmp_731142;
}
reg_t genfunc_tmp_929292 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_929261 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_929261 >> 8) == 0)
field_imm = tmp_929261;
else goto fail_tmp_929260;
}
/* commit */
{
tmp_731858 = genfunc_tmp_929239();
goto next_tmp_929263;
next_tmp_929263:
goto tmp_929262;
tmp_929262:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_929291;
fail_tmp_929260:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_929283 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_929283))
field_imm = inv_maskmask(8, tmp_929283);
else goto fail_tmp_929282;
}
/* commit */
{
tmp_731075 = genfunc_tmp_929239();
goto next_tmp_929285;
next_tmp_929285:
goto tmp_929284;
tmp_929284:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_929291;
fail_tmp_929282:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_929239();
goto next_tmp_929289;
next_tmp_929289:
goto tmp_929288;
tmp_929288:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_929291:
return tmp_731862;
}
reg_t genfunc_tmp_929239 (void) {
reg_t tmp_731876;
/* ADDQ_IMM */
{
word_5 tmp_731893;
word_5 field_rc;
word_5 tmp_731894;
word_5 field_ra;
word_64 tmp_731896;
word_8 field_imm;
tmp_731896 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_929224 = tmp_731896;
if ((tmp_929224 >> 8) == 0)
field_imm = tmp_929224;
else goto fail_tmp_929223;
}
/* commit */
tmp_731894 = ref_gpr_reg_for_reading(0 + rm);
tmp_731893 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731893;
field_ra = tmp_731894;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731894);
/* can fail: T   num insns: 1 */
}
goto done_tmp_929238;
fail_tmp_929223:
/* LDA */
{
word_5 tmp_731397;
word_5 field_ra;
word_5 tmp_731398;
word_5 field_rb;
word_64 tmp_731400;
word_16 field_memory_disp;
tmp_731400 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_929232 = tmp_731400;
if ((tmp_929232 >> 16) == 0xFFFFFFFFFFFF || (tmp_929232 >> 16) == 0)
field_memory_disp = (tmp_929232 & 0xFFFF);
else goto fail_tmp_929231;
}
/* commit */
tmp_731398 = ref_gpr_reg_for_reading(0 + rm);
tmp_731397 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731397;
field_rb = tmp_731398;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731398);
/* can fail: T   num insns: 1 */
}
goto done_tmp_929238;
fail_tmp_929231:
/* LDAH */
{
word_5 tmp_731393;
word_5 field_ra;
word_5 tmp_731394;
word_5 field_rb;
word_64 tmp_731396;
word_16 field_memory_disp;
tmp_731396 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_929236 = tmp_731396;
if ((tmp_929236 & 0xFFFF) == 0)
{
word_64 tmp_929237 = (tmp_929236 >> 16);
if ((tmp_929237 >> 16) == 0xFFFFFFFFFFFF || (tmp_929237 >> 16) == 0)
field_memory_disp = (tmp_929237 & 0xFFFF);
else goto fail_tmp_929235;
}
else goto fail_tmp_929235;
}
/* commit */
tmp_731394 = ref_gpr_reg_for_reading(0 + rm);
tmp_731393 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731393;
field_rb = tmp_731394;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731394);
/* can fail: T   num insns: 1 */
}
goto done_tmp_929238;
fail_tmp_929235:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731900 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731900, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_929238:
return tmp_731876;
}
void genfunc_tmp_929196 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_928792();
goto next_tmp_928671;
next_tmp_928671:
goto tmp_928670;
tmp_928670:
}
{
tmp_731146 = genfunc_tmp_929193();
goto next_tmp_928795;
next_tmp_928795:
goto tmp_928794;
tmp_928794:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 9 */
}
done_tmp_929195:
}
reg_t genfunc_tmp_929193 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_929190();
goto next_tmp_929022;
next_tmp_929022:
goto tmp_929021;
tmp_929021:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_929192:
return tmp_731146;
}
reg_t genfunc_tmp_929190 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_928792();
goto next_tmp_929187;
next_tmp_929187:
goto tmp_929186;
tmp_929186:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_929189:
return tmp_731087;
}
reg_t genfunc_tmp_929155 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_928792();
goto next_tmp_929099;
next_tmp_929099:
goto tmp_929098;
tmp_929098:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_929154:
return tmp_731906;
}
reg_t genfunc_tmp_928792 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_928759 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_928759 >> 8) == 0)
field_imm = tmp_928759;
else goto fail_tmp_928758;
}
/* commit */
{
tmp_731858 = genfunc_tmp_928703();
goto next_tmp_928761;
next_tmp_928761:
goto tmp_928760;
tmp_928760:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_928791;
fail_tmp_928758:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_928783 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_928783))
field_imm = inv_maskmask(8, tmp_928783);
else goto fail_tmp_928782;
}
/* commit */
{
tmp_731075 = genfunc_tmp_928703();
goto next_tmp_928785;
next_tmp_928785:
goto tmp_928784;
tmp_928784:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_928791;
fail_tmp_928782:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_928703();
goto next_tmp_928789;
next_tmp_928789:
goto tmp_928788;
tmp_928788:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_928791:
return tmp_731142;
}
reg_t genfunc_tmp_928756 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_928725 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_928725 >> 8) == 0)
field_imm = tmp_928725;
else goto fail_tmp_928724;
}
/* commit */
{
tmp_731858 = genfunc_tmp_928703();
goto next_tmp_928727;
next_tmp_928727:
goto tmp_928726;
tmp_928726:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_928755;
fail_tmp_928724:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_928747 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_928747))
field_imm = inv_maskmask(8, tmp_928747);
else goto fail_tmp_928746;
}
/* commit */
{
tmp_731075 = genfunc_tmp_928703();
goto next_tmp_928749;
next_tmp_928749:
goto tmp_928748;
tmp_928748:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_928755;
fail_tmp_928746:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_928703();
goto next_tmp_928753;
next_tmp_928753:
goto tmp_928752;
tmp_928752:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_928755:
return tmp_731862;
}
reg_t genfunc_tmp_928703 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_928700;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + 5);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_928702;
fail_tmp_928700:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_928701;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + 5);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_928702;
fail_tmp_928701:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731900 = ref_gpr_reg_for_reading(0 + 5);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_928702:
return tmp_731876;
}
void genfunc_tmp_928665 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_928261();
goto next_tmp_928109;
next_tmp_928109:
goto tmp_928108;
tmp_928108:
}
{
tmp_731146 = genfunc_tmp_928662();
goto next_tmp_928264;
next_tmp_928264:
goto tmp_928263;
tmp_928263:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 13 */
}
done_tmp_928664:
}
reg_t genfunc_tmp_928662 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_928659();
goto next_tmp_928491;
next_tmp_928491:
goto tmp_928490;
tmp_928490:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_928661:
return tmp_731146;
}
reg_t genfunc_tmp_928659 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_928261();
goto next_tmp_928656;
next_tmp_928656:
goto tmp_928655;
tmp_928655:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_928658:
return tmp_731087;
}
reg_t genfunc_tmp_928624 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_928261();
goto next_tmp_928568;
next_tmp_928568:
goto tmp_928567;
tmp_928567:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_928623:
return tmp_731906;
}
reg_t genfunc_tmp_928261 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_928228 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_928228 >> 8) == 0)
field_imm = tmp_928228;
else goto fail_tmp_928227;
}
/* commit */
{
tmp_731858 = genfunc_tmp_928172();
goto next_tmp_928230;
next_tmp_928230:
goto tmp_928229;
tmp_928229:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_928260;
fail_tmp_928227:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_928252 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_928252))
field_imm = inv_maskmask(8, tmp_928252);
else goto fail_tmp_928251;
}
/* commit */
{
tmp_731075 = genfunc_tmp_928172();
goto next_tmp_928254;
next_tmp_928254:
goto tmp_928253;
tmp_928253:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_928260;
fail_tmp_928251:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_928172();
goto next_tmp_928258;
next_tmp_928258:
goto tmp_928257;
tmp_928257:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_928260:
return tmp_731142;
}
reg_t genfunc_tmp_928225 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_928194 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_928194 >> 8) == 0)
field_imm = tmp_928194;
else goto fail_tmp_928193;
}
/* commit */
{
tmp_731858 = genfunc_tmp_928172();
goto next_tmp_928196;
next_tmp_928196:
goto tmp_928195;
tmp_928195:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_928224;
fail_tmp_928193:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_928216 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_928216))
field_imm = inv_maskmask(8, tmp_928216);
else goto fail_tmp_928215;
}
/* commit */
{
tmp_731075 = genfunc_tmp_928172();
goto next_tmp_928218;
next_tmp_928218:
goto tmp_928217;
tmp_928217:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_928224;
fail_tmp_928215:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_928172();
goto next_tmp_928222;
next_tmp_928222:
goto tmp_928221;
tmp_928221:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_928224:
return tmp_731862;
}
reg_t genfunc_tmp_928172 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_928163;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_928147();
goto next_tmp_928165;
next_tmp_928165:
goto tmp_928164;
tmp_928164:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_928171;
fail_tmp_928163:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_928167;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_928147();
goto next_tmp_928169;
next_tmp_928169:
goto tmp_928168;
tmp_928168:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_928171;
fail_tmp_928167:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_928147();
goto next_tmp_928125;
next_tmp_928125:
goto tmp_928124;
tmp_928124:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_928171:
return tmp_731876;
}
reg_t genfunc_tmp_928147 (void) {
reg_t tmp_731900;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + 5);
{
tmp_731900 = genfunc_tmp_922917();
goto next_tmp_928130;
next_tmp_928130:
goto tmp_928129;
tmp_928129:
}
tmp_731897 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_928146:
return tmp_731900;
}
void genfunc_tmp_928103 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_927699();
goto next_tmp_927550;
next_tmp_927550:
goto tmp_927549;
tmp_927549:
}
{
tmp_731146 = genfunc_tmp_928100();
goto next_tmp_927702;
next_tmp_927702:
goto tmp_927701;
tmp_927701:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 11 */
}
done_tmp_928102:
}
reg_t genfunc_tmp_928100 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_928097();
goto next_tmp_927929;
next_tmp_927929:
goto tmp_927928;
tmp_927928:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_928099:
return tmp_731146;
}
reg_t genfunc_tmp_928097 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_927699();
goto next_tmp_928094;
next_tmp_928094:
goto tmp_928093;
tmp_928093:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_928096:
return tmp_731087;
}
reg_t genfunc_tmp_928062 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_927699();
goto next_tmp_928006;
next_tmp_928006:
goto tmp_928005;
tmp_928005:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_928061:
return tmp_731906;
}
reg_t genfunc_tmp_927699 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_927666 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_927666 >> 8) == 0)
field_imm = tmp_927666;
else goto fail_tmp_927665;
}
/* commit */
{
tmp_731858 = genfunc_tmp_927610();
goto next_tmp_927668;
next_tmp_927668:
goto tmp_927667;
tmp_927667:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_927698;
fail_tmp_927665:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_927690 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_927690))
field_imm = inv_maskmask(8, tmp_927690);
else goto fail_tmp_927689;
}
/* commit */
{
tmp_731075 = genfunc_tmp_927610();
goto next_tmp_927692;
next_tmp_927692:
goto tmp_927691;
tmp_927691:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_927698;
fail_tmp_927689:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_927610();
goto next_tmp_927696;
next_tmp_927696:
goto tmp_927695;
tmp_927695:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_927698:
return tmp_731142;
}
reg_t genfunc_tmp_927663 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_927632 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_927632 >> 8) == 0)
field_imm = tmp_927632;
else goto fail_tmp_927631;
}
/* commit */
{
tmp_731858 = genfunc_tmp_927610();
goto next_tmp_927634;
next_tmp_927634:
goto tmp_927633;
tmp_927633:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_927662;
fail_tmp_927631:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_927654 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_927654))
field_imm = inv_maskmask(8, tmp_927654);
else goto fail_tmp_927653;
}
/* commit */
{
tmp_731075 = genfunc_tmp_927610();
goto next_tmp_927656;
next_tmp_927656:
goto tmp_927655;
tmp_927655:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_927662;
fail_tmp_927653:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_927610();
goto next_tmp_927660;
next_tmp_927660:
goto tmp_927659;
tmp_927659:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_927662:
return tmp_731862;
}
reg_t genfunc_tmp_927610 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_927601;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_927585();
goto next_tmp_927603;
next_tmp_927603:
goto tmp_927602;
tmp_927602:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_927609;
fail_tmp_927601:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_927605;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_927585();
goto next_tmp_927607;
next_tmp_927607:
goto tmp_927606;
tmp_927606:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_927609;
fail_tmp_927605:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_927585();
goto next_tmp_927566;
next_tmp_927566:
goto tmp_927565;
tmp_927565:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_927609:
return tmp_731876;
}
reg_t genfunc_tmp_927585 (void) {
reg_t tmp_731900;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + 5);
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_927584:
return tmp_731900;
}
void genfunc_tmp_927544 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_927140();
goto next_tmp_927019;
next_tmp_927019:
goto tmp_927018;
tmp_927018:
}
{
tmp_731146 = genfunc_tmp_927541();
goto next_tmp_927143;
next_tmp_927143:
goto tmp_927142;
tmp_927142:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 9 */
}
done_tmp_927543:
}
reg_t genfunc_tmp_927541 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_927538();
goto next_tmp_927370;
next_tmp_927370:
goto tmp_927369;
tmp_927369:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_927540:
return tmp_731146;
}
reg_t genfunc_tmp_927538 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_927140();
goto next_tmp_927535;
next_tmp_927535:
goto tmp_927534;
tmp_927534:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_927537:
return tmp_731087;
}
reg_t genfunc_tmp_927503 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_927140();
goto next_tmp_927447;
next_tmp_927447:
goto tmp_927446;
tmp_927446:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_927502:
return tmp_731906;
}
reg_t genfunc_tmp_927140 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_927107 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_927107 >> 8) == 0)
field_imm = tmp_927107;
else goto fail_tmp_927106;
}
/* commit */
{
tmp_731858 = genfunc_tmp_927051();
goto next_tmp_927109;
next_tmp_927109:
goto tmp_927108;
tmp_927108:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_927139;
fail_tmp_927106:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_927131 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_927131))
field_imm = inv_maskmask(8, tmp_927131);
else goto fail_tmp_927130;
}
/* commit */
{
tmp_731075 = genfunc_tmp_927051();
goto next_tmp_927133;
next_tmp_927133:
goto tmp_927132;
tmp_927132:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_927139;
fail_tmp_927130:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_927051();
goto next_tmp_927137;
next_tmp_927137:
goto tmp_927136;
tmp_927136:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_927139:
return tmp_731142;
}
reg_t genfunc_tmp_927104 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_927073 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_927073 >> 8) == 0)
field_imm = tmp_927073;
else goto fail_tmp_927072;
}
/* commit */
{
tmp_731858 = genfunc_tmp_927051();
goto next_tmp_927075;
next_tmp_927075:
goto tmp_927074;
tmp_927074:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_927103;
fail_tmp_927072:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_927095 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_927095))
field_imm = inv_maskmask(8, tmp_927095);
else goto fail_tmp_927094;
}
/* commit */
{
tmp_731075 = genfunc_tmp_927051();
goto next_tmp_927097;
next_tmp_927097:
goto tmp_927096;
tmp_927096:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_927103;
fail_tmp_927094:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_927051();
goto next_tmp_927101;
next_tmp_927101:
goto tmp_927100;
tmp_927100:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_927103:
return tmp_731862;
}
reg_t genfunc_tmp_927051 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_927048;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + base);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_927050;
fail_tmp_927048:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_927049;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + base);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_927050;
fail_tmp_927049:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731900 = ref_gpr_reg_for_reading(0 + base);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_927050:
return tmp_731876;
}
void genfunc_tmp_927013 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_926609();
goto next_tmp_926479;
next_tmp_926479:
goto tmp_926478;
tmp_926478:
}
{
tmp_731146 = genfunc_tmp_927010();
goto next_tmp_926612;
next_tmp_926612:
goto tmp_926611;
tmp_926611:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 13 */
}
done_tmp_927012:
}
reg_t genfunc_tmp_927010 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_927007();
goto next_tmp_926839;
next_tmp_926839:
goto tmp_926838;
tmp_926838:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 7 */
}
done_tmp_927009:
return tmp_731146;
}
reg_t genfunc_tmp_927007 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_926609();
goto next_tmp_927004;
next_tmp_927004:
goto tmp_927003;
tmp_927003:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_927006:
return tmp_731087;
}
reg_t genfunc_tmp_926972 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_926609();
goto next_tmp_926916;
next_tmp_926916:
goto tmp_926915;
tmp_926915:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 6 */
}
done_tmp_926971:
return tmp_731906;
}
reg_t genfunc_tmp_926609 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_926576 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_926576 >> 8) == 0)
field_imm = tmp_926576;
else goto fail_tmp_926575;
}
/* commit */
{
tmp_731858 = genfunc_tmp_926520();
goto next_tmp_926578;
next_tmp_926578:
goto tmp_926577;
tmp_926577:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_926608;
fail_tmp_926575:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_926600 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_926600))
field_imm = inv_maskmask(8, tmp_926600);
else goto fail_tmp_926599;
}
/* commit */
{
tmp_731075 = genfunc_tmp_926520();
goto next_tmp_926602;
next_tmp_926602:
goto tmp_926601;
tmp_926601:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_926608;
fail_tmp_926599:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_926520();
goto next_tmp_926606;
next_tmp_926606:
goto tmp_926605;
tmp_926605:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_926608:
return tmp_731142;
}
reg_t genfunc_tmp_926573 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_926542 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_926542 >> 8) == 0)
field_imm = tmp_926542;
else goto fail_tmp_926541;
}
/* commit */
{
tmp_731858 = genfunc_tmp_926520();
goto next_tmp_926544;
next_tmp_926544:
goto tmp_926543;
tmp_926543:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_926572;
fail_tmp_926541:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_926564 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_926564))
field_imm = inv_maskmask(8, tmp_926564);
else goto fail_tmp_926563;
}
/* commit */
{
tmp_731075 = genfunc_tmp_926520();
goto next_tmp_926566;
next_tmp_926566:
goto tmp_926565;
tmp_926565:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_926572;
fail_tmp_926563:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_926520();
goto next_tmp_926570;
next_tmp_926570:
goto tmp_926569;
tmp_926569:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_926572:
return tmp_731862;
}
reg_t genfunc_tmp_926520 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_926511;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_922934();
goto next_tmp_926513;
next_tmp_926513:
goto tmp_926512;
tmp_926512:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_926519;
fail_tmp_926511:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_926515;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_922934();
goto next_tmp_926517;
next_tmp_926517:
goto tmp_926516;
tmp_926516:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_926519;
fail_tmp_926515:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_922934();
goto next_tmp_926495;
next_tmp_926495:
goto tmp_926494;
tmp_926494:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_926519:
return tmp_731876;
}
void genfunc_tmp_926473 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_926069();
goto next_tmp_925939;
next_tmp_925939:
goto tmp_925938;
tmp_925938:
}
{
tmp_731146 = genfunc_tmp_926470();
goto next_tmp_926072;
next_tmp_926072:
goto tmp_926071;
tmp_926071:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 11 */
}
done_tmp_926472:
}
reg_t genfunc_tmp_926470 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_926467();
goto next_tmp_926299;
next_tmp_926299:
goto tmp_926298;
tmp_926298:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_926469:
return tmp_731146;
}
reg_t genfunc_tmp_926467 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_926069();
goto next_tmp_926464;
next_tmp_926464:
goto tmp_926463;
tmp_926463:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_926466:
return tmp_731087;
}
reg_t genfunc_tmp_926432 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_926069();
goto next_tmp_926376;
next_tmp_926376:
goto tmp_926375;
tmp_926375:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_926431:
return tmp_731906;
}
reg_t genfunc_tmp_926069 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_926036 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_926036 >> 8) == 0)
field_imm = tmp_926036;
else goto fail_tmp_926035;
}
/* commit */
{
tmp_731858 = genfunc_tmp_925980();
goto next_tmp_926038;
next_tmp_926038:
goto tmp_926037;
tmp_926037:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_926068;
fail_tmp_926035:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_926060 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_926060))
field_imm = inv_maskmask(8, tmp_926060);
else goto fail_tmp_926059;
}
/* commit */
{
tmp_731075 = genfunc_tmp_925980();
goto next_tmp_926062;
next_tmp_926062:
goto tmp_926061;
tmp_926061:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_926068;
fail_tmp_926059:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_925980();
goto next_tmp_926066;
next_tmp_926066:
goto tmp_926065;
tmp_926065:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_926068:
return tmp_731142;
}
reg_t genfunc_tmp_926033 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_926002 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_926002 >> 8) == 0)
field_imm = tmp_926002;
else goto fail_tmp_926001;
}
/* commit */
{
tmp_731858 = genfunc_tmp_925980();
goto next_tmp_926004;
next_tmp_926004:
goto tmp_926003;
tmp_926003:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_926032;
fail_tmp_926001:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_926024 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_926024))
field_imm = inv_maskmask(8, tmp_926024);
else goto fail_tmp_926023;
}
/* commit */
{
tmp_731075 = genfunc_tmp_925980();
goto next_tmp_926026;
next_tmp_926026:
goto tmp_926025;
tmp_926025:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_926032;
fail_tmp_926023:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_925980();
goto next_tmp_926030;
next_tmp_926030:
goto tmp_926029;
tmp_926029:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_926032:
return tmp_731862;
}
reg_t genfunc_tmp_925980 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_925971;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_922370();
goto next_tmp_925973;
next_tmp_925973:
goto tmp_925972;
tmp_925972:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_925979;
fail_tmp_925971:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_925975;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_922370();
goto next_tmp_925977;
next_tmp_925977:
goto tmp_925976;
tmp_925976:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_925979;
fail_tmp_925975:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_922370();
goto next_tmp_925955;
next_tmp_925955:
goto tmp_925954;
tmp_925954:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_925979:
return tmp_731876;
}
void genfunc_tmp_925933 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_925529();
goto next_tmp_925403;
next_tmp_925403:
goto tmp_925402;
tmp_925402:
}
{
tmp_731146 = genfunc_tmp_925930();
goto next_tmp_925532;
next_tmp_925532:
goto tmp_925531;
tmp_925531:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 9 */
}
done_tmp_925932:
}
reg_t genfunc_tmp_925930 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_925927();
goto next_tmp_925759;
next_tmp_925759:
goto tmp_925758;
tmp_925758:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_925929:
return tmp_731146;
}
reg_t genfunc_tmp_925927 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_925529();
goto next_tmp_925924;
next_tmp_925924:
goto tmp_925923;
tmp_925923:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_925926:
return tmp_731087;
}
reg_t genfunc_tmp_925892 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_925529();
goto next_tmp_925836;
next_tmp_925836:
goto tmp_925835;
tmp_925835:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_925891:
return tmp_731906;
}
reg_t genfunc_tmp_925529 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_925496 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_925496 >> 8) == 0)
field_imm = tmp_925496;
else goto fail_tmp_925495;
}
/* commit */
{
tmp_731858 = genfunc_tmp_925440();
goto next_tmp_925498;
next_tmp_925498:
goto tmp_925497;
tmp_925497:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_925528;
fail_tmp_925495:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_925520 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_925520))
field_imm = inv_maskmask(8, tmp_925520);
else goto fail_tmp_925519;
}
/* commit */
{
tmp_731075 = genfunc_tmp_925440();
goto next_tmp_925522;
next_tmp_925522:
goto tmp_925521;
tmp_925521:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_925528;
fail_tmp_925519:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_925440();
goto next_tmp_925526;
next_tmp_925526:
goto tmp_925525;
tmp_925525:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_925528:
return tmp_731142;
}
reg_t genfunc_tmp_925493 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_925462 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_925462 >> 8) == 0)
field_imm = tmp_925462;
else goto fail_tmp_925461;
}
/* commit */
{
tmp_731858 = genfunc_tmp_925440();
goto next_tmp_925464;
next_tmp_925464:
goto tmp_925463;
tmp_925463:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_925492;
fail_tmp_925461:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_925484 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_925484))
field_imm = inv_maskmask(8, tmp_925484);
else goto fail_tmp_925483;
}
/* commit */
{
tmp_731075 = genfunc_tmp_925440();
goto next_tmp_925486;
next_tmp_925486:
goto tmp_925485;
tmp_925485:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_925492;
fail_tmp_925483:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_925440();
goto next_tmp_925490;
next_tmp_925490:
goto tmp_925489;
tmp_925489:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_925492:
return tmp_731862;
}
reg_t genfunc_tmp_925440 (void) {
reg_t tmp_731876;
/* ADDQ_IMM */
{
word_5 tmp_731893;
word_5 field_rc;
word_5 tmp_731894;
word_5 field_ra;
word_64 tmp_731896;
word_8 field_imm;
tmp_731896 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_925425 = tmp_731896;
if ((tmp_925425 >> 8) == 0)
field_imm = tmp_925425;
else goto fail_tmp_925424;
}
/* commit */
tmp_731894 = ref_gpr_reg_for_reading(0 + rm);
tmp_731893 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731893;
field_ra = tmp_731894;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731894);
/* can fail: T   num insns: 1 */
}
goto done_tmp_925439;
fail_tmp_925424:
/* LDA */
{
word_5 tmp_731397;
word_5 field_ra;
word_5 tmp_731398;
word_5 field_rb;
word_64 tmp_731400;
word_16 field_memory_disp;
tmp_731400 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_925433 = tmp_731400;
if ((tmp_925433 >> 16) == 0xFFFFFFFFFFFF || (tmp_925433 >> 16) == 0)
field_memory_disp = (tmp_925433 & 0xFFFF);
else goto fail_tmp_925432;
}
/* commit */
tmp_731398 = ref_gpr_reg_for_reading(0 + rm);
tmp_731397 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731397;
field_rb = tmp_731398;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731398);
/* can fail: T   num insns: 1 */
}
goto done_tmp_925439;
fail_tmp_925432:
/* LDAH */
{
word_5 tmp_731393;
word_5 field_ra;
word_5 tmp_731394;
word_5 field_rb;
word_64 tmp_731396;
word_16 field_memory_disp;
tmp_731396 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_925437 = tmp_731396;
if ((tmp_925437 & 0xFFFF) == 0)
{
word_64 tmp_925438 = (tmp_925437 >> 16);
if ((tmp_925438 >> 16) == 0xFFFFFFFFFFFF || (tmp_925438 >> 16) == 0)
field_memory_disp = (tmp_925438 & 0xFFFF);
else goto fail_tmp_925436;
}
else goto fail_tmp_925436;
}
/* commit */
tmp_731394 = ref_gpr_reg_for_reading(0 + rm);
tmp_731393 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731393;
field_rb = tmp_731394;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731394);
/* can fail: T   num insns: 1 */
}
goto done_tmp_925439;
fail_tmp_925436:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731900 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731900, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_925439:
return tmp_731876;
}
void genfunc_tmp_925394 (void) {
/* STL */
{
word_5 field_rb;
word_64 tmp_731143;
word_16 field_memory_disp;
word_5 tmp_731145;
word_5 field_ra;
tmp_731143 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_925389 = tmp_731143;
if ((tmp_925389 >> 16) == 0xFFFFFFFFFFFF || (tmp_925389 >> 16) == 0)
field_memory_disp = (tmp_925389 & 0xFFFF);
else goto fail_tmp_925388;
}
/* commit */
{
tmp_731145 = genfunc_tmp_925386();
goto next_tmp_925391;
next_tmp_925391:
goto tmp_925390;
tmp_925390:
}
field_ra = tmp_731145;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731145);
/* can fail: T   num insns: 4 */
}
goto done_tmp_925393;
fail_tmp_925388:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
tmp_731142 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731142, ((word_64)disp32));
{
tmp_731146 = genfunc_tmp_925386();
goto next_tmp_924990;
next_tmp_924990:
goto tmp_924989;
tmp_924989:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_925393:
}
reg_t genfunc_tmp_925386 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_925383();
goto next_tmp_925217;
next_tmp_925217:
goto tmp_925216;
tmp_925216:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 3 */
}
done_tmp_925385:
return tmp_731146;
}
reg_t genfunc_tmp_925383 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_731383;
word_16 field_memory_disp;
tmp_731383 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_925381 = tmp_731383;
if ((tmp_925381 >> 16) == 0xFFFFFFFFFFFF || (tmp_925381 >> 16) == 0)
field_memory_disp = (tmp_925381 & 0xFFFF);
else goto fail_tmp_925380;
}
/* commit */
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_925382;
fail_tmp_925380:
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
tmp_731382 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731382, ((word_64)disp32));
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_925382:
return tmp_731087;
}
reg_t genfunc_tmp_925349 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_731383;
word_16 field_memory_disp;
tmp_731383 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_925294 = tmp_731383;
if ((tmp_925294 >> 16) == 0xFFFFFFFFFFFF || (tmp_925294 >> 16) == 0)
field_memory_disp = (tmp_925294 & 0xFFFF);
else goto fail_tmp_925293;
}
/* commit */
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_925348;
fail_tmp_925293:
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
tmp_731382 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731382, ((word_64)disp32));
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_925348:
return tmp_731906;
}
void genfunc_tmp_924984 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_924580();
goto next_tmp_924450;
next_tmp_924450:
goto tmp_924449;
tmp_924449:
}
{
tmp_731146 = genfunc_tmp_924981();
goto next_tmp_924583;
next_tmp_924583:
goto tmp_924582;
tmp_924582:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 11 */
}
done_tmp_924983:
}
reg_t genfunc_tmp_924981 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_924978();
goto next_tmp_924810;
next_tmp_924810:
goto tmp_924809;
tmp_924809:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 6 */
}
done_tmp_924980:
return tmp_731146;
}
reg_t genfunc_tmp_924978 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_924580();
goto next_tmp_924975;
next_tmp_924975:
goto tmp_924974;
tmp_924974:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_924977:
return tmp_731087;
}
reg_t genfunc_tmp_924943 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_924580();
goto next_tmp_924887;
next_tmp_924887:
goto tmp_924886;
tmp_924886:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 5 */
}
done_tmp_924942:
return tmp_731906;
}
reg_t genfunc_tmp_924580 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_924547 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_924547 >> 8) == 0)
field_imm = tmp_924547;
else goto fail_tmp_924546;
}
/* commit */
{
tmp_731858 = genfunc_tmp_924491();
goto next_tmp_924549;
next_tmp_924549:
goto tmp_924548;
tmp_924548:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_924579;
fail_tmp_924546:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_924571 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_924571))
field_imm = inv_maskmask(8, tmp_924571);
else goto fail_tmp_924570;
}
/* commit */
{
tmp_731075 = genfunc_tmp_924491();
goto next_tmp_924573;
next_tmp_924573:
goto tmp_924572;
tmp_924572:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_924579;
fail_tmp_924570:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_924491();
goto next_tmp_924577;
next_tmp_924577:
goto tmp_924576;
tmp_924576:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_924579:
return tmp_731142;
}
reg_t genfunc_tmp_924544 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_924513 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_924513 >> 8) == 0)
field_imm = tmp_924513;
else goto fail_tmp_924512;
}
/* commit */
{
tmp_731858 = genfunc_tmp_924491();
goto next_tmp_924515;
next_tmp_924515:
goto tmp_924514;
tmp_924514:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_924543;
fail_tmp_924512:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_924535 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_924535))
field_imm = inv_maskmask(8, tmp_924535);
else goto fail_tmp_924534;
}
/* commit */
{
tmp_731075 = genfunc_tmp_924491();
goto next_tmp_924537;
next_tmp_924537:
goto tmp_924536;
tmp_924536:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_924543;
fail_tmp_924534:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_924491();
goto next_tmp_924541;
next_tmp_924541:
goto tmp_924540;
tmp_924540:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_924543:
return tmp_731862;
}
reg_t genfunc_tmp_924491 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_924482;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_922917();
goto next_tmp_924484;
next_tmp_924484:
goto tmp_924483;
tmp_924483:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_924490;
fail_tmp_924482:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_924486;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_922917();
goto next_tmp_924488;
next_tmp_924488:
goto tmp_924487;
tmp_924487:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_924490;
fail_tmp_924486:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_922917();
goto next_tmp_924466;
next_tmp_924466:
goto tmp_924465;
tmp_924465:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_924490:
return tmp_731876;
}
void genfunc_tmp_924444 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_924040();
goto next_tmp_923919;
next_tmp_923919:
goto tmp_923918;
tmp_923918:
}
{
tmp_731146 = genfunc_tmp_924441();
goto next_tmp_924043;
next_tmp_924043:
goto tmp_924042;
tmp_924042:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 9 */
}
done_tmp_924443:
}
reg_t genfunc_tmp_924441 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_924438();
goto next_tmp_924270;
next_tmp_924270:
goto tmp_924269;
tmp_924269:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_924440:
return tmp_731146;
}
reg_t genfunc_tmp_924438 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_924040();
goto next_tmp_924435;
next_tmp_924435:
goto tmp_924434;
tmp_924434:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_924437:
return tmp_731087;
}
reg_t genfunc_tmp_924403 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_924040();
goto next_tmp_924347;
next_tmp_924347:
goto tmp_924346;
tmp_924346:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_924402:
return tmp_731906;
}
reg_t genfunc_tmp_924040 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_924007 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_924007 >> 8) == 0)
field_imm = tmp_924007;
else goto fail_tmp_924006;
}
/* commit */
{
tmp_731858 = genfunc_tmp_923951();
goto next_tmp_924009;
next_tmp_924009:
goto tmp_924008;
tmp_924008:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_924039;
fail_tmp_924006:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_924031 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_924031))
field_imm = inv_maskmask(8, tmp_924031);
else goto fail_tmp_924030;
}
/* commit */
{
tmp_731075 = genfunc_tmp_923951();
goto next_tmp_924033;
next_tmp_924033:
goto tmp_924032;
tmp_924032:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_924039;
fail_tmp_924030:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_923951();
goto next_tmp_924037;
next_tmp_924037:
goto tmp_924036;
tmp_924036:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_924039:
return tmp_731142;
}
reg_t genfunc_tmp_924004 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_923973 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_923973 >> 8) == 0)
field_imm = tmp_923973;
else goto fail_tmp_923972;
}
/* commit */
{
tmp_731858 = genfunc_tmp_923951();
goto next_tmp_923975;
next_tmp_923975:
goto tmp_923974;
tmp_923974:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_924003;
fail_tmp_923972:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_923995 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_923995))
field_imm = inv_maskmask(8, tmp_923995);
else goto fail_tmp_923994;
}
/* commit */
{
tmp_731075 = genfunc_tmp_923951();
goto next_tmp_923997;
next_tmp_923997:
goto tmp_923996;
tmp_923996:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_924003;
fail_tmp_923994:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_923951();
goto next_tmp_924001;
next_tmp_924001:
goto tmp_924000;
tmp_924000:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_924003:
return tmp_731862;
}
reg_t genfunc_tmp_923951 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_923948;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + index);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_923950;
fail_tmp_923948:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_923949;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + index);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_923950;
fail_tmp_923949:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_923950:
return tmp_731876;
}
void genfunc_tmp_923913 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_923509();
goto next_tmp_923433;
next_tmp_923433:
goto tmp_923432;
tmp_923432:
}
{
tmp_731146 = genfunc_tmp_923910();
goto next_tmp_923512;
next_tmp_923512:
goto tmp_923511;
tmp_923511:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_923912:
}
reg_t genfunc_tmp_923910 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_923907();
goto next_tmp_923739;
next_tmp_923739:
goto tmp_923738;
tmp_923738:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 3 */
}
done_tmp_923909:
return tmp_731146;
}
reg_t genfunc_tmp_923907 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_923509();
goto next_tmp_923904;
next_tmp_923904:
goto tmp_923903;
tmp_923903:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_923906:
return tmp_731087;
}
reg_t genfunc_tmp_923872 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_923509();
goto next_tmp_923816;
next_tmp_923816:
goto tmp_923815;
tmp_923815:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_923871:
return tmp_731906;
}
reg_t genfunc_tmp_923509 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_923485 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_923485 >> 8) == 0)
field_imm = tmp_923485;
else goto fail_tmp_923484;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + base);
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_923508;
fail_tmp_923484:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_923506 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_923506))
field_imm = inv_maskmask(8, tmp_923506);
else goto fail_tmp_923505;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + base);
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_923508;
fail_tmp_923505:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + base);
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_923508:
return tmp_731142;
}
reg_t genfunc_tmp_923482 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_923460 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_923460 >> 8) == 0)
field_imm = tmp_923460;
else goto fail_tmp_923459;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + base);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_923481;
fail_tmp_923459:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_923479 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_923479))
field_imm = inv_maskmask(8, tmp_923479);
else goto fail_tmp_923478;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + base);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_923481;
fail_tmp_923478:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + base);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_923481:
return tmp_731862;
}
void genfunc_tmp_923427 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_923023();
goto next_tmp_922869;
next_tmp_922869:
goto tmp_922868;
tmp_922868:
}
{
tmp_731146 = genfunc_tmp_923424();
goto next_tmp_923026;
next_tmp_923026:
goto tmp_923025;
tmp_923025:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 9 */
}
done_tmp_923426:
}
reg_t genfunc_tmp_923424 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_923421();
goto next_tmp_923253;
next_tmp_923253:
goto tmp_923252;
tmp_923252:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 5 */
}
done_tmp_923423:
return tmp_731146;
}
reg_t genfunc_tmp_923421 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_923023();
goto next_tmp_923418;
next_tmp_923418:
goto tmp_923417;
tmp_923417:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_923420:
return tmp_731087;
}
reg_t genfunc_tmp_923386 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_923023();
goto next_tmp_923330;
next_tmp_923330:
goto tmp_923329;
tmp_923329:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 4 */
}
done_tmp_923385:
return tmp_731906;
}
reg_t genfunc_tmp_923023 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_922990 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_922990 >> 8) == 0)
field_imm = tmp_922990;
else goto fail_tmp_922989;
}
/* commit */
{
tmp_731858 = genfunc_tmp_922934();
goto next_tmp_922992;
next_tmp_922992:
goto tmp_922991;
tmp_922991:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_923022;
fail_tmp_922989:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_923014 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_923014))
field_imm = inv_maskmask(8, tmp_923014);
else goto fail_tmp_923013;
}
/* commit */
{
tmp_731075 = genfunc_tmp_922934();
goto next_tmp_923016;
next_tmp_923016:
goto tmp_923015;
tmp_923015:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_923022;
fail_tmp_923013:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_922934();
goto next_tmp_923020;
next_tmp_923020:
goto tmp_923019;
tmp_923019:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_923022:
return tmp_731142;
}
reg_t genfunc_tmp_922987 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_922956 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_922956 >> 8) == 0)
field_imm = tmp_922956;
else goto fail_tmp_922955;
}
/* commit */
{
tmp_731858 = genfunc_tmp_922934();
goto next_tmp_922958;
next_tmp_922958:
goto tmp_922957;
tmp_922957:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_922986;
fail_tmp_922955:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_922978 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_922978))
field_imm = inv_maskmask(8, tmp_922978);
else goto fail_tmp_922977;
}
/* commit */
{
tmp_731075 = genfunc_tmp_922934();
goto next_tmp_922980;
next_tmp_922980:
goto tmp_922979;
tmp_922979:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_922986;
fail_tmp_922977:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_922934();
goto next_tmp_922984;
next_tmp_922984:
goto tmp_922983;
tmp_922983:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_922986:
return tmp_731862;
}
reg_t genfunc_tmp_922934 (void) {
reg_t tmp_731876;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + base);
{
tmp_731900 = genfunc_tmp_922917();
goto next_tmp_922885;
next_tmp_922885:
goto tmp_922884;
tmp_922884:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_922933:
return tmp_731876;
}
reg_t genfunc_tmp_922917 (void) {
reg_t tmp_731900;
/* EXTQH */
{
word_5 tmp_731618;
word_5 field_rc;
word_5 tmp_731619;
word_5 field_ra;
word_5 field_rb;
if (64 != ((word_64)scale)) goto fail_tmp_922898;
field_rb = 31;
/* commit */
tmp_731619 = ref_gpr_reg_for_reading(0 + index);
tmp_731618 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731618;
field_ra = tmp_731619;
emit(COMPOSE_EXTQH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731619);
/* can fail: T   num insns: 1 */
}
goto done_tmp_922916;
fail_tmp_922898:
/* EXTQH_IMM */
{
word_5 tmp_731614;
word_5 field_rc;
word_5 tmp_731615;
word_5 field_ra;
word_64 tmp_731617;
word_8 field_imm;
tmp_731617 = ((word_64)scale);
{
word_64 tmp_922900 = ((64 - tmp_731617) & 0xFFFFFFFFFFFFFFFF);
if (tmp_922900 % 8 == 0)
{
word_64 tmp_922901 = (tmp_922900 / 8);
if ((tmp_922901 & 7) == tmp_922901)
{
word_64 tmp_922902 = tmp_922901;
if ((tmp_922902 >> 8) == 0)
field_imm = tmp_922902;
else goto fail_tmp_922899;
}
else goto fail_tmp_922899;
}
else goto fail_tmp_922899;
}
/* commit */
tmp_731615 = ref_gpr_reg_for_reading(0 + index);
tmp_731614 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731614;
field_ra = tmp_731615;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731615);
/* can fail: T   num insns: 1 */
}
goto done_tmp_922916;
fail_tmp_922899:
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 tmp_731241;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_922908;
field_rb = 31;
/* commit */
tmp_731241 = ref_gpr_reg_for_reading(0 + index);
tmp_731240 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_ra = tmp_731241;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731241);
/* can fail: T   num insns: 1 */
}
goto done_tmp_922916;
fail_tmp_922908:
/* S4ADDQ_IMM */
{
word_5 tmp_731236;
word_5 field_rc;
word_5 tmp_731237;
word_5 field_ra;
word_64 tmp_731239;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_922909;
tmp_731239 = 0;
field_imm = 0;
/* commit */
tmp_731237 = ref_gpr_reg_for_reading(0 + index);
tmp_731236 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731236;
field_ra = tmp_731237;
emit(COMPOSE_S4ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731237);
/* can fail: T   num insns: 1 */
}
goto done_tmp_922916;
fail_tmp_922909:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 tmp_731209;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_922911;
field_rb = 31;
/* commit */
tmp_731209 = ref_gpr_reg_for_reading(0 + index);
tmp_731208 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_ra = tmp_731209;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731209);
/* can fail: T   num insns: 1 */
}
goto done_tmp_922916;
fail_tmp_922911:
/* S8ADDQ_IMM */
{
word_5 tmp_731204;
word_5 field_rc;
word_5 tmp_731205;
word_5 field_ra;
word_64 tmp_731207;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_922912;
tmp_731207 = 0;
field_imm = 0;
/* commit */
tmp_731205 = ref_gpr_reg_for_reading(0 + index);
tmp_731204 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731204;
field_ra = tmp_731205;
emit(COMPOSE_S8ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731205);
/* can fail: T   num insns: 1 */
}
goto done_tmp_922916;
fail_tmp_922912:
/* SLL */
{
word_5 tmp_731176;
word_5 field_rc;
word_5 tmp_731177;
word_5 field_ra;
word_5 field_rb;
if (0 != ((word_64)scale)) goto fail_tmp_922913;
field_rb = 31;
/* commit */
tmp_731177 = ref_gpr_reg_for_reading(0 + index);
tmp_731176 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731176;
field_ra = tmp_731177;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731177);
/* can fail: T   num insns: 1 */
}
goto done_tmp_922916;
fail_tmp_922913:
/* SLL_IMM */
{
word_5 tmp_731172;
word_5 field_rc;
word_5 tmp_731173;
word_5 field_ra;
word_64 tmp_731175;
word_8 field_imm;
tmp_731175 = ((word_64)scale);
field_imm = tmp_731175;
/* commit */
tmp_731173 = ref_gpr_reg_for_reading(0 + index);
tmp_731172 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731172;
field_ra = tmp_731173;
emit(COMPOSE_SLL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731173);
/* can fail: NIL   num insns: 1 */
}
done_tmp_922916:
return tmp_731900;
}
void genfunc_tmp_922863 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_922459();
goto next_tmp_922340;
next_tmp_922340:
goto tmp_922339;
tmp_922339:
}
{
tmp_731146 = genfunc_tmp_922860();
goto next_tmp_922462;
next_tmp_922462:
goto tmp_922461;
tmp_922461:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 7 */
}
done_tmp_922862:
}
reg_t genfunc_tmp_922860 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_922857();
goto next_tmp_922689;
next_tmp_922689:
goto tmp_922688;
tmp_922688:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 4 */
}
done_tmp_922859:
return tmp_731146;
}
reg_t genfunc_tmp_922857 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_922459();
goto next_tmp_922854;
next_tmp_922854:
goto tmp_922853;
tmp_922853:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 3 */
}
done_tmp_922856:
return tmp_731087;
}
reg_t genfunc_tmp_922822 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_922459();
goto next_tmp_922766;
next_tmp_922766:
goto tmp_922765;
tmp_922765:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 3 */
}
done_tmp_922821:
return tmp_731906;
}
reg_t genfunc_tmp_922459 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_922426 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_922426 >> 8) == 0)
field_imm = tmp_922426;
else goto fail_tmp_922425;
}
/* commit */
{
tmp_731858 = genfunc_tmp_922370();
goto next_tmp_922428;
next_tmp_922428:
goto tmp_922427;
tmp_922427:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_922458;
fail_tmp_922425:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_922450 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_922450))
field_imm = inv_maskmask(8, tmp_922450);
else goto fail_tmp_922449;
}
/* commit */
{
tmp_731075 = genfunc_tmp_922370();
goto next_tmp_922452;
next_tmp_922452:
goto tmp_922451;
tmp_922451:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_922458;
fail_tmp_922449:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_922370();
goto next_tmp_922456;
next_tmp_922456:
goto tmp_922455;
tmp_922455:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_922458:
return tmp_731142;
}
reg_t genfunc_tmp_922423 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_922392 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_922392 >> 8) == 0)
field_imm = tmp_922392;
else goto fail_tmp_922391;
}
/* commit */
{
tmp_731858 = genfunc_tmp_922370();
goto next_tmp_922394;
next_tmp_922394:
goto tmp_922393;
tmp_922393:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_922422;
fail_tmp_922391:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_922414 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_922414))
field_imm = inv_maskmask(8, tmp_922414);
else goto fail_tmp_922413;
}
/* commit */
{
tmp_731075 = genfunc_tmp_922370();
goto next_tmp_922416;
next_tmp_922416:
goto tmp_922415;
tmp_922415:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_922422;
fail_tmp_922413:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_922370();
goto next_tmp_922420;
next_tmp_922420:
goto tmp_922419;
tmp_922419:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_922422:
return tmp_731862;
}
reg_t genfunc_tmp_922370 (void) {
reg_t tmp_731876;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + base);
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_922369:
return tmp_731876;
}
void genfunc_tmp_922334 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_921930();
goto next_tmp_921854;
next_tmp_921854:
goto tmp_921853;
tmp_921853:
}
{
tmp_731146 = genfunc_tmp_922331();
goto next_tmp_921933;
next_tmp_921933:
goto tmp_921932;
tmp_921932:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_922333:
}
reg_t genfunc_tmp_922331 (void) {
reg_t tmp_731146;
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
{
tmp_731087 = genfunc_tmp_922328();
goto next_tmp_922160;
next_tmp_922160:
goto tmp_922159;
tmp_922159:
}
tmp_731089 = ref_gpr_reg_for_reading(0 + reg);
tmp_731086 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 3 */
}
done_tmp_922330:
return tmp_731146;
}
reg_t genfunc_tmp_922328 (void) {
reg_t tmp_731087;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_921930();
goto next_tmp_922325;
next_tmp_922325:
goto tmp_922324;
tmp_922324:
}
tmp_731381 = tmp_731087 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_922327:
return tmp_731087;
}
reg_t genfunc_tmp_922293 (void) {
reg_t tmp_731906;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_921930();
goto next_tmp_922237;
next_tmp_922237:
goto tmp_922236;
tmp_922236:
}
tmp_731381 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_922292:
return tmp_731906;
}
reg_t genfunc_tmp_921930 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_921906 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_921906 >> 8) == 0)
field_imm = tmp_921906;
else goto fail_tmp_921905;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + rm);
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_921929;
fail_tmp_921905:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_921927 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_921927))
field_imm = inv_maskmask(8, tmp_921927);
else goto fail_tmp_921926;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + rm);
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_921929;
fail_tmp_921926:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + rm);
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_921929:
return tmp_731142;
}
reg_t genfunc_tmp_921903 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_921881 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_921881 >> 8) == 0)
field_imm = tmp_921881;
else goto fail_tmp_921880;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + rm);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_921902;
fail_tmp_921880:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_921900 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_921900))
field_imm = inv_maskmask(8, tmp_921900);
else goto fail_tmp_921899;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + rm);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_921902;
fail_tmp_921899:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + rm);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_921902:
return tmp_731862;
}
