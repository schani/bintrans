#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compile_mov_moffs32_eax_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 )
{
genfunc_tmp_873870();
goto next_tmp_873865;
next_tmp_873865:
goto finish_tmp_873864;
finish_tmp_873864:
}
}
void genfunc_tmp_873870 (void) {
/* STL */
{
word_5 field_rb;
word_64 tmp_731143;
word_16 field_memory_disp;
word_5 tmp_731145;
word_5 field_ra;
tmp_731143 = ((word_64)imm32);
field_rb = 31;
{
word_64 tmp_873868 = tmp_731143;
if ((tmp_873868 >> 16) == 0xFFFFFFFFFFFF || (tmp_873868 >> 16) == 0)
field_memory_disp = (tmp_873868 & 0xFFFF);
else goto fail_tmp_873867;
}
/* commit */
tmp_731145 = ref_gpr_reg_for_reading(0 + 0);
field_ra = tmp_731145;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731145);
/* can fail: T   num insns: 1 */
}
goto done_tmp_873869;
fail_tmp_873867:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
tmp_731142 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731142, ((word_64)imm32));
tmp_731146 = ref_gpr_reg_for_reading(0 + 0);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 2 */
}
done_tmp_873869:
}
