#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compiler_tmp_1007216 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_1007207 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_1007212 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_1007205 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_1007195 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_1007204 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_1007203 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_1007200 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_997078 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_997073 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997071 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_997024 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997069 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997028 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997029 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997032 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997062 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997066 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997063 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997054 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997059 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997055 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997058 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997033 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997036 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997046 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997053 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997047 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997052 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997050 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997039 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997042 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997044 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997043 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997040 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_997034 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_1007216 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 6 6 T)
*/
{
{
reg_t tmp_1007217;
rhs_func(&tmp_1007217, 11, env);
emit(COMPOSE_AND_IMM(tmp_1007217, 1, tmp_1007217));
unref_integer_reg(tmp_1007217);
}
}

void compiler_tmp_1007207 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (=
  (CASE
   ((0 1 2)
    (MEM
     (CASE
      ((0)
       (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
        ((4)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))
        ((5) (FIELD DISP32 NIL NIL))))
      ((1)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
        ((4)
         (+ (SEX (FIELD DISP8 NIL NIL))
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0))))))))
      ((2)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
        ((4)
         (+ (FIELD DISP32 NIL NIL)
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0)))))))))))
   ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
  (INTEGER 0))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_1007209 = alloc_label(), tmp_1007210 = alloc_label(), tmp_1007211 = alloc_label();
reg_t tmp_1007208;
compiler_tmp_1007212(tmp_1007209, tmp_1007210, env);

tmp_1007208 = ref_integer_reg_for_writing(-1);
emit_label(tmp_1007209);
push_alloc();
compiler_tmp_1007203(&tmp_1007208, tmp_1007208 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_1007211);
emit_label(tmp_1007210);
push_alloc();
compiler_tmp_1007204(&tmp_1007208, tmp_1007208 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_1007211);
free_label(tmp_1007209);
free_label(tmp_1007210);
free_label(tmp_1007211);
if (foreign_target == -1)
*target = tmp_1007208;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_1007208, *target));
unref_integer_reg(tmp_1007208);
}

}
}

void compiler_tmp_1007212 (label_t true_label, label_t false_label, void **env)
/*
(=
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (INTEGER 0))
*/
{
{
reg_t tmp_1007213, tmp_1007214, tmp_1007215;
compiler_tmp_997028(&tmp_1007213, -1, env);
compiler_tmp_997053(&tmp_1007214, -1, env);
tmp_1007215 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_CMPEQ(tmp_1007213, tmp_1007214, tmp_1007215));
unref_integer_reg(tmp_1007213);
unref_integer_reg(tmp_1007214);
emit_branch(COMPOSE_BEQ(tmp_1007215, 0), false_label);
unref_integer_reg(tmp_1007215);
emit_branch(COMPOSE_BR(31, 0), true_label);
}
}

void compiler_tmp_1007205 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 7 7 T)
*/
{
{
reg_t tmp_1007206;
rhs_func(&tmp_1007206, 12, env);
emit(COMPOSE_AND_IMM(tmp_1007206, 1, tmp_1007206));
unref_integer_reg(tmp_1007206);
}
}

void compiler_tmp_1007195 (reg_t *target, int foreign_target, void **env)
/*
(IF
 (BIT-SET-P
  (CASE
   ((0 1 2)
    (MEM
     (CASE
      ((0)
       (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
        ((4)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))
        ((5) (FIELD DISP32 NIL NIL))))
      ((1)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
        ((4)
         (+ (SEX (FIELD DISP8 NIL NIL))
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0))))))))
      ((2)
       (CASE
        ((0 1 2 3 5 6 7)
         (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
        ((4)
         (+ (FIELD DISP32 NIL NIL)
          (+
           (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
            ((5)
             (CASE ((0) (FIELD DISP32 NIL NIL))
              ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
           (CASE
            ((0 1 2 3 5 6 7)
             (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
              (ZEX (FIELD SCALE NIL NIL))))
            ((4) (INTEGER 0)))))))))))
   ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
  (- (INTEGER 32) (INTEGER 1)))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_1007197 = alloc_label(), tmp_1007198 = alloc_label(), tmp_1007199 = alloc_label();
reg_t tmp_1007196;
compiler_tmp_1007200(tmp_1007197, tmp_1007198, env);

tmp_1007196 = ref_integer_reg_for_writing(-1);
emit_label(tmp_1007197);
push_alloc();
compiler_tmp_1007203(&tmp_1007196, tmp_1007196 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_1007199);
emit_label(tmp_1007198);
push_alloc();
compiler_tmp_1007204(&tmp_1007196, tmp_1007196 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_1007199);
free_label(tmp_1007197);
free_label(tmp_1007198);
free_label(tmp_1007199);
if (foreign_target == -1)
*target = tmp_1007196;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_1007196, *target));
unref_integer_reg(tmp_1007196);
}

}
}

void compiler_tmp_1007204 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_1007203 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 1)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 1);
}

void compiler_tmp_1007200 (label_t true_label, label_t false_label, void **env)
/*
(BIT-SET-P
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (- (INTEGER 32) (INTEGER 1)))
*/
{
{
reg_t tmp_1007201, tmp_1007202;
compiler_tmp_997028(&tmp_1007201, -1, env);
tmp_1007202 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_SRL_IMM(tmp_1007201, (32 - 1), tmp_1007202));
unref_integer_reg(tmp_1007201);
emit_branch(COMPOSE_BLBS(tmp_1007202, 0), true_label);
unref_integer_reg(tmp_1007202);
emit_branch(COMPOSE_BR(31, 0), false_label);
}
}

void compiler_tmp_997078 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 0 0 T)
*/
{
{
reg_t tmp_997079;
rhs_func(&tmp_997079, 10, env);
emit(COMPOSE_AND_IMM(tmp_997079, 1, tmp_997079));
unref_integer_reg(tmp_997079);
}
}

void compiler_tmp_997073 (reg_t *target, int foreign_target, void **env)
/*
(+CARRY
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (REGISTER NIL GPR (FIELD REG NIL NIL)))
*/
{
{
reg_t tmp_997076, tmp_997077, tmp_997074, tmp_997075;
compiler_tmp_997028(&tmp_997076, -1, env);
tmp_997074 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ZAPNOT_IMM(tmp_997076, 15, tmp_997074));
unref_integer_reg(tmp_997076);
compiler_tmp_997069(&tmp_997077, -1, env);
tmp_997075 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ZAPNOT_IMM(tmp_997077, 15, tmp_997075));
unref_integer_reg(tmp_997077);*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDQ(tmp_997074, tmp_997075, *target));
unref_integer_reg(tmp_997074);
unref_integer_reg(tmp_997075);
emit(COMPOSE_SRL_IMM(*target, 32, *target));
}
}

void compiler_tmp_997071 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 11 11 T)
*/
{
{
reg_t tmp_997072;
rhs_func(&tmp_997072, 13, env);
emit(COMPOSE_AND_IMM(tmp_997072, 1, tmp_997072));
unref_integer_reg(tmp_997072);
}
}

void compiler_tmp_997024 (reg_t *target, int foreign_target, void **env)
/*
(+OVERFLOW
 (CASE
  ((0 1 2)
   (MEM
    (CASE
     ((0)
      (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
       ((4)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))
       ((5) (FIELD DISP32 NIL NIL))))
     ((1)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
       ((4)
        (+ (SEX (FIELD DISP8 NIL NIL))
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0))))))))
     ((2)
      (CASE
       ((0 1 2 3 5 6 7)
        (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
       ((4)
        (+ (FIELD DISP32 NIL NIL)
         (+
          (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
           ((5)
            (CASE ((0) (FIELD DISP32 NIL NIL))
             ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
          (CASE
           ((0 1 2 3 5 6 7)
            (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
             (ZEX (FIELD SCALE NIL NIL))))
           ((4) (INTEGER 0)))))))))))
  ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
 (REGISTER NIL GPR (FIELD REG NIL NIL)))
*/
{
{
reg_t tmp_997025, tmp_997026, tmp_997027;
compiler_tmp_997028(&tmp_997025, -1, env);
compiler_tmp_997069(&tmp_997026, -1, env);
tmp_997027 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ADDQ(tmp_997025, tmp_997026, tmp_997027));
unref_integer_reg(tmp_997025);
unref_integer_reg(tmp_997026);
emit(COMPOSE_SRA_IMM(tmp_997027, 32, tmp_997027));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDQ_IMM(31, 1, *target));
emit(COMPOSE_CMOVEQ_IMM(tmp_997027, 0, *target));
emit(COMPOSE_NOT(tmp_997027, tmp_997027));
emit(COMPOSE_CMOVEQ_IMM(tmp_997027, 0, *target));
unref_integer_reg(tmp_997027);
}
}

void compiler_tmp_997069 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD REG NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + reg));
else {
reg_t tmp_997070 = ref_integer_reg_for_reading((0 + reg));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_997070, *target));
unref_integer_reg(tmp_997070);
}
}

void compiler_tmp_997028 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2)
  (MEM
   (CASE
    ((0)
     (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
      ((4)
       (+
        (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
         ((5)
          (CASE ((0) (FIELD DISP32 NIL NIL))
           ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
        (CASE
         ((0 1 2 3 5 6 7)
          (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
           (ZEX (FIELD SCALE NIL NIL))))
         ((4) (INTEGER 0)))))
      ((5) (FIELD DISP32 NIL NIL))))
    ((1)
     (CASE
      ((0 1 2 3 5 6 7)
       (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
      ((4)
       (+ (SEX (FIELD DISP8 NIL NIL))
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0))))))))
    ((2)
     (CASE
      ((0 1 2 3 5 6 7)
       (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
      ((4)
       (+ (FIELD DISP32 NIL NIL)
        (+
         (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
          ((5)
           (CASE ((0) (FIELD DISP32 NIL NIL))
            ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
         (CASE
          ((0 1 2 3 5 6 7)
           (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
            (ZEX (FIELD SCALE NIL NIL))))
          ((4) (INTEGER 0)))))))))))
 ((3) (REGISTER NIL GPR (FIELD RM NIL NIL))))
*/
{
switch (mod) {
case 0:
case 1:
case 2:
compiler_tmp_997029(&(*target), foreign_target, env);
break;
case 3:
compiler_tmp_997034(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_997029 (reg_t *target, int foreign_target, void **env)
/*
(MEM
 (CASE
  ((0)
   (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
    ((4)
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0)))))
    ((5) (FIELD DISP32 NIL NIL))))
  ((1)
   (CASE
    ((0 1 2 3 5 6 7)
     (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
    ((4)
     (+ (SEX (FIELD DISP8 NIL NIL))
      (+
       (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
        ((5)
         (CASE ((0) (FIELD DISP32 NIL NIL))
          ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
       (CASE
        ((0 1 2 3 5 6 7)
         (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
          (ZEX (FIELD SCALE NIL NIL))))
        ((4) (INTEGER 0))))))))
  ((2)
   (CASE
    ((0 1 2 3 5 6 7)
     (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
    ((4)
     (+ (FIELD DISP32 NIL NIL)
      (+
       (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
        ((5)
         (CASE ((0) (FIELD DISP32 NIL NIL))
          ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
       (CASE
        ((0 1 2 3 5 6 7)
         (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
          (ZEX (FIELD SCALE NIL NIL))))
        ((4) (INTEGER 0))))))))))
*/
{
{
reg_t tmp_997030, tmp_997031;
compiler_tmp_997032(&tmp_997030, -1, env);
#ifdef EMU_I386
tmp_997031 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_ZAPNOT_IMM(tmp_997030, 15, tmp_997031));
unref_integer_reg(tmp_997030);
#else
tmp_997031 = tmp_997030;
#endif
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_mem_32(*target, tmp_997031);
unref_integer_reg(tmp_997031);
}
}

void compiler_tmp_997032 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0)
  (CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
   ((4)
    (+
     (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
      ((5)
       (CASE ((0) (FIELD DISP32 NIL NIL))
        ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
     (CASE
      ((0 1 2 3 5 6 7)
       (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
        (ZEX (FIELD SCALE NIL NIL))))
      ((4) (INTEGER 0)))))
   ((5) (FIELD DISP32 NIL NIL))))
 ((1)
  (CASE
   ((0 1 2 3 5 6 7)
    (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
   ((4)
    (+ (SEX (FIELD DISP8 NIL NIL))
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0))))))))
 ((2)
  (CASE
   ((0 1 2 3 5 6 7)
    (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
   ((4)
    (+ (FIELD DISP32 NIL NIL)
     (+
      (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
       ((5)
        (CASE ((0) (FIELD DISP32 NIL NIL))
         ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
      (CASE
       ((0 1 2 3 5 6 7)
        (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
         (ZEX (FIELD SCALE NIL NIL))))
       ((4) (INTEGER 0)))))))))
*/
{
switch (mod) {
case 0:
compiler_tmp_997033(&(*target), foreign_target, env);
break;
case 1:
compiler_tmp_997054(&(*target), foreign_target, env);
break;
case 2:
compiler_tmp_997062(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_997062 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL)))
 ((4)
  (+ (FIELD DISP32 NIL NIL)
   (+
    (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
     ((5)
      (CASE ((0) (FIELD DISP32 NIL NIL))
       ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
    (CASE
     ((0 1 2 3 5 6 7)
      (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
       (ZEX (FIELD SCALE NIL NIL))))
     ((4) (INTEGER 0)))))))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_997063(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_997066(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_997066 (reg_t *target, int foreign_target, void **env)
/*
(+ (FIELD DISP32 NIL NIL)
 (+
  (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
   ((5)
    (CASE ((0) (FIELD DISP32 NIL NIL))
     ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
  (CASE
   ((0 1 2 3 5 6 7)
    (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
     (ZEX (FIELD SCALE NIL NIL))))
   ((4) (INTEGER 0)))))
*/
{
{
reg_t tmp_997067, tmp_997068;
compiler_tmp_997043(&tmp_997067, -1, env);
compiler_tmp_997036(&tmp_997068, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_997067, tmp_997068, *target));
unref_integer_reg(tmp_997067);
unref_integer_reg(tmp_997068);
}
}

void compiler_tmp_997063 (reg_t *target, int foreign_target, void **env)
/*
(+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (FIELD DISP32 NIL NIL))
*/
{
{
reg_t tmp_997064, tmp_997065;
compiler_tmp_997034(&tmp_997064, -1, env);
compiler_tmp_997043(&tmp_997065, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_997064, tmp_997065, *target));
unref_integer_reg(tmp_997064);
unref_integer_reg(tmp_997065);
}
}

void compiler_tmp_997054 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL))))
 ((4)
  (+ (SEX (FIELD DISP8 NIL NIL))
   (+
    (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
     ((5)
      (CASE ((0) (FIELD DISP32 NIL NIL))
       ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
    (CASE
     ((0 1 2 3 5 6 7)
      (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
       (ZEX (FIELD SCALE NIL NIL))))
     ((4) (INTEGER 0)))))))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_997055(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_997059(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_997059 (reg_t *target, int foreign_target, void **env)
/*
(+ (SEX (FIELD DISP8 NIL NIL))
 (+
  (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
   ((5)
    (CASE ((0) (FIELD DISP32 NIL NIL))
     ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
  (CASE
   ((0 1 2 3 5 6 7)
    (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
     (ZEX (FIELD SCALE NIL NIL))))
   ((4) (INTEGER 0)))))
*/
{
{
reg_t tmp_997060, tmp_997061;
compiler_tmp_997058(&tmp_997060, -1, env);
compiler_tmp_997036(&tmp_997061, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_997060, tmp_997061, *target));
unref_integer_reg(tmp_997060);
unref_integer_reg(tmp_997061);
}
}

void compiler_tmp_997055 (reg_t *target, int foreign_target, void **env)
/*
(+ (REGISTER NIL GPR (FIELD RM NIL NIL)) (SEX (FIELD DISP8 NIL NIL)))
*/
{
{
reg_t tmp_997056, tmp_997057;
compiler_tmp_997034(&tmp_997056, -1, env);
compiler_tmp_997058(&tmp_997057, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_997056, tmp_997057, *target));
unref_integer_reg(tmp_997056);
unref_integer_reg(tmp_997057);
}
}

void compiler_tmp_997058 (reg_t *target, int foreign_target, void **env)
/*
(SEX (FIELD DISP8 NIL NIL))
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, ((disp8 & 0x80) ? ((word_32)disp8 | 0xFFFFFF00) : (word_32)disp8));
}

void compiler_tmp_997033 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0 1 2 3 6 7) (REGISTER NIL GPR (FIELD RM NIL NIL)))
 ((4)
  (+
   (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
    ((5)
     (CASE ((0) (FIELD DISP32 NIL NIL))
      ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
   (CASE
    ((0 1 2 3 5 6 7)
     (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
      (ZEX (FIELD SCALE NIL NIL))))
    ((4) (INTEGER 0)))))
 ((5) (FIELD DISP32 NIL NIL)))
*/
{
switch (rm) {
case 0:
case 1:
case 2:
case 3:
case 6:
case 7:
compiler_tmp_997034(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_997036(&(*target), foreign_target, env);
break;
case 5:
compiler_tmp_997043(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_997036 (reg_t *target, int foreign_target, void **env)
/*
(+
 (CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
  ((5)
   (CASE ((0) (FIELD DISP32 NIL NIL))
    ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
 (CASE
  ((0 1 2 3 5 6 7)
   (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
    (ZEX (FIELD SCALE NIL NIL))))
  ((4) (INTEGER 0))))
*/
{
{
reg_t tmp_997037, tmp_997038;
compiler_tmp_997039(&tmp_997037, -1, env);
compiler_tmp_997046(&tmp_997038, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_ADDL(tmp_997037, tmp_997038, *target));
unref_integer_reg(tmp_997037);
unref_integer_reg(tmp_997038);
}
}

void compiler_tmp_997046 (reg_t *target, int foreign_target, void **env)
/*
(CASE
 ((0 1 2 3 5 6 7)
  (SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL))
   (ZEX (FIELD SCALE NIL NIL))))
 ((4) (INTEGER 0)))
*/
{
switch (index) {
case 0:
case 1:
case 2:
case 3:
case 5:
case 6:
case 7:
compiler_tmp_997047(&(*target), foreign_target, env);
break;
case 4:
compiler_tmp_997053(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_997053 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_997047 (reg_t *target, int foreign_target, void **env)
/*
(SHIFTL (REGISTER NIL GPR (FIELD INDEX NIL NIL)) (ZEX (FIELD SCALE NIL NIL)))
*/
{
{
reg_t tmp_997048, tmp_997049;
compiler_tmp_997050(&tmp_997048, -1, env);
compiler_tmp_997052(&tmp_997049, -1, env);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_SLL(tmp_997048, tmp_997049, *target));
unref_integer_reg(tmp_997048);
unref_integer_reg(tmp_997049);
emit(COMPOSE_ADDL((*target), 31, (*target)));
}
}

void compiler_tmp_997052 (reg_t *target, int foreign_target, void **env)
/*
(ZEX (FIELD SCALE NIL NIL))
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, scale);
}

void compiler_tmp_997050 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD INDEX NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + index));
else {
reg_t tmp_997051 = ref_integer_reg_for_reading((0 + index));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_997051, *target));
unref_integer_reg(tmp_997051);
}
}

void compiler_tmp_997039 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0 1 2 3 4 6 7) (REGISTER NIL GPR (FIELD BASE NIL NIL)))
 ((5)
  (CASE ((0) (FIELD DISP32 NIL NIL))
   ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))))
*/
{
switch (base) {
case 0:
case 1:
case 2:
case 3:
case 4:
case 6:
case 7:
compiler_tmp_997040(&(*target), foreign_target, env);
break;
case 5:
compiler_tmp_997042(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_997042 (reg_t *target, int foreign_target, void **env)
/*
(CASE ((0) (FIELD DISP32 NIL NIL)) ((1 2 3) (REGISTER EBP GPR (INTEGER 5))))
*/
{
switch (mod) {
case 0:
compiler_tmp_997043(&(*target), foreign_target, env);
break;
case 1:
case 2:
case 3:
compiler_tmp_997044(&(*target), foreign_target, env);
break;
}
}

void compiler_tmp_997044 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER EBP GPR (INTEGER 5))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading(5);
else {
reg_t tmp_997045 = ref_integer_reg_for_reading(5);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_997045, *target));
unref_integer_reg(tmp_997045);
}
}

void compiler_tmp_997043 (reg_t *target, int foreign_target, void **env)
/*
(FIELD DISP32 NIL NIL)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, disp32);
}

void compiler_tmp_997040 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD BASE NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + base));
else {
reg_t tmp_997041 = ref_integer_reg_for_reading((0 + base));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_997041, *target));
unref_integer_reg(tmp_997041);
}
}

void compiler_tmp_997034 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER NIL GPR (FIELD RM NIL NIL))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading((0 + rm));
else {
reg_t tmp_997035 = ref_integer_reg_for_reading((0 + rm));
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_997035, *target));
unref_integer_reg(tmp_997035);
}
}

void compile_add_rm32_r32_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_997024;
killed |= 0x800;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_997071(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_997073;
killed |= 0x1;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_997078(rhs_func, env);
}
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_997494();
goto next_tmp_997081;
next_tmp_997081:
goto finish_tmp_997080;
finish_tmp_997080:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_997969();
goto next_tmp_997497;
next_tmp_997497:
goto finish_tmp_997496;
finish_tmp_997496:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_998488();
goto next_tmp_997972;
next_tmp_997972:
goto finish_tmp_997971;
finish_tmp_997971:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_998904();
goto next_tmp_998491;
next_tmp_998491:
goto finish_tmp_998490;
finish_tmp_998490:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_999381();
goto next_tmp_998907;
next_tmp_998907:
goto finish_tmp_998906;
finish_tmp_998906:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_999870();
goto next_tmp_999384;
next_tmp_999384:
goto finish_tmp_999383;
finish_tmp_999383:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_1000188();
goto next_tmp_999873;
next_tmp_999873:
goto finish_tmp_999872;
finish_tmp_999872:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; }))
{
genfunc_tmp_1000188();
goto next_tmp_1000191;
next_tmp_1000191:
goto finish_tmp_1000190;
finish_tmp_1000190:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_1000673();
goto next_tmp_1000194;
next_tmp_1000194:
goto finish_tmp_1000193;
finish_tmp_1000193:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_1001162();
goto next_tmp_1000676;
next_tmp_1000676:
goto finish_tmp_1000675;
finish_tmp_1000675:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_1001651();
goto next_tmp_1001165;
next_tmp_1001165:
goto finish_tmp_1001164;
finish_tmp_1001164:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_1002128();
goto next_tmp_1001654;
next_tmp_1001654:
goto finish_tmp_1001653;
finish_tmp_1001653:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_1002644();
goto next_tmp_1002131;
next_tmp_1002131:
goto finish_tmp_1002130;
finish_tmp_1002130:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_1003164();
goto next_tmp_1002647;
next_tmp_1002647:
goto finish_tmp_1002646;
finish_tmp_1002646:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_1003641();
goto next_tmp_1003167;
next_tmp_1003167:
goto finish_tmp_1003166;
finish_tmp_1003166:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_1004123();
goto next_tmp_1003644;
next_tmp_1003644:
goto finish_tmp_1003643;
finish_tmp_1003643:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_1004612();
goto next_tmp_1004126;
next_tmp_1004126:
goto finish_tmp_1004125;
finish_tmp_1004125:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_1005101();
goto next_tmp_1004615;
next_tmp_1004615:
goto finish_tmp_1004614;
finish_tmp_1004614:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_1005578();
goto next_tmp_1005104;
next_tmp_1005104:
goto finish_tmp_1005103;
finish_tmp_1005103:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0)&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_1006067();
goto next_tmp_1005581;
next_tmp_1005581:
goto finish_tmp_1005580;
finish_tmp_1005580:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0))&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_1006556();
goto next_tmp_1006070;
next_tmp_1006070:
goto finish_tmp_1006069;
finish_tmp_1006069:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; })&& ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_1007033();
goto next_tmp_1006559;
next_tmp_1006559:
goto finish_tmp_1006558;
finish_tmp_1006558:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 3; })&& ({ word_2 tmp = mod; 0 || tmp == 3; }))
{
genfunc_tmp_1007193();
goto next_tmp_1007036;
next_tmp_1007036:
goto finish_tmp_1007035;
finish_tmp_1007035:
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_1007195;
killed |= 0x80;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_1007205(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_1007207;
killed |= 0x40;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_1007216(rhs_func, env);
}
}
}
void genfunc_tmp_1007193 (void) {
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
tmp_982363 = ref_gpr_reg_for_reading(0 + rm);
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982362);
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 1 */
}
done_tmp_1007192:
}
reg_t genfunc_tmp_1007134 (void) {
reg_t tmp_1007038;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
tmp_982363 = ref_gpr_reg_for_reading(0 + rm);
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1007038 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 1 */
}
done_tmp_1007133:
return tmp_1007038;
}
reg_t genfunc_tmp_1007096 (void) {
reg_t tmp_1007055;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
tmp_982363 = ref_gpr_reg_for_reading(0 + rm);
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1007055 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 1 */
}
done_tmp_1007095:
return tmp_1007055;
}
void genfunc_tmp_1007033 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_1006720();
goto next_tmp_1006563;
next_tmp_1006563:
goto tmp_1006562;
tmp_1006562:
}
{
tmp_981603 = genfunc_tmp_1007030();
goto next_tmp_1006724;
next_tmp_1006724:
goto tmp_1006723;
tmp_1006723:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_1007032:
}
reg_t genfunc_tmp_1007030 (void) {
reg_t tmp_1006722;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1006935();
goto next_tmp_1006731;
next_tmp_1006731:
goto tmp_1006730;
tmp_1006730:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1006722 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1007029:
return tmp_1006722;
}
reg_t genfunc_tmp_1006992 (void) {
reg_t tmp_1006947;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1006935();
goto next_tmp_1006956;
next_tmp_1006956:
goto tmp_1006955;
tmp_1006955:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1006947 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1006991:
return tmp_1006947;
}
reg_t genfunc_tmp_1006935 (void) {
reg_t tmp_1006729;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1006720();
goto next_tmp_1006909;
next_tmp_1006909:
goto tmp_1006908;
tmp_1006908:
}
tmp_981838 = tmp_1006729 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1006934:
return tmp_1006729;
}
reg_t genfunc_tmp_1006878 (void) {
reg_t tmp_1006814;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1006839 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1006839 >> 8) == 0)
field_imm = tmp_1006839;
else goto fail_tmp_1006838;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1006790();
goto next_tmp_1006842;
next_tmp_1006842:
goto tmp_1006841;
tmp_1006841:
}
tmp_982314 = tmp_1006814 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1006877;
fail_tmp_1006838:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1006867 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1006867))
field_imm = inv_maskmask(8, tmp_1006867);
else goto fail_tmp_1006866;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1006790();
goto next_tmp_1006870;
next_tmp_1006870:
goto tmp_1006869;
tmp_1006869:
}
tmp_981531 = tmp_1006814 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1006877;
fail_tmp_1006866:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1006790();
goto next_tmp_1006875;
next_tmp_1006875:
goto tmp_1006874;
tmp_1006874:
}
tmp_981523 = tmp_1006814 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1006877:
return tmp_1006814;
}
reg_t genfunc_tmp_1006790 (void) {
reg_t tmp_1006745;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1006720();
goto next_tmp_1006787;
next_tmp_1006787:
goto tmp_1006786;
tmp_1006786:
}
tmp_981838 = tmp_1006745 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1006789:
return tmp_1006745;
}
reg_t genfunc_tmp_1006720 (void) {
reg_t tmp_1006561;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1006679 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1006679 >> 8) == 0)
field_imm = tmp_1006679;
else goto fail_tmp_1006678;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1006608();
goto next_tmp_1006682;
next_tmp_1006682:
goto tmp_1006681;
tmp_1006681:
}
tmp_982314 = tmp_1006561 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1006719;
fail_tmp_1006678:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1006709 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1006709))
field_imm = inv_maskmask(8, tmp_1006709);
else goto fail_tmp_1006708;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1006608();
goto next_tmp_1006712;
next_tmp_1006712:
goto tmp_1006711;
tmp_1006711:
}
tmp_981531 = tmp_1006561 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1006719;
fail_tmp_1006708:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1006608();
goto next_tmp_1006717;
next_tmp_1006717:
goto tmp_1006716;
tmp_1006716:
}
tmp_981523 = tmp_1006561 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1006719:
return tmp_1006561;
}
reg_t genfunc_tmp_1006676 (void) {
reg_t tmp_1006612;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1006637 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1006637 >> 8) == 0)
field_imm = tmp_1006637;
else goto fail_tmp_1006636;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1006608();
goto next_tmp_1006640;
next_tmp_1006640:
goto tmp_1006639;
tmp_1006639:
}
tmp_982314 = tmp_1006612 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1006675;
fail_tmp_1006636:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1006665 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1006665))
field_imm = inv_maskmask(8, tmp_1006665);
else goto fail_tmp_1006664;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1006608();
goto next_tmp_1006668;
next_tmp_1006668:
goto tmp_1006667;
tmp_1006667:
}
tmp_981531 = tmp_1006612 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1006675;
fail_tmp_1006664:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1006608();
goto next_tmp_1006673;
next_tmp_1006673:
goto tmp_1006672;
tmp_1006672:
}
tmp_981523 = tmp_1006612 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1006675:
return tmp_1006612;
}
reg_t genfunc_tmp_1006608 (void) {
reg_t tmp_1006577;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_1006605;
field_ra = 31;
/* commit */
tmp_981699 = ref_gpr_reg_for_reading(0 + 5);
tmp_981697 = tmp_1006577 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 1 */
}
goto done_tmp_1006607;
fail_tmp_1006605:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_1006606;
field_ra = 31;
/* commit */
tmp_981667 = ref_gpr_reg_for_reading(0 + 5);
tmp_981665 = tmp_1006577 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 1 */
}
goto done_tmp_1006607;
fail_tmp_1006606:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_982357 = ref_gpr_reg_for_reading(0 + 5);
tmp_982354 = tmp_1006577 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_1006607:
return tmp_1006577;
}
void genfunc_tmp_1006556 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_1006243();
goto next_tmp_1006074;
next_tmp_1006074:
goto tmp_1006073;
tmp_1006073:
}
{
tmp_981603 = genfunc_tmp_1006553();
goto next_tmp_1006247;
next_tmp_1006247:
goto tmp_1006246;
tmp_1006246:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 13 */
}
done_tmp_1006555:
}
reg_t genfunc_tmp_1006553 (void) {
reg_t tmp_1006245;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1006458();
goto next_tmp_1006254;
next_tmp_1006254:
goto tmp_1006253;
tmp_1006253:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1006245 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 7 */
}
done_tmp_1006552:
return tmp_1006245;
}
reg_t genfunc_tmp_1006515 (void) {
reg_t tmp_1006470;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1006458();
goto next_tmp_1006479;
next_tmp_1006479:
goto tmp_1006478;
tmp_1006478:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1006470 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 7 */
}
done_tmp_1006514:
return tmp_1006470;
}
reg_t genfunc_tmp_1006458 (void) {
reg_t tmp_1006252;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1006243();
goto next_tmp_1006432;
next_tmp_1006432:
goto tmp_1006431;
tmp_1006431:
}
tmp_981838 = tmp_1006252 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1006457:
return tmp_1006252;
}
reg_t genfunc_tmp_1006401 (void) {
reg_t tmp_1006337;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1006362 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1006362 >> 8) == 0)
field_imm = tmp_1006362;
else goto fail_tmp_1006361;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1006313();
goto next_tmp_1006365;
next_tmp_1006365:
goto tmp_1006364;
tmp_1006364:
}
tmp_982314 = tmp_1006337 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 7 */
}
goto done_tmp_1006400;
fail_tmp_1006361:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1006390 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1006390))
field_imm = inv_maskmask(8, tmp_1006390);
else goto fail_tmp_1006389;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1006313();
goto next_tmp_1006393;
next_tmp_1006393:
goto tmp_1006392;
tmp_1006392:
}
tmp_981531 = tmp_1006337 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 7 */
}
goto done_tmp_1006400;
fail_tmp_1006389:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1006313();
goto next_tmp_1006398;
next_tmp_1006398:
goto tmp_1006397;
tmp_1006397:
}
tmp_981523 = tmp_1006337 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 7 */
}
done_tmp_1006400:
return tmp_1006337;
}
reg_t genfunc_tmp_1006313 (void) {
reg_t tmp_1006268;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1006243();
goto next_tmp_1006310;
next_tmp_1006310:
goto tmp_1006309;
tmp_1006309:
}
tmp_981838 = tmp_1006268 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1006312:
return tmp_1006268;
}
reg_t genfunc_tmp_1006243 (void) {
reg_t tmp_1006072;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1006202 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1006202 >> 8) == 0)
field_imm = tmp_1006202;
else goto fail_tmp_1006201;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1006131();
goto next_tmp_1006205;
next_tmp_1006205:
goto tmp_1006204;
tmp_1006204:
}
tmp_982314 = tmp_1006072 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1006242;
fail_tmp_1006201:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1006232 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1006232))
field_imm = inv_maskmask(8, tmp_1006232);
else goto fail_tmp_1006231;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1006131();
goto next_tmp_1006235;
next_tmp_1006235:
goto tmp_1006234;
tmp_1006234:
}
tmp_981531 = tmp_1006072 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1006242;
fail_tmp_1006231:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1006131();
goto next_tmp_1006240;
next_tmp_1006240:
goto tmp_1006239;
tmp_1006239:
}
tmp_981523 = tmp_1006072 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1006242:
return tmp_1006072;
}
reg_t genfunc_tmp_1006199 (void) {
reg_t tmp_1006135;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1006160 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1006160 >> 8) == 0)
field_imm = tmp_1006160;
else goto fail_tmp_1006159;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1006131();
goto next_tmp_1006163;
next_tmp_1006163:
goto tmp_1006162;
tmp_1006162:
}
tmp_982314 = tmp_1006135 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1006198;
fail_tmp_1006159:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1006188 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1006188))
field_imm = inv_maskmask(8, tmp_1006188);
else goto fail_tmp_1006187;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1006131();
goto next_tmp_1006191;
next_tmp_1006191:
goto tmp_1006190;
tmp_1006190:
}
tmp_981531 = tmp_1006135 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1006198;
fail_tmp_1006187:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1006131();
goto next_tmp_1006196;
next_tmp_1006196:
goto tmp_1006195;
tmp_1006195:
}
tmp_981523 = tmp_1006135 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1006198:
return tmp_1006135;
}
reg_t genfunc_tmp_1006131 (void) {
reg_t tmp_1006088;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_1006120;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_1002705();
goto next_tmp_1006123;
next_tmp_1006123:
goto tmp_1006122;
tmp_1006122:
}
tmp_981697 = tmp_1006088 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1006130;
fail_tmp_1006120:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_1006125;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_1002705();
goto next_tmp_1006128;
next_tmp_1006128:
goto tmp_1006127;
tmp_1006127:
}
tmp_981665 = tmp_1006088 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1006130;
fail_tmp_1006125:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_982357 = genfunc_tmp_1002705();
goto next_tmp_1006097;
next_tmp_1006097:
goto tmp_1006096;
tmp_1006096:
}
tmp_982354 = tmp_1006088 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1006130:
return tmp_1006088;
}
void genfunc_tmp_1006067 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_1005754();
goto next_tmp_1005585;
next_tmp_1005585:
goto tmp_1005584;
tmp_1005584:
}
{
tmp_981603 = genfunc_tmp_1006064();
goto next_tmp_1005758;
next_tmp_1005758:
goto tmp_1005757;
tmp_1005757:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 11 */
}
done_tmp_1006066:
}
reg_t genfunc_tmp_1006064 (void) {
reg_t tmp_1005756;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1005969();
goto next_tmp_1005765;
next_tmp_1005765:
goto tmp_1005764;
tmp_1005764:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1005756 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1006063:
return tmp_1005756;
}
reg_t genfunc_tmp_1006026 (void) {
reg_t tmp_1005981;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1005969();
goto next_tmp_1005990;
next_tmp_1005990:
goto tmp_1005989;
tmp_1005989:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1005981 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1006025:
return tmp_1005981;
}
reg_t genfunc_tmp_1005969 (void) {
reg_t tmp_1005763;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1005754();
goto next_tmp_1005943;
next_tmp_1005943:
goto tmp_1005942;
tmp_1005942:
}
tmp_981838 = tmp_1005763 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1005968:
return tmp_1005763;
}
reg_t genfunc_tmp_1005912 (void) {
reg_t tmp_1005848;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1005873 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1005873 >> 8) == 0)
field_imm = tmp_1005873;
else goto fail_tmp_1005872;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1005824();
goto next_tmp_1005876;
next_tmp_1005876:
goto tmp_1005875;
tmp_1005875:
}
tmp_982314 = tmp_1005848 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 6 */
}
goto done_tmp_1005911;
fail_tmp_1005872:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1005901 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1005901))
field_imm = inv_maskmask(8, tmp_1005901);
else goto fail_tmp_1005900;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1005824();
goto next_tmp_1005904;
next_tmp_1005904:
goto tmp_1005903;
tmp_1005903:
}
tmp_981531 = tmp_1005848 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 6 */
}
goto done_tmp_1005911;
fail_tmp_1005900:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1005824();
goto next_tmp_1005909;
next_tmp_1005909:
goto tmp_1005908;
tmp_1005908:
}
tmp_981523 = tmp_1005848 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1005911:
return tmp_1005848;
}
reg_t genfunc_tmp_1005824 (void) {
reg_t tmp_1005779;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1005754();
goto next_tmp_1005821;
next_tmp_1005821:
goto tmp_1005820;
tmp_1005820:
}
tmp_981838 = tmp_1005779 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1005823:
return tmp_1005779;
}
reg_t genfunc_tmp_1005754 (void) {
reg_t tmp_1005583;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1005713 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1005713 >> 8) == 0)
field_imm = tmp_1005713;
else goto fail_tmp_1005712;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1005642();
goto next_tmp_1005716;
next_tmp_1005716:
goto tmp_1005715;
tmp_1005715:
}
tmp_982314 = tmp_1005583 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1005753;
fail_tmp_1005712:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1005743 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1005743))
field_imm = inv_maskmask(8, tmp_1005743);
else goto fail_tmp_1005742;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1005642();
goto next_tmp_1005746;
next_tmp_1005746:
goto tmp_1005745;
tmp_1005745:
}
tmp_981531 = tmp_1005583 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1005753;
fail_tmp_1005742:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1005642();
goto next_tmp_1005751;
next_tmp_1005751:
goto tmp_1005750;
tmp_1005750:
}
tmp_981523 = tmp_1005583 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1005753:
return tmp_1005583;
}
reg_t genfunc_tmp_1005710 (void) {
reg_t tmp_1005646;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1005671 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1005671 >> 8) == 0)
field_imm = tmp_1005671;
else goto fail_tmp_1005670;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1005642();
goto next_tmp_1005674;
next_tmp_1005674:
goto tmp_1005673;
tmp_1005673:
}
tmp_982314 = tmp_1005646 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1005709;
fail_tmp_1005670:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1005699 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1005699))
field_imm = inv_maskmask(8, tmp_1005699);
else goto fail_tmp_1005698;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1005642();
goto next_tmp_1005702;
next_tmp_1005702:
goto tmp_1005701;
tmp_1005701:
}
tmp_981531 = tmp_1005646 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1005709;
fail_tmp_1005698:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1005642();
goto next_tmp_1005707;
next_tmp_1005707:
goto tmp_1005706;
tmp_1005706:
}
tmp_981523 = tmp_1005646 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1005709:
return tmp_1005646;
}
reg_t genfunc_tmp_1005642 (void) {
reg_t tmp_1005599;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_1005631;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_1002185();
goto next_tmp_1005634;
next_tmp_1005634:
goto tmp_1005633;
tmp_1005633:
}
tmp_981697 = tmp_1005599 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 2 */
}
goto done_tmp_1005641;
fail_tmp_1005631:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_1005636;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_1002185();
goto next_tmp_1005639;
next_tmp_1005639:
goto tmp_1005638;
tmp_1005638:
}
tmp_981665 = tmp_1005599 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 2 */
}
goto done_tmp_1005641;
fail_tmp_1005636:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_982357 = genfunc_tmp_1002185();
goto next_tmp_1005608;
next_tmp_1005608:
goto tmp_1005607;
tmp_1005607:
}
tmp_982354 = tmp_1005599 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1005641:
return tmp_1005599;
}
void genfunc_tmp_1005578 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_1005265();
goto next_tmp_1005108;
next_tmp_1005108:
goto tmp_1005107;
tmp_1005107:
}
{
tmp_981603 = genfunc_tmp_1005575();
goto next_tmp_1005269;
next_tmp_1005269:
goto tmp_1005268;
tmp_1005268:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_1005577:
}
reg_t genfunc_tmp_1005575 (void) {
reg_t tmp_1005267;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1005480();
goto next_tmp_1005276;
next_tmp_1005276:
goto tmp_1005275;
tmp_1005275:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1005267 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1005574:
return tmp_1005267;
}
reg_t genfunc_tmp_1005537 (void) {
reg_t tmp_1005492;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1005480();
goto next_tmp_1005501;
next_tmp_1005501:
goto tmp_1005500;
tmp_1005500:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1005492 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1005536:
return tmp_1005492;
}
reg_t genfunc_tmp_1005480 (void) {
reg_t tmp_1005274;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1005265();
goto next_tmp_1005454;
next_tmp_1005454:
goto tmp_1005453;
tmp_1005453:
}
tmp_981838 = tmp_1005274 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1005479:
return tmp_1005274;
}
reg_t genfunc_tmp_1005423 (void) {
reg_t tmp_1005359;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1005384 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1005384 >> 8) == 0)
field_imm = tmp_1005384;
else goto fail_tmp_1005383;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1005335();
goto next_tmp_1005387;
next_tmp_1005387:
goto tmp_1005386;
tmp_1005386:
}
tmp_982314 = tmp_1005359 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1005422;
fail_tmp_1005383:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1005412 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1005412))
field_imm = inv_maskmask(8, tmp_1005412);
else goto fail_tmp_1005411;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1005335();
goto next_tmp_1005415;
next_tmp_1005415:
goto tmp_1005414;
tmp_1005414:
}
tmp_981531 = tmp_1005359 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1005422;
fail_tmp_1005411:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1005335();
goto next_tmp_1005420;
next_tmp_1005420:
goto tmp_1005419;
tmp_1005419:
}
tmp_981523 = tmp_1005359 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1005422:
return tmp_1005359;
}
reg_t genfunc_tmp_1005335 (void) {
reg_t tmp_1005290;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1005265();
goto next_tmp_1005332;
next_tmp_1005332:
goto tmp_1005331;
tmp_1005331:
}
tmp_981838 = tmp_1005290 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1005334:
return tmp_1005290;
}
reg_t genfunc_tmp_1005265 (void) {
reg_t tmp_1005106;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1005224 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1005224 >> 8) == 0)
field_imm = tmp_1005224;
else goto fail_tmp_1005223;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1005153();
goto next_tmp_1005227;
next_tmp_1005227:
goto tmp_1005226;
tmp_1005226:
}
tmp_982314 = tmp_1005106 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1005264;
fail_tmp_1005223:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1005254 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1005254))
field_imm = inv_maskmask(8, tmp_1005254);
else goto fail_tmp_1005253;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1005153();
goto next_tmp_1005257;
next_tmp_1005257:
goto tmp_1005256;
tmp_1005256:
}
tmp_981531 = tmp_1005106 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1005264;
fail_tmp_1005253:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1005153();
goto next_tmp_1005262;
next_tmp_1005262:
goto tmp_1005261;
tmp_1005261:
}
tmp_981523 = tmp_1005106 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1005264:
return tmp_1005106;
}
reg_t genfunc_tmp_1005221 (void) {
reg_t tmp_1005157;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1005182 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1005182 >> 8) == 0)
field_imm = tmp_1005182;
else goto fail_tmp_1005181;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1005153();
goto next_tmp_1005185;
next_tmp_1005185:
goto tmp_1005184;
tmp_1005184:
}
tmp_982314 = tmp_1005157 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1005220;
fail_tmp_1005181:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1005210 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1005210))
field_imm = inv_maskmask(8, tmp_1005210);
else goto fail_tmp_1005209;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1005153();
goto next_tmp_1005213;
next_tmp_1005213:
goto tmp_1005212;
tmp_1005212:
}
tmp_981531 = tmp_1005157 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1005220;
fail_tmp_1005209:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1005153();
goto next_tmp_1005218;
next_tmp_1005218:
goto tmp_1005217;
tmp_1005217:
}
tmp_981523 = tmp_1005157 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1005220:
return tmp_1005157;
}
reg_t genfunc_tmp_1005153 (void) {
reg_t tmp_1005122;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_1005150;
field_ra = 31;
/* commit */
tmp_981699 = ref_gpr_reg_for_reading(0 + base);
tmp_981697 = tmp_1005122 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 1 */
}
goto done_tmp_1005152;
fail_tmp_1005150:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_1005151;
field_ra = 31;
/* commit */
tmp_981667 = ref_gpr_reg_for_reading(0 + base);
tmp_981665 = tmp_1005122 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 1 */
}
goto done_tmp_1005152;
fail_tmp_1005151:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_982357 = ref_gpr_reg_for_reading(0 + base);
tmp_982354 = tmp_1005122 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_1005152:
return tmp_1005122;
}
void genfunc_tmp_1005101 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_1004788();
goto next_tmp_1004619;
next_tmp_1004619:
goto tmp_1004618;
tmp_1004618:
}
{
tmp_981603 = genfunc_tmp_1005098();
goto next_tmp_1004792;
next_tmp_1004792:
goto tmp_1004791;
tmp_1004791:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 13 */
}
done_tmp_1005100:
}
reg_t genfunc_tmp_1005098 (void) {
reg_t tmp_1004790;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1005003();
goto next_tmp_1004799;
next_tmp_1004799:
goto tmp_1004798;
tmp_1004798:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1004790 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 7 */
}
done_tmp_1005097:
return tmp_1004790;
}
reg_t genfunc_tmp_1005060 (void) {
reg_t tmp_1005015;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1005003();
goto next_tmp_1005024;
next_tmp_1005024:
goto tmp_1005023;
tmp_1005023:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1005015 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 7 */
}
done_tmp_1005059:
return tmp_1005015;
}
reg_t genfunc_tmp_1005003 (void) {
reg_t tmp_1004797;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1004788();
goto next_tmp_1004977;
next_tmp_1004977:
goto tmp_1004976;
tmp_1004976:
}
tmp_981838 = tmp_1004797 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1005002:
return tmp_1004797;
}
reg_t genfunc_tmp_1004946 (void) {
reg_t tmp_1004882;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1004907 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1004907 >> 8) == 0)
field_imm = tmp_1004907;
else goto fail_tmp_1004906;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1004858();
goto next_tmp_1004910;
next_tmp_1004910:
goto tmp_1004909;
tmp_1004909:
}
tmp_982314 = tmp_1004882 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 7 */
}
goto done_tmp_1004945;
fail_tmp_1004906:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1004935 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1004935))
field_imm = inv_maskmask(8, tmp_1004935);
else goto fail_tmp_1004934;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1004858();
goto next_tmp_1004938;
next_tmp_1004938:
goto tmp_1004937;
tmp_1004937:
}
tmp_981531 = tmp_1004882 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 7 */
}
goto done_tmp_1004945;
fail_tmp_1004934:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1004858();
goto next_tmp_1004943;
next_tmp_1004943:
goto tmp_1004942;
tmp_1004942:
}
tmp_981523 = tmp_1004882 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 7 */
}
done_tmp_1004945:
return tmp_1004882;
}
reg_t genfunc_tmp_1004858 (void) {
reg_t tmp_1004813;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1004788();
goto next_tmp_1004855;
next_tmp_1004855:
goto tmp_1004854;
tmp_1004854:
}
tmp_981838 = tmp_1004813 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1004857:
return tmp_1004813;
}
reg_t genfunc_tmp_1004788 (void) {
reg_t tmp_1004617;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1004747 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1004747 >> 8) == 0)
field_imm = tmp_1004747;
else goto fail_tmp_1004746;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1004676();
goto next_tmp_1004750;
next_tmp_1004750:
goto tmp_1004749;
tmp_1004749:
}
tmp_982314 = tmp_1004617 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1004787;
fail_tmp_1004746:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1004777 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1004777))
field_imm = inv_maskmask(8, tmp_1004777);
else goto fail_tmp_1004776;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1004676();
goto next_tmp_1004780;
next_tmp_1004780:
goto tmp_1004779;
tmp_1004779:
}
tmp_981531 = tmp_1004617 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1004787;
fail_tmp_1004776:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1004676();
goto next_tmp_1004785;
next_tmp_1004785:
goto tmp_1004784;
tmp_1004784:
}
tmp_981523 = tmp_1004617 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1004787:
return tmp_1004617;
}
reg_t genfunc_tmp_1004744 (void) {
reg_t tmp_1004680;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1004705 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1004705 >> 8) == 0)
field_imm = tmp_1004705;
else goto fail_tmp_1004704;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1004676();
goto next_tmp_1004708;
next_tmp_1004708:
goto tmp_1004707;
tmp_1004707:
}
tmp_982314 = tmp_1004680 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1004743;
fail_tmp_1004704:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1004733 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1004733))
field_imm = inv_maskmask(8, tmp_1004733);
else goto fail_tmp_1004732;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1004676();
goto next_tmp_1004736;
next_tmp_1004736:
goto tmp_1004735;
tmp_1004735:
}
tmp_981531 = tmp_1004680 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1004743;
fail_tmp_1004732:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1004676();
goto next_tmp_1004741;
next_tmp_1004741:
goto tmp_1004740;
tmp_1004740:
}
tmp_981523 = tmp_1004680 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1004743:
return tmp_1004680;
}
reg_t genfunc_tmp_1004676 (void) {
reg_t tmp_1004633;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_1004665;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_998063();
goto next_tmp_1004668;
next_tmp_1004668:
goto tmp_1004667;
tmp_1004667:
}
tmp_981697 = tmp_1004633 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1004675;
fail_tmp_1004665:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_1004670;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_998063();
goto next_tmp_1004673;
next_tmp_1004673:
goto tmp_1004672;
tmp_1004672:
}
tmp_981665 = tmp_1004633 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1004675;
fail_tmp_1004670:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_982357 = genfunc_tmp_998063();
goto next_tmp_1004642;
next_tmp_1004642:
goto tmp_1004641;
tmp_1004641:
}
tmp_982354 = tmp_1004633 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1004675:
return tmp_1004633;
}
void genfunc_tmp_1004612 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_1004299();
goto next_tmp_1004130;
next_tmp_1004130:
goto tmp_1004129;
tmp_1004129:
}
{
tmp_981603 = genfunc_tmp_1004609();
goto next_tmp_1004303;
next_tmp_1004303:
goto tmp_1004302;
tmp_1004302:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 11 */
}
done_tmp_1004611:
}
reg_t genfunc_tmp_1004609 (void) {
reg_t tmp_1004301;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1004514();
goto next_tmp_1004310;
next_tmp_1004310:
goto tmp_1004309;
tmp_1004309:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1004301 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1004608:
return tmp_1004301;
}
reg_t genfunc_tmp_1004571 (void) {
reg_t tmp_1004526;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1004514();
goto next_tmp_1004535;
next_tmp_1004535:
goto tmp_1004534;
tmp_1004534:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1004526 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1004570:
return tmp_1004526;
}
reg_t genfunc_tmp_1004514 (void) {
reg_t tmp_1004308;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1004299();
goto next_tmp_1004488;
next_tmp_1004488:
goto tmp_1004487;
tmp_1004487:
}
tmp_981838 = tmp_1004308 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1004513:
return tmp_1004308;
}
reg_t genfunc_tmp_1004457 (void) {
reg_t tmp_1004393;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1004418 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1004418 >> 8) == 0)
field_imm = tmp_1004418;
else goto fail_tmp_1004417;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1004369();
goto next_tmp_1004421;
next_tmp_1004421:
goto tmp_1004420;
tmp_1004420:
}
tmp_982314 = tmp_1004393 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 6 */
}
goto done_tmp_1004456;
fail_tmp_1004417:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1004446 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1004446))
field_imm = inv_maskmask(8, tmp_1004446);
else goto fail_tmp_1004445;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1004369();
goto next_tmp_1004449;
next_tmp_1004449:
goto tmp_1004448;
tmp_1004448:
}
tmp_981531 = tmp_1004393 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 6 */
}
goto done_tmp_1004456;
fail_tmp_1004445:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1004369();
goto next_tmp_1004454;
next_tmp_1004454:
goto tmp_1004453;
tmp_1004453:
}
tmp_981523 = tmp_1004393 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1004456:
return tmp_1004393;
}
reg_t genfunc_tmp_1004369 (void) {
reg_t tmp_1004324;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1004299();
goto next_tmp_1004366;
next_tmp_1004366:
goto tmp_1004365;
tmp_1004365:
}
tmp_981838 = tmp_1004324 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1004368:
return tmp_1004324;
}
reg_t genfunc_tmp_1004299 (void) {
reg_t tmp_1004128;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1004258 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1004258 >> 8) == 0)
field_imm = tmp_1004258;
else goto fail_tmp_1004257;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1004187();
goto next_tmp_1004261;
next_tmp_1004261:
goto tmp_1004260;
tmp_1004260:
}
tmp_982314 = tmp_1004128 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1004298;
fail_tmp_1004257:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1004288 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1004288))
field_imm = inv_maskmask(8, tmp_1004288);
else goto fail_tmp_1004287;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1004187();
goto next_tmp_1004291;
next_tmp_1004291:
goto tmp_1004290;
tmp_1004290:
}
tmp_981531 = tmp_1004128 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1004298;
fail_tmp_1004287:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1004187();
goto next_tmp_1004296;
next_tmp_1004296:
goto tmp_1004295;
tmp_1004295:
}
tmp_981523 = tmp_1004128 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1004298:
return tmp_1004128;
}
reg_t genfunc_tmp_1004255 (void) {
reg_t tmp_1004191;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1004216 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1004216 >> 8) == 0)
field_imm = tmp_1004216;
else goto fail_tmp_1004215;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1004187();
goto next_tmp_1004219;
next_tmp_1004219:
goto tmp_1004218;
tmp_1004218:
}
tmp_982314 = tmp_1004191 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1004254;
fail_tmp_1004215:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1004244 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1004244))
field_imm = inv_maskmask(8, tmp_1004244);
else goto fail_tmp_1004243;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1004187();
goto next_tmp_1004247;
next_tmp_1004247:
goto tmp_1004246;
tmp_1004246:
}
tmp_981531 = tmp_1004191 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1004254;
fail_tmp_1004243:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1004187();
goto next_tmp_1004252;
next_tmp_1004252:
goto tmp_1004251;
tmp_1004251:
}
tmp_981523 = tmp_1004191 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1004254:
return tmp_1004191;
}
reg_t genfunc_tmp_1004187 (void) {
reg_t tmp_1004144;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_1004176;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_997544();
goto next_tmp_1004179;
next_tmp_1004179:
goto tmp_1004178;
tmp_1004178:
}
tmp_981697 = tmp_1004144 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 2 */
}
goto done_tmp_1004186;
fail_tmp_1004176:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_1004181;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_997544();
goto next_tmp_1004184;
next_tmp_1004184:
goto tmp_1004183;
tmp_1004183:
}
tmp_981665 = tmp_1004144 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 2 */
}
goto done_tmp_1004186;
fail_tmp_1004181:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_982357 = genfunc_tmp_997544();
goto next_tmp_1004153;
next_tmp_1004153:
goto tmp_1004152;
tmp_1004152:
}
tmp_982354 = tmp_1004144 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1004186:
return tmp_1004144;
}
void genfunc_tmp_1004123 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_1003810();
goto next_tmp_1003648;
next_tmp_1003648:
goto tmp_1003647;
tmp_1003647:
}
{
tmp_981603 = genfunc_tmp_1004120();
goto next_tmp_1003814;
next_tmp_1003814:
goto tmp_1003813;
tmp_1003813:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_1004122:
}
reg_t genfunc_tmp_1004120 (void) {
reg_t tmp_1003812;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1004025();
goto next_tmp_1003821;
next_tmp_1003821:
goto tmp_1003820;
tmp_1003820:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1003812 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1004119:
return tmp_1003812;
}
reg_t genfunc_tmp_1004082 (void) {
reg_t tmp_1004037;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1004025();
goto next_tmp_1004046;
next_tmp_1004046:
goto tmp_1004045;
tmp_1004045:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1004037 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1004081:
return tmp_1004037;
}
reg_t genfunc_tmp_1004025 (void) {
reg_t tmp_1003819;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1003810();
goto next_tmp_1003999;
next_tmp_1003999:
goto tmp_1003998;
tmp_1003998:
}
tmp_981838 = tmp_1003819 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1004024:
return tmp_1003819;
}
reg_t genfunc_tmp_1003968 (void) {
reg_t tmp_1003904;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1003929 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1003929 >> 8) == 0)
field_imm = tmp_1003929;
else goto fail_tmp_1003928;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1003880();
goto next_tmp_1003932;
next_tmp_1003932:
goto tmp_1003931;
tmp_1003931:
}
tmp_982314 = tmp_1003904 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1003967;
fail_tmp_1003928:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1003957 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1003957))
field_imm = inv_maskmask(8, tmp_1003957);
else goto fail_tmp_1003956;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1003880();
goto next_tmp_1003960;
next_tmp_1003960:
goto tmp_1003959;
tmp_1003959:
}
tmp_981531 = tmp_1003904 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1003967;
fail_tmp_1003956:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1003880();
goto next_tmp_1003965;
next_tmp_1003965:
goto tmp_1003964;
tmp_1003964:
}
tmp_981523 = tmp_1003904 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1003967:
return tmp_1003904;
}
reg_t genfunc_tmp_1003880 (void) {
reg_t tmp_1003835;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1003810();
goto next_tmp_1003877;
next_tmp_1003877:
goto tmp_1003876;
tmp_1003876:
}
tmp_981838 = tmp_1003835 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1003879:
return tmp_1003835;
}
reg_t genfunc_tmp_1003810 (void) {
reg_t tmp_1003646;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1003769 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1003769 >> 8) == 0)
field_imm = tmp_1003769;
else goto fail_tmp_1003768;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1003698();
goto next_tmp_1003772;
next_tmp_1003772:
goto tmp_1003771;
tmp_1003771:
}
tmp_982314 = tmp_1003646 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1003809;
fail_tmp_1003768:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1003799 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1003799))
field_imm = inv_maskmask(8, tmp_1003799);
else goto fail_tmp_1003798;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1003698();
goto next_tmp_1003802;
next_tmp_1003802:
goto tmp_1003801;
tmp_1003801:
}
tmp_981531 = tmp_1003646 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1003809;
fail_tmp_1003798:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1003698();
goto next_tmp_1003807;
next_tmp_1003807:
goto tmp_1003806;
tmp_1003806:
}
tmp_981523 = tmp_1003646 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1003809:
return tmp_1003646;
}
reg_t genfunc_tmp_1003766 (void) {
reg_t tmp_1003702;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1003727 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1003727 >> 8) == 0)
field_imm = tmp_1003727;
else goto fail_tmp_1003726;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1003698();
goto next_tmp_1003730;
next_tmp_1003730:
goto tmp_1003729;
tmp_1003729:
}
tmp_982314 = tmp_1003702 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1003765;
fail_tmp_1003726:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1003755 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1003755))
field_imm = inv_maskmask(8, tmp_1003755);
else goto fail_tmp_1003754;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1003698();
goto next_tmp_1003758;
next_tmp_1003758:
goto tmp_1003757;
tmp_1003757:
}
tmp_981531 = tmp_1003702 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1003765;
fail_tmp_1003754:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1003698();
goto next_tmp_1003763;
next_tmp_1003763:
goto tmp_1003762;
tmp_1003762:
}
tmp_981523 = tmp_1003702 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1003765:
return tmp_1003702;
}
reg_t genfunc_tmp_1003698 (void) {
reg_t tmp_1003662;
/* ADDQ_IMM */
{
word_5 tmp_982350;
word_5 field_rc;
word_5 tmp_982351;
word_5 field_ra;
word_64 tmp_982353;
word_8 field_imm;
tmp_982353 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_1003679 = tmp_982353;
if ((tmp_1003679 >> 8) == 0)
field_imm = tmp_1003679;
else goto fail_tmp_1003678;
}
/* commit */
tmp_982351 = ref_gpr_reg_for_reading(0 + rm);
tmp_982350 = tmp_1003662 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982350;
field_ra = tmp_982351;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982351);
/* can fail: T   num insns: 1 */
}
goto done_tmp_1003697;
fail_tmp_1003678:
/* LDA */
{
word_5 tmp_981854;
word_5 field_ra;
word_5 tmp_981855;
word_5 field_rb;
word_64 tmp_981857;
word_16 field_memory_disp;
tmp_981857 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_1003690 = tmp_981857;
if ((tmp_1003690 >> 16) == 0xFFFFFFFFFFFF || (tmp_1003690 >> 16) == 0)
field_memory_disp = (tmp_1003690 & 0xFFFF);
else goto fail_tmp_1003689;
}
/* commit */
tmp_981855 = ref_gpr_reg_for_reading(0 + rm);
tmp_981854 = tmp_1003662 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981854;
field_rb = tmp_981855;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981855);
/* can fail: T   num insns: 1 */
}
goto done_tmp_1003697;
fail_tmp_1003689:
/* LDAH */
{
word_5 tmp_981850;
word_5 field_ra;
word_5 tmp_981851;
word_5 field_rb;
word_64 tmp_981853;
word_16 field_memory_disp;
tmp_981853 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_1003695 = tmp_981853;
if ((tmp_1003695 & 0xFFFF) == 0)
{
word_64 tmp_1003696 = (tmp_1003695 >> 16);
if ((tmp_1003696 >> 16) == 0xFFFFFFFFFFFF || (tmp_1003696 >> 16) == 0)
field_memory_disp = (tmp_1003696 & 0xFFFF);
else goto fail_tmp_1003694;
}
else goto fail_tmp_1003694;
}
/* commit */
tmp_981851 = ref_gpr_reg_for_reading(0 + rm);
tmp_981850 = tmp_1003662 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981850;
field_rb = tmp_981851;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981851);
/* can fail: T   num insns: 1 */
}
goto done_tmp_1003697;
fail_tmp_1003694:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_reading(0 + rm);
tmp_982357 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982357, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_982354 = tmp_1003662 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_1003697:
return tmp_1003662;
}
void genfunc_tmp_1003641 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_1003328();
goto next_tmp_1003171;
next_tmp_1003171:
goto tmp_1003170;
tmp_1003170:
}
{
tmp_981603 = genfunc_tmp_1003638();
goto next_tmp_1003332;
next_tmp_1003332:
goto tmp_1003331;
tmp_1003331:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_1003640:
}
reg_t genfunc_tmp_1003638 (void) {
reg_t tmp_1003330;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1003543();
goto next_tmp_1003339;
next_tmp_1003339:
goto tmp_1003338;
tmp_1003338:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1003330 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1003637:
return tmp_1003330;
}
reg_t genfunc_tmp_1003600 (void) {
reg_t tmp_1003555;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1003543();
goto next_tmp_1003564;
next_tmp_1003564:
goto tmp_1003563;
tmp_1003563:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1003555 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1003599:
return tmp_1003555;
}
reg_t genfunc_tmp_1003543 (void) {
reg_t tmp_1003337;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1003328();
goto next_tmp_1003517;
next_tmp_1003517:
goto tmp_1003516;
tmp_1003516:
}
tmp_981838 = tmp_1003337 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1003542:
return tmp_1003337;
}
reg_t genfunc_tmp_1003486 (void) {
reg_t tmp_1003422;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1003447 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1003447 >> 8) == 0)
field_imm = tmp_1003447;
else goto fail_tmp_1003446;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1003398();
goto next_tmp_1003450;
next_tmp_1003450:
goto tmp_1003449;
tmp_1003449:
}
tmp_982314 = tmp_1003422 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1003485;
fail_tmp_1003446:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1003475 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1003475))
field_imm = inv_maskmask(8, tmp_1003475);
else goto fail_tmp_1003474;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1003398();
goto next_tmp_1003478;
next_tmp_1003478:
goto tmp_1003477;
tmp_1003477:
}
tmp_981531 = tmp_1003422 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1003485;
fail_tmp_1003474:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1003398();
goto next_tmp_1003483;
next_tmp_1003483:
goto tmp_1003482;
tmp_1003482:
}
tmp_981523 = tmp_1003422 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1003485:
return tmp_1003422;
}
reg_t genfunc_tmp_1003398 (void) {
reg_t tmp_1003353;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1003328();
goto next_tmp_1003395;
next_tmp_1003395:
goto tmp_1003394;
tmp_1003394:
}
tmp_981838 = tmp_1003353 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1003397:
return tmp_1003353;
}
reg_t genfunc_tmp_1003328 (void) {
reg_t tmp_1003169;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1003287 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1003287 >> 8) == 0)
field_imm = tmp_1003287;
else goto fail_tmp_1003286;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1003216();
goto next_tmp_1003290;
next_tmp_1003290:
goto tmp_1003289;
tmp_1003289:
}
tmp_982314 = tmp_1003169 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1003327;
fail_tmp_1003286:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1003317 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1003317))
field_imm = inv_maskmask(8, tmp_1003317);
else goto fail_tmp_1003316;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1003216();
goto next_tmp_1003320;
next_tmp_1003320:
goto tmp_1003319;
tmp_1003319:
}
tmp_981531 = tmp_1003169 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1003327;
fail_tmp_1003316:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1003216();
goto next_tmp_1003325;
next_tmp_1003325:
goto tmp_1003324;
tmp_1003324:
}
tmp_981523 = tmp_1003169 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1003327:
return tmp_1003169;
}
reg_t genfunc_tmp_1003284 (void) {
reg_t tmp_1003220;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1003245 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1003245 >> 8) == 0)
field_imm = tmp_1003245;
else goto fail_tmp_1003244;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1003216();
goto next_tmp_1003248;
next_tmp_1003248:
goto tmp_1003247;
tmp_1003247:
}
tmp_982314 = tmp_1003220 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1003283;
fail_tmp_1003244:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1003273 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1003273))
field_imm = inv_maskmask(8, tmp_1003273);
else goto fail_tmp_1003272;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1003216();
goto next_tmp_1003276;
next_tmp_1003276:
goto tmp_1003275;
tmp_1003275:
}
tmp_981531 = tmp_1003220 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1003283;
fail_tmp_1003272:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1003216();
goto next_tmp_1003281;
next_tmp_1003281:
goto tmp_1003280;
tmp_1003280:
}
tmp_981523 = tmp_1003220 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1003283:
return tmp_1003220;
}
reg_t genfunc_tmp_1003216 (void) {
reg_t tmp_1003185;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_1003213;
field_ra = 31;
/* commit */
tmp_981699 = ref_gpr_reg_for_reading(0 + 5);
tmp_981697 = tmp_1003185 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 1 */
}
goto done_tmp_1003215;
fail_tmp_1003213:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_1003214;
field_ra = 31;
/* commit */
tmp_981667 = ref_gpr_reg_for_reading(0 + 5);
tmp_981665 = tmp_1003185 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 1 */
}
goto done_tmp_1003215;
fail_tmp_1003214:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_982357 = ref_gpr_reg_for_reading(0 + 5);
tmp_982354 = tmp_1003185 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_1003215:
return tmp_1003185;
}
void genfunc_tmp_1003164 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_1002851();
goto next_tmp_1002651;
next_tmp_1002651:
goto tmp_1002650;
tmp_1002650:
}
{
tmp_981603 = genfunc_tmp_1003161();
goto next_tmp_1002855;
next_tmp_1002855:
goto tmp_1002854;
tmp_1002854:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 13 */
}
done_tmp_1003163:
}
reg_t genfunc_tmp_1003161 (void) {
reg_t tmp_1002853;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1003066();
goto next_tmp_1002862;
next_tmp_1002862:
goto tmp_1002861;
tmp_1002861:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1002853 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 7 */
}
done_tmp_1003160:
return tmp_1002853;
}
reg_t genfunc_tmp_1003123 (void) {
reg_t tmp_1003078;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1003066();
goto next_tmp_1003087;
next_tmp_1003087:
goto tmp_1003086;
tmp_1003086:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1003078 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 7 */
}
done_tmp_1003122:
return tmp_1003078;
}
reg_t genfunc_tmp_1003066 (void) {
reg_t tmp_1002860;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1002851();
goto next_tmp_1003040;
next_tmp_1003040:
goto tmp_1003039;
tmp_1003039:
}
tmp_981838 = tmp_1002860 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1003065:
return tmp_1002860;
}
reg_t genfunc_tmp_1003009 (void) {
reg_t tmp_1002945;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1002970 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1002970 >> 8) == 0)
field_imm = tmp_1002970;
else goto fail_tmp_1002969;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1002921();
goto next_tmp_1002973;
next_tmp_1002973:
goto tmp_1002972;
tmp_1002972:
}
tmp_982314 = tmp_1002945 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 7 */
}
goto done_tmp_1003008;
fail_tmp_1002969:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1002998 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1002998))
field_imm = inv_maskmask(8, tmp_1002998);
else goto fail_tmp_1002997;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1002921();
goto next_tmp_1003001;
next_tmp_1003001:
goto tmp_1003000;
tmp_1003000:
}
tmp_981531 = tmp_1002945 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 7 */
}
goto done_tmp_1003008;
fail_tmp_1002997:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1002921();
goto next_tmp_1003006;
next_tmp_1003006:
goto tmp_1003005;
tmp_1003005:
}
tmp_981523 = tmp_1002945 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 7 */
}
done_tmp_1003008:
return tmp_1002945;
}
reg_t genfunc_tmp_1002921 (void) {
reg_t tmp_1002876;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1002851();
goto next_tmp_1002918;
next_tmp_1002918:
goto tmp_1002917;
tmp_1002917:
}
tmp_981838 = tmp_1002876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1002920:
return tmp_1002876;
}
reg_t genfunc_tmp_1002851 (void) {
reg_t tmp_1002649;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1002810 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1002810 >> 8) == 0)
field_imm = tmp_1002810;
else goto fail_tmp_1002809;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1002739();
goto next_tmp_1002813;
next_tmp_1002813:
goto tmp_1002812;
tmp_1002812:
}
tmp_982314 = tmp_1002649 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1002850;
fail_tmp_1002809:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1002840 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1002840))
field_imm = inv_maskmask(8, tmp_1002840);
else goto fail_tmp_1002839;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1002739();
goto next_tmp_1002843;
next_tmp_1002843:
goto tmp_1002842;
tmp_1002842:
}
tmp_981531 = tmp_1002649 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1002850;
fail_tmp_1002839:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1002739();
goto next_tmp_1002848;
next_tmp_1002848:
goto tmp_1002847;
tmp_1002847:
}
tmp_981523 = tmp_1002649 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1002850:
return tmp_1002649;
}
reg_t genfunc_tmp_1002807 (void) {
reg_t tmp_1002743;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1002768 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1002768 >> 8) == 0)
field_imm = tmp_1002768;
else goto fail_tmp_1002767;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1002739();
goto next_tmp_1002771;
next_tmp_1002771:
goto tmp_1002770;
tmp_1002770:
}
tmp_982314 = tmp_1002743 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1002806;
fail_tmp_1002767:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1002796 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1002796))
field_imm = inv_maskmask(8, tmp_1002796);
else goto fail_tmp_1002795;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1002739();
goto next_tmp_1002799;
next_tmp_1002799:
goto tmp_1002798;
tmp_1002798:
}
tmp_981531 = tmp_1002743 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1002806;
fail_tmp_1002795:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1002739();
goto next_tmp_1002804;
next_tmp_1002804:
goto tmp_1002803;
tmp_1002803:
}
tmp_981523 = tmp_1002743 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1002806:
return tmp_1002743;
}
reg_t genfunc_tmp_1002739 (void) {
reg_t tmp_1002665;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_1002728;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_1002705();
goto next_tmp_1002731;
next_tmp_1002731:
goto tmp_1002730;
tmp_1002730:
}
tmp_981697 = tmp_1002665 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1002738;
fail_tmp_1002728:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_1002733;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_1002705();
goto next_tmp_1002736;
next_tmp_1002736:
goto tmp_1002735;
tmp_1002735:
}
tmp_981665 = tmp_1002665 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1002738;
fail_tmp_1002733:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_982357 = genfunc_tmp_1002705();
goto next_tmp_1002674;
next_tmp_1002674:
goto tmp_1002673;
tmp_1002673:
}
tmp_982354 = tmp_1002665 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1002738:
return tmp_1002665;
}
reg_t genfunc_tmp_1002705 (void) {
reg_t tmp_1002672;
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_reading(0 + 5);
{
tmp_982357 = genfunc_tmp_998039();
goto next_tmp_1002681;
next_tmp_1002681:
goto tmp_1002680;
tmp_1002680:
}
tmp_982354 = tmp_1002672 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_1002704:
return tmp_1002672;
}
void genfunc_tmp_1002644 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_1002331();
goto next_tmp_1002135;
next_tmp_1002135:
goto tmp_1002134;
tmp_1002134:
}
{
tmp_981603 = genfunc_tmp_1002641();
goto next_tmp_1002335;
next_tmp_1002335:
goto tmp_1002334;
tmp_1002334:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 11 */
}
done_tmp_1002643:
}
reg_t genfunc_tmp_1002641 (void) {
reg_t tmp_1002333;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1002546();
goto next_tmp_1002342;
next_tmp_1002342:
goto tmp_1002341;
tmp_1002341:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1002333 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1002640:
return tmp_1002333;
}
reg_t genfunc_tmp_1002603 (void) {
reg_t tmp_1002558;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1002546();
goto next_tmp_1002567;
next_tmp_1002567:
goto tmp_1002566;
tmp_1002566:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1002558 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1002602:
return tmp_1002558;
}
reg_t genfunc_tmp_1002546 (void) {
reg_t tmp_1002340;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1002331();
goto next_tmp_1002520;
next_tmp_1002520:
goto tmp_1002519;
tmp_1002519:
}
tmp_981838 = tmp_1002340 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1002545:
return tmp_1002340;
}
reg_t genfunc_tmp_1002489 (void) {
reg_t tmp_1002425;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1002450 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1002450 >> 8) == 0)
field_imm = tmp_1002450;
else goto fail_tmp_1002449;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1002401();
goto next_tmp_1002453;
next_tmp_1002453:
goto tmp_1002452;
tmp_1002452:
}
tmp_982314 = tmp_1002425 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 6 */
}
goto done_tmp_1002488;
fail_tmp_1002449:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1002478 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1002478))
field_imm = inv_maskmask(8, tmp_1002478);
else goto fail_tmp_1002477;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1002401();
goto next_tmp_1002481;
next_tmp_1002481:
goto tmp_1002480;
tmp_1002480:
}
tmp_981531 = tmp_1002425 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 6 */
}
goto done_tmp_1002488;
fail_tmp_1002477:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1002401();
goto next_tmp_1002486;
next_tmp_1002486:
goto tmp_1002485;
tmp_1002485:
}
tmp_981523 = tmp_1002425 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1002488:
return tmp_1002425;
}
reg_t genfunc_tmp_1002401 (void) {
reg_t tmp_1002356;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1002331();
goto next_tmp_1002398;
next_tmp_1002398:
goto tmp_1002397;
tmp_1002397:
}
tmp_981838 = tmp_1002356 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1002400:
return tmp_1002356;
}
reg_t genfunc_tmp_1002331 (void) {
reg_t tmp_1002133;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1002290 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1002290 >> 8) == 0)
field_imm = tmp_1002290;
else goto fail_tmp_1002289;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1002219();
goto next_tmp_1002293;
next_tmp_1002293:
goto tmp_1002292;
tmp_1002292:
}
tmp_982314 = tmp_1002133 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1002330;
fail_tmp_1002289:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1002320 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1002320))
field_imm = inv_maskmask(8, tmp_1002320);
else goto fail_tmp_1002319;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1002219();
goto next_tmp_1002323;
next_tmp_1002323:
goto tmp_1002322;
tmp_1002322:
}
tmp_981531 = tmp_1002133 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1002330;
fail_tmp_1002319:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1002219();
goto next_tmp_1002328;
next_tmp_1002328:
goto tmp_1002327;
tmp_1002327:
}
tmp_981523 = tmp_1002133 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1002330:
return tmp_1002133;
}
reg_t genfunc_tmp_1002287 (void) {
reg_t tmp_1002223;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1002248 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1002248 >> 8) == 0)
field_imm = tmp_1002248;
else goto fail_tmp_1002247;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1002219();
goto next_tmp_1002251;
next_tmp_1002251:
goto tmp_1002250;
tmp_1002250:
}
tmp_982314 = tmp_1002223 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1002286;
fail_tmp_1002247:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1002276 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1002276))
field_imm = inv_maskmask(8, tmp_1002276);
else goto fail_tmp_1002275;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1002219();
goto next_tmp_1002279;
next_tmp_1002279:
goto tmp_1002278;
tmp_1002278:
}
tmp_981531 = tmp_1002223 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1002286;
fail_tmp_1002275:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1002219();
goto next_tmp_1002284;
next_tmp_1002284:
goto tmp_1002283;
tmp_1002283:
}
tmp_981523 = tmp_1002223 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1002286:
return tmp_1002223;
}
reg_t genfunc_tmp_1002219 (void) {
reg_t tmp_1002149;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_1002208;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_1002185();
goto next_tmp_1002211;
next_tmp_1002211:
goto tmp_1002210;
tmp_1002210:
}
tmp_981697 = tmp_1002149 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 2 */
}
goto done_tmp_1002218;
fail_tmp_1002208:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_1002213;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_1002185();
goto next_tmp_1002216;
next_tmp_1002216:
goto tmp_1002215;
tmp_1002215:
}
tmp_981665 = tmp_1002149 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 2 */
}
goto done_tmp_1002218;
fail_tmp_1002213:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_982357 = genfunc_tmp_1002185();
goto next_tmp_1002158;
next_tmp_1002158:
goto tmp_1002157;
tmp_1002157:
}
tmp_982354 = tmp_1002149 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1002218:
return tmp_1002149;
}
reg_t genfunc_tmp_1002185 (void) {
reg_t tmp_1002156;
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_reading(0 + 5);
tmp_982357 = ref_gpr_reg_for_reading(0 + index);
tmp_982354 = tmp_1002156 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 1 */
}
done_tmp_1002184:
return tmp_1002156;
}
void genfunc_tmp_1002128 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_1001815();
goto next_tmp_1001658;
next_tmp_1001658:
goto tmp_1001657;
tmp_1001657:
}
{
tmp_981603 = genfunc_tmp_1002125();
goto next_tmp_1001819;
next_tmp_1001819:
goto tmp_1001818;
tmp_1001818:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_1002127:
}
reg_t genfunc_tmp_1002125 (void) {
reg_t tmp_1001817;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1002030();
goto next_tmp_1001826;
next_tmp_1001826:
goto tmp_1001825;
tmp_1001825:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1001817 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1002124:
return tmp_1001817;
}
reg_t genfunc_tmp_1002087 (void) {
reg_t tmp_1002042;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1002030();
goto next_tmp_1002051;
next_tmp_1002051:
goto tmp_1002050;
tmp_1002050:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1002042 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1002086:
return tmp_1002042;
}
reg_t genfunc_tmp_1002030 (void) {
reg_t tmp_1001824;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1001815();
goto next_tmp_1002004;
next_tmp_1002004:
goto tmp_1002003;
tmp_1002003:
}
tmp_981838 = tmp_1001824 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1002029:
return tmp_1001824;
}
reg_t genfunc_tmp_1001973 (void) {
reg_t tmp_1001909;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1001934 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1001934 >> 8) == 0)
field_imm = tmp_1001934;
else goto fail_tmp_1001933;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1001885();
goto next_tmp_1001937;
next_tmp_1001937:
goto tmp_1001936;
tmp_1001936:
}
tmp_982314 = tmp_1001909 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1001972;
fail_tmp_1001933:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1001962 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1001962))
field_imm = inv_maskmask(8, tmp_1001962);
else goto fail_tmp_1001961;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1001885();
goto next_tmp_1001965;
next_tmp_1001965:
goto tmp_1001964;
tmp_1001964:
}
tmp_981531 = tmp_1001909 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1001972;
fail_tmp_1001961:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1001885();
goto next_tmp_1001970;
next_tmp_1001970:
goto tmp_1001969;
tmp_1001969:
}
tmp_981523 = tmp_1001909 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1001972:
return tmp_1001909;
}
reg_t genfunc_tmp_1001885 (void) {
reg_t tmp_1001840;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1001815();
goto next_tmp_1001882;
next_tmp_1001882:
goto tmp_1001881;
tmp_1001881:
}
tmp_981838 = tmp_1001840 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1001884:
return tmp_1001840;
}
reg_t genfunc_tmp_1001815 (void) {
reg_t tmp_1001656;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1001774 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1001774 >> 8) == 0)
field_imm = tmp_1001774;
else goto fail_tmp_1001773;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1001703();
goto next_tmp_1001777;
next_tmp_1001777:
goto tmp_1001776;
tmp_1001776:
}
tmp_982314 = tmp_1001656 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1001814;
fail_tmp_1001773:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1001804 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1001804))
field_imm = inv_maskmask(8, tmp_1001804);
else goto fail_tmp_1001803;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1001703();
goto next_tmp_1001807;
next_tmp_1001807:
goto tmp_1001806;
tmp_1001806:
}
tmp_981531 = tmp_1001656 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1001814;
fail_tmp_1001803:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1001703();
goto next_tmp_1001812;
next_tmp_1001812:
goto tmp_1001811;
tmp_1001811:
}
tmp_981523 = tmp_1001656 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1001814:
return tmp_1001656;
}
reg_t genfunc_tmp_1001771 (void) {
reg_t tmp_1001707;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1001732 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1001732 >> 8) == 0)
field_imm = tmp_1001732;
else goto fail_tmp_1001731;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1001703();
goto next_tmp_1001735;
next_tmp_1001735:
goto tmp_1001734;
tmp_1001734:
}
tmp_982314 = tmp_1001707 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1001770;
fail_tmp_1001731:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1001760 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1001760))
field_imm = inv_maskmask(8, tmp_1001760);
else goto fail_tmp_1001759;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1001703();
goto next_tmp_1001763;
next_tmp_1001763:
goto tmp_1001762;
tmp_1001762:
}
tmp_981531 = tmp_1001707 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1001770;
fail_tmp_1001759:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1001703();
goto next_tmp_1001768;
next_tmp_1001768:
goto tmp_1001767;
tmp_1001767:
}
tmp_981523 = tmp_1001707 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1001770:
return tmp_1001707;
}
reg_t genfunc_tmp_1001703 (void) {
reg_t tmp_1001672;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_1001700;
field_ra = 31;
/* commit */
tmp_981699 = ref_gpr_reg_for_reading(0 + base);
tmp_981697 = tmp_1001672 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 1 */
}
goto done_tmp_1001702;
fail_tmp_1001700:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_1001701;
field_ra = 31;
/* commit */
tmp_981667 = ref_gpr_reg_for_reading(0 + base);
tmp_981665 = tmp_1001672 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 1 */
}
goto done_tmp_1001702;
fail_tmp_1001701:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_982357 = ref_gpr_reg_for_reading(0 + base);
tmp_982354 = tmp_1001672 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_1001702:
return tmp_1001672;
}
void genfunc_tmp_1001651 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_1001338();
goto next_tmp_1001169;
next_tmp_1001169:
goto tmp_1001168;
tmp_1001168:
}
{
tmp_981603 = genfunc_tmp_1001648();
goto next_tmp_1001342;
next_tmp_1001342:
goto tmp_1001341;
tmp_1001341:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 13 */
}
done_tmp_1001650:
}
reg_t genfunc_tmp_1001648 (void) {
reg_t tmp_1001340;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1001553();
goto next_tmp_1001349;
next_tmp_1001349:
goto tmp_1001348;
tmp_1001348:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1001340 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 7 */
}
done_tmp_1001647:
return tmp_1001340;
}
reg_t genfunc_tmp_1001610 (void) {
reg_t tmp_1001565;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1001553();
goto next_tmp_1001574;
next_tmp_1001574:
goto tmp_1001573;
tmp_1001573:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1001565 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 7 */
}
done_tmp_1001609:
return tmp_1001565;
}
reg_t genfunc_tmp_1001553 (void) {
reg_t tmp_1001347;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1001338();
goto next_tmp_1001527;
next_tmp_1001527:
goto tmp_1001526;
tmp_1001526:
}
tmp_981838 = tmp_1001347 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1001552:
return tmp_1001347;
}
reg_t genfunc_tmp_1001496 (void) {
reg_t tmp_1001432;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1001457 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1001457 >> 8) == 0)
field_imm = tmp_1001457;
else goto fail_tmp_1001456;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1001408();
goto next_tmp_1001460;
next_tmp_1001460:
goto tmp_1001459;
tmp_1001459:
}
tmp_982314 = tmp_1001432 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 7 */
}
goto done_tmp_1001495;
fail_tmp_1001456:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1001485 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1001485))
field_imm = inv_maskmask(8, tmp_1001485);
else goto fail_tmp_1001484;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1001408();
goto next_tmp_1001488;
next_tmp_1001488:
goto tmp_1001487;
tmp_1001487:
}
tmp_981531 = tmp_1001432 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 7 */
}
goto done_tmp_1001495;
fail_tmp_1001484:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1001408();
goto next_tmp_1001493;
next_tmp_1001493:
goto tmp_1001492;
tmp_1001492:
}
tmp_981523 = tmp_1001432 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 7 */
}
done_tmp_1001495:
return tmp_1001432;
}
reg_t genfunc_tmp_1001408 (void) {
reg_t tmp_1001363;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1001338();
goto next_tmp_1001405;
next_tmp_1001405:
goto tmp_1001404;
tmp_1001404:
}
tmp_981838 = tmp_1001363 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1001407:
return tmp_1001363;
}
reg_t genfunc_tmp_1001338 (void) {
reg_t tmp_1001167;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1001297 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1001297 >> 8) == 0)
field_imm = tmp_1001297;
else goto fail_tmp_1001296;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1001226();
goto next_tmp_1001300;
next_tmp_1001300:
goto tmp_1001299;
tmp_1001299:
}
tmp_982314 = tmp_1001167 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1001337;
fail_tmp_1001296:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1001327 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1001327))
field_imm = inv_maskmask(8, tmp_1001327);
else goto fail_tmp_1001326;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1001226();
goto next_tmp_1001330;
next_tmp_1001330:
goto tmp_1001329;
tmp_1001329:
}
tmp_981531 = tmp_1001167 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1001337;
fail_tmp_1001326:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1001226();
goto next_tmp_1001335;
next_tmp_1001335:
goto tmp_1001334;
tmp_1001334:
}
tmp_981523 = tmp_1001167 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1001337:
return tmp_1001167;
}
reg_t genfunc_tmp_1001294 (void) {
reg_t tmp_1001230;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1001255 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1001255 >> 8) == 0)
field_imm = tmp_1001255;
else goto fail_tmp_1001254;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1001226();
goto next_tmp_1001258;
next_tmp_1001258:
goto tmp_1001257;
tmp_1001257:
}
tmp_982314 = tmp_1001230 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1001293;
fail_tmp_1001254:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1001283 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1001283))
field_imm = inv_maskmask(8, tmp_1001283);
else goto fail_tmp_1001282;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1001226();
goto next_tmp_1001286;
next_tmp_1001286:
goto tmp_1001285;
tmp_1001285:
}
tmp_981531 = tmp_1001230 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1001293;
fail_tmp_1001282:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1001226();
goto next_tmp_1001291;
next_tmp_1001291:
goto tmp_1001290;
tmp_1001290:
}
tmp_981523 = tmp_1001230 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1001293:
return tmp_1001230;
}
reg_t genfunc_tmp_1001226 (void) {
reg_t tmp_1001183;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_1001215;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_998063();
goto next_tmp_1001218;
next_tmp_1001218:
goto tmp_1001217;
tmp_1001217:
}
tmp_981697 = tmp_1001183 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1001225;
fail_tmp_1001215:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_1001220;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_998063();
goto next_tmp_1001223;
next_tmp_1001223:
goto tmp_1001222;
tmp_1001222:
}
tmp_981665 = tmp_1001183 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1001225;
fail_tmp_1001220:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_982357 = genfunc_tmp_998063();
goto next_tmp_1001192;
next_tmp_1001192:
goto tmp_1001191;
tmp_1001191:
}
tmp_982354 = tmp_1001183 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1001225:
return tmp_1001183;
}
void genfunc_tmp_1001162 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_1000849();
goto next_tmp_1000680;
next_tmp_1000680:
goto tmp_1000679;
tmp_1000679:
}
{
tmp_981603 = genfunc_tmp_1001159();
goto next_tmp_1000853;
next_tmp_1000853:
goto tmp_1000852;
tmp_1000852:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 11 */
}
done_tmp_1001161:
}
reg_t genfunc_tmp_1001159 (void) {
reg_t tmp_1000851;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1001064();
goto next_tmp_1000860;
next_tmp_1000860:
goto tmp_1000859;
tmp_1000859:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1000851 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1001158:
return tmp_1000851;
}
reg_t genfunc_tmp_1001121 (void) {
reg_t tmp_1001076;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1001064();
goto next_tmp_1001085;
next_tmp_1001085:
goto tmp_1001084;
tmp_1001084:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1001076 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1001120:
return tmp_1001076;
}
reg_t genfunc_tmp_1001064 (void) {
reg_t tmp_1000858;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1000849();
goto next_tmp_1001038;
next_tmp_1001038:
goto tmp_1001037;
tmp_1001037:
}
tmp_981838 = tmp_1000858 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1001063:
return tmp_1000858;
}
reg_t genfunc_tmp_1001007 (void) {
reg_t tmp_1000943;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1000968 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1000968 >> 8) == 0)
field_imm = tmp_1000968;
else goto fail_tmp_1000967;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1000919();
goto next_tmp_1000971;
next_tmp_1000971:
goto tmp_1000970;
tmp_1000970:
}
tmp_982314 = tmp_1000943 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 6 */
}
goto done_tmp_1001006;
fail_tmp_1000967:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1000996 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1000996))
field_imm = inv_maskmask(8, tmp_1000996);
else goto fail_tmp_1000995;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1000919();
goto next_tmp_1000999;
next_tmp_1000999:
goto tmp_1000998;
tmp_1000998:
}
tmp_981531 = tmp_1000943 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 6 */
}
goto done_tmp_1001006;
fail_tmp_1000995:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1000919();
goto next_tmp_1001004;
next_tmp_1001004:
goto tmp_1001003;
tmp_1001003:
}
tmp_981523 = tmp_1000943 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 6 */
}
done_tmp_1001006:
return tmp_1000943;
}
reg_t genfunc_tmp_1000919 (void) {
reg_t tmp_1000874;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1000849();
goto next_tmp_1000916;
next_tmp_1000916:
goto tmp_1000915;
tmp_1000915:
}
tmp_981838 = tmp_1000874 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1000918:
return tmp_1000874;
}
reg_t genfunc_tmp_1000849 (void) {
reg_t tmp_1000678;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1000808 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1000808 >> 8) == 0)
field_imm = tmp_1000808;
else goto fail_tmp_1000807;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1000737();
goto next_tmp_1000811;
next_tmp_1000811:
goto tmp_1000810;
tmp_1000810:
}
tmp_982314 = tmp_1000678 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1000848;
fail_tmp_1000807:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1000838 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1000838))
field_imm = inv_maskmask(8, tmp_1000838);
else goto fail_tmp_1000837;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1000737();
goto next_tmp_1000841;
next_tmp_1000841:
goto tmp_1000840;
tmp_1000840:
}
tmp_981531 = tmp_1000678 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1000848;
fail_tmp_1000837:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1000737();
goto next_tmp_1000846;
next_tmp_1000846:
goto tmp_1000845;
tmp_1000845:
}
tmp_981523 = tmp_1000678 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1000848:
return tmp_1000678;
}
reg_t genfunc_tmp_1000805 (void) {
reg_t tmp_1000741;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1000766 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1000766 >> 8) == 0)
field_imm = tmp_1000766;
else goto fail_tmp_1000765;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1000737();
goto next_tmp_1000769;
next_tmp_1000769:
goto tmp_1000768;
tmp_1000768:
}
tmp_982314 = tmp_1000741 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1000804;
fail_tmp_1000765:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1000794 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1000794))
field_imm = inv_maskmask(8, tmp_1000794);
else goto fail_tmp_1000793;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1000737();
goto next_tmp_1000797;
next_tmp_1000797:
goto tmp_1000796;
tmp_1000796:
}
tmp_981531 = tmp_1000741 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1000804;
fail_tmp_1000793:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1000737();
goto next_tmp_1000802;
next_tmp_1000802:
goto tmp_1000801;
tmp_1000801:
}
tmp_981523 = tmp_1000741 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1000804:
return tmp_1000741;
}
reg_t genfunc_tmp_1000737 (void) {
reg_t tmp_1000694;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_1000726;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_997544();
goto next_tmp_1000729;
next_tmp_1000729:
goto tmp_1000728;
tmp_1000728:
}
tmp_981697 = tmp_1000694 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 2 */
}
goto done_tmp_1000736;
fail_tmp_1000726:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_1000731;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_997544();
goto next_tmp_1000734;
next_tmp_1000734:
goto tmp_1000733;
tmp_1000733:
}
tmp_981665 = tmp_1000694 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 2 */
}
goto done_tmp_1000736;
fail_tmp_1000731:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_982357 = genfunc_tmp_997544();
goto next_tmp_1000703;
next_tmp_1000703:
goto tmp_1000702;
tmp_1000702:
}
tmp_982354 = tmp_1000694 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1000736:
return tmp_1000694;
}
void genfunc_tmp_1000673 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_1000360();
goto next_tmp_1000198;
next_tmp_1000198:
goto tmp_1000197;
tmp_1000197:
}
{
tmp_981603 = genfunc_tmp_1000670();
goto next_tmp_1000364;
next_tmp_1000364:
goto tmp_1000363;
tmp_1000363:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_1000672:
}
reg_t genfunc_tmp_1000670 (void) {
reg_t tmp_1000362;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1000575();
goto next_tmp_1000371;
next_tmp_1000371:
goto tmp_1000370;
tmp_1000370:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1000362 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1000669:
return tmp_1000362;
}
reg_t genfunc_tmp_1000632 (void) {
reg_t tmp_1000587;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1000575();
goto next_tmp_1000596;
next_tmp_1000596:
goto tmp_1000595;
tmp_1000595:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1000587 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1000631:
return tmp_1000587;
}
reg_t genfunc_tmp_1000575 (void) {
reg_t tmp_1000369;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1000360();
goto next_tmp_1000549;
next_tmp_1000549:
goto tmp_1000548;
tmp_1000548:
}
tmp_981838 = tmp_1000369 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1000574:
return tmp_1000369;
}
reg_t genfunc_tmp_1000518 (void) {
reg_t tmp_1000454;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1000479 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1000479 >> 8) == 0)
field_imm = tmp_1000479;
else goto fail_tmp_1000478;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1000430();
goto next_tmp_1000482;
next_tmp_1000482:
goto tmp_1000481;
tmp_1000481:
}
tmp_982314 = tmp_1000454 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1000517;
fail_tmp_1000478:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1000507 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1000507))
field_imm = inv_maskmask(8, tmp_1000507);
else goto fail_tmp_1000506;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1000430();
goto next_tmp_1000510;
next_tmp_1000510:
goto tmp_1000509;
tmp_1000509:
}
tmp_981531 = tmp_1000454 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_1000517;
fail_tmp_1000506:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1000430();
goto next_tmp_1000515;
next_tmp_1000515:
goto tmp_1000514;
tmp_1000514:
}
tmp_981523 = tmp_1000454 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1000517:
return tmp_1000454;
}
reg_t genfunc_tmp_1000430 (void) {
reg_t tmp_1000385;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_1000360();
goto next_tmp_1000427;
next_tmp_1000427:
goto tmp_1000426;
tmp_1000426:
}
tmp_981838 = tmp_1000385 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_1000429:
return tmp_1000385;
}
reg_t genfunc_tmp_1000360 (void) {
reg_t tmp_1000196;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1000319 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1000319 >> 8) == 0)
field_imm = tmp_1000319;
else goto fail_tmp_1000318;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1000248();
goto next_tmp_1000322;
next_tmp_1000322:
goto tmp_1000321;
tmp_1000321:
}
tmp_982314 = tmp_1000196 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1000359;
fail_tmp_1000318:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1000349 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1000349))
field_imm = inv_maskmask(8, tmp_1000349);
else goto fail_tmp_1000348;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1000248();
goto next_tmp_1000352;
next_tmp_1000352:
goto tmp_1000351;
tmp_1000351:
}
tmp_981531 = tmp_1000196 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1000359;
fail_tmp_1000348:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1000248();
goto next_tmp_1000357;
next_tmp_1000357:
goto tmp_1000356;
tmp_1000356:
}
tmp_981523 = tmp_1000196 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1000359:
return tmp_1000196;
}
reg_t genfunc_tmp_1000316 (void) {
reg_t tmp_1000252;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_1000277 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_1000277 >> 8) == 0)
field_imm = tmp_1000277;
else goto fail_tmp_1000276;
}
/* commit */
{
tmp_982315 = genfunc_tmp_1000248();
goto next_tmp_1000280;
next_tmp_1000280:
goto tmp_1000279;
tmp_1000279:
}
tmp_982314 = tmp_1000252 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1000315;
fail_tmp_1000276:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1000305 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1000305))
field_imm = inv_maskmask(8, tmp_1000305);
else goto fail_tmp_1000304;
}
/* commit */
{
tmp_981532 = genfunc_tmp_1000248();
goto next_tmp_1000308;
next_tmp_1000308:
goto tmp_1000307;
tmp_1000307:
}
tmp_981531 = tmp_1000252 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1000315;
fail_tmp_1000304:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_1000248();
goto next_tmp_1000313;
next_tmp_1000313:
goto tmp_1000312;
tmp_1000312:
}
tmp_981523 = tmp_1000252 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1000315:
return tmp_1000252;
}
reg_t genfunc_tmp_1000248 (void) {
reg_t tmp_1000212;
/* ADDQ_IMM */
{
word_5 tmp_982350;
word_5 field_rc;
word_5 tmp_982351;
word_5 field_ra;
word_64 tmp_982353;
word_8 field_imm;
tmp_982353 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_1000229 = tmp_982353;
if ((tmp_1000229 >> 8) == 0)
field_imm = tmp_1000229;
else goto fail_tmp_1000228;
}
/* commit */
tmp_982351 = ref_gpr_reg_for_reading(0 + rm);
tmp_982350 = tmp_1000212 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982350;
field_ra = tmp_982351;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982351);
/* can fail: T   num insns: 1 */
}
goto done_tmp_1000247;
fail_tmp_1000228:
/* LDA */
{
word_5 tmp_981854;
word_5 field_ra;
word_5 tmp_981855;
word_5 field_rb;
word_64 tmp_981857;
word_16 field_memory_disp;
tmp_981857 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_1000240 = tmp_981857;
if ((tmp_1000240 >> 16) == 0xFFFFFFFFFFFF || (tmp_1000240 >> 16) == 0)
field_memory_disp = (tmp_1000240 & 0xFFFF);
else goto fail_tmp_1000239;
}
/* commit */
tmp_981855 = ref_gpr_reg_for_reading(0 + rm);
tmp_981854 = tmp_1000212 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981854;
field_rb = tmp_981855;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981855);
/* can fail: T   num insns: 1 */
}
goto done_tmp_1000247;
fail_tmp_1000239:
/* LDAH */
{
word_5 tmp_981850;
word_5 field_ra;
word_5 tmp_981851;
word_5 field_rb;
word_64 tmp_981853;
word_16 field_memory_disp;
tmp_981853 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_1000245 = tmp_981853;
if ((tmp_1000245 & 0xFFFF) == 0)
{
word_64 tmp_1000246 = (tmp_1000245 >> 16);
if ((tmp_1000246 >> 16) == 0xFFFFFFFFFFFF || (tmp_1000246 >> 16) == 0)
field_memory_disp = (tmp_1000246 & 0xFFFF);
else goto fail_tmp_1000244;
}
else goto fail_tmp_1000244;
}
/* commit */
tmp_981851 = ref_gpr_reg_for_reading(0 + rm);
tmp_981850 = tmp_1000212 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981850;
field_rb = tmp_981851;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981851);
/* can fail: T   num insns: 1 */
}
goto done_tmp_1000247;
fail_tmp_1000244:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_reading(0 + rm);
tmp_982357 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982357, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_982354 = tmp_1000212 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_1000247:
return tmp_1000212;
}
void genfunc_tmp_1000188 (void) {
/* STL */
{
word_5 field_rb;
word_64 tmp_981600;
word_16 field_memory_disp;
word_5 tmp_981602;
word_5 field_ra;
tmp_981600 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_1000182 = tmp_981600;
if ((tmp_1000182 >> 16) == 0xFFFFFFFFFFFF || (tmp_1000182 >> 16) == 0)
field_memory_disp = (tmp_1000182 & 0xFFFF);
else goto fail_tmp_1000181;
}
/* commit */
{
tmp_981602 = genfunc_tmp_1000179();
goto next_tmp_1000185;
next_tmp_1000185:
goto tmp_1000184;
tmp_1000184:
}
field_ra = tmp_981602;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981602);
/* can fail: T   num insns: 4 */
}
goto done_tmp_1000187;
fail_tmp_1000181:
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
tmp_981599 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_981599, ((word_64)disp32));
{
tmp_981603 = genfunc_tmp_1000179();
goto next_tmp_999877;
next_tmp_999877:
goto tmp_999876;
tmp_999876:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 5 */
}
done_tmp_1000187:
}
reg_t genfunc_tmp_1000179 (void) {
reg_t tmp_999875;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1000084();
goto next_tmp_999884;
next_tmp_999884:
goto tmp_999883;
tmp_999883:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_999875 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1000178:
return tmp_999875;
}
reg_t genfunc_tmp_1000141 (void) {
reg_t tmp_1000096;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_1000084();
goto next_tmp_1000105;
next_tmp_1000105:
goto tmp_1000104;
tmp_1000104:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_1000096 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1000140:
return tmp_1000096;
}
reg_t genfunc_tmp_1000084 (void) {
reg_t tmp_999882;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_981840;
word_16 field_memory_disp;
tmp_981840 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_1000059 = tmp_981840;
if ((tmp_1000059 >> 16) == 0xFFFFFFFFFFFF || (tmp_1000059 >> 16) == 0)
field_memory_disp = (tmp_1000059 & 0xFFFF);
else goto fail_tmp_1000058;
}
/* commit */
tmp_981838 = tmp_999882 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_1000083;
fail_tmp_1000058:
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
tmp_981839 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_981839, ((word_64)disp32));
tmp_981838 = tmp_999882 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 2 */
}
done_tmp_1000083:
return tmp_999882;
}
reg_t genfunc_tmp_1000029 (void) {
reg_t tmp_999965;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_999990 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_999990 >> 8) == 0)
field_imm = tmp_999990;
else goto fail_tmp_999989;
}
/* commit */
{
tmp_982315 = genfunc_tmp_999941();
goto next_tmp_999993;
next_tmp_999993:
goto tmp_999992;
tmp_999992:
}
tmp_982314 = tmp_999965 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1000028;
fail_tmp_999989:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_1000018 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_1000018))
field_imm = inv_maskmask(8, tmp_1000018);
else goto fail_tmp_1000017;
}
/* commit */
{
tmp_981532 = genfunc_tmp_999941();
goto next_tmp_1000021;
next_tmp_1000021:
goto tmp_1000020;
tmp_1000020:
}
tmp_981531 = tmp_999965 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_1000028;
fail_tmp_1000017:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_999941();
goto next_tmp_1000026;
next_tmp_1000026:
goto tmp_1000025;
tmp_1000025:
}
tmp_981523 = tmp_999965 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_1000028:
return tmp_999965;
}
reg_t genfunc_tmp_999941 (void) {
reg_t tmp_999898;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_981840;
word_16 field_memory_disp;
tmp_981840 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_999939 = tmp_981840;
if ((tmp_999939 >> 16) == 0xFFFFFFFFFFFF || (tmp_999939 >> 16) == 0)
field_memory_disp = (tmp_999939 & 0xFFFF);
else goto fail_tmp_999938;
}
/* commit */
tmp_981838 = tmp_999898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_999940;
fail_tmp_999938:
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
tmp_981839 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_981839, ((word_64)disp32));
tmp_981838 = tmp_999898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 2 */
}
done_tmp_999940:
return tmp_999898;
}
void genfunc_tmp_999870 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_999557();
goto next_tmp_999388;
next_tmp_999388:
goto tmp_999387;
tmp_999387:
}
{
tmp_981603 = genfunc_tmp_999867();
goto next_tmp_999561;
next_tmp_999561:
goto tmp_999560;
tmp_999560:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 11 */
}
done_tmp_999869:
}
reg_t genfunc_tmp_999867 (void) {
reg_t tmp_999559;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_999772();
goto next_tmp_999568;
next_tmp_999568:
goto tmp_999567;
tmp_999567:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_999559 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 6 */
}
done_tmp_999866:
return tmp_999559;
}
reg_t genfunc_tmp_999829 (void) {
reg_t tmp_999784;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_999772();
goto next_tmp_999793;
next_tmp_999793:
goto tmp_999792;
tmp_999792:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_999784 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 6 */
}
done_tmp_999828:
return tmp_999784;
}
reg_t genfunc_tmp_999772 (void) {
reg_t tmp_999566;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_999557();
goto next_tmp_999746;
next_tmp_999746:
goto tmp_999745;
tmp_999745:
}
tmp_981838 = tmp_999566 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_999771:
return tmp_999566;
}
reg_t genfunc_tmp_999715 (void) {
reg_t tmp_999651;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_999676 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_999676 >> 8) == 0)
field_imm = tmp_999676;
else goto fail_tmp_999675;
}
/* commit */
{
tmp_982315 = genfunc_tmp_999627();
goto next_tmp_999679;
next_tmp_999679:
goto tmp_999678;
tmp_999678:
}
tmp_982314 = tmp_999651 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 6 */
}
goto done_tmp_999714;
fail_tmp_999675:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_999704 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_999704))
field_imm = inv_maskmask(8, tmp_999704);
else goto fail_tmp_999703;
}
/* commit */
{
tmp_981532 = genfunc_tmp_999627();
goto next_tmp_999707;
next_tmp_999707:
goto tmp_999706;
tmp_999706:
}
tmp_981531 = tmp_999651 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 6 */
}
goto done_tmp_999714;
fail_tmp_999703:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_999627();
goto next_tmp_999712;
next_tmp_999712:
goto tmp_999711;
tmp_999711:
}
tmp_981523 = tmp_999651 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 6 */
}
done_tmp_999714:
return tmp_999651;
}
reg_t genfunc_tmp_999627 (void) {
reg_t tmp_999582;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_999557();
goto next_tmp_999624;
next_tmp_999624:
goto tmp_999623;
tmp_999623:
}
tmp_981838 = tmp_999582 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 5 */
}
done_tmp_999626:
return tmp_999582;
}
reg_t genfunc_tmp_999557 (void) {
reg_t tmp_999386;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_999516 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_999516 >> 8) == 0)
field_imm = tmp_999516;
else goto fail_tmp_999515;
}
/* commit */
{
tmp_982315 = genfunc_tmp_999445();
goto next_tmp_999519;
next_tmp_999519:
goto tmp_999518;
tmp_999518:
}
tmp_982314 = tmp_999386 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_999556;
fail_tmp_999515:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_999546 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_999546))
field_imm = inv_maskmask(8, tmp_999546);
else goto fail_tmp_999545;
}
/* commit */
{
tmp_981532 = genfunc_tmp_999445();
goto next_tmp_999549;
next_tmp_999549:
goto tmp_999548;
tmp_999548:
}
tmp_981531 = tmp_999386 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_999556;
fail_tmp_999545:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_999445();
goto next_tmp_999554;
next_tmp_999554:
goto tmp_999553;
tmp_999553:
}
tmp_981523 = tmp_999386 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_999556:
return tmp_999386;
}
reg_t genfunc_tmp_999513 (void) {
reg_t tmp_999449;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_999474 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_999474 >> 8) == 0)
field_imm = tmp_999474;
else goto fail_tmp_999473;
}
/* commit */
{
tmp_982315 = genfunc_tmp_999445();
goto next_tmp_999477;
next_tmp_999477:
goto tmp_999476;
tmp_999476:
}
tmp_982314 = tmp_999449 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_999512;
fail_tmp_999473:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_999502 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_999502))
field_imm = inv_maskmask(8, tmp_999502);
else goto fail_tmp_999501;
}
/* commit */
{
tmp_981532 = genfunc_tmp_999445();
goto next_tmp_999505;
next_tmp_999505:
goto tmp_999504;
tmp_999504:
}
tmp_981531 = tmp_999449 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_999512;
fail_tmp_999501:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_999445();
goto next_tmp_999510;
next_tmp_999510:
goto tmp_999509;
tmp_999509:
}
tmp_981523 = tmp_999449 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_999512:
return tmp_999449;
}
reg_t genfunc_tmp_999445 (void) {
reg_t tmp_999402;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_999434;
field_ra = 31;
/* commit */
{
tmp_981699 = genfunc_tmp_998039();
goto next_tmp_999437;
next_tmp_999437:
goto tmp_999436;
tmp_999436:
}
tmp_981697 = tmp_999402 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 2 */
}
goto done_tmp_999444;
fail_tmp_999434:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_999439;
field_ra = 31;
/* commit */
{
tmp_981667 = genfunc_tmp_998039();
goto next_tmp_999442;
next_tmp_999442:
goto tmp_999441;
tmp_999441:
}
tmp_981665 = tmp_999402 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 2 */
}
goto done_tmp_999444;
fail_tmp_999439:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_982357 = genfunc_tmp_998039();
goto next_tmp_999411;
next_tmp_999411:
goto tmp_999410;
tmp_999410:
}
tmp_982354 = tmp_999402 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 3 */
}
done_tmp_999444:
return tmp_999402;
}
void genfunc_tmp_999381 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_999068();
goto next_tmp_998911;
next_tmp_998911:
goto tmp_998910;
tmp_998910:
}
{
tmp_981603 = genfunc_tmp_999378();
goto next_tmp_999072;
next_tmp_999072:
goto tmp_999071;
tmp_999071:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_999380:
}
reg_t genfunc_tmp_999378 (void) {
reg_t tmp_999070;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_999283();
goto next_tmp_999079;
next_tmp_999079:
goto tmp_999078;
tmp_999078:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_999070 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_999377:
return tmp_999070;
}
reg_t genfunc_tmp_999340 (void) {
reg_t tmp_999295;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_999283();
goto next_tmp_999304;
next_tmp_999304:
goto tmp_999303;
tmp_999303:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_999295 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_999339:
return tmp_999295;
}
reg_t genfunc_tmp_999283 (void) {
reg_t tmp_999077;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_999068();
goto next_tmp_999257;
next_tmp_999257:
goto tmp_999256;
tmp_999256:
}
tmp_981838 = tmp_999077 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_999282:
return tmp_999077;
}
reg_t genfunc_tmp_999226 (void) {
reg_t tmp_999162;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_999187 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_999187 >> 8) == 0)
field_imm = tmp_999187;
else goto fail_tmp_999186;
}
/* commit */
{
tmp_982315 = genfunc_tmp_999138();
goto next_tmp_999190;
next_tmp_999190:
goto tmp_999189;
tmp_999189:
}
tmp_982314 = tmp_999162 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_999225;
fail_tmp_999186:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_999215 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_999215))
field_imm = inv_maskmask(8, tmp_999215);
else goto fail_tmp_999214;
}
/* commit */
{
tmp_981532 = genfunc_tmp_999138();
goto next_tmp_999218;
next_tmp_999218:
goto tmp_999217;
tmp_999217:
}
tmp_981531 = tmp_999162 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_999225;
fail_tmp_999214:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_999138();
goto next_tmp_999223;
next_tmp_999223:
goto tmp_999222;
tmp_999222:
}
tmp_981523 = tmp_999162 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_999225:
return tmp_999162;
}
reg_t genfunc_tmp_999138 (void) {
reg_t tmp_999093;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_999068();
goto next_tmp_999135;
next_tmp_999135:
goto tmp_999134;
tmp_999134:
}
tmp_981838 = tmp_999093 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_999137:
return tmp_999093;
}
reg_t genfunc_tmp_999068 (void) {
reg_t tmp_998909;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_999027 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_999027 >> 8) == 0)
field_imm = tmp_999027;
else goto fail_tmp_999026;
}
/* commit */
{
tmp_982315 = genfunc_tmp_998956();
goto next_tmp_999030;
next_tmp_999030:
goto tmp_999029;
tmp_999029:
}
tmp_982314 = tmp_998909 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_999067;
fail_tmp_999026:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_999057 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_999057))
field_imm = inv_maskmask(8, tmp_999057);
else goto fail_tmp_999056;
}
/* commit */
{
tmp_981532 = genfunc_tmp_998956();
goto next_tmp_999060;
next_tmp_999060:
goto tmp_999059;
tmp_999059:
}
tmp_981531 = tmp_998909 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_999067;
fail_tmp_999056:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_998956();
goto next_tmp_999065;
next_tmp_999065:
goto tmp_999064;
tmp_999064:
}
tmp_981523 = tmp_998909 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_999067:
return tmp_998909;
}
reg_t genfunc_tmp_999024 (void) {
reg_t tmp_998960;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_998985 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_998985 >> 8) == 0)
field_imm = tmp_998985;
else goto fail_tmp_998984;
}
/* commit */
{
tmp_982315 = genfunc_tmp_998956();
goto next_tmp_998988;
next_tmp_998988:
goto tmp_998987;
tmp_998987:
}
tmp_982314 = tmp_998960 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_999023;
fail_tmp_998984:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_999013 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_999013))
field_imm = inv_maskmask(8, tmp_999013);
else goto fail_tmp_999012;
}
/* commit */
{
tmp_981532 = genfunc_tmp_998956();
goto next_tmp_999016;
next_tmp_999016:
goto tmp_999015;
tmp_999015:
}
tmp_981531 = tmp_998960 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_999023;
fail_tmp_999012:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_998956();
goto next_tmp_999021;
next_tmp_999021:
goto tmp_999020;
tmp_999020:
}
tmp_981523 = tmp_998960 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_999023:
return tmp_998960;
}
reg_t genfunc_tmp_998956 (void) {
reg_t tmp_998925;
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981699;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_998953;
field_ra = 31;
/* commit */
tmp_981699 = ref_gpr_reg_for_reading(0 + index);
tmp_981697 = tmp_998925 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_rb = tmp_981699;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981699);
/* can fail: T   num insns: 1 */
}
goto done_tmp_998955;
fail_tmp_998953:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_981667;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_998954;
field_ra = 31;
/* commit */
tmp_981667 = ref_gpr_reg_for_reading(0 + index);
tmp_981665 = tmp_998925 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_rb = tmp_981667;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981667);
/* can fail: T   num insns: 1 */
}
goto done_tmp_998955;
fail_tmp_998954:
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_982355, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_982357 = ref_gpr_reg_for_reading(0 + index);
tmp_982354 = tmp_998925 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_998955:
return tmp_998925;
}
void genfunc_tmp_998904 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_998591();
goto next_tmp_998495;
next_tmp_998495:
goto tmp_998494;
tmp_998494:
}
{
tmp_981603 = genfunc_tmp_998901();
goto next_tmp_998595;
next_tmp_998595:
goto tmp_998594;
tmp_998594:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 5 */
}
done_tmp_998903:
}
reg_t genfunc_tmp_998901 (void) {
reg_t tmp_998593;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_998806();
goto next_tmp_998602;
next_tmp_998602:
goto tmp_998601;
tmp_998601:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_998593 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 3 */
}
done_tmp_998900:
return tmp_998593;
}
reg_t genfunc_tmp_998863 (void) {
reg_t tmp_998818;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_998806();
goto next_tmp_998827;
next_tmp_998827:
goto tmp_998826;
tmp_998826:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_998818 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 3 */
}
done_tmp_998862:
return tmp_998818;
}
reg_t genfunc_tmp_998806 (void) {
reg_t tmp_998600;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_998591();
goto next_tmp_998780;
next_tmp_998780:
goto tmp_998779;
tmp_998779:
}
tmp_981838 = tmp_998600 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 2 */
}
done_tmp_998805:
return tmp_998600;
}
reg_t genfunc_tmp_998749 (void) {
reg_t tmp_998685;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_998710 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_998710 >> 8) == 0)
field_imm = tmp_998710;
else goto fail_tmp_998709;
}
/* commit */
{
tmp_982315 = genfunc_tmp_998661();
goto next_tmp_998713;
next_tmp_998713:
goto tmp_998712;
tmp_998712:
}
tmp_982314 = tmp_998685 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_998748;
fail_tmp_998709:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_998738 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_998738))
field_imm = inv_maskmask(8, tmp_998738);
else goto fail_tmp_998737;
}
/* commit */
{
tmp_981532 = genfunc_tmp_998661();
goto next_tmp_998741;
next_tmp_998741:
goto tmp_998740;
tmp_998740:
}
tmp_981531 = tmp_998685 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_998748;
fail_tmp_998737:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_998661();
goto next_tmp_998746;
next_tmp_998746:
goto tmp_998745;
tmp_998745:
}
tmp_981523 = tmp_998685 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_998748:
return tmp_998685;
}
reg_t genfunc_tmp_998661 (void) {
reg_t tmp_998616;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_998591();
goto next_tmp_998658;
next_tmp_998658:
goto tmp_998657;
tmp_998657:
}
tmp_981838 = tmp_998616 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 2 */
}
done_tmp_998660:
return tmp_998616;
}
reg_t genfunc_tmp_998591 (void) {
reg_t tmp_998493;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_998562 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_998562 >> 8) == 0)
field_imm = tmp_998562;
else goto fail_tmp_998561;
}
/* commit */
tmp_982315 = ref_gpr_reg_for_reading(0 + base);
tmp_982314 = tmp_998493 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 1 */
}
goto done_tmp_998590;
fail_tmp_998561:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_998588 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_998588))
field_imm = inv_maskmask(8, tmp_998588);
else goto fail_tmp_998587;
}
/* commit */
tmp_981532 = ref_gpr_reg_for_reading(0 + base);
tmp_981531 = tmp_998493 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 1 */
}
goto done_tmp_998590;
fail_tmp_998587:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
tmp_981524 = ref_gpr_reg_for_reading(0 + base);
tmp_981523 = tmp_998493 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 1 */
}
done_tmp_998590:
return tmp_998493;
}
reg_t genfunc_tmp_998559 (void) {
reg_t tmp_998511;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_998532 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_998532 >> 8) == 0)
field_imm = tmp_998532;
else goto fail_tmp_998531;
}
/* commit */
tmp_982315 = ref_gpr_reg_for_reading(0 + base);
tmp_982314 = tmp_998511 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 1 */
}
goto done_tmp_998558;
fail_tmp_998531:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_998556 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_998556))
field_imm = inv_maskmask(8, tmp_998556);
else goto fail_tmp_998555;
}
/* commit */
tmp_981532 = ref_gpr_reg_for_reading(0 + base);
tmp_981531 = tmp_998511 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 1 */
}
goto done_tmp_998558;
fail_tmp_998555:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
tmp_981524 = ref_gpr_reg_for_reading(0 + base);
tmp_981523 = tmp_998511 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 1 */
}
done_tmp_998558:
return tmp_998511;
}
void genfunc_tmp_998488 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_998175();
goto next_tmp_997976;
next_tmp_997976:
goto tmp_997975;
tmp_997975:
}
{
tmp_981603 = genfunc_tmp_998485();
goto next_tmp_998179;
next_tmp_998179:
goto tmp_998178;
tmp_998178:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 9 */
}
done_tmp_998487:
}
reg_t genfunc_tmp_998485 (void) {
reg_t tmp_998177;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_998390();
goto next_tmp_998186;
next_tmp_998186:
goto tmp_998185;
tmp_998185:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_998177 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_998484:
return tmp_998177;
}
reg_t genfunc_tmp_998447 (void) {
reg_t tmp_998402;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_998390();
goto next_tmp_998411;
next_tmp_998411:
goto tmp_998410;
tmp_998410:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_998402 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 5 */
}
done_tmp_998446:
return tmp_998402;
}
reg_t genfunc_tmp_998390 (void) {
reg_t tmp_998184;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_998175();
goto next_tmp_998364;
next_tmp_998364:
goto tmp_998363;
tmp_998363:
}
tmp_981838 = tmp_998184 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_998389:
return tmp_998184;
}
reg_t genfunc_tmp_998333 (void) {
reg_t tmp_998269;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_998294 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_998294 >> 8) == 0)
field_imm = tmp_998294;
else goto fail_tmp_998293;
}
/* commit */
{
tmp_982315 = genfunc_tmp_998245();
goto next_tmp_998297;
next_tmp_998297:
goto tmp_998296;
tmp_998296:
}
tmp_982314 = tmp_998269 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 5 */
}
goto done_tmp_998332;
fail_tmp_998293:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_998322 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_998322))
field_imm = inv_maskmask(8, tmp_998322);
else goto fail_tmp_998321;
}
/* commit */
{
tmp_981532 = genfunc_tmp_998245();
goto next_tmp_998325;
next_tmp_998325:
goto tmp_998324;
tmp_998324:
}
tmp_981531 = tmp_998269 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 5 */
}
goto done_tmp_998332;
fail_tmp_998321:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_998245();
goto next_tmp_998330;
next_tmp_998330:
goto tmp_998329;
tmp_998329:
}
tmp_981523 = tmp_998269 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 5 */
}
done_tmp_998332:
return tmp_998269;
}
reg_t genfunc_tmp_998245 (void) {
reg_t tmp_998200;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_998175();
goto next_tmp_998242;
next_tmp_998242:
goto tmp_998241;
tmp_998241:
}
tmp_981838 = tmp_998200 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 4 */
}
done_tmp_998244:
return tmp_998200;
}
reg_t genfunc_tmp_998175 (void) {
reg_t tmp_997974;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_998134 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_998134 >> 8) == 0)
field_imm = tmp_998134;
else goto fail_tmp_998133;
}
/* commit */
{
tmp_982315 = genfunc_tmp_998063();
goto next_tmp_998137;
next_tmp_998137:
goto tmp_998136;
tmp_998136:
}
tmp_982314 = tmp_997974 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_998174;
fail_tmp_998133:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_998164 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_998164))
field_imm = inv_maskmask(8, tmp_998164);
else goto fail_tmp_998163;
}
/* commit */
{
tmp_981532 = genfunc_tmp_998063();
goto next_tmp_998167;
next_tmp_998167:
goto tmp_998166;
tmp_998166:
}
tmp_981531 = tmp_997974 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_998174;
fail_tmp_998163:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_998063();
goto next_tmp_998172;
next_tmp_998172:
goto tmp_998171;
tmp_998171:
}
tmp_981523 = tmp_997974 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_998174:
return tmp_997974;
}
reg_t genfunc_tmp_998131 (void) {
reg_t tmp_998067;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_998092 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_998092 >> 8) == 0)
field_imm = tmp_998092;
else goto fail_tmp_998091;
}
/* commit */
{
tmp_982315 = genfunc_tmp_998063();
goto next_tmp_998095;
next_tmp_998095:
goto tmp_998094;
tmp_998094:
}
tmp_982314 = tmp_998067 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_998130;
fail_tmp_998091:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_998120 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_998120))
field_imm = inv_maskmask(8, tmp_998120);
else goto fail_tmp_998119;
}
/* commit */
{
tmp_981532 = genfunc_tmp_998063();
goto next_tmp_998123;
next_tmp_998123:
goto tmp_998122;
tmp_998122:
}
tmp_981531 = tmp_998067 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_998130;
fail_tmp_998119:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_998063();
goto next_tmp_998128;
next_tmp_998128:
goto tmp_998127;
tmp_998127:
}
tmp_981523 = tmp_998067 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_998130:
return tmp_998067;
}
reg_t genfunc_tmp_998063 (void) {
reg_t tmp_997990;
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_reading(0 + base);
{
tmp_982357 = genfunc_tmp_998039();
goto next_tmp_997999;
next_tmp_997999:
goto tmp_997998;
tmp_997998:
}
tmp_982354 = tmp_997990 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 2 */
}
done_tmp_998062:
return tmp_997990;
}
reg_t genfunc_tmp_998039 (void) {
reg_t tmp_997997;
/* EXTQH */
{
word_5 tmp_982075;
word_5 field_rc;
word_5 tmp_982076;
word_5 field_ra;
word_5 field_rb;
if (64 != ((word_64)scale)) goto fail_tmp_998018;
field_rb = 31;
/* commit */
tmp_982076 = ref_gpr_reg_for_reading(0 + index);
tmp_982075 = tmp_997997 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982075;
field_ra = tmp_982076;
emit(COMPOSE_EXTQH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982076);
/* can fail: T   num insns: 1 */
}
goto done_tmp_998038;
fail_tmp_998018:
/* EXTQH_IMM */
{
word_5 tmp_982071;
word_5 field_rc;
word_5 tmp_982072;
word_5 field_ra;
word_64 tmp_982074;
word_8 field_imm;
tmp_982074 = ((word_64)scale);
{
word_64 tmp_998020 = ((64 - tmp_982074) & 0xFFFFFFFFFFFFFFFF);
if (tmp_998020 % 8 == 0)
{
word_64 tmp_998021 = (tmp_998020 / 8);
if ((tmp_998021 & 7) == tmp_998021)
{
word_64 tmp_998022 = tmp_998021;
if ((tmp_998022 >> 8) == 0)
field_imm = tmp_998022;
else goto fail_tmp_998019;
}
else goto fail_tmp_998019;
}
else goto fail_tmp_998019;
}
/* commit */
tmp_982072 = ref_gpr_reg_for_reading(0 + index);
tmp_982071 = tmp_997997 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982071;
field_ra = tmp_982072;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982072);
/* can fail: T   num insns: 1 */
}
goto done_tmp_998038;
fail_tmp_998019:
/* S4ADDQ */
{
word_5 tmp_981697;
word_5 field_rc;
word_5 tmp_981698;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_998030;
field_rb = 31;
/* commit */
tmp_981698 = ref_gpr_reg_for_reading(0 + index);
tmp_981697 = tmp_997997 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981697;
field_ra = tmp_981698;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981698);
/* can fail: T   num insns: 1 */
}
goto done_tmp_998038;
fail_tmp_998030:
/* S4ADDQ_IMM */
{
word_5 tmp_981693;
word_5 field_rc;
word_5 tmp_981694;
word_5 field_ra;
word_64 tmp_981696;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_998031;
tmp_981696 = 0;
field_imm = 0;
/* commit */
tmp_981694 = ref_gpr_reg_for_reading(0 + index);
tmp_981693 = tmp_997997 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981693;
field_ra = tmp_981694;
emit(COMPOSE_S4ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981694);
/* can fail: T   num insns: 1 */
}
goto done_tmp_998038;
fail_tmp_998031:
/* S8ADDQ */
{
word_5 tmp_981665;
word_5 field_rc;
word_5 tmp_981666;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_998033;
field_rb = 31;
/* commit */
tmp_981666 = ref_gpr_reg_for_reading(0 + index);
tmp_981665 = tmp_997997 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981665;
field_ra = tmp_981666;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981666);
/* can fail: T   num insns: 1 */
}
goto done_tmp_998038;
fail_tmp_998033:
/* S8ADDQ_IMM */
{
word_5 tmp_981661;
word_5 field_rc;
word_5 tmp_981662;
word_5 field_ra;
word_64 tmp_981664;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_998034;
tmp_981664 = 0;
field_imm = 0;
/* commit */
tmp_981662 = ref_gpr_reg_for_reading(0 + index);
tmp_981661 = tmp_997997 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981661;
field_ra = tmp_981662;
emit(COMPOSE_S8ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981662);
/* can fail: T   num insns: 1 */
}
goto done_tmp_998038;
fail_tmp_998034:
/* SLL */
{
word_5 tmp_981633;
word_5 field_rc;
word_5 tmp_981634;
word_5 field_ra;
word_5 field_rb;
if (0 != ((word_64)scale)) goto fail_tmp_998035;
field_rb = 31;
/* commit */
tmp_981634 = ref_gpr_reg_for_reading(0 + index);
tmp_981633 = tmp_997997 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981633;
field_ra = tmp_981634;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_981634);
/* can fail: T   num insns: 1 */
}
goto done_tmp_998038;
fail_tmp_998035:
/* SLL_IMM */
{
word_5 tmp_981629;
word_5 field_rc;
word_5 tmp_981630;
word_5 field_ra;
word_64 tmp_981632;
word_8 field_imm;
tmp_981632 = ((word_64)scale);
field_imm = tmp_981632;
/* commit */
tmp_981630 = ref_gpr_reg_for_reading(0 + index);
tmp_981629 = tmp_997997 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981629;
field_ra = tmp_981630;
emit(COMPOSE_SLL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981630);
/* can fail: NIL   num insns: 1 */
}
done_tmp_998038:
return tmp_997997;
}
void genfunc_tmp_997969 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_997656();
goto next_tmp_997501;
next_tmp_997501:
goto tmp_997500;
tmp_997500:
}
{
tmp_981603 = genfunc_tmp_997966();
goto next_tmp_997660;
next_tmp_997660:
goto tmp_997659;
tmp_997659:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 7 */
}
done_tmp_997968:
}
reg_t genfunc_tmp_997966 (void) {
reg_t tmp_997658;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_997871();
goto next_tmp_997667;
next_tmp_997667:
goto tmp_997666;
tmp_997666:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_997658 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 4 */
}
done_tmp_997965:
return tmp_997658;
}
reg_t genfunc_tmp_997928 (void) {
reg_t tmp_997883;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_997871();
goto next_tmp_997892;
next_tmp_997892:
goto tmp_997891;
tmp_997891:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_997883 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 4 */
}
done_tmp_997927:
return tmp_997883;
}
reg_t genfunc_tmp_997871 (void) {
reg_t tmp_997665;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_997656();
goto next_tmp_997845;
next_tmp_997845:
goto tmp_997844;
tmp_997844:
}
tmp_981838 = tmp_997665 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 3 */
}
done_tmp_997870:
return tmp_997665;
}
reg_t genfunc_tmp_997814 (void) {
reg_t tmp_997750;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_997775 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_997775 >> 8) == 0)
field_imm = tmp_997775;
else goto fail_tmp_997774;
}
/* commit */
{
tmp_982315 = genfunc_tmp_997726();
goto next_tmp_997778;
next_tmp_997778:
goto tmp_997777;
tmp_997777:
}
tmp_982314 = tmp_997750 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 4 */
}
goto done_tmp_997813;
fail_tmp_997774:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_997803 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_997803))
field_imm = inv_maskmask(8, tmp_997803);
else goto fail_tmp_997802;
}
/* commit */
{
tmp_981532 = genfunc_tmp_997726();
goto next_tmp_997806;
next_tmp_997806:
goto tmp_997805;
tmp_997805:
}
tmp_981531 = tmp_997750 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 4 */
}
goto done_tmp_997813;
fail_tmp_997802:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_997726();
goto next_tmp_997811;
next_tmp_997811:
goto tmp_997810;
tmp_997810:
}
tmp_981523 = tmp_997750 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 4 */
}
done_tmp_997813:
return tmp_997750;
}
reg_t genfunc_tmp_997726 (void) {
reg_t tmp_997681;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_997656();
goto next_tmp_997723;
next_tmp_997723:
goto tmp_997722;
tmp_997722:
}
tmp_981838 = tmp_997681 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 3 */
}
done_tmp_997725:
return tmp_997681;
}
reg_t genfunc_tmp_997656 (void) {
reg_t tmp_997499;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_997615 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_997615 >> 8) == 0)
field_imm = tmp_997615;
else goto fail_tmp_997614;
}
/* commit */
{
tmp_982315 = genfunc_tmp_997544();
goto next_tmp_997618;
next_tmp_997618:
goto tmp_997617;
tmp_997617:
}
tmp_982314 = tmp_997499 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 2 */
}
goto done_tmp_997655;
fail_tmp_997614:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_997645 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_997645))
field_imm = inv_maskmask(8, tmp_997645);
else goto fail_tmp_997644;
}
/* commit */
{
tmp_981532 = genfunc_tmp_997544();
goto next_tmp_997648;
next_tmp_997648:
goto tmp_997647;
tmp_997647:
}
tmp_981531 = tmp_997499 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 2 */
}
goto done_tmp_997655;
fail_tmp_997644:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_997544();
goto next_tmp_997653;
next_tmp_997653:
goto tmp_997652;
tmp_997652:
}
tmp_981523 = tmp_997499 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 2 */
}
done_tmp_997655:
return tmp_997499;
}
reg_t genfunc_tmp_997612 (void) {
reg_t tmp_997548;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_997573 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_997573 >> 8) == 0)
field_imm = tmp_997573;
else goto fail_tmp_997572;
}
/* commit */
{
tmp_982315 = genfunc_tmp_997544();
goto next_tmp_997576;
next_tmp_997576:
goto tmp_997575;
tmp_997575:
}
tmp_982314 = tmp_997548 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 2 */
}
goto done_tmp_997611;
fail_tmp_997572:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_997601 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_997601))
field_imm = inv_maskmask(8, tmp_997601);
else goto fail_tmp_997600;
}
/* commit */
{
tmp_981532 = genfunc_tmp_997544();
goto next_tmp_997604;
next_tmp_997604:
goto tmp_997603;
tmp_997603:
}
tmp_981531 = tmp_997548 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 2 */
}
goto done_tmp_997611;
fail_tmp_997600:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_997544();
goto next_tmp_997609;
next_tmp_997609:
goto tmp_997608;
tmp_997608:
}
tmp_981523 = tmp_997548 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 2 */
}
done_tmp_997611:
return tmp_997548;
}
reg_t genfunc_tmp_997544 (void) {
reg_t tmp_997515;
/* ADDQ */
{
word_5 tmp_982354;
word_5 field_rc;
word_5 tmp_982355;
word_5 field_ra;
word_5 tmp_982357;
word_5 field_rb;
/* commit */
tmp_982355 = ref_gpr_reg_for_reading(0 + base);
tmp_982357 = ref_gpr_reg_for_reading(0 + index);
tmp_982354 = tmp_997515 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982354;
field_ra = tmp_982355;
field_rb = tmp_982357;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982357);
unref_gpr_reg(tmp_982355);
/* can fail: NIL   num insns: 1 */
}
done_tmp_997543:
return tmp_997515;
}
void genfunc_tmp_997494 (void) {
/* STL */
{
word_5 tmp_981599;
word_5 field_rb;
word_64 tmp_981601;
word_16 field_memory_disp;
word_5 tmp_981603;
word_5 field_ra;
tmp_981601 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981599 = genfunc_tmp_997181();
goto next_tmp_997085;
next_tmp_997085:
goto tmp_997084;
tmp_997084:
}
{
tmp_981603 = genfunc_tmp_997491();
goto next_tmp_997185;
next_tmp_997185:
goto tmp_997184;
tmp_997184:
}
field_rb = tmp_981599;
field_ra = tmp_981603;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981603);
unref_gpr_reg(tmp_981599);
/* can fail: NIL   num insns: 5 */
}
done_tmp_997493:
}
reg_t genfunc_tmp_997491 (void) {
reg_t tmp_997183;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_997396();
goto next_tmp_997192;
next_tmp_997192:
goto tmp_997191;
tmp_997191:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_997183 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 3 */
}
done_tmp_997490:
return tmp_997183;
}
reg_t genfunc_tmp_997453 (void) {
reg_t tmp_997408;
/* ADDL */
{
word_5 tmp_982362;
word_5 field_rc;
word_5 tmp_982363;
word_5 field_ra;
word_5 tmp_982365;
word_5 field_rb;
/* commit */
{
tmp_982363 = genfunc_tmp_997396();
goto next_tmp_997417;
next_tmp_997417:
goto tmp_997416;
tmp_997416:
}
tmp_982365 = ref_gpr_reg_for_reading(0 + reg);
tmp_982362 = tmp_997408 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982362;
field_ra = tmp_982363;
field_rb = tmp_982365;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_982365);
unref_gpr_reg(tmp_982363);
/* can fail: NIL   num insns: 3 */
}
done_tmp_997452:
return tmp_997408;
}
reg_t genfunc_tmp_997396 (void) {
reg_t tmp_997190;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_997181();
goto next_tmp_997370;
next_tmp_997370:
goto tmp_997369;
tmp_997369:
}
tmp_981838 = tmp_997190 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 2 */
}
done_tmp_997395:
return tmp_997190;
}
reg_t genfunc_tmp_997339 (void) {
reg_t tmp_997275;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_997300 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_997300 >> 8) == 0)
field_imm = tmp_997300;
else goto fail_tmp_997299;
}
/* commit */
{
tmp_982315 = genfunc_tmp_997251();
goto next_tmp_997303;
next_tmp_997303:
goto tmp_997302;
tmp_997302:
}
tmp_982314 = tmp_997275 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 3 */
}
goto done_tmp_997338;
fail_tmp_997299:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_997328 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_997328))
field_imm = inv_maskmask(8, tmp_997328);
else goto fail_tmp_997327;
}
/* commit */
{
tmp_981532 = genfunc_tmp_997251();
goto next_tmp_997331;
next_tmp_997331:
goto tmp_997330;
tmp_997330:
}
tmp_981531 = tmp_997275 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 3 */
}
goto done_tmp_997338;
fail_tmp_997327:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_981524 = genfunc_tmp_997251();
goto next_tmp_997336;
next_tmp_997336:
goto tmp_997335;
tmp_997335:
}
tmp_981523 = tmp_997275 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 3 */
}
done_tmp_997338:
return tmp_997275;
}
reg_t genfunc_tmp_997251 (void) {
reg_t tmp_997206;
/* LDL */
{
word_5 tmp_981838;
word_5 field_ra;
word_5 tmp_981839;
word_5 field_rb;
word_64 tmp_981841;
word_16 field_memory_disp;
tmp_981841 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_981839 = genfunc_tmp_997181();
goto next_tmp_997248;
next_tmp_997248:
goto tmp_997247;
tmp_997247:
}
tmp_981838 = tmp_997206 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_981838;
field_rb = tmp_981839;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_981839);
/* can fail: NIL   num insns: 2 */
}
done_tmp_997250:
return tmp_997206;
}
reg_t genfunc_tmp_997181 (void) {
reg_t tmp_997083;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_997152 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_997152 >> 8) == 0)
field_imm = tmp_997152;
else goto fail_tmp_997151;
}
/* commit */
tmp_982315 = ref_gpr_reg_for_reading(0 + rm);
tmp_982314 = tmp_997083 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 1 */
}
goto done_tmp_997180;
fail_tmp_997151:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_997178 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_997178))
field_imm = inv_maskmask(8, tmp_997178);
else goto fail_tmp_997177;
}
/* commit */
tmp_981532 = ref_gpr_reg_for_reading(0 + rm);
tmp_981531 = tmp_997083 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 1 */
}
goto done_tmp_997180;
fail_tmp_997177:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
tmp_981524 = ref_gpr_reg_for_reading(0 + rm);
tmp_981523 = tmp_997083 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 1 */
}
done_tmp_997180:
return tmp_997083;
}
reg_t genfunc_tmp_997149 (void) {
reg_t tmp_997101;
/* BIC_IMM */
{
word_5 tmp_982314;
word_5 field_rc;
word_5 tmp_982315;
word_5 field_ra;
word_64 tmp_982317;
word_8 field_imm;
tmp_982317 = 4294967295;
{
word_64 tmp_997122 = (~tmp_982317 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_997122 >> 8) == 0)
field_imm = tmp_997122;
else goto fail_tmp_997121;
}
/* commit */
tmp_982315 = ref_gpr_reg_for_reading(0 + rm);
tmp_982314 = tmp_997101 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_982314;
field_ra = tmp_982315;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_982315);
/* can fail: T   num insns: 1 */
}
goto done_tmp_997148;
fail_tmp_997121:
/* ZAP_IMM */
{
word_5 tmp_981531;
word_5 field_rc;
word_5 tmp_981532;
word_5 field_ra;
word_64 tmp_981534;
word_8 field_imm;
tmp_981534 = 4294967295;
{
word_64 tmp_997146 = (~tmp_981534 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_997146))
field_imm = inv_maskmask(8, tmp_997146);
else goto fail_tmp_997145;
}
/* commit */
tmp_981532 = ref_gpr_reg_for_reading(0 + rm);
tmp_981531 = tmp_997101 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981531;
field_ra = tmp_981532;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981532);
/* can fail: T   num insns: 1 */
}
goto done_tmp_997148;
fail_tmp_997145:
/* ZAPNOT_IMM */
{
word_5 tmp_981523;
word_5 field_rc;
word_5 tmp_981524;
word_5 field_ra;
word_64 tmp_981526;
word_8 field_imm;
tmp_981526 = 4294967295;
field_imm = 15;
/* commit */
tmp_981524 = ref_gpr_reg_for_reading(0 + rm);
tmp_981523 = tmp_997101 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_981523;
field_ra = tmp_981524;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_981524);
/* can fail: NIL   num insns: 1 */
}
done_tmp_997148:
return tmp_997101;
}
