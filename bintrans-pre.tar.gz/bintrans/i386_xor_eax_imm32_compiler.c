#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compiler_tmp_898468 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_898458 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_898463 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_898467 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_898454 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_898443 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_898453 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_898448 (label_t true_label, label_t false_label, void **env);
void compiler_tmp_898451 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_898439 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_898435 (void (*rhs_func) (reg_t*, int, void**), void **env);
void compiler_tmp_898434 (reg_t *target, int foreign_target, void **env);
void compiler_tmp_898468 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 6 6 T)
*/
{
{
reg_t tmp_898470, tmp_898471, tmp_898469;
rhs_func(&tmp_898470, -1, env);
emit(COMPOSE_SLL_IMM(tmp_898470, 63, tmp_898470));
emit(COMPOSE_SRL_IMM(tmp_898470, 57, tmp_898470));
tmp_898471 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_898471, -1);
emit(COMPOSE_SLL_IMM(tmp_898471, 63, tmp_898471));
emit(COMPOSE_SRL_IMM(tmp_898471, 57, tmp_898471));
tmp_898469 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_898469, tmp_898471, tmp_898469));
unref_integer_reg(tmp_898471);
emit(COMPOSE_BIS(tmp_898469, tmp_898470, tmp_898469));
unref_integer_reg(tmp_898470);
unref_integer_reg(tmp_898469);
}
}

void compiler_tmp_898458 (reg_t *target, int foreign_target, void **env)
/*
(IF (= (REGISTER EAX GPR (INTEGER 0)) (INTEGER 0)) (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_898460 = alloc_label(), tmp_898461 = alloc_label(), tmp_898462 = alloc_label();
reg_t tmp_898459;
compiler_tmp_898463(tmp_898460, tmp_898461, env);

tmp_898459 = ref_integer_reg_for_writing(-1);
emit_label(tmp_898460);
push_alloc();
compiler_tmp_898453(&tmp_898459, tmp_898459 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_898462);
emit_label(tmp_898461);
push_alloc();
compiler_tmp_898434(&tmp_898459, tmp_898459 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_898462);
free_label(tmp_898460);
free_label(tmp_898461);
free_label(tmp_898462);
if (foreign_target == -1)
*target = tmp_898459;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_898459, *target));
unref_integer_reg(tmp_898459);
}

}
}

void compiler_tmp_898463 (label_t true_label, label_t false_label, void **env)
/*
(= (REGISTER EAX GPR (INTEGER 0)) (INTEGER 0))
*/
{
{
reg_t tmp_898464, tmp_898465, tmp_898466;
compiler_tmp_898451(&tmp_898464, -1, env);
compiler_tmp_898467(&tmp_898465, -1, env);
tmp_898466 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_CMPEQ(tmp_898464, tmp_898465, tmp_898466));
unref_integer_reg(tmp_898464);
unref_integer_reg(tmp_898465);
emit_branch(COMPOSE_BEQ(tmp_898466, 0), false_label);
unref_integer_reg(tmp_898466);
emit_branch(COMPOSE_BR(31, 0), true_label);
}
}

void compiler_tmp_898467 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compiler_tmp_898454 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 7 7 T)
*/
{
{
reg_t tmp_898456, tmp_898457, tmp_898455;
rhs_func(&tmp_898456, -1, env);
emit(COMPOSE_SLL_IMM(tmp_898456, 63, tmp_898456));
emit(COMPOSE_SRL_IMM(tmp_898456, 56, tmp_898456));
tmp_898457 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_898457, -1);
emit(COMPOSE_SLL_IMM(tmp_898457, 63, tmp_898457));
emit(COMPOSE_SRL_IMM(tmp_898457, 56, tmp_898457));
tmp_898455 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_898455, tmp_898457, tmp_898455));
unref_integer_reg(tmp_898457);
emit(COMPOSE_BIS(tmp_898455, tmp_898456, tmp_898455));
unref_integer_reg(tmp_898456);
unref_integer_reg(tmp_898455);
}
}

void compiler_tmp_898443 (reg_t *target, int foreign_target, void **env)
/*
(IF (BIT-SET-P (REGISTER EAX GPR (INTEGER 0)) (- (INTEGER 32) (INTEGER 1)))
 (INTEGER 1) (INTEGER 0))
*/
{
{
label_t tmp_898445 = alloc_label(), tmp_898446 = alloc_label(), tmp_898447 = alloc_label();
reg_t tmp_898444;
compiler_tmp_898448(tmp_898445, tmp_898446, env);

tmp_898444 = ref_integer_reg_for_writing(-1);
emit_label(tmp_898445);
push_alloc();
compiler_tmp_898453(&tmp_898444, tmp_898444 | NEED_NATIVE, env);
pop_alloc();
emit_branch(COMPOSE_BR(31, 0), tmp_898447);
emit_label(tmp_898446);
push_alloc();
compiler_tmp_898434(&tmp_898444, tmp_898444 | NEED_NATIVE, env);
pop_alloc();
emit_label(tmp_898447);
free_label(tmp_898445);
free_label(tmp_898446);
free_label(tmp_898447);
if (foreign_target == -1)
*target = tmp_898444;
else {
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_898444, *target));
unref_integer_reg(tmp_898444);
}

}
}

void compiler_tmp_898453 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 1)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 1);
}

void compiler_tmp_898448 (label_t true_label, label_t false_label, void **env)
/*
(BIT-SET-P (REGISTER EAX GPR (INTEGER 0)) (- (INTEGER 32) (INTEGER 1)))
*/
{
{
reg_t tmp_898449, tmp_898450;
compiler_tmp_898451(&tmp_898449, -1, env);
tmp_898450 = ref_integer_reg_for_writing(-1);
emit(COMPOSE_SRL_IMM(tmp_898449, (32 - 1), tmp_898450));
unref_integer_reg(tmp_898449);
emit_branch(COMPOSE_BLBS(tmp_898450, 0), true_label);
unref_integer_reg(tmp_898450);
emit_branch(COMPOSE_BR(31, 0), false_label);
}
}

void compiler_tmp_898451 (reg_t *target, int foreign_target, void **env)
/*
(REGISTER EAX GPR (INTEGER 0))
*/
{
if (foreign_target == -1)
*target = ref_integer_reg_for_reading(0);
else {
reg_t tmp_898452 = ref_integer_reg_for_reading(0);
*target = ref_integer_reg_for_writing(foreign_target);
emit(COMPOSE_MOV(tmp_898452, *target));
unref_integer_reg(tmp_898452);
}
}

void compiler_tmp_898439 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 11 11 T)
*/
{
{
reg_t tmp_898441, tmp_898442, tmp_898440;
rhs_func(&tmp_898441, -1, env);
emit(COMPOSE_SLL_IMM(tmp_898441, 63, tmp_898441));
emit(COMPOSE_SRL_IMM(tmp_898441, 52, tmp_898441));
tmp_898442 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_898442, -1);
emit(COMPOSE_SLL_IMM(tmp_898442, 63, tmp_898442));
emit(COMPOSE_SRL_IMM(tmp_898442, 52, tmp_898442));
tmp_898440 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_898440, tmp_898442, tmp_898440));
unref_integer_reg(tmp_898442);
emit(COMPOSE_BIS(tmp_898440, tmp_898441, tmp_898440));
unref_integer_reg(tmp_898441);
unref_integer_reg(tmp_898440);
}
}

void compiler_tmp_898435 (void (*rhs_func) (reg_t*, int, void**), void **env)
/*
(SUBREGISTER EFLAGS SPR (INTEGER 0) 0 0 T)
*/
{
{
reg_t tmp_898437, tmp_898438, tmp_898436;
rhs_func(&tmp_898437, -1, env);
emit(COMPOSE_SLL_IMM(tmp_898437, 63, tmp_898437));
emit(COMPOSE_SRL_IMM(tmp_898437, 63, tmp_898437));
tmp_898438 = ref_integer_reg_for_writing(-1);
emit_load_integer_32(tmp_898438, -1);
emit(COMPOSE_SLL_IMM(tmp_898438, 63, tmp_898438));
emit(COMPOSE_SRL_IMM(tmp_898438, 63, tmp_898438));
tmp_898436 = ref_integer_reg_for_reading_and_writing(8);
emit(COMPOSE_BIC(tmp_898436, tmp_898438, tmp_898436));
unref_integer_reg(tmp_898438);
emit(COMPOSE_BIS(tmp_898436, tmp_898437, tmp_898436));
unref_integer_reg(tmp_898437);
unref_integer_reg(tmp_898436);
}
}

void compiler_tmp_898434 (reg_t *target, int foreign_target, void **env)
/*
(INTEGER 0)
*/
{
*target = ref_integer_reg_for_writing(foreign_target);
emit_load_integer_32(*target, 0);
}

void compile_xor_eax_imm32_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 && (imm32 == 0))
{
genfunc_tmp_898363();
goto next_tmp_898353;
next_tmp_898353:
goto finish_tmp_898352;
finish_tmp_898352:
}
if (1 && (!(imm32 == 0)))
{
genfunc_tmp_898432();
goto next_tmp_898366;
next_tmp_898366:
goto finish_tmp_898365;
finish_tmp_898365:
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_898434;
killed |= 0x1;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_898435(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_898434;
killed |= 0x800;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_898439(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_898443;
killed |= 0x80;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_898454(rhs_func, env);
}
}
{
word_32 killed = 0;
void (*rhs_func) (reg_t*, int, void**) = compiler_tmp_898458;
killed |= 0x40;
if (killed == 0 || (killed & to_be_killed)) {
compiler_tmp_898468(rhs_func, env);
}
}
}
void genfunc_tmp_898432 (void) {
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_898416;
field_rb = 31;
/* commit */
tmp_731669 = ref_gpr_reg_for_reading(0 + 0);
tmp_731668 = ref_gpr_reg_for_writing(0 + 0);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731668);
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898431;
fail_tmp_898416:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_898418 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_898418 >> 8) == 0)
field_imm = tmp_898418;
else goto fail_tmp_898417;
}
/* commit */
tmp_731665 = ref_gpr_reg_for_reading(0 + 0);
tmp_731664 = ref_gpr_reg_for_writing(0 + 0);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731664);
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898431;
fail_tmp_898417:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_898428;
field_rb = 31;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + 0);
tmp_731086 = ref_gpr_reg_for_writing(0 + 0);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898431;
fail_tmp_898428:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_898430 = tmp_731085;
if ((tmp_898430 >> 8) == 0)
field_imm = tmp_898430;
else goto fail_tmp_898429;
}
/* commit */
tmp_731083 = ref_gpr_reg_for_reading(0 + 0);
tmp_731082 = ref_gpr_reg_for_writing(0 + 0);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731082);
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898431;
fail_tmp_898429:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + 0);
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = ref_gpr_reg_for_writing(0 + 0);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 2 */
}
done_tmp_898431:
}
reg_t genfunc_tmp_898394 (void) {
reg_t tmp_731898;
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 tmp_731669;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_898382;
field_rb = 31;
/* commit */
tmp_731669 = ref_gpr_reg_for_reading(0 + 0);
tmp_731668 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731668;
field_ra = tmp_731669;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731669);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898393;
fail_tmp_898382:
/* EQV_IMM */
{
word_5 tmp_731664;
word_5 field_rc;
word_5 tmp_731665;
word_5 field_ra;
word_64 tmp_731667;
word_8 field_imm;
tmp_731667 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_898384 = (~tmp_731667 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_898384 >> 8) == 0)
field_imm = tmp_898384;
else goto fail_tmp_898383;
}
/* commit */
tmp_731665 = ref_gpr_reg_for_reading(0 + 0);
tmp_731664 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731664;
field_ra = tmp_731665;
emit(COMPOSE_EQV_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731665);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898393;
fail_tmp_898383:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_898390;
field_rb = 31;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + 0);
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731087);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898393;
fail_tmp_898390:
/* XOR_IMM */
{
word_5 tmp_731082;
word_5 field_rc;
word_5 tmp_731083;
word_5 field_ra;
word_64 tmp_731085;
word_8 field_imm;
tmp_731085 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_898392 = tmp_731085;
if ((tmp_898392 >> 8) == 0)
field_imm = tmp_898392;
else goto fail_tmp_898391;
}
/* commit */
tmp_731083 = ref_gpr_reg_for_reading(0 + 0);
tmp_731082 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731082;
field_ra = tmp_731083;
emit(COMPOSE_XOR_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731083);
/* can fail: T   num insns: 1 */
}
goto done_tmp_898393;
fail_tmp_898391:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 tmp_731087;
word_5 field_ra;
word_5 tmp_731089;
word_5 field_rb;
/* commit */
tmp_731087 = ref_gpr_reg_for_reading(0 + 0);
tmp_731089 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731089, ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32));
tmp_731086 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731086;
field_ra = tmp_731087;
field_rb = tmp_731089;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731089);
unref_gpr_reg(tmp_731087);
/* can fail: NIL   num insns: 2 */
}
done_tmp_898393:
return tmp_731898;
}
void genfunc_tmp_898363 (void) {
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 field_rb;
field_rb = 31;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + 0);
tmp_731897 = ref_gpr_reg_for_writing(0 + 0);
field_rc = tmp_731897;
field_ra = tmp_731898;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731897);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_898362:
}
