void consume_ppc_insn (word_32 insn, word_32 pc, word_32 *_consumed_CR, word_32 *_consumed_XER, word_32 *_consumed_GPR) {
word_32 consumed_CR;
word_32 consumed_XER;

word_32 consumed_GPR;
switch (((insn >> 26) & 0x3F)) {
case 27:
/* XORIS */
assert((insn & 0xFC000000) == 0x6C000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 26:
/* XORI */
assert((insn & 0xFC000000) == 0x68000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 31:
switch (((insn >> 0) & 0x7FF)) {
case 633:
/* XOR. */
assert((insn & 0xFC0007FF) == 0x7C000279);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 632:
/* XOR */
assert((insn & 0xFC0007FF) == 0x7C000278);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 1196:
/* SYNC */
assert((insn & 0xFFFFFFFF) == 0x7C0004AC);
{
word_32 consumed = 0;
/* nop */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
/* nop */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
/* nop */
consumed_GPR = consumed;
}
break;
case 1425:
/* SUBFZEO. */
assert((insn & 0xFC00FFFF) == 0x7C000591);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1424:
/* SUBFZEO */
assert((insn & 0xFC00FFFF) == 0x7C000590);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 401:
/* SUBFZE. */
assert((insn & 0xFC00FFFF) == 0x7C000191);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 400:
/* SUBFZE */
assert((insn & 0xFC00FFFF) == 0x7C000190);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0);
consumed_GPR = consumed;
}
break;
case 1489:
/* SUBFMEO. */
assert((insn & 0xFC00FFFF) == 0x7C0005D1);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| 0);
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1488:
/* SUBFMEO */
assert((insn & 0xFC00FFFF) == 0x7C0005D0);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| 0);
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 465:
/* SUBFME. */
assert((insn & 0xFC00FFFF) == 0x7C0001D1);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| 0);
consumed |= 0 | 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 464:
/* SUBFME */
assert((insn & 0xFC00FFFF) == 0x7C0001D0);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1297:
/* SUBFEO. */
assert((insn & 0xFC0007FF) == 0x7C000511);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | (0 | 0x20000000)| 0)));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1296:
/* SUBFEO */
assert((insn & 0xFC0007FF) == 0x7C000510);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | (0 | 0x20000000)| 0)));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 273:
/* SUBFE. */
assert((insn & 0xFC0007FF) == 0x7C000111);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | (0 | 0x20000000)| 0)));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 272:
/* SUBFE */
assert((insn & 0xFC0007FF) == 0x7C000110);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0| (0 | (0 | 0x20000000)| 0)));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1041:
/* SUBFCO. */
assert((insn & 0xFC0007FF) == 0x7C000411);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| 0));
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1040:
/* SUBFCO */
assert((insn & 0xFC0007FF) == 0x7C000410);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| 0));
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 17:
/* SUBFC. */
assert((insn & 0xFC0007FF) == 0x7C000011);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| 0));
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 16:
/* SUBFC */
assert((insn & 0xFC0007FF) == 0x7C000010);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F)))| 0));
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 1105:
/* SUBFO. */
assert((insn & 0xFC0007FF) == 0x7C000451);
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1104:
/* SUBFO */
assert((insn & 0xFC0007FF) == 0x7C000450);
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 81:
/* SUBF. */
assert((insn & 0xFC0007FF) == 0x7C000051);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 80:
/* SUBF */
assert((insn & 0xFC0007FF) == 0x7C000050);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 11) & 0x1F))| (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 302:
/* STWX */
assert((insn & 0xFC0007FF) == 0x7C00012E);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 366:
/* STWUX */
assert((insn & 0xFC0007FF) == 0x7C00016E);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 1324:
/* STWBRX */
assert((insn & 0xFC0007FF) == 0x7C00052C);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 814:
/* STHX */
assert((insn & 0xFC0007FF) == 0x7C00032E);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 1836:
/* STHBRX */
assert((insn & 0xFC0007FF) == 0x7C00072C);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 1326:
/* STFSX */
assert((insn & 0xFC0007FF) == 0x7C00052E);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | 0;
consumed_GPR = consumed;
}
break;
case 1454:
/* STFDX */
assert((insn & 0xFC0007FF) == 0x7C0005AE);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | 0;
consumed_GPR = consumed;
}
break;
case 430:
/* STBX */
assert((insn & 0xFC0007FF) == 0x7C0001AE);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| (1 << ((insn >> 11) & 0x1F))) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 1073:
/* SRW. */
assert((insn & 0xFC0007FF) == 0x7C000431);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1072:
/* SRW */
assert((insn & 0xFC0007FF) == 0x7C000430);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0));
consumed_GPR = consumed;
}
break;
case 1649:
/* SRAWI. */
assert((insn & 0xFC0007FF) == 0x7C000671);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | ((0 | (0 | 0| (1 << ((insn >> 21) & 0x1F)))| 0) | 0 | 0) | 0);
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1648:
/* SRAWI */
assert((insn & 0xFC0007FF) == 0x7C000670);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | ((0 | (0 | 0| (1 << ((insn >> 21) & 0x1F)))| 0) | 0 | 0) | 0);
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 1585:
/* SRAW. */
assert((insn & 0xFC0007FF) == 0x7C000631);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | ((0 | (0 | (0 | (0 | 0| (0 | (1 << ((insn >> 11) & 0x1F))| 0))| 0)| (1 << ((insn >> 21) & 0x1F)))| 0) | 0 | 0) | 0);
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1584:
/* SRAW */
assert((insn & 0xFC0007FF) == 0x7C000630);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | ((0 | (0 | (0 | (0 | 0| (0 | (1 << ((insn >> 11) & 0x1F))| 0))| 0)| (1 << ((insn >> 21) & 0x1F)))| 0) | 0 | 0) | 0);
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0));
consumed_GPR = consumed;
}
break;
case 49:
/* SLW. */
assert((insn & 0xFC0007FF) == 0x7C000031);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 11) & 0x1F))| 0) | 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F)))));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 48:
/* SLW */
assert((insn & 0xFC0007FF) == 0x7C000030);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 11) & 0x1F))| 0) | 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F)))));
consumed_GPR = consumed;
}
break;
case 825:
/* ORC. */
assert((insn & 0xFC0007FF) == 0x7C000339);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 824:
/* ORC */
assert((insn & 0xFC0007FF) == 0x7C000338);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
break;
case 889:
/* OR. */
assert((insn & 0xFC0007FF) == 0x7C000379);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 888:
/* OR */
assert((insn & 0xFC0007FF) == 0x7C000378);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 249:
/* NOR. */
assert((insn & 0xFC0007FF) == 0x7C0000F9);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F))));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 248:
/* NOR */
assert((insn & 0xFC0007FF) == 0x7C0000F8);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
break;
case 1233:
/* NEGO. */
assert((insn & 0xFC00FFFF) == 0x7C0004D1);
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F)));
assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1232:
/* NEGO */
assert((insn & 0xFC00FFFF) == 0x7C0004D0);
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F)));
assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 209:
/* NEG. */
assert((insn & 0xFC00FFFF) == 0x7C0000D1);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 208:
/* NEG */
assert((insn & 0xFC00FFFF) == 0x7C0000D0);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 953:
/* NAND. */
assert((insn & 0xFC0007FF) == 0x7C0003B9);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F))));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 952:
/* NAND */
assert((insn & 0xFC0007FF) == 0x7C0003B8);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
break;
case 1495:
/* MULLWO. */
assert((insn & 0xFC0007FF) == 0x7C0005D7);
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1494:
/* MULLWO */
assert((insn & 0xFC0007FF) == 0x7C0005D6);
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 471:
/* MULLW. */
assert((insn & 0xFC0007FF) == 0x7C0001D7);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 470:
/* MULLW */
assert((insn & 0xFC0007FF) == 0x7C0001D6);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 22:
/* MULHWU */
assert((insn & 0xFC0007FF) == 0x7C000016);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (0 | (1 << ((insn >> 11) & 0x1F))))| 0));
consumed_GPR = consumed;
}
break;
case 150:
/* MULHW */
assert((insn & 0xFC0007FF) == 0x7C000096);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| (0 | (1 << ((insn >> 11) & 0x1F))))| 0));
consumed_GPR = consumed;
}
break;
case 934:
switch (((insn >> 11) & 0x3FF)) {
case 32:
/* MTXER */
assert((insn & 0xFC1FFFFF) == 0x7C0103A6);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 256:
/* MTLR */
assert((insn & 0xFC1FFFFF) == 0x7C0803A6);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 288:
/* MTCTR */
assert((insn & 0xFC1FFFFF) == 0x7C0903A6);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 288:
/* MTCRF */
assert((insn & 0xFC100FFF) == 0x7C000120);
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0xFFFFFFFF| 0)| 0);
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | (1 << ((insn >> 21) & 0x1F))| 0));
consumed_GPR = consumed;
}
break;
case 678:
switch (((insn >> 11) & 0x3FF)) {
case 32:
/* MFXER */
assert((insn & 0xFC1FFFFF) == 0x7C0102A6);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0xFFFFFFFF;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 256:
/* MFLR */
assert((insn & 0xFC1FFFFF) == 0x7C0802A6);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 288:
/* MFCTR */
assert((insn & 0xFC1FFFFF) == 0x7C0902A6);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 38:
/* MFCR */
assert((insn & 0xFC1FFFFF) == 0x7C000026);
{
word_32 consumed = 0;
consumed |= 0 | 0xFFFFFFFF;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1024:
/* MCRXR */
assert((insn & 0xFC7FFFFF) == 0x7C000400);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (15 << (4 * 7));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 46:
/* LWZX */
assert((insn & 0xFC0007FF) == 0x7C00002E);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)))));
consumed_GPR = consumed;
}
break;
case 110:
/* LWZUX */
assert((insn & 0xFC0007FF) == 0x7C00006E);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1068:
/* LWBRX */
assert((insn & 0xFC0007FF) == 0x7C00042C);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)))));
consumed_GPR = consumed;
}
break;
case 558:
/* LHZX */
assert((insn & 0xFC0007FF) == 0x7C00022E);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))))));
consumed_GPR = consumed;
}
break;
case 1580:
/* LHBRX */
assert((insn & 0xFC0007FF) == 0x7C00062C);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))))));
consumed_GPR = consumed;
}
break;
case 686:
/* LHAX */
assert((insn & 0xFC0007FF) == 0x7C0002AE);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))))));
consumed_GPR = consumed;
}
break;
case 1070:
/* LFSX */
assert((insn & 0xFC0007FF) == 0x7C00042E);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)))))));
consumed_GPR = consumed;
}
break;
case 1198:
/* LFDX */
assert((insn & 0xFC0007FF) == 0x7C0004AE);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))))));
consumed_GPR = consumed;
}
break;
case 174:
/* LBZX */
assert((insn & 0xFC0007FF) == 0x7C0000AE);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? (1 << ((insn >> 11) & 0x1F)) : (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))))));
consumed_GPR = consumed;
}
break;
case 238:
/* LBZUX */
assert((insn & 0xFC0007FF) == 0x7C0000EE);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1964:
/* ICBI */
assert((insn & 0xFFE007FF) == 0x7C0007AC);
{
word_32 consumed = 0;
/* ignore */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
/* ignore */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
/* ignore */
consumed_GPR = consumed;
}
break;
case 1845:
/* EXTSH. */
assert((insn & 0xFC00FFFF) == 0x7C000735);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1844:
/* EXTSH */
assert((insn & 0xFC00FFFF) == 0x7C000734);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 1908:
/* EXTSB */
assert((insn & 0xFC00FFFF) == 0x7C000774);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 569:
/* EQV. */
assert((insn & 0xFC0007FF) == 0x7C000239);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 568:
/* EQV */
assert((insn & 0xFC0007FF) == 0x7C000238);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
break;
case 1943:
/* DIVWUO. */
assert((insn & 0xFC0007FF) == 0x7C000797);
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1942:
/* DIVWUO */
assert((insn & 0xFC0007FF) == 0x7C000796);
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 919:
/* DIVWU. */
assert((insn & 0xFC0007FF) == 0x7C000397);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 918:
/* DIVWU */
assert((insn & 0xFC0007FF) == 0x7C000396);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 2007:
/* DIVWO. */
assert((insn & 0xFC0007FF) == 0x7C0007D7);
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 2006:
/* DIVWO */
assert((insn & 0xFC0007FF) == 0x7C0007D6);
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 983:
/* DIVW. */
assert((insn & 0xFC0007FF) == 0x7C0003D7);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 982:
/* DIVW */
assert((insn & 0xFC0007FF) == 0x7C0003D6);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 2028:
/* DCBZ */
assert((insn & 0xFFE007FF) == 0x7C0007EC);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 108:
/* DCBST */
assert((insn & 0xFFE007FF) == 0x7C00006C);
{
word_32 consumed = 0;
/* ignore */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
/* ignore */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
/* ignore */
consumed_GPR = consumed;
}
break;
case 52:
/* CNTLZW */
assert((insn & 0xFC00FFFF) == 0x7C000034);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 0:
/* CMPW */
assert((insn & 0xFC6007FF) == 0x7C000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 64:
/* CMPLW */
assert((insn & 0xFC6007FF) == 0x7C000040);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F))) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 121:
/* ANDC. */
assert((insn & 0xFC0007FF) == 0x7C000079);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 120:
/* ANDC */
assert((insn & 0xFC0007FF) == 0x7C000078);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))));
consumed_GPR = consumed;
}
break;
case 57:
/* AND. */
assert((insn & 0xFC0007FF) == 0x7C000039);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 56:
/* AND */
assert((insn & 0xFC0007FF) == 0x7C000038);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 1429:
/* ADDZEO. */
assert((insn & 0xFC00FFFF) == 0x7C000595);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1428:
/* ADDZEO */
assert((insn & 0xFC00FFFF) == 0x7C000594);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 405:
/* ADDZE. */
assert((insn & 0xFC00FFFF) == 0x7C000195);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 404:
/* ADDZE */
assert((insn & 0xFC00FFFF) == 0x7C000194);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1493:
/* ADDMEO. */
assert((insn & 0xFC00FFFF) == 0x7C0005D5);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0)| 0);
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1492:
/* ADDMEO */
assert((insn & 0xFC00FFFF) == 0x7C0005D4);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0)| 0);
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 469:
/* ADDME. */
assert((insn & 0xFC00FFFF) == 0x7C0001D5);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0)| 0);
consumed |= 0 | 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 468:
/* ADDME */
assert((insn & 0xFC00FFFF) == 0x7C0001D4);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| 0);
consumed |= 0 | (0 | (0 | 0| (0 | 0x20000000))| (0 | (0 | 0| (0 | 0x20000000))| 0));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0)| 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1301:
/* ADDEO. */
assert((insn & 0xFC0007FF) == 0x7C000515);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1300:
/* ADDEO */
assert((insn & 0xFC0007FF) == 0x7C000514);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 277:
/* ADDE. */
assert((insn & 0xFC0007FF) == 0x7C000115);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 276:
/* ADDE */
assert((insn & 0xFC0007FF) == 0x7C000114);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | 0| (0 | 0x20000000));
consumed |= 0 | (0 | 0| (0 | 0| (0 | 0x20000000)));
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1045:
/* ADDCO. */
assert((insn & 0xFC0007FF) == 0x7C000415);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1044:
/* ADDCO */
assert((insn & 0xFC0007FF) == 0x7C000414);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 21:
/* ADDC. */
assert((insn & 0xFC0007FF) == 0x7C000015);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 20:
/* ADDC */
assert((insn & 0xFC0007FF) == 0x7C000014);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 1557:
/* ADDO. */
assert((insn & 0xFC0007FF) == 0x7C000615);
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
assert(0); /* not implemented */
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 1556:
/* ADDO */
assert((insn & 0xFC0007FF) == 0x7C000614);
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
assert(0); /* not implemented */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
assert(0); /* not implemented */
consumed_GPR = consumed;
}
break;
case 533:
/* ADD. */
assert((insn & 0xFC0007FF) == 0x7C000215);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 532:
/* ADD */
assert((insn & 0xFC0007FF) == 0x7C000214);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| (1 << ((insn >> 11) & 0x1F)));
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 8:
/* SUBFIC */
assert((insn & 0xFC000000) == 0x20000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| (0 | (0 | (0 | (1 << ((insn >> 16) & 0x1F)))| 0)| 0));
consumed |= 0 | (0 | 0| (1 << ((insn >> 16) & 0x1F)));
consumed_GPR = consumed;
}
break;
case 37:
/* STWU */
assert((insn & 0xFC000000) == 0x94000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | (1 << ((insn >> 16) & 0x1F))| 0) | (1 << ((insn >> 21) & 0x1F));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 36:
/* STW */
assert((insn & 0xFC000000) == 0x90000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| 0) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 45:
/* STHU */
assert((insn & 0xFC000000) == 0xB4000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | (1 << ((insn >> 16) & 0x1F))| 0) | (1 << ((insn >> 21) & 0x1F));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 44:
/* STH */
assert((insn & 0xFC000000) == 0xB0000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0)) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 52:
/* STFS */
assert((insn & 0xFC000000) == 0xD0000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| 0) | 0;
consumed_GPR = consumed;
}
break;
case 55:
/* STFDU */
assert((insn & 0xFC000000) == 0xDC000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 54:
/* STFD */
assert((insn & 0xFC000000) == 0xD8000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (1 << ((insn >> 16) & 0x1F)))| 0) | 0;
consumed_GPR = consumed;
}
break;
case 39:
/* STBU */
assert((insn & 0xFC000000) == 0x9C000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= (0 | (1 << ((insn >> 16) & 0x1F))| 0) | (1 << ((insn >> 21) & 0x1F));
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 38:
/* STB */
assert((insn & 0xFC000000) == 0x98000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0)) | (1 << ((insn >> 21) & 0x1F));
consumed_GPR = consumed;
}
break;
case 17:
/* SC */
assert((insn & 0xFFFFFFFF) == 0x44000002);
{
word_32 consumed = 0;
consumed = 0xFFFFFFFF;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed = 0xFFFFFFFF;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed = 0xFFFFFFFF;
consumed_GPR = consumed;
}
break;
case 23:
switch (((insn >> 0) & 0x1)) {
case 1:
/* RLWNM. */
assert((insn & 0xFC000001) == 0x5C000001);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0))| 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 0:
/* RLWNM */
assert((insn & 0xFC000001) == 0x5C000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| (0 | (1 << ((insn >> 11) & 0x1F))| 0))| 0);
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 21:
switch (((insn >> 0) & 0x1)) {
case 1:
/* RLWINM. */
assert((insn & 0xFC000001) == 0x54000001);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0)| 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 0:
/* RLWINM */
assert((insn & 0xFC000001) == 0x54000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0)| 0);
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 20:
/* RLWIMI */
assert((insn & 0xFC000001) == 0x50000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0)| 0)| (0 | (1 << ((insn >> 16) & 0x1F))| 0));
consumed_GPR = consumed;
}
break;
case 25:
/* ORIS */
assert((insn & 0xFC000000) == 0x64000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 24:
/* ORI */
assert((insn & 0xFC000000) == 0x60000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 7:
/* MULLI */
assert((insn & 0xFC000000) == 0x1C000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 63:
switch (((insn >> 0) & 0x3F)) {
case 12:
switch (((insn >> 6) & 0x3F)) {
case 4:
/* MTFSFI */
assert((insn & 0xFC7F0FFF) == 0xFC00010C);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 2:
/* MTFSB0 */
assert((insn & 0xFC1FFFFF) == 0xFC00008C);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 14:
switch (((insn >> 6) & 0x1F)) {
case 22:
/* MTFSF */
assert((insn & 0xFFFF07FF) == 0xFDFE058E);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 18:
/* MFFS */
assert((insn & 0xFC1FFFFF) == 0xFC00048E);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 40:
/* FSUB */
assert((insn & 0xFC0007FF) == 0xFC000028);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 24:
/* FRSP */
assert((insn & 0xFC1F07FF) == 0xFC000018);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 60:
/* FNMSUB */
assert((insn & 0xFC00003F) == 0xFC00003C);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 16:
switch (((insn >> 6) & 0x1F)) {
case 1:
/* FNEG */
assert((insn & 0xFC1F07FF) == 0xFC000050);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 2:
/* FMR */
assert((insn & 0xFC1F07FF) == 0xFC000090);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 8:
/* FABS */
assert((insn & 0xFC1F07FF) == 0xFC000210);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 50:
/* FMUL */
assert((insn & 0xFC00F83F) == 0xFC000032);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 56:
/* FMSUB */
assert((insn & 0xFC00003F) == 0xFC000038);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 58:
/* FMADD */
assert((insn & 0xFC00003F) == 0xFC00003A);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 36:
/* FDIV */
assert((insn & 0xFC0007FF) == 0xFC000024);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 30:
/* FCTIWZ */
assert((insn & 0xFC1F07FF) == 0xFC00001E);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 0:
/* FCMPU */
assert((insn & 0xFC6007FF) == 0xFC000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 42:
/* FADD */
assert((insn & 0xFC0007FF) == 0xFC00002A);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 19:
switch (((insn >> 0) & 0x7FF)) {
case 0:
/* MCRF */
assert((insn & 0xFC63FFFF) == 0x4C000000);
{
word_32 consumed = 0;
consumed |= 0 | (15 << (4 * ((7 - ((insn >> 18) & 0x7)) & 0x7)));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 300:
/* ISYNC */
assert((insn & 0xFFFFFFFF) == 0x4C00012C);
{
word_32 consumed = 0;
/* nop */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
/* nop */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
/* nop */
consumed_GPR = consumed;
}
break;
case 386:
/* CRXOR */
assert((insn & 0xFC0007FF) == 0x4C000182);
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 834:
/* CRORC */
assert((insn & 0xFC0007FF) == 0x4C000342);
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (0 | (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F)))| 0));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 898:
/* CROR */
assert((insn & 0xFC0007FF) == 0x4C000382);
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 66:
/* CRNOR */
assert((insn & 0xFC0007FF) == 0x4C000042);
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))))| 0);
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 450:
/* CRNAND */
assert((insn & 0xFC0007FF) == 0x4C0001C2);
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))))| 0);
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 578:
/* CREQV */
assert((insn & 0xFC0007FF) == 0x4C000242);
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))))| 0);
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 258:
/* CRANDC */
assert((insn & 0xFC0007FF) == 0x4C000102);
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (0 | (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F)))| 0));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 514:
/* CRAND */
assert((insn & 0xFC0007FF) == 0x4C000202);
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << (1 * ((31 - ((insn >> 16) & 0x1F)) & 0x1F)))| (1 << (1 * ((31 - ((insn >> 11) & 0x1F)) & 0x1F))));
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 32:
switch (((insn >> 11) & 0x1F)) {
case 0:
switch (((insn >> 21) & 0x1F)) {
case 5:
/* BNELR+ */
assert((insn & 0xFFE0FFFF) == 0x4CA00020);
{
word_32 consumed = 0;
consumed |= (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
/* nop */
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_GPR = consumed;
}
break;
case 4:
/* BNELR */
assert((insn & 0xFFE0FFFF) == 0x4C800020);
{
word_32 consumed = 0;
consumed |= (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
/* nop */
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_GPR = consumed;
}
break;
case 20:
/* BLR */
assert((insn & 0xFFE0FFFF) == 0x4E800020);
{
word_32 consumed = 0;
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_GPR = consumed;
}
break;
case 12:
/* BEQLR */
assert((insn & 0xFFE0FFFF) == 0x4D800020);
{
word_32 consumed = 0;
consumed |= (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
consumed |= 0;
/* nop */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
default:
goto unrecognized;
}
break;
case 33:
/* BLRL */
assert((insn & 0xFFE0FFFF) == 0x4E800021);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
consumed_GPR = consumed;
}
break;
case 1056:
/* BCTR */
assert((insn & 0xFFE0FFFF) == 0x4E800420);
{
word_32 consumed = 0;
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 33:
/* LWZU */
assert((insn & 0xFC000000) == 0x84000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 32:
/* LWZ */
assert((insn & 0xFC000000) == 0x80000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0)));
consumed_GPR = consumed;
}
break;
case 41:
/* LHZU */
assert((insn & 0xFC000000) == 0xA4000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 40:
/* LHZ */
assert((insn & 0xFC000000) == 0xA0000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0))));
consumed_GPR = consumed;
}
break;
case 43:
/* LHAU */
assert((insn & 0xFC000000) == 0xAC000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 42:
/* LHA */
assert((insn & 0xFC000000) == 0xA8000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0))));
consumed_GPR = consumed;
}
break;
case 48:
/* LFS */
assert((insn & 0xFC000000) == 0xC0000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0)))));
consumed_GPR = consumed;
}
break;
case 50:
/* LFD */
assert((insn & 0xFC000000) == 0xC8000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0))));
consumed_GPR = consumed;
}
break;
case 35:
/* LBZU */
assert((insn & 0xFC000000) == 0x8C000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 34:
/* LBZ */
assert((insn & 0xFC000000) == 0x88000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0))));
consumed_GPR = consumed;
}
break;
case 59:
switch (((insn >> 0) & 0x3F)) {
case 40:
/* FSUBS */
assert((insn & 0xFC0007FF) == 0xEC000028);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 50:
/* FMULS */
assert((insn & 0xFC00F83F) == 0xEC000032);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 56:
/* FMSUBS */
assert((insn & 0xFC00003F) == 0xEC000038);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 58:
/* FMADDS */
assert((insn & 0xFC00003F) == 0xEC00003A);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 36:
/* FDIVS */
assert((insn & 0xFC0007FF) == 0xEC000024);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 42:
/* FADDS */
assert((insn & 0xFC0007FF) == 0xEC00002A);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 11:
/* CMPWI */
assert((insn & 0xFC600000) == 0x2C000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 10:
/* CMPLWI */
assert((insn & 0xFC600000) == 0x28000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 16:
switch (((insn >> 21) & 0x1F)) {
case 5:
/* BNE- */
assert((insn & 0xFFE00003) == 0x40A00000);
{
word_32 consumed = 0;
consumed |= (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
/* nop */
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_GPR = consumed;
}
break;
case 4:
/* BNE */
assert((insn & 0xFFE00003) == 0x40800000);
{
word_32 consumed = 0;
consumed |= (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
/* nop */
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_GPR = consumed;
}
break;
case 13:
/* BEQ+ */
assert((insn & 0xFFE00003) == 0x41A00000);
{
word_32 consumed = 0;
consumed |= (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
consumed |= 0;
/* nop */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_GPR = consumed;
}
break;
case 12:
/* BEQ */
assert((insn & 0xFFE00003) == 0x41800000);
{
word_32 consumed = 0;
consumed |= (1 << ((31 - ((insn >> 16) & 0x1F)) & 0x1F));
consumed |= 0;
/* nop */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_GPR = consumed;
}
break;
case 18:
/* BDZ */
assert((insn & 0xFFE00003) == 0x42400000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
consumed |= 0;
/* nop */
consumed_GPR = consumed;
}
break;
case 16:
/* BDNZ */
assert((insn & 0xFFE00003) == 0x42000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
/* nop */
consumed |= 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 18:
switch (((insn >> 0) & 0x3)) {
case 1:
/* BL */
assert((insn & 0xFC000003) == 0x48000001);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0;
consumed_GPR = consumed;
}
break;
case 0:
/* B */
assert((insn & 0xFC000003) == 0x48000000);
{
word_32 consumed = 0;
consumed |= 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0;
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
break;
case 29:
/* ANDIS. */
assert((insn & 0xFC000000) == 0x74000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 28:
/* ANDI. */
assert((insn & 0xFC000000) == 0x70000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 21) & 0x1F))| 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 16) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 15:
/* ADDIS */
assert((insn & 0xFC000000) == 0x3C000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0));
consumed_GPR = consumed;
}
break;
case 13:
/* ADDIC. */
assert((insn & 0xFC000000) == 0x34000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed |= 0 | 0x80000000;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | ((0 | (1 << ((insn >> 21) & 0x1F))| 0) | 0 | 0);
consumed |= 0 | 0;
consumed_GPR = consumed;
}
break;
case 12:
/* ADDIC */
assert((insn & 0xFC000000) == 0x30000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed |= 0 | (0 | (1 << ((insn >> 16) & 0x1F))| 0);
consumed_GPR = consumed;
}
break;
case 14:
/* ADDI */
assert((insn & 0xFC000000) == 0x38000000);
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_CR = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | 0;
consumed_XER = consumed;
}
{
word_32 consumed = 0;
consumed |= 0 | ((((insn >> 16) & 0x1F) == 0) ? 0 : (0 | (1 << ((insn >> 16) & 0x1F))| 0));
consumed_GPR = consumed;
}
break;
default:
goto unrecognized;
}
*_consumed_CR = consumed_CR;
*_consumed_XER = consumed_XER;
*_consumed_GPR = consumed_GPR;
return;
unrecognized:
*_consumed_CR = 0xffffffff;
*_consumed_XER = 0xffffffff;
*_consumed_GPR = 0xffffffff;
}
