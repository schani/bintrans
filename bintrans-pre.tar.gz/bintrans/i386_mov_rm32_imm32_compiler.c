#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compile_mov_rm32_imm32_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_873963();
goto next_tmp_873873;
next_tmp_873873:
goto finish_tmp_873872;
finish_tmp_873872:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_874099();
goto next_tmp_873966;
next_tmp_873966:
goto finish_tmp_873965;
finish_tmp_873965:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_874270();
goto next_tmp_874102;
next_tmp_874102:
goto finish_tmp_874101;
finish_tmp_874101:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_874363();
goto next_tmp_874273;
next_tmp_874273:
goto finish_tmp_874272;
finish_tmp_874272:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_874501();
goto next_tmp_874366;
next_tmp_874366:
goto finish_tmp_874365;
finish_tmp_874365:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_874648();
goto next_tmp_874504;
next_tmp_874504:
goto finish_tmp_874503;
finish_tmp_874503:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_874662();
goto next_tmp_874651;
next_tmp_874651:
goto finish_tmp_874650;
finish_tmp_874650:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; }))
{
genfunc_tmp_874662();
goto next_tmp_874665;
next_tmp_874665:
goto finish_tmp_874664;
finish_tmp_874664:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_874808();
goto next_tmp_874668;
next_tmp_874668:
goto finish_tmp_874667;
finish_tmp_874667:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_874955();
goto next_tmp_874811;
next_tmp_874811:
goto finish_tmp_874810;
finish_tmp_874810:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_875102();
goto next_tmp_874958;
next_tmp_874958:
goto finish_tmp_874957;
finish_tmp_874957:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_875240();
goto next_tmp_875105;
next_tmp_875105:
goto finish_tmp_875104;
finish_tmp_875104:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_875406();
goto next_tmp_875243;
next_tmp_875243:
goto finish_tmp_875242;
finish_tmp_875242:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_875575();
goto next_tmp_875409;
next_tmp_875409:
goto finish_tmp_875408;
finish_tmp_875408:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_875713();
goto next_tmp_875578;
next_tmp_875578:
goto finish_tmp_875577;
finish_tmp_875577:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_875856();
goto next_tmp_875716;
next_tmp_875716:
goto finish_tmp_875715;
finish_tmp_875715:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_876003();
goto next_tmp_875859;
next_tmp_875859:
goto finish_tmp_875858;
finish_tmp_875858:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_876150();
goto next_tmp_876006;
next_tmp_876006:
goto finish_tmp_876005;
finish_tmp_876005:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_876288();
goto next_tmp_876153;
next_tmp_876153:
goto finish_tmp_876152;
finish_tmp_876152:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_876435();
goto next_tmp_876291;
next_tmp_876291:
goto finish_tmp_876290;
finish_tmp_876290:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_876582();
goto next_tmp_876438;
next_tmp_876438:
goto finish_tmp_876437;
finish_tmp_876437:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_876720();
goto next_tmp_876585;
next_tmp_876585:
goto finish_tmp_876584;
finish_tmp_876584:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 3; }))
{
genfunc_tmp_876803();
goto next_tmp_876723;
next_tmp_876723:
goto finish_tmp_876722;
finish_tmp_876722:
}
}
void genfunc_tmp_876803 (void) {
/* ADDL */
{
word_5 tmp_731905;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876727;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731905 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731905;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731905);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876727:
/* ADDL_IMM */
{
word_5 tmp_731901;
word_5 field_rc;
word_5 field_ra;
word_32 tmp_731903;
word_8 field_imm;
tmp_731903 = imm32;
field_ra = 31;
{
word_32 tmp_876730 = tmp_731903;
if ((tmp_876730 >> 8) == 0)
field_imm = tmp_876730;
else goto fail_tmp_876729;
}
/* commit */
tmp_731901 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731901;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731901);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876729:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876734;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731897 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731897;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731897);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876734:
/* ADDQ_IMM */
{
word_5 tmp_731893;
word_5 field_rc;
word_5 field_ra;
word_64 tmp_731895;
word_8 field_imm;
tmp_731895 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
field_ra = 31;
{
word_64 tmp_876737 = tmp_731895;
if ((tmp_876737 >> 8) == 0)
field_imm = tmp_876737;
else goto fail_tmp_876736;
}
/* commit */
tmp_731893 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731893;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731893);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876736:
/* AND */
{
word_5 tmp_731875;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876738;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731875 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731875;
emit(COMPOSE_AND(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731875);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876738:
/* BIC */
{
word_5 tmp_731861;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876739;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731861 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731861;
emit(COMPOSE_BIC(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731861);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876739:
/* BIS */
{
word_5 tmp_731853;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876742;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731853 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731853;
emit(COMPOSE_BIS(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731853);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876742:
/* BIS_IMM */
{
word_5 tmp_731849;
word_5 field_rc;
word_5 field_ra;
word_64 tmp_731851;
word_8 field_imm;
tmp_731851 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
field_ra = 31;
{
word_64 tmp_876744 = tmp_731851;
if ((tmp_876744 >> 8) == 0)
field_imm = tmp_876744;
else goto fail_tmp_876743;
}
/* commit */
tmp_731849 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731849;
emit(COMPOSE_BIS_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731849);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876743:
/* CMPEQ */
{
word_5 tmp_731754;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (1 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876745;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731754 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731754;
emit(COMPOSE_CMPEQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731754);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876745:
/* CMPLE */
{
word_5 tmp_731746;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (1 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876746;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731746 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731746;
emit(COMPOSE_CMPLE(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731746);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876746:
/* CMPLT */
{
word_5 tmp_731738;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876747;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731738 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731738;
emit(COMPOSE_CMPLT(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731738);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876747:
/* CMPULE */
{
word_5 tmp_731716;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (1 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876748;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731716 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731716;
emit(COMPOSE_CMPULE(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731716);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876748:
/* CMPULT */
{
word_5 tmp_731708;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876749;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731708 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731708;
emit(COMPOSE_CMPULT(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731708);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876749:
/* CTLZ */
{
word_5 tmp_731694;
word_5 field_rc;
word_5 field_rb;
if (64 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876750;
field_rb = 31;
/* commit */
tmp_731694 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731694;
emit(COMPOSE_CTLZ(field_rb, field_rc));
unref_gpr_reg(tmp_731694);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876750:
/* CTPOP */
{
word_5 tmp_731692;
word_5 field_rc;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876751;
field_rb = 31;
/* commit */
tmp_731692 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731692;
emit(COMPOSE_CTPOP(field_rb, field_rc));
unref_gpr_reg(tmp_731692);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876751:
/* CTTZ */
{
word_5 tmp_731690;
word_5 field_rc;
word_5 field_rb;
if (64 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876752;
field_rb = 31;
/* commit */
tmp_731690 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731690;
emit(COMPOSE_CTTZ(field_rb, field_rc));
unref_gpr_reg(tmp_731690);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876752:
/* EQV */
{
word_5 tmp_731668;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876753;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731668 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731668;
emit(COMPOSE_EQV(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731668);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876753:
/* EXTQH */
{
word_5 tmp_731618;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (64 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876754;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731618 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731618;
emit(COMPOSE_EXTQH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731618);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876754:
/* EXTQL */
{
word_5 tmp_731610;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876755;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731610 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731610;
emit(COMPOSE_EXTQL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731610);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876755:
/* FTOIS */
{
word_5 tmp_731534;
word_5 field_rc;
word_5 field_fa;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876756;
field_fa = 31;
/* commit */
tmp_731534 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731534;
emit(COMPOSE_FTOIS(field_fa, field_rc));
unref_gpr_reg(tmp_731534);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876756:
/* FTOIT */
{
word_5 tmp_731532;
word_5 field_rc;
word_5 field_fa;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876757;
field_fa = 31;
/* commit */
tmp_731532 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731532;
emit(COMPOSE_FTOIT(field_fa, field_rc));
unref_gpr_reg(tmp_731532);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876757:
/* LDA */
{
word_5 tmp_731397;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_731399;
word_16 field_memory_disp;
tmp_731399 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
field_rb = 31;
{
word_64 tmp_876760 = tmp_731399;
if ((tmp_876760 >> 16) == 0xFFFFFFFFFFFF || (tmp_876760 >> 16) == 0)
field_memory_disp = (tmp_876760 & 0xFFFF);
else goto fail_tmp_876759;
}
/* commit */
tmp_731397 = ref_gpr_reg_for_writing(0 + rm);
field_ra = tmp_731397;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731397);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876759:
/* LDAH */
{
word_5 tmp_731393;
word_5 field_ra;
word_5 field_rb;
word_64 tmp_731395;
word_16 field_memory_disp;
tmp_731395 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
field_rb = 31;
{
word_64 tmp_876763 = tmp_731395;
if ((tmp_876763 & 0xFFFF) == 0)
{
word_64 tmp_876764 = (tmp_876763 >> 16);
if ((tmp_876764 >> 16) == 0xFFFFFFFFFFFF || (tmp_876764 >> 16) == 0)
field_memory_disp = (tmp_876764 & 0xFFFF);
else goto fail_tmp_876762;
}
else goto fail_tmp_876762;
}
/* commit */
tmp_731393 = ref_gpr_reg_for_writing(0 + rm);
field_ra = tmp_731393;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731393);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876762:
/* MULL */
{
word_5 tmp_731280;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876765;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731280 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731280;
emit(COMPOSE_MULL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731280);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876765:
/* MULQ */
{
word_5 tmp_731272;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876766;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731272 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731272;
emit(COMPOSE_MULQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731272);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876766:
/* ORNOT */
{
word_5 tmp_731256;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (18446744073709551615 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876767;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731256 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731256;
emit(COMPOSE_ORNOT(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731256);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876767:
/* ORNOT_IMM */
{
word_5 tmp_731252;
word_5 field_rc;
word_5 field_ra;
word_64 tmp_731254;
word_8 field_imm;
tmp_731254 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
field_ra = 31;
{
word_64 tmp_876769 = (~tmp_731254 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_876769 >> 8) == 0)
field_imm = tmp_876769;
else goto fail_tmp_876768;
}
/* commit */
tmp_731252 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731252;
emit(COMPOSE_ORNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731252);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876768:
/* S4ADDL */
{
word_5 tmp_731248;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (2 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876771;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731248 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731248;
emit(COMPOSE_S4ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731248);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876771:
/* S4ADDL_IMM */
{
word_5 tmp_731244;
word_5 field_rc;
word_5 field_ra;
word_32 tmp_731246;
word_8 field_imm;
if (2 != imm32) goto fail_tmp_876772;
tmp_731246 = 0;
field_ra = 31;
field_imm = 0;
/* commit */
tmp_731244 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731244;
emit(COMPOSE_S4ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731244);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876772:
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (2 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876774;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731240 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731240;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731240);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876774:
/* S4ADDQ_IMM */
{
word_5 tmp_731236;
word_5 field_rc;
word_5 field_ra;
word_64 tmp_731238;
word_8 field_imm;
if (2 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876775;
tmp_731238 = 0;
field_ra = 31;
field_imm = 0;
/* commit */
tmp_731236 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731236;
emit(COMPOSE_S4ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731236);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876775:
/* S4SUBL */
{
word_5 tmp_731232;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (2 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876776;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731232 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731232;
emit(COMPOSE_S4SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731232);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876776:
/* S4SUBQ */
{
word_5 tmp_731224;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (2 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876777;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731224 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731224;
emit(COMPOSE_S4SUBQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731224);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876777:
/* S8ADDL */
{
word_5 tmp_731216;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (2 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876779;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731216 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731216;
emit(COMPOSE_S8ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731216);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876779:
/* S8ADDL_IMM */
{
word_5 tmp_731212;
word_5 field_rc;
word_5 field_ra;
word_32 tmp_731214;
word_8 field_imm;
if (2 != imm32) goto fail_tmp_876780;
tmp_731214 = 0;
field_ra = 31;
field_imm = 0;
/* commit */
tmp_731212 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731212;
emit(COMPOSE_S8ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731212);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876780:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (2 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876782;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731208 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731208;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731208);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876782:
/* S8ADDQ_IMM */
{
word_5 tmp_731204;
word_5 field_rc;
word_5 field_ra;
word_64 tmp_731206;
word_8 field_imm;
if (2 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876783;
tmp_731206 = 0;
field_ra = 31;
field_imm = 0;
/* commit */
tmp_731204 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731204;
emit(COMPOSE_S8ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731204);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876783:
/* S8SUBL */
{
word_5 tmp_731200;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (2 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876784;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731200 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731200;
emit(COMPOSE_S8SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731200);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876784:
/* S8SUBQ */
{
word_5 tmp_731192;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (2 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876785;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731192 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731192;
emit(COMPOSE_S8SUBQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731192);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876785:
/* SEXTB */
{
word_5 tmp_731186;
word_5 field_rc;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876786;
field_rb = 31;
/* commit */
tmp_731186 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731186;
emit(COMPOSE_SEXTB(field_rb, field_rc));
unref_gpr_reg(tmp_731186);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876786:
/* SEXTB_IMM */
{
word_5 tmp_731184;
word_5 field_rc;
word_64 tmp_731185;
word_8 field_imm;
tmp_731185 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_876788 = tmp_731185;
if ((tmp_876788 >> 8) == 0xFFFFFFFFFFFFFF || (tmp_876788 >> 8) == 0)
field_imm = (tmp_876788 & 0xFF);
else goto fail_tmp_876787;
}
/* commit */
tmp_731184 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731184;
emit(COMPOSE_SEXTB_IMM(field_imm, field_rc));
unref_gpr_reg(tmp_731184);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876787:
/* SEXTW */
{
word_5 tmp_731182;
word_5 field_rc;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876789;
field_rb = 31;
/* commit */
tmp_731182 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731182;
emit(COMPOSE_SEXTW(field_rb, field_rc));
unref_gpr_reg(tmp_731182);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876789:
/* SEXTW_IMM */
{
word_5 tmp_731180;
word_5 field_rc;
word_64 tmp_731181;
word_8 field_imm;
tmp_731181 = ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32);
{
word_64 tmp_876791 = tmp_731181;
if ((tmp_876791 >> 16) == 0xFFFFFFFFFFFF || (tmp_876791 >> 16) == 0)
{
word_16 tmp_876792 = (tmp_876791 & 0xFFFF);
if ((tmp_876792 >> 8) == 0)
field_imm = tmp_876792;
else goto fail_tmp_876790;
}
else goto fail_tmp_876790;
}
/* commit */
tmp_731180 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731180;
emit(COMPOSE_SEXTW_IMM(field_imm, field_rc));
unref_gpr_reg(tmp_731180);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876790:
/* SLL */
{
word_5 tmp_731176;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876793;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731176 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731176;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731176);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876793:
/* SRA */
{
word_5 tmp_731164;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876794;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731164 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731164;
emit(COMPOSE_SRA(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731164);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876794:
/* SRL */
{
word_5 tmp_731156;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876795;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731156 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731156;
emit(COMPOSE_SRL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731156);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876795:
/* SUBL */
{
word_5 tmp_731118;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876796;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731118 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731118;
emit(COMPOSE_SUBL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731118);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876796:
/* SUBQ */
{
word_5 tmp_731110;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876797;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731110 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731110;
emit(COMPOSE_SUBQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731110);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876797:
/* UMULH */
{
word_5 tmp_731094;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (64 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876798;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731094 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731094;
emit(COMPOSE_UMULH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731094);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876798:
/* XOR */
{
word_5 tmp_731086;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876799;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731086 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731086;
emit(COMPOSE_XOR(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731086);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876799:
/* ZAP */
{
word_5 tmp_731078;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876800;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731078 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731078;
emit(COMPOSE_ZAP(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731078);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876800:
/* ZAPNOT */
{
word_5 tmp_731070;
word_5 field_rc;
word_5 field_ra;
word_5 field_rb;
if (0 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876801;
field_ra = 31;
field_rb = 31;
/* commit */
tmp_731070 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731070;
emit(COMPOSE_ZAPNOT(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731070);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876802;
fail_tmp_876801:
/* S4ADDL */
{
word_5 tmp_731248;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731250;
word_5 field_rb;
if (2 != imm32) goto fail_tmp_876770;
field_ra = 31;
/* commit */
tmp_731250 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731250, 0);
tmp_731248 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731248;
field_rb = tmp_731250;
emit(COMPOSE_S4ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731248);
unref_gpr_reg(tmp_731250);
/* can fail: T   num insns: 2 */
}
goto done_tmp_876802;
fail_tmp_876770:
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876773;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731242, 0);
tmp_731240 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731240);
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_876802;
fail_tmp_876773:
/* S8ADDL */
{
word_5 tmp_731216;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731218;
word_5 field_rb;
if (2 != imm32) goto fail_tmp_876778;
field_ra = 31;
/* commit */
tmp_731218 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731218, 0);
tmp_731216 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731216;
field_rb = tmp_731218;
emit(COMPOSE_S8ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731216);
unref_gpr_reg(tmp_731218);
/* can fail: T   num insns: 2 */
}
goto done_tmp_876802;
fail_tmp_876778:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((imm32 & 0x80000000) ? ((word_64)imm32 | 0xFFFFFFFF00000000) : (word_64)imm32)) goto fail_tmp_876781;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731210, 0);
tmp_731208 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731208);
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_876802;
fail_tmp_876781:
/* ADDL */
{
word_5 tmp_731905;
word_5 field_rc;
word_5 tmp_731906;
word_5 field_ra;
word_5 field_rb;
field_rb = 31;
/* commit */
tmp_731906 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731906, imm32);
tmp_731905 = ref_gpr_reg_for_writing(0 + rm);
field_rc = tmp_731905;
field_ra = tmp_731906;
emit(COMPOSE_ADDL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731905);
unref_gpr_reg(tmp_731906);
/* can fail: NIL   num insns: 2 */
}
done_tmp_876802:
}
void genfunc_tmp_876720 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_876711;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_876709();
goto next_tmp_876713;
next_tmp_876713:
goto tmp_876712;
tmp_876712:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 4 */
}
goto done_tmp_876719;
fail_tmp_876711:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_876715;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_876709();
goto next_tmp_876717;
next_tmp_876717:
goto tmp_876716;
tmp_876716:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 4 */
}
goto done_tmp_876719;
fail_tmp_876715:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_876709();
goto next_tmp_876588;
next_tmp_876588:
goto tmp_876587;
tmp_876587:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_876719:
}
reg_t genfunc_tmp_876709 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_876676 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_876676 >> 8) == 0)
field_imm = tmp_876676;
else goto fail_tmp_876675;
}
/* commit */
{
tmp_731858 = genfunc_tmp_876620();
goto next_tmp_876678;
next_tmp_876678:
goto tmp_876677;
tmp_876677:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_876708;
fail_tmp_876675:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_876700 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_876700))
field_imm = inv_maskmask(8, tmp_876700);
else goto fail_tmp_876699;
}
/* commit */
{
tmp_731075 = genfunc_tmp_876620();
goto next_tmp_876702;
next_tmp_876702:
goto tmp_876701;
tmp_876701:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_876708;
fail_tmp_876699:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_876620();
goto next_tmp_876706;
next_tmp_876706:
goto tmp_876705;
tmp_876705:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_876708:
return tmp_731142;
}
reg_t genfunc_tmp_876673 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_876642 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_876642 >> 8) == 0)
field_imm = tmp_876642;
else goto fail_tmp_876641;
}
/* commit */
{
tmp_731858 = genfunc_tmp_876620();
goto next_tmp_876644;
next_tmp_876644:
goto tmp_876643;
tmp_876643:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_876672;
fail_tmp_876641:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_876664 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_876664))
field_imm = inv_maskmask(8, tmp_876664);
else goto fail_tmp_876663;
}
/* commit */
{
tmp_731075 = genfunc_tmp_876620();
goto next_tmp_876666;
next_tmp_876666:
goto tmp_876665;
tmp_876665:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_876672;
fail_tmp_876663:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_876620();
goto next_tmp_876670;
next_tmp_876670:
goto tmp_876669;
tmp_876669:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_876672:
return tmp_731862;
}
reg_t genfunc_tmp_876620 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_876617;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + 5);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876619;
fail_tmp_876617:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_876618;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + 5);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876619;
fail_tmp_876618:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + 5);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_876619:
return tmp_731876;
}
void genfunc_tmp_876582 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_876573;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_876571();
goto next_tmp_876575;
next_tmp_876575:
goto tmp_876574;
tmp_876574:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 6 */
}
goto done_tmp_876581;
fail_tmp_876573:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_876577;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_876571();
goto next_tmp_876579;
next_tmp_876579:
goto tmp_876578;
tmp_876578:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 6 */
}
goto done_tmp_876581;
fail_tmp_876577:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_876571();
goto next_tmp_876441;
next_tmp_876441:
goto tmp_876440;
tmp_876440:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 7 */
}
done_tmp_876581:
}
reg_t genfunc_tmp_876571 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_876538 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_876538 >> 8) == 0)
field_imm = tmp_876538;
else goto fail_tmp_876537;
}
/* commit */
{
tmp_731858 = genfunc_tmp_876482();
goto next_tmp_876540;
next_tmp_876540:
goto tmp_876539;
tmp_876539:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_876570;
fail_tmp_876537:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_876562 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_876562))
field_imm = inv_maskmask(8, tmp_876562);
else goto fail_tmp_876561;
}
/* commit */
{
tmp_731075 = genfunc_tmp_876482();
goto next_tmp_876564;
next_tmp_876564:
goto tmp_876563;
tmp_876563:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_876570;
fail_tmp_876561:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_876482();
goto next_tmp_876568;
next_tmp_876568:
goto tmp_876567;
tmp_876567:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_876570:
return tmp_731142;
}
reg_t genfunc_tmp_876535 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_876504 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_876504 >> 8) == 0)
field_imm = tmp_876504;
else goto fail_tmp_876503;
}
/* commit */
{
tmp_731858 = genfunc_tmp_876482();
goto next_tmp_876506;
next_tmp_876506:
goto tmp_876505;
tmp_876505:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_876534;
fail_tmp_876503:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_876526 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_876526))
field_imm = inv_maskmask(8, tmp_876526);
else goto fail_tmp_876525;
}
/* commit */
{
tmp_731075 = genfunc_tmp_876482();
goto next_tmp_876528;
next_tmp_876528:
goto tmp_876527;
tmp_876527:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_876534;
fail_tmp_876525:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_876482();
goto next_tmp_876532;
next_tmp_876532:
goto tmp_876531;
tmp_876531:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_876534:
return tmp_731862;
}
reg_t genfunc_tmp_876482 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_876473;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_875450();
goto next_tmp_876475;
next_tmp_876475:
goto tmp_876474;
tmp_876474:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_876481;
fail_tmp_876473:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_876477;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_875450();
goto next_tmp_876479;
next_tmp_876479:
goto tmp_876478;
tmp_876478:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_876481;
fail_tmp_876477:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_875450();
goto next_tmp_876457;
next_tmp_876457:
goto tmp_876456;
tmp_876456:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_876481:
return tmp_731876;
}
void genfunc_tmp_876435 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_876426;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_876424();
goto next_tmp_876428;
next_tmp_876428:
goto tmp_876427;
tmp_876427:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 5 */
}
goto done_tmp_876434;
fail_tmp_876426:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_876430;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_876424();
goto next_tmp_876432;
next_tmp_876432:
goto tmp_876431;
tmp_876431:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 5 */
}
goto done_tmp_876434;
fail_tmp_876430:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_876424();
goto next_tmp_876294;
next_tmp_876294:
goto tmp_876293;
tmp_876293:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_876434:
}
reg_t genfunc_tmp_876424 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_876391 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_876391 >> 8) == 0)
field_imm = tmp_876391;
else goto fail_tmp_876390;
}
/* commit */
{
tmp_731858 = genfunc_tmp_876335();
goto next_tmp_876393;
next_tmp_876393:
goto tmp_876392;
tmp_876392:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_876423;
fail_tmp_876390:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_876415 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_876415))
field_imm = inv_maskmask(8, tmp_876415);
else goto fail_tmp_876414;
}
/* commit */
{
tmp_731075 = genfunc_tmp_876335();
goto next_tmp_876417;
next_tmp_876417:
goto tmp_876416;
tmp_876416:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_876423;
fail_tmp_876414:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_876335();
goto next_tmp_876421;
next_tmp_876421:
goto tmp_876420;
tmp_876420:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_876423:
return tmp_731142;
}
reg_t genfunc_tmp_876388 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_876357 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_876357 >> 8) == 0)
field_imm = tmp_876357;
else goto fail_tmp_876356;
}
/* commit */
{
tmp_731858 = genfunc_tmp_876335();
goto next_tmp_876359;
next_tmp_876359:
goto tmp_876358;
tmp_876358:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_876387;
fail_tmp_876356:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_876379 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_876379))
field_imm = inv_maskmask(8, tmp_876379);
else goto fail_tmp_876378;
}
/* commit */
{
tmp_731075 = genfunc_tmp_876335();
goto next_tmp_876381;
next_tmp_876381:
goto tmp_876380;
tmp_876380:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_876387;
fail_tmp_876378:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_876335();
goto next_tmp_876385;
next_tmp_876385:
goto tmp_876384;
tmp_876384:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_876387:
return tmp_731862;
}
reg_t genfunc_tmp_876335 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_876326;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_875281();
goto next_tmp_876328;
next_tmp_876328:
goto tmp_876327;
tmp_876327:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_876334;
fail_tmp_876326:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_876330;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_875281();
goto next_tmp_876332;
next_tmp_876332:
goto tmp_876331;
tmp_876331:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_876334;
fail_tmp_876330:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_875281();
goto next_tmp_876310;
next_tmp_876310:
goto tmp_876309;
tmp_876309:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_876334:
return tmp_731876;
}
void genfunc_tmp_876288 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_876279;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_876277();
goto next_tmp_876281;
next_tmp_876281:
goto tmp_876280;
tmp_876280:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 4 */
}
goto done_tmp_876287;
fail_tmp_876279:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_876283;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_876277();
goto next_tmp_876285;
next_tmp_876285:
goto tmp_876284;
tmp_876284:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 4 */
}
goto done_tmp_876287;
fail_tmp_876283:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_876277();
goto next_tmp_876156;
next_tmp_876156:
goto tmp_876155;
tmp_876155:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_876287:
}
reg_t genfunc_tmp_876277 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_876244 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_876244 >> 8) == 0)
field_imm = tmp_876244;
else goto fail_tmp_876243;
}
/* commit */
{
tmp_731858 = genfunc_tmp_876188();
goto next_tmp_876246;
next_tmp_876246:
goto tmp_876245;
tmp_876245:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_876276;
fail_tmp_876243:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_876268 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_876268))
field_imm = inv_maskmask(8, tmp_876268);
else goto fail_tmp_876267;
}
/* commit */
{
tmp_731075 = genfunc_tmp_876188();
goto next_tmp_876270;
next_tmp_876270:
goto tmp_876269;
tmp_876269:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_876276;
fail_tmp_876267:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_876188();
goto next_tmp_876274;
next_tmp_876274:
goto tmp_876273;
tmp_876273:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_876276:
return tmp_731142;
}
reg_t genfunc_tmp_876241 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_876210 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_876210 >> 8) == 0)
field_imm = tmp_876210;
else goto fail_tmp_876209;
}
/* commit */
{
tmp_731858 = genfunc_tmp_876188();
goto next_tmp_876212;
next_tmp_876212:
goto tmp_876211;
tmp_876211:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_876240;
fail_tmp_876209:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_876232 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_876232))
field_imm = inv_maskmask(8, tmp_876232);
else goto fail_tmp_876231;
}
/* commit */
{
tmp_731075 = genfunc_tmp_876188();
goto next_tmp_876234;
next_tmp_876234:
goto tmp_876233;
tmp_876233:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_876240;
fail_tmp_876231:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_876188();
goto next_tmp_876238;
next_tmp_876238:
goto tmp_876237;
tmp_876237:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_876240:
return tmp_731862;
}
reg_t genfunc_tmp_876188 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_876185;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + base);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876187;
fail_tmp_876185:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_876186;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + base);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_876187;
fail_tmp_876186:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + base);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_876187:
return tmp_731876;
}
void genfunc_tmp_876150 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_876141;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_876139();
goto next_tmp_876143;
next_tmp_876143:
goto tmp_876142;
tmp_876142:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 6 */
}
goto done_tmp_876149;
fail_tmp_876141:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_876145;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_876139();
goto next_tmp_876147;
next_tmp_876147:
goto tmp_876146;
tmp_876146:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 6 */
}
goto done_tmp_876149;
fail_tmp_876145:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_876139();
goto next_tmp_876009;
next_tmp_876009:
goto tmp_876008;
tmp_876008:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 7 */
}
done_tmp_876149:
}
reg_t genfunc_tmp_876139 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_876106 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_876106 >> 8) == 0)
field_imm = tmp_876106;
else goto fail_tmp_876105;
}
/* commit */
{
tmp_731858 = genfunc_tmp_876050();
goto next_tmp_876108;
next_tmp_876108:
goto tmp_876107;
tmp_876107:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_876138;
fail_tmp_876105:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_876130 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_876130))
field_imm = inv_maskmask(8, tmp_876130);
else goto fail_tmp_876129;
}
/* commit */
{
tmp_731075 = genfunc_tmp_876050();
goto next_tmp_876132;
next_tmp_876132:
goto tmp_876131;
tmp_876131:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_876138;
fail_tmp_876129:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_876050();
goto next_tmp_876136;
next_tmp_876136:
goto tmp_876135;
tmp_876135:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_876138:
return tmp_731142;
}
reg_t genfunc_tmp_876103 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_876072 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_876072 >> 8) == 0)
field_imm = tmp_876072;
else goto fail_tmp_876071;
}
/* commit */
{
tmp_731858 = genfunc_tmp_876050();
goto next_tmp_876074;
next_tmp_876074:
goto tmp_876073;
tmp_876073:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_876102;
fail_tmp_876071:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_876094 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_876094))
field_imm = inv_maskmask(8, tmp_876094);
else goto fail_tmp_876093;
}
/* commit */
{
tmp_731075 = genfunc_tmp_876050();
goto next_tmp_876096;
next_tmp_876096:
goto tmp_876095;
tmp_876095:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_876102;
fail_tmp_876093:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_876050();
goto next_tmp_876100;
next_tmp_876100:
goto tmp_876099;
tmp_876099:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_876102:
return tmp_731862;
}
reg_t genfunc_tmp_876050 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_876041;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_874170();
goto next_tmp_876043;
next_tmp_876043:
goto tmp_876042;
tmp_876042:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_876049;
fail_tmp_876041:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_876045;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_874170();
goto next_tmp_876047;
next_tmp_876047:
goto tmp_876046;
tmp_876046:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_876049;
fail_tmp_876045:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_874170();
goto next_tmp_876025;
next_tmp_876025:
goto tmp_876024;
tmp_876024:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_876049:
return tmp_731876;
}
void genfunc_tmp_876003 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_875994;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_875992();
goto next_tmp_875996;
next_tmp_875996:
goto tmp_875995;
tmp_875995:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 5 */
}
goto done_tmp_876002;
fail_tmp_875994:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_875998;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_875992();
goto next_tmp_876000;
next_tmp_876000:
goto tmp_875999;
tmp_875999:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 5 */
}
goto done_tmp_876002;
fail_tmp_875998:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_875992();
goto next_tmp_875862;
next_tmp_875862:
goto tmp_875861;
tmp_875861:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_876002:
}
reg_t genfunc_tmp_875992 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_875959 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_875959 >> 8) == 0)
field_imm = tmp_875959;
else goto fail_tmp_875958;
}
/* commit */
{
tmp_731858 = genfunc_tmp_875903();
goto next_tmp_875961;
next_tmp_875961:
goto tmp_875960;
tmp_875960:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_875991;
fail_tmp_875958:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_875983 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_875983))
field_imm = inv_maskmask(8, tmp_875983);
else goto fail_tmp_875982;
}
/* commit */
{
tmp_731075 = genfunc_tmp_875903();
goto next_tmp_875985;
next_tmp_875985:
goto tmp_875984;
tmp_875984:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_875991;
fail_tmp_875982:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_875903();
goto next_tmp_875989;
next_tmp_875989:
goto tmp_875988;
tmp_875988:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_875991:
return tmp_731142;
}
reg_t genfunc_tmp_875956 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_875925 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_875925 >> 8) == 0)
field_imm = tmp_875925;
else goto fail_tmp_875924;
}
/* commit */
{
tmp_731858 = genfunc_tmp_875903();
goto next_tmp_875927;
next_tmp_875927:
goto tmp_875926;
tmp_875926:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_875955;
fail_tmp_875924:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_875947 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_875947))
field_imm = inv_maskmask(8, tmp_875947);
else goto fail_tmp_875946;
}
/* commit */
{
tmp_731075 = genfunc_tmp_875903();
goto next_tmp_875949;
next_tmp_875949:
goto tmp_875948;
tmp_875948:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_875955;
fail_tmp_875946:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_875903();
goto next_tmp_875953;
next_tmp_875953:
goto tmp_875952;
tmp_875952:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_875955:
return tmp_731862;
}
reg_t genfunc_tmp_875903 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_875894;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_873999();
goto next_tmp_875896;
next_tmp_875896:
goto tmp_875895;
tmp_875895:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_875902;
fail_tmp_875894:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_875898;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_873999();
goto next_tmp_875900;
next_tmp_875900:
goto tmp_875899;
tmp_875899:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_875902;
fail_tmp_875898:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_873999();
goto next_tmp_875878;
next_tmp_875878:
goto tmp_875877;
tmp_875877:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_875902:
return tmp_731876;
}
void genfunc_tmp_875856 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_875847;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_875845();
goto next_tmp_875849;
next_tmp_875849:
goto tmp_875848;
tmp_875848:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 4 */
}
goto done_tmp_875855;
fail_tmp_875847:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_875851;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_875845();
goto next_tmp_875853;
next_tmp_875853:
goto tmp_875852;
tmp_875852:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 4 */
}
goto done_tmp_875855;
fail_tmp_875851:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_875845();
goto next_tmp_875719;
next_tmp_875719:
goto tmp_875718;
tmp_875718:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_875855:
}
reg_t genfunc_tmp_875845 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_875812 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_875812 >> 8) == 0)
field_imm = tmp_875812;
else goto fail_tmp_875811;
}
/* commit */
{
tmp_731858 = genfunc_tmp_875756();
goto next_tmp_875814;
next_tmp_875814:
goto tmp_875813;
tmp_875813:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875844;
fail_tmp_875811:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_875836 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_875836))
field_imm = inv_maskmask(8, tmp_875836);
else goto fail_tmp_875835;
}
/* commit */
{
tmp_731075 = genfunc_tmp_875756();
goto next_tmp_875838;
next_tmp_875838:
goto tmp_875837;
tmp_875837:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875844;
fail_tmp_875835:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_875756();
goto next_tmp_875842;
next_tmp_875842:
goto tmp_875841;
tmp_875841:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_875844:
return tmp_731142;
}
reg_t genfunc_tmp_875809 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_875778 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_875778 >> 8) == 0)
field_imm = tmp_875778;
else goto fail_tmp_875777;
}
/* commit */
{
tmp_731858 = genfunc_tmp_875756();
goto next_tmp_875780;
next_tmp_875780:
goto tmp_875779;
tmp_875779:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875808;
fail_tmp_875777:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_875800 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_875800))
field_imm = inv_maskmask(8, tmp_875800);
else goto fail_tmp_875799;
}
/* commit */
{
tmp_731075 = genfunc_tmp_875756();
goto next_tmp_875802;
next_tmp_875802:
goto tmp_875801;
tmp_875801:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875808;
fail_tmp_875799:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_875756();
goto next_tmp_875806;
next_tmp_875806:
goto tmp_875805;
tmp_875805:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_875808:
return tmp_731862;
}
reg_t genfunc_tmp_875756 (void) {
reg_t tmp_731876;
/* ADDQ_IMM */
{
word_5 tmp_731893;
word_5 field_rc;
word_5 tmp_731894;
word_5 field_ra;
word_64 tmp_731896;
word_8 field_imm;
tmp_731896 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_875741 = tmp_731896;
if ((tmp_875741 >> 8) == 0)
field_imm = tmp_875741;
else goto fail_tmp_875740;
}
/* commit */
tmp_731894 = ref_gpr_reg_for_reading(0 + rm);
tmp_731893 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731893;
field_ra = tmp_731894;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731894);
/* can fail: T   num insns: 1 */
}
goto done_tmp_875755;
fail_tmp_875740:
/* LDA */
{
word_5 tmp_731397;
word_5 field_ra;
word_5 tmp_731398;
word_5 field_rb;
word_64 tmp_731400;
word_16 field_memory_disp;
tmp_731400 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_875749 = tmp_731400;
if ((tmp_875749 >> 16) == 0xFFFFFFFFFFFF || (tmp_875749 >> 16) == 0)
field_memory_disp = (tmp_875749 & 0xFFFF);
else goto fail_tmp_875748;
}
/* commit */
tmp_731398 = ref_gpr_reg_for_reading(0 + rm);
tmp_731397 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731397;
field_rb = tmp_731398;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731398);
/* can fail: T   num insns: 1 */
}
goto done_tmp_875755;
fail_tmp_875748:
/* LDAH */
{
word_5 tmp_731393;
word_5 field_ra;
word_5 tmp_731394;
word_5 field_rb;
word_64 tmp_731396;
word_16 field_memory_disp;
tmp_731396 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_875753 = tmp_731396;
if ((tmp_875753 & 0xFFFF) == 0)
{
word_64 tmp_875754 = (tmp_875753 >> 16);
if ((tmp_875754 >> 16) == 0xFFFFFFFFFFFF || (tmp_875754 >> 16) == 0)
field_memory_disp = (tmp_875754 & 0xFFFF);
else goto fail_tmp_875752;
}
else goto fail_tmp_875752;
}
/* commit */
tmp_731394 = ref_gpr_reg_for_reading(0 + rm);
tmp_731393 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731393;
field_rb = tmp_731394;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731394);
/* can fail: T   num insns: 1 */
}
goto done_tmp_875755;
fail_tmp_875752:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731900 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731900, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_875755:
return tmp_731876;
}
void genfunc_tmp_875713 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_875704;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_875702();
goto next_tmp_875706;
next_tmp_875706:
goto tmp_875705;
tmp_875705:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 4 */
}
goto done_tmp_875712;
fail_tmp_875704:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_875708;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_875702();
goto next_tmp_875710;
next_tmp_875710:
goto tmp_875709;
tmp_875709:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 4 */
}
goto done_tmp_875712;
fail_tmp_875708:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_875702();
goto next_tmp_875581;
next_tmp_875581:
goto tmp_875580;
tmp_875580:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_875712:
}
reg_t genfunc_tmp_875702 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_875669 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_875669 >> 8) == 0)
field_imm = tmp_875669;
else goto fail_tmp_875668;
}
/* commit */
{
tmp_731858 = genfunc_tmp_875613();
goto next_tmp_875671;
next_tmp_875671:
goto tmp_875670;
tmp_875670:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875701;
fail_tmp_875668:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_875693 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_875693))
field_imm = inv_maskmask(8, tmp_875693);
else goto fail_tmp_875692;
}
/* commit */
{
tmp_731075 = genfunc_tmp_875613();
goto next_tmp_875695;
next_tmp_875695:
goto tmp_875694;
tmp_875694:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875701;
fail_tmp_875692:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_875613();
goto next_tmp_875699;
next_tmp_875699:
goto tmp_875698;
tmp_875698:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_875701:
return tmp_731142;
}
reg_t genfunc_tmp_875666 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_875635 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_875635 >> 8) == 0)
field_imm = tmp_875635;
else goto fail_tmp_875634;
}
/* commit */
{
tmp_731858 = genfunc_tmp_875613();
goto next_tmp_875637;
next_tmp_875637:
goto tmp_875636;
tmp_875636:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875665;
fail_tmp_875634:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_875657 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_875657))
field_imm = inv_maskmask(8, tmp_875657);
else goto fail_tmp_875656;
}
/* commit */
{
tmp_731075 = genfunc_tmp_875613();
goto next_tmp_875659;
next_tmp_875659:
goto tmp_875658;
tmp_875658:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875665;
fail_tmp_875656:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_875613();
goto next_tmp_875663;
next_tmp_875663:
goto tmp_875662;
tmp_875662:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_875665:
return tmp_731862;
}
reg_t genfunc_tmp_875613 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_875610;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + 5);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_875612;
fail_tmp_875610:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_875611;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + 5);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_875612;
fail_tmp_875611:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731900 = ref_gpr_reg_for_reading(0 + 5);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_875612:
return tmp_731876;
}
void genfunc_tmp_875575 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_875566;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_875564();
goto next_tmp_875568;
next_tmp_875568:
goto tmp_875567;
tmp_875567:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 6 */
}
goto done_tmp_875574;
fail_tmp_875566:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_875570;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_875564();
goto next_tmp_875572;
next_tmp_875572:
goto tmp_875571;
tmp_875571:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 6 */
}
goto done_tmp_875574;
fail_tmp_875570:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_875564();
goto next_tmp_875412;
next_tmp_875412:
goto tmp_875411;
tmp_875411:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 7 */
}
done_tmp_875574:
}
reg_t genfunc_tmp_875564 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_875531 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_875531 >> 8) == 0)
field_imm = tmp_875531;
else goto fail_tmp_875530;
}
/* commit */
{
tmp_731858 = genfunc_tmp_875475();
goto next_tmp_875533;
next_tmp_875533:
goto tmp_875532;
tmp_875532:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_875563;
fail_tmp_875530:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_875555 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_875555))
field_imm = inv_maskmask(8, tmp_875555);
else goto fail_tmp_875554;
}
/* commit */
{
tmp_731075 = genfunc_tmp_875475();
goto next_tmp_875557;
next_tmp_875557:
goto tmp_875556;
tmp_875556:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_875563;
fail_tmp_875554:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_875475();
goto next_tmp_875561;
next_tmp_875561:
goto tmp_875560;
tmp_875560:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_875563:
return tmp_731142;
}
reg_t genfunc_tmp_875528 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_875497 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_875497 >> 8) == 0)
field_imm = tmp_875497;
else goto fail_tmp_875496;
}
/* commit */
{
tmp_731858 = genfunc_tmp_875475();
goto next_tmp_875499;
next_tmp_875499:
goto tmp_875498;
tmp_875498:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_875527;
fail_tmp_875496:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_875519 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_875519))
field_imm = inv_maskmask(8, tmp_875519);
else goto fail_tmp_875518;
}
/* commit */
{
tmp_731075 = genfunc_tmp_875475();
goto next_tmp_875521;
next_tmp_875521:
goto tmp_875520;
tmp_875520:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_875527;
fail_tmp_875518:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_875475();
goto next_tmp_875525;
next_tmp_875525:
goto tmp_875524;
tmp_875524:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_875527:
return tmp_731862;
}
reg_t genfunc_tmp_875475 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_875466;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_875450();
goto next_tmp_875468;
next_tmp_875468:
goto tmp_875467;
tmp_875467:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875474;
fail_tmp_875466:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_875470;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_875450();
goto next_tmp_875472;
next_tmp_875472:
goto tmp_875471;
tmp_875471:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875474;
fail_tmp_875470:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_875450();
goto next_tmp_875428;
next_tmp_875428:
goto tmp_875427;
tmp_875427:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_875474:
return tmp_731876;
}
reg_t genfunc_tmp_875450 (void) {
reg_t tmp_731900;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + 5);
{
tmp_731900 = genfunc_tmp_874153();
goto next_tmp_875433;
next_tmp_875433:
goto tmp_875432;
tmp_875432:
}
tmp_731897 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_875449:
return tmp_731900;
}
void genfunc_tmp_875406 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_875397;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_875395();
goto next_tmp_875399;
next_tmp_875399:
goto tmp_875398;
tmp_875398:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 5 */
}
goto done_tmp_875405;
fail_tmp_875397:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_875401;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_875395();
goto next_tmp_875403;
next_tmp_875403:
goto tmp_875402;
tmp_875402:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 5 */
}
goto done_tmp_875405;
fail_tmp_875401:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_875395();
goto next_tmp_875246;
next_tmp_875246:
goto tmp_875245;
tmp_875245:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_875405:
}
reg_t genfunc_tmp_875395 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_875362 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_875362 >> 8) == 0)
field_imm = tmp_875362;
else goto fail_tmp_875361;
}
/* commit */
{
tmp_731858 = genfunc_tmp_875306();
goto next_tmp_875364;
next_tmp_875364:
goto tmp_875363;
tmp_875363:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_875394;
fail_tmp_875361:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_875386 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_875386))
field_imm = inv_maskmask(8, tmp_875386);
else goto fail_tmp_875385;
}
/* commit */
{
tmp_731075 = genfunc_tmp_875306();
goto next_tmp_875388;
next_tmp_875388:
goto tmp_875387;
tmp_875387:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_875394;
fail_tmp_875385:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_875306();
goto next_tmp_875392;
next_tmp_875392:
goto tmp_875391;
tmp_875391:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_875394:
return tmp_731142;
}
reg_t genfunc_tmp_875359 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_875328 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_875328 >> 8) == 0)
field_imm = tmp_875328;
else goto fail_tmp_875327;
}
/* commit */
{
tmp_731858 = genfunc_tmp_875306();
goto next_tmp_875330;
next_tmp_875330:
goto tmp_875329;
tmp_875329:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_875358;
fail_tmp_875327:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_875350 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_875350))
field_imm = inv_maskmask(8, tmp_875350);
else goto fail_tmp_875349;
}
/* commit */
{
tmp_731075 = genfunc_tmp_875306();
goto next_tmp_875352;
next_tmp_875352:
goto tmp_875351;
tmp_875351:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_875358;
fail_tmp_875349:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_875306();
goto next_tmp_875356;
next_tmp_875356:
goto tmp_875355;
tmp_875355:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_875358:
return tmp_731862;
}
reg_t genfunc_tmp_875306 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_875297;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_875281();
goto next_tmp_875299;
next_tmp_875299:
goto tmp_875298;
tmp_875298:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_875305;
fail_tmp_875297:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_875301;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_875281();
goto next_tmp_875303;
next_tmp_875303:
goto tmp_875302;
tmp_875302:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_875305;
fail_tmp_875301:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_875281();
goto next_tmp_875262;
next_tmp_875262:
goto tmp_875261;
tmp_875261:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_875305:
return tmp_731876;
}
reg_t genfunc_tmp_875281 (void) {
reg_t tmp_731900;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + 5);
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_875280:
return tmp_731900;
}
void genfunc_tmp_875240 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_875231;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_875229();
goto next_tmp_875233;
next_tmp_875233:
goto tmp_875232;
tmp_875232:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 4 */
}
goto done_tmp_875239;
fail_tmp_875231:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_875235;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_875229();
goto next_tmp_875237;
next_tmp_875237:
goto tmp_875236;
tmp_875236:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 4 */
}
goto done_tmp_875239;
fail_tmp_875235:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_875229();
goto next_tmp_875108;
next_tmp_875108:
goto tmp_875107;
tmp_875107:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_875239:
}
reg_t genfunc_tmp_875229 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_875196 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_875196 >> 8) == 0)
field_imm = tmp_875196;
else goto fail_tmp_875195;
}
/* commit */
{
tmp_731858 = genfunc_tmp_875140();
goto next_tmp_875198;
next_tmp_875198:
goto tmp_875197;
tmp_875197:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875228;
fail_tmp_875195:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_875220 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_875220))
field_imm = inv_maskmask(8, tmp_875220);
else goto fail_tmp_875219;
}
/* commit */
{
tmp_731075 = genfunc_tmp_875140();
goto next_tmp_875222;
next_tmp_875222:
goto tmp_875221;
tmp_875221:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875228;
fail_tmp_875219:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_875140();
goto next_tmp_875226;
next_tmp_875226:
goto tmp_875225;
tmp_875225:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_875228:
return tmp_731142;
}
reg_t genfunc_tmp_875193 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_875162 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_875162 >> 8) == 0)
field_imm = tmp_875162;
else goto fail_tmp_875161;
}
/* commit */
{
tmp_731858 = genfunc_tmp_875140();
goto next_tmp_875164;
next_tmp_875164:
goto tmp_875163;
tmp_875163:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875192;
fail_tmp_875161:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_875184 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_875184))
field_imm = inv_maskmask(8, tmp_875184);
else goto fail_tmp_875183;
}
/* commit */
{
tmp_731075 = genfunc_tmp_875140();
goto next_tmp_875186;
next_tmp_875186:
goto tmp_875185;
tmp_875185:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875192;
fail_tmp_875183:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_875140();
goto next_tmp_875190;
next_tmp_875190:
goto tmp_875189;
tmp_875189:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_875192:
return tmp_731862;
}
reg_t genfunc_tmp_875140 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_875137;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + base);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_875139;
fail_tmp_875137:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_875138;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + base);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_875139;
fail_tmp_875138:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731900 = ref_gpr_reg_for_reading(0 + base);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_875139:
return tmp_731876;
}
void genfunc_tmp_875102 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_875093;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_875091();
goto next_tmp_875095;
next_tmp_875095:
goto tmp_875094;
tmp_875094:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 6 */
}
goto done_tmp_875101;
fail_tmp_875093:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_875097;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_875091();
goto next_tmp_875099;
next_tmp_875099:
goto tmp_875098;
tmp_875098:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 6 */
}
goto done_tmp_875101;
fail_tmp_875097:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_875091();
goto next_tmp_874961;
next_tmp_874961:
goto tmp_874960;
tmp_874960:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 7 */
}
done_tmp_875101:
}
reg_t genfunc_tmp_875091 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_875058 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_875058 >> 8) == 0)
field_imm = tmp_875058;
else goto fail_tmp_875057;
}
/* commit */
{
tmp_731858 = genfunc_tmp_875002();
goto next_tmp_875060;
next_tmp_875060:
goto tmp_875059;
tmp_875059:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_875090;
fail_tmp_875057:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_875082 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_875082))
field_imm = inv_maskmask(8, tmp_875082);
else goto fail_tmp_875081;
}
/* commit */
{
tmp_731075 = genfunc_tmp_875002();
goto next_tmp_875084;
next_tmp_875084:
goto tmp_875083;
tmp_875083:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_875090;
fail_tmp_875081:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_875002();
goto next_tmp_875088;
next_tmp_875088:
goto tmp_875087;
tmp_875087:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_875090:
return tmp_731142;
}
reg_t genfunc_tmp_875055 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_875024 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_875024 >> 8) == 0)
field_imm = tmp_875024;
else goto fail_tmp_875023;
}
/* commit */
{
tmp_731858 = genfunc_tmp_875002();
goto next_tmp_875026;
next_tmp_875026:
goto tmp_875025;
tmp_875025:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_875054;
fail_tmp_875023:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_875046 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_875046))
field_imm = inv_maskmask(8, tmp_875046);
else goto fail_tmp_875045;
}
/* commit */
{
tmp_731075 = genfunc_tmp_875002();
goto next_tmp_875048;
next_tmp_875048:
goto tmp_875047;
tmp_875047:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_875054;
fail_tmp_875045:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_875002();
goto next_tmp_875052;
next_tmp_875052:
goto tmp_875051;
tmp_875051:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_875054:
return tmp_731862;
}
reg_t genfunc_tmp_875002 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_874993;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_874170();
goto next_tmp_874995;
next_tmp_874995:
goto tmp_874994;
tmp_874994:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875001;
fail_tmp_874993:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_874997;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_874170();
goto next_tmp_874999;
next_tmp_874999:
goto tmp_874998;
tmp_874998:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_875001;
fail_tmp_874997:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_874170();
goto next_tmp_874977;
next_tmp_874977:
goto tmp_874976;
tmp_874976:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_875001:
return tmp_731876;
}
void genfunc_tmp_874955 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_874946;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_874944();
goto next_tmp_874948;
next_tmp_874948:
goto tmp_874947;
tmp_874947:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 5 */
}
goto done_tmp_874954;
fail_tmp_874946:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_874950;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_874944();
goto next_tmp_874952;
next_tmp_874952:
goto tmp_874951;
tmp_874951:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 5 */
}
goto done_tmp_874954;
fail_tmp_874950:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_874944();
goto next_tmp_874814;
next_tmp_874814:
goto tmp_874813;
tmp_874813:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_874954:
}
reg_t genfunc_tmp_874944 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_874911 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_874911 >> 8) == 0)
field_imm = tmp_874911;
else goto fail_tmp_874910;
}
/* commit */
{
tmp_731858 = genfunc_tmp_874855();
goto next_tmp_874913;
next_tmp_874913:
goto tmp_874912;
tmp_874912:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_874943;
fail_tmp_874910:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_874935 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_874935))
field_imm = inv_maskmask(8, tmp_874935);
else goto fail_tmp_874934;
}
/* commit */
{
tmp_731075 = genfunc_tmp_874855();
goto next_tmp_874937;
next_tmp_874937:
goto tmp_874936;
tmp_874936:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_874943;
fail_tmp_874934:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_874855();
goto next_tmp_874941;
next_tmp_874941:
goto tmp_874940;
tmp_874940:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_874943:
return tmp_731142;
}
reg_t genfunc_tmp_874908 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_874877 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_874877 >> 8) == 0)
field_imm = tmp_874877;
else goto fail_tmp_874876;
}
/* commit */
{
tmp_731858 = genfunc_tmp_874855();
goto next_tmp_874879;
next_tmp_874879:
goto tmp_874878;
tmp_874878:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_874907;
fail_tmp_874876:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_874899 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_874899))
field_imm = inv_maskmask(8, tmp_874899);
else goto fail_tmp_874898;
}
/* commit */
{
tmp_731075 = genfunc_tmp_874855();
goto next_tmp_874901;
next_tmp_874901:
goto tmp_874900;
tmp_874900:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_874907;
fail_tmp_874898:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_874855();
goto next_tmp_874905;
next_tmp_874905:
goto tmp_874904;
tmp_874904:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_874907:
return tmp_731862;
}
reg_t genfunc_tmp_874855 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_874846;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_873999();
goto next_tmp_874848;
next_tmp_874848:
goto tmp_874847;
tmp_874847:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_874854;
fail_tmp_874846:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_874850;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_873999();
goto next_tmp_874852;
next_tmp_874852:
goto tmp_874851;
tmp_874851:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_874854;
fail_tmp_874850:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_873999();
goto next_tmp_874830;
next_tmp_874830:
goto tmp_874829;
tmp_874829:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_874854:
return tmp_731876;
}
void genfunc_tmp_874808 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_874799;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_874797();
goto next_tmp_874801;
next_tmp_874801:
goto tmp_874800;
tmp_874800:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 4 */
}
goto done_tmp_874807;
fail_tmp_874799:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_874803;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_874797();
goto next_tmp_874805;
next_tmp_874805:
goto tmp_874804;
tmp_874804:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 4 */
}
goto done_tmp_874807;
fail_tmp_874803:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_874797();
goto next_tmp_874671;
next_tmp_874671:
goto tmp_874670;
tmp_874670:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_874807:
}
reg_t genfunc_tmp_874797 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_874764 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_874764 >> 8) == 0)
field_imm = tmp_874764;
else goto fail_tmp_874763;
}
/* commit */
{
tmp_731858 = genfunc_tmp_874708();
goto next_tmp_874766;
next_tmp_874766:
goto tmp_874765;
tmp_874765:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_874796;
fail_tmp_874763:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_874788 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_874788))
field_imm = inv_maskmask(8, tmp_874788);
else goto fail_tmp_874787;
}
/* commit */
{
tmp_731075 = genfunc_tmp_874708();
goto next_tmp_874790;
next_tmp_874790:
goto tmp_874789;
tmp_874789:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_874796;
fail_tmp_874787:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_874708();
goto next_tmp_874794;
next_tmp_874794:
goto tmp_874793;
tmp_874793:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_874796:
return tmp_731142;
}
reg_t genfunc_tmp_874761 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_874730 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_874730 >> 8) == 0)
field_imm = tmp_874730;
else goto fail_tmp_874729;
}
/* commit */
{
tmp_731858 = genfunc_tmp_874708();
goto next_tmp_874732;
next_tmp_874732:
goto tmp_874731;
tmp_874731:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_874760;
fail_tmp_874729:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_874752 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_874752))
field_imm = inv_maskmask(8, tmp_874752);
else goto fail_tmp_874751;
}
/* commit */
{
tmp_731075 = genfunc_tmp_874708();
goto next_tmp_874754;
next_tmp_874754:
goto tmp_874753;
tmp_874753:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_874760;
fail_tmp_874751:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_874708();
goto next_tmp_874758;
next_tmp_874758:
goto tmp_874757;
tmp_874757:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_874760:
return tmp_731862;
}
reg_t genfunc_tmp_874708 (void) {
reg_t tmp_731876;
/* ADDQ_IMM */
{
word_5 tmp_731893;
word_5 field_rc;
word_5 tmp_731894;
word_5 field_ra;
word_64 tmp_731896;
word_8 field_imm;
tmp_731896 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_874693 = tmp_731896;
if ((tmp_874693 >> 8) == 0)
field_imm = tmp_874693;
else goto fail_tmp_874692;
}
/* commit */
tmp_731894 = ref_gpr_reg_for_reading(0 + rm);
tmp_731893 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731893;
field_ra = tmp_731894;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731894);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874707;
fail_tmp_874692:
/* LDA */
{
word_5 tmp_731397;
word_5 field_ra;
word_5 tmp_731398;
word_5 field_rb;
word_64 tmp_731400;
word_16 field_memory_disp;
tmp_731400 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_874701 = tmp_731400;
if ((tmp_874701 >> 16) == 0xFFFFFFFFFFFF || (tmp_874701 >> 16) == 0)
field_memory_disp = (tmp_874701 & 0xFFFF);
else goto fail_tmp_874700;
}
/* commit */
tmp_731398 = ref_gpr_reg_for_reading(0 + rm);
tmp_731397 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731397;
field_rb = tmp_731398;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731398);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874707;
fail_tmp_874700:
/* LDAH */
{
word_5 tmp_731393;
word_5 field_ra;
word_5 tmp_731394;
word_5 field_rb;
word_64 tmp_731396;
word_16 field_memory_disp;
tmp_731396 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_874705 = tmp_731396;
if ((tmp_874705 & 0xFFFF) == 0)
{
word_64 tmp_874706 = (tmp_874705 >> 16);
if ((tmp_874706 >> 16) == 0xFFFFFFFFFFFF || (tmp_874706 >> 16) == 0)
field_memory_disp = (tmp_874706 & 0xFFFF);
else goto fail_tmp_874704;
}
else goto fail_tmp_874704;
}
/* commit */
tmp_731394 = ref_gpr_reg_for_reading(0 + rm);
tmp_731393 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731393;
field_rb = tmp_731394;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731394);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874707;
fail_tmp_874704:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731900 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731900, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_874707:
return tmp_731876;
}
void genfunc_tmp_874662 (void) {
/* STL */
{
word_5 field_rb;
word_64 tmp_731143;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731143 = ((word_64)disp32);
if (0 != imm32) goto fail_tmp_874656;
field_rb = 31;
{
word_64 tmp_874657 = tmp_731143;
if ((tmp_874657 >> 16) == 0xFFFFFFFFFFFF || (tmp_874657 >> 16) == 0)
field_memory_disp = (tmp_874657 & 0xFFFF);
else goto fail_tmp_874656;
}
field_ra = 31;
/* commit */
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_874661;
fail_tmp_874656:
/* STS */
{
word_5 field_rb;
word_64 tmp_731133;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731133 = ((word_64)disp32);
if (0 != imm32) goto fail_tmp_874659;
field_rb = 31;
{
word_64 tmp_874660 = tmp_731133;
if ((tmp_874660 >> 16) == 0xFFFFFFFFFFFF || (tmp_874660 >> 16) == 0)
field_memory_disp = (tmp_874660 & 0xFFFF);
else goto fail_tmp_874659;
}
field_fa = 31;
/* commit */
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
/* can fail: T   num insns: 1 */
}
goto done_tmp_874661;
fail_tmp_874659:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_874653;
field_memory_disp = 0;
field_ra = 31;
/* commit */
tmp_731142 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731142, ((word_64)disp32));
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 2 */
}
goto done_tmp_874661;
fail_tmp_874653:
/* STL */
{
word_5 field_rb;
word_64 tmp_731143;
word_16 field_memory_disp;
word_5 tmp_731145;
word_5 field_ra;
tmp_731143 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_874655 = tmp_731143;
if ((tmp_874655 >> 16) == 0xFFFFFFFFFFFF || (tmp_874655 >> 16) == 0)
field_memory_disp = (tmp_874655 & 0xFFFF);
else goto fail_tmp_874654;
}
/* commit */
tmp_731145 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731145, imm32);
field_ra = tmp_731145;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731145);
/* can fail: T   num insns: 2 */
}
goto done_tmp_874661;
fail_tmp_874654:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_874658;
field_memory_disp = 0;
field_fa = 31;
/* commit */
tmp_731132 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731132, ((word_64)disp32));
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 2 */
}
goto done_tmp_874661;
fail_tmp_874658:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
tmp_731142 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731142, ((word_64)disp32));
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 3 */
}
done_tmp_874661:
}
void genfunc_tmp_874648 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_874639;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_874637();
goto next_tmp_874641;
next_tmp_874641:
goto tmp_874640;
tmp_874640:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 5 */
}
goto done_tmp_874647;
fail_tmp_874639:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_874643;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_874637();
goto next_tmp_874645;
next_tmp_874645:
goto tmp_874644;
tmp_874644:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 5 */
}
goto done_tmp_874647;
fail_tmp_874643:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_874637();
goto next_tmp_874507;
next_tmp_874507:
goto tmp_874506;
tmp_874506:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_874647:
}
reg_t genfunc_tmp_874637 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_874604 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_874604 >> 8) == 0)
field_imm = tmp_874604;
else goto fail_tmp_874603;
}
/* commit */
{
tmp_731858 = genfunc_tmp_874548();
goto next_tmp_874606;
next_tmp_874606:
goto tmp_874605;
tmp_874605:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_874636;
fail_tmp_874603:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_874628 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_874628))
field_imm = inv_maskmask(8, tmp_874628);
else goto fail_tmp_874627;
}
/* commit */
{
tmp_731075 = genfunc_tmp_874548();
goto next_tmp_874630;
next_tmp_874630:
goto tmp_874629;
tmp_874629:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_874636;
fail_tmp_874627:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_874548();
goto next_tmp_874634;
next_tmp_874634:
goto tmp_874633;
tmp_874633:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_874636:
return tmp_731142;
}
reg_t genfunc_tmp_874601 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_874570 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_874570 >> 8) == 0)
field_imm = tmp_874570;
else goto fail_tmp_874569;
}
/* commit */
{
tmp_731858 = genfunc_tmp_874548();
goto next_tmp_874572;
next_tmp_874572:
goto tmp_874571;
tmp_874571:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_874600;
fail_tmp_874569:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_874592 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_874592))
field_imm = inv_maskmask(8, tmp_874592);
else goto fail_tmp_874591;
}
/* commit */
{
tmp_731075 = genfunc_tmp_874548();
goto next_tmp_874594;
next_tmp_874594:
goto tmp_874593;
tmp_874593:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_874600;
fail_tmp_874591:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_874548();
goto next_tmp_874598;
next_tmp_874598:
goto tmp_874597;
tmp_874597:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_874600:
return tmp_731862;
}
reg_t genfunc_tmp_874548 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_874539;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_874153();
goto next_tmp_874541;
next_tmp_874541:
goto tmp_874540;
tmp_874540:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_874547;
fail_tmp_874539:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_874543;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_874153();
goto next_tmp_874545;
next_tmp_874545:
goto tmp_874544;
tmp_874544:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_874547;
fail_tmp_874543:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_874153();
goto next_tmp_874523;
next_tmp_874523:
goto tmp_874522;
tmp_874522:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_874547:
return tmp_731876;
}
void genfunc_tmp_874501 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_874492;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_874490();
goto next_tmp_874494;
next_tmp_874494:
goto tmp_874493;
tmp_874493:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 4 */
}
goto done_tmp_874500;
fail_tmp_874492:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_874496;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_874490();
goto next_tmp_874498;
next_tmp_874498:
goto tmp_874497;
tmp_874497:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 4 */
}
goto done_tmp_874500;
fail_tmp_874496:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_874490();
goto next_tmp_874369;
next_tmp_874369:
goto tmp_874368;
tmp_874368:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_874500:
}
reg_t genfunc_tmp_874490 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_874457 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_874457 >> 8) == 0)
field_imm = tmp_874457;
else goto fail_tmp_874456;
}
/* commit */
{
tmp_731858 = genfunc_tmp_874401();
goto next_tmp_874459;
next_tmp_874459:
goto tmp_874458;
tmp_874458:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_874489;
fail_tmp_874456:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_874481 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_874481))
field_imm = inv_maskmask(8, tmp_874481);
else goto fail_tmp_874480;
}
/* commit */
{
tmp_731075 = genfunc_tmp_874401();
goto next_tmp_874483;
next_tmp_874483:
goto tmp_874482;
tmp_874482:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_874489;
fail_tmp_874480:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_874401();
goto next_tmp_874487;
next_tmp_874487:
goto tmp_874486;
tmp_874486:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_874489:
return tmp_731142;
}
reg_t genfunc_tmp_874454 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_874423 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_874423 >> 8) == 0)
field_imm = tmp_874423;
else goto fail_tmp_874422;
}
/* commit */
{
tmp_731858 = genfunc_tmp_874401();
goto next_tmp_874425;
next_tmp_874425:
goto tmp_874424;
tmp_874424:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_874453;
fail_tmp_874422:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_874445 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_874445))
field_imm = inv_maskmask(8, tmp_874445);
else goto fail_tmp_874444;
}
/* commit */
{
tmp_731075 = genfunc_tmp_874401();
goto next_tmp_874447;
next_tmp_874447:
goto tmp_874446;
tmp_874446:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_874453;
fail_tmp_874444:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_874401();
goto next_tmp_874451;
next_tmp_874451:
goto tmp_874450;
tmp_874450:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_874453:
return tmp_731862;
}
reg_t genfunc_tmp_874401 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_874398;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + index);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874400;
fail_tmp_874398:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_874399;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + index);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874400;
fail_tmp_874399:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_874400:
return tmp_731876;
}
void genfunc_tmp_874363 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_874354;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_874352();
goto next_tmp_874356;
next_tmp_874356:
goto tmp_874355;
tmp_874355:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 2 */
}
goto done_tmp_874362;
fail_tmp_874354:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_874358;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_874352();
goto next_tmp_874360;
next_tmp_874360:
goto tmp_874359;
tmp_874359:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 2 */
}
goto done_tmp_874362;
fail_tmp_874358:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_874352();
goto next_tmp_874276;
next_tmp_874276:
goto tmp_874275;
tmp_874275:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 3 */
}
done_tmp_874362:
}
reg_t genfunc_tmp_874352 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_874328 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_874328 >> 8) == 0)
field_imm = tmp_874328;
else goto fail_tmp_874327;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + base);
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874351;
fail_tmp_874327:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_874349 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_874349))
field_imm = inv_maskmask(8, tmp_874349);
else goto fail_tmp_874348;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + base);
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874351;
fail_tmp_874348:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + base);
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_874351:
return tmp_731142;
}
reg_t genfunc_tmp_874325 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_874303 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_874303 >> 8) == 0)
field_imm = tmp_874303;
else goto fail_tmp_874302;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + base);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874324;
fail_tmp_874302:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_874322 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_874322))
field_imm = inv_maskmask(8, tmp_874322);
else goto fail_tmp_874321;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + base);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874324;
fail_tmp_874321:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + base);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_874324:
return tmp_731862;
}
void genfunc_tmp_874270 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_874261;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_874259();
goto next_tmp_874263;
next_tmp_874263:
goto tmp_874262;
tmp_874262:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 4 */
}
goto done_tmp_874269;
fail_tmp_874261:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_874265;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_874259();
goto next_tmp_874267;
next_tmp_874267:
goto tmp_874266;
tmp_874266:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 4 */
}
goto done_tmp_874269;
fail_tmp_874265:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_874259();
goto next_tmp_874105;
next_tmp_874105:
goto tmp_874104;
tmp_874104:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_874269:
}
reg_t genfunc_tmp_874259 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_874226 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_874226 >> 8) == 0)
field_imm = tmp_874226;
else goto fail_tmp_874225;
}
/* commit */
{
tmp_731858 = genfunc_tmp_874170();
goto next_tmp_874228;
next_tmp_874228:
goto tmp_874227;
tmp_874227:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_874258;
fail_tmp_874225:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_874250 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_874250))
field_imm = inv_maskmask(8, tmp_874250);
else goto fail_tmp_874249;
}
/* commit */
{
tmp_731075 = genfunc_tmp_874170();
goto next_tmp_874252;
next_tmp_874252:
goto tmp_874251;
tmp_874251:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_874258;
fail_tmp_874249:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_874170();
goto next_tmp_874256;
next_tmp_874256:
goto tmp_874255;
tmp_874255:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_874258:
return tmp_731142;
}
reg_t genfunc_tmp_874223 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_874192 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_874192 >> 8) == 0)
field_imm = tmp_874192;
else goto fail_tmp_874191;
}
/* commit */
{
tmp_731858 = genfunc_tmp_874170();
goto next_tmp_874194;
next_tmp_874194:
goto tmp_874193;
tmp_874193:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_874222;
fail_tmp_874191:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_874214 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_874214))
field_imm = inv_maskmask(8, tmp_874214);
else goto fail_tmp_874213;
}
/* commit */
{
tmp_731075 = genfunc_tmp_874170();
goto next_tmp_874216;
next_tmp_874216:
goto tmp_874215;
tmp_874215:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_874222;
fail_tmp_874213:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_874170();
goto next_tmp_874220;
next_tmp_874220:
goto tmp_874219;
tmp_874219:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_874222:
return tmp_731862;
}
reg_t genfunc_tmp_874170 (void) {
reg_t tmp_731876;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + base);
{
tmp_731900 = genfunc_tmp_874153();
goto next_tmp_874121;
next_tmp_874121:
goto tmp_874120;
tmp_874120:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_874169:
return tmp_731876;
}
reg_t genfunc_tmp_874153 (void) {
reg_t tmp_731900;
/* EXTQH */
{
word_5 tmp_731618;
word_5 field_rc;
word_5 tmp_731619;
word_5 field_ra;
word_5 field_rb;
if (64 != ((word_64)scale)) goto fail_tmp_874134;
field_rb = 31;
/* commit */
tmp_731619 = ref_gpr_reg_for_reading(0 + index);
tmp_731618 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731618;
field_ra = tmp_731619;
emit(COMPOSE_EXTQH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731619);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874152;
fail_tmp_874134:
/* EXTQH_IMM */
{
word_5 tmp_731614;
word_5 field_rc;
word_5 tmp_731615;
word_5 field_ra;
word_64 tmp_731617;
word_8 field_imm;
tmp_731617 = ((word_64)scale);
{
word_64 tmp_874136 = ((64 - tmp_731617) & 0xFFFFFFFFFFFFFFFF);
if (tmp_874136 % 8 == 0)
{
word_64 tmp_874137 = (tmp_874136 / 8);
if ((tmp_874137 & 7) == tmp_874137)
{
word_64 tmp_874138 = tmp_874137;
if ((tmp_874138 >> 8) == 0)
field_imm = tmp_874138;
else goto fail_tmp_874135;
}
else goto fail_tmp_874135;
}
else goto fail_tmp_874135;
}
/* commit */
tmp_731615 = ref_gpr_reg_for_reading(0 + index);
tmp_731614 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731614;
field_ra = tmp_731615;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731615);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874152;
fail_tmp_874135:
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 tmp_731241;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_874144;
field_rb = 31;
/* commit */
tmp_731241 = ref_gpr_reg_for_reading(0 + index);
tmp_731240 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_ra = tmp_731241;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731241);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874152;
fail_tmp_874144:
/* S4ADDQ_IMM */
{
word_5 tmp_731236;
word_5 field_rc;
word_5 tmp_731237;
word_5 field_ra;
word_64 tmp_731239;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_874145;
tmp_731239 = 0;
field_imm = 0;
/* commit */
tmp_731237 = ref_gpr_reg_for_reading(0 + index);
tmp_731236 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731236;
field_ra = tmp_731237;
emit(COMPOSE_S4ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731237);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874152;
fail_tmp_874145:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 tmp_731209;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_874147;
field_rb = 31;
/* commit */
tmp_731209 = ref_gpr_reg_for_reading(0 + index);
tmp_731208 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_ra = tmp_731209;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731209);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874152;
fail_tmp_874147:
/* S8ADDQ_IMM */
{
word_5 tmp_731204;
word_5 field_rc;
word_5 tmp_731205;
word_5 field_ra;
word_64 tmp_731207;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_874148;
tmp_731207 = 0;
field_imm = 0;
/* commit */
tmp_731205 = ref_gpr_reg_for_reading(0 + index);
tmp_731204 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731204;
field_ra = tmp_731205;
emit(COMPOSE_S8ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731205);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874152;
fail_tmp_874148:
/* SLL */
{
word_5 tmp_731176;
word_5 field_rc;
word_5 tmp_731177;
word_5 field_ra;
word_5 field_rb;
if (0 != ((word_64)scale)) goto fail_tmp_874149;
field_rb = 31;
/* commit */
tmp_731177 = ref_gpr_reg_for_reading(0 + index);
tmp_731176 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731176;
field_ra = tmp_731177;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731177);
/* can fail: T   num insns: 1 */
}
goto done_tmp_874152;
fail_tmp_874149:
/* SLL_IMM */
{
word_5 tmp_731172;
word_5 field_rc;
word_5 tmp_731173;
word_5 field_ra;
word_64 tmp_731175;
word_8 field_imm;
tmp_731175 = ((word_64)scale);
field_imm = tmp_731175;
/* commit */
tmp_731173 = ref_gpr_reg_for_reading(0 + index);
tmp_731172 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731172;
field_ra = tmp_731173;
emit(COMPOSE_SLL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731173);
/* can fail: NIL   num insns: 1 */
}
done_tmp_874152:
return tmp_731900;
}
void genfunc_tmp_874099 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_874090;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_874088();
goto next_tmp_874092;
next_tmp_874092:
goto tmp_874091;
tmp_874091:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 3 */
}
goto done_tmp_874098;
fail_tmp_874090:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_874094;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_874088();
goto next_tmp_874096;
next_tmp_874096:
goto tmp_874095;
tmp_874095:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 3 */
}
goto done_tmp_874098;
fail_tmp_874094:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_874088();
goto next_tmp_873969;
next_tmp_873969:
goto tmp_873968;
tmp_873968:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_874098:
}
reg_t genfunc_tmp_874088 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_874055 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_874055 >> 8) == 0)
field_imm = tmp_874055;
else goto fail_tmp_874054;
}
/* commit */
{
tmp_731858 = genfunc_tmp_873999();
goto next_tmp_874057;
next_tmp_874057:
goto tmp_874056;
tmp_874056:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_874087;
fail_tmp_874054:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_874079 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_874079))
field_imm = inv_maskmask(8, tmp_874079);
else goto fail_tmp_874078;
}
/* commit */
{
tmp_731075 = genfunc_tmp_873999();
goto next_tmp_874081;
next_tmp_874081:
goto tmp_874080;
tmp_874080:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_874087;
fail_tmp_874078:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_873999();
goto next_tmp_874085;
next_tmp_874085:
goto tmp_874084;
tmp_874084:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_874087:
return tmp_731142;
}
reg_t genfunc_tmp_874052 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_874021 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_874021 >> 8) == 0)
field_imm = tmp_874021;
else goto fail_tmp_874020;
}
/* commit */
{
tmp_731858 = genfunc_tmp_873999();
goto next_tmp_874023;
next_tmp_874023:
goto tmp_874022;
tmp_874022:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_874051;
fail_tmp_874020:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_874043 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_874043))
field_imm = inv_maskmask(8, tmp_874043);
else goto fail_tmp_874042;
}
/* commit */
{
tmp_731075 = genfunc_tmp_873999();
goto next_tmp_874045;
next_tmp_874045:
goto tmp_874044;
tmp_874044:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_874051;
fail_tmp_874042:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_873999();
goto next_tmp_874049;
next_tmp_874049:
goto tmp_874048;
tmp_874048:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_874051:
return tmp_731862;
}
reg_t genfunc_tmp_873999 (void) {
reg_t tmp_731876;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + base);
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_873998:
return tmp_731876;
}
void genfunc_tmp_873963 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 field_ra;
tmp_731144 = 0;
if (0 != imm32) goto fail_tmp_873954;
field_memory_disp = 0;
field_ra = 31;
/* commit */
{
tmp_731142 = genfunc_tmp_873952();
goto next_tmp_873956;
next_tmp_873956:
goto tmp_873955;
tmp_873955:
}
field_rb = tmp_731142;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731142);
/* can fail: T   num insns: 2 */
}
goto done_tmp_873962;
fail_tmp_873954:
/* STS */
{
word_5 tmp_731132;
word_5 field_rb;
word_64 tmp_731134;
word_16 field_memory_disp;
word_5 field_fa;
tmp_731134 = 0;
if (0 != imm32) goto fail_tmp_873958;
field_memory_disp = 0;
field_fa = 31;
/* commit */
{
tmp_731132 = genfunc_tmp_873952();
goto next_tmp_873960;
next_tmp_873960:
goto tmp_873959;
tmp_873959:
}
field_rb = tmp_731132;
emit(COMPOSE_STS(field_fa, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731132);
/* can fail: T   num insns: 2 */
}
goto done_tmp_873962;
fail_tmp_873958:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_873952();
goto next_tmp_873876;
next_tmp_873876:
goto tmp_873875;
tmp_873875:
}
tmp_731146 = ref_gpr_reg_for_writing(-1);
emit_load_integer_32(tmp_731146, imm32);
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 3 */
}
done_tmp_873962:
}
reg_t genfunc_tmp_873952 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_873928 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_873928 >> 8) == 0)
field_imm = tmp_873928;
else goto fail_tmp_873927;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + rm);
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_873951;
fail_tmp_873927:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_873949 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_873949))
field_imm = inv_maskmask(8, tmp_873949);
else goto fail_tmp_873948;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + rm);
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_873951;
fail_tmp_873948:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + rm);
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_873951:
return tmp_731142;
}
reg_t genfunc_tmp_873925 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_873903 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_873903 >> 8) == 0)
field_imm = tmp_873903;
else goto fail_tmp_873902;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + rm);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_873924;
fail_tmp_873902:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_873922 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_873922))
field_imm = inv_maskmask(8, tmp_873922);
else goto fail_tmp_873921;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + rm);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_873924;
fail_tmp_873921:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + rm);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_873924:
return tmp_731862;
}
