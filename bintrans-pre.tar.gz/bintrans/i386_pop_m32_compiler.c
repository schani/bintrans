#include <assert.h>
#include "bintrans.h"
#include "compiler.h"
#include "alpha_composer.h"
static word_8 mod, reg, rm, scale, index, base, disp8, opcode_reg, imm8;
static word_16 imm16;
static word_32 pc, disp32, imm32;
void compile_pop_m32_insn (word_32 _pc, word_8 _mod, word_8 _reg, word_8 _rm, word_8 _scale, word_8 _index, word_8 _base, word_8 _disp8, word_8 _opcode_reg, word_8 _imm8, word_16 _imm16, word_32 _disp32, word_32 _imm32, word_32 to_be_killed) {
void **env = 0;
pc = _pc; mod = _mod; reg = _reg; rm = _rm; scale = _scale; index = _index; base = _base; disp8 = _disp8;
opcode_reg = _opcode_reg; imm8 = _imm8; imm16 = _imm16; disp32 = _disp32; imm32 = _imm32;
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_894393();
goto next_tmp_894074;
next_tmp_894074:
goto finish_tmp_894073;
finish_tmp_894073:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_894524();
goto next_tmp_894396;
next_tmp_894396:
goto finish_tmp_894395;
finish_tmp_894395:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_894690();
goto next_tmp_894527;
next_tmp_894527:
goto finish_tmp_894526;
finish_tmp_894526:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_894778();
goto next_tmp_894693;
next_tmp_894693:
goto finish_tmp_894692;
finish_tmp_894692:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_894911();
goto next_tmp_894781;
next_tmp_894781:
goto finish_tmp_894780;
finish_tmp_894780:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_895053();
goto next_tmp_894914;
next_tmp_894914:
goto finish_tmp_894913;
finish_tmp_894913:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_895067();
goto next_tmp_895056;
next_tmp_895056:
goto finish_tmp_895055;
finish_tmp_895055:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 0; })&& ({ word_3 tmp = rm; 0 || tmp == 5; }))
{
genfunc_tmp_895067();
goto next_tmp_895070;
next_tmp_895070:
goto finish_tmp_895069;
finish_tmp_895069:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_895208();
goto next_tmp_895073;
next_tmp_895073:
goto finish_tmp_895072;
finish_tmp_895072:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_895350();
goto next_tmp_895211;
next_tmp_895211:
goto finish_tmp_895210;
finish_tmp_895210:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_895492();
goto next_tmp_895353;
next_tmp_895353:
goto finish_tmp_895352;
finish_tmp_895352:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_895625();
goto next_tmp_895495;
next_tmp_895495:
goto finish_tmp_895494;
finish_tmp_895494:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_895786();
goto next_tmp_895628;
next_tmp_895628:
goto finish_tmp_895627;
finish_tmp_895627:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_895950();
goto next_tmp_895789;
next_tmp_895789:
goto finish_tmp_895788;
finish_tmp_895788:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 1; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_896083();
goto next_tmp_895953;
next_tmp_895953:
goto finish_tmp_895952;
finish_tmp_895952:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; }))
{
genfunc_tmp_896221();
goto next_tmp_896086;
next_tmp_896086:
goto finish_tmp_896085;
finish_tmp_896085:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_896363();
goto next_tmp_896224;
next_tmp_896224:
goto finish_tmp_896223;
finish_tmp_896223:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_896505();
goto next_tmp_896366;
next_tmp_896366:
goto finish_tmp_896365;
finish_tmp_896365:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 4 || tmp == 6 || tmp == 7; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_896638();
goto next_tmp_896508;
next_tmp_896508:
goto finish_tmp_896507;
finish_tmp_896507:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (scale == 0))
{
genfunc_tmp_896780();
goto next_tmp_896641;
next_tmp_896641:
goto finish_tmp_896640;
finish_tmp_896640:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 0 || tmp == 1 || tmp == 2 || tmp == 3 || tmp == 5 || tmp == 6 || tmp == 7; })&& (!(scale == 0)))
{
genfunc_tmp_896922();
goto next_tmp_896783;
next_tmp_896783:
goto finish_tmp_896782;
finish_tmp_896782:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 0 || tmp == 1 || tmp == 2; })&& ({ word_2 tmp = mod; 0 || tmp == 2; })&& ({ word_3 tmp = rm; 0 || tmp == 4; })&& ({ word_3 tmp = base; 0 || tmp == 5; })&& ({ word_2 tmp = mod; 0 || tmp == 1 || tmp == 2 || tmp == 3; })&& ({ word_3 tmp = index; 0 || tmp == 4; }))
{
genfunc_tmp_897055();
goto next_tmp_896925;
next_tmp_896925:
goto finish_tmp_896924;
finish_tmp_896924:
}
if (1 && ({ word_2 tmp = mod; 0 || tmp == 3; }))
{
genfunc_tmp_897112();
goto next_tmp_897058;
next_tmp_897058:
goto finish_tmp_897057;
finish_tmp_897057:
}
if (1 )
{
genfunc_tmp_897239();
goto next_tmp_897115;
next_tmp_897115:
goto finish_tmp_897114;
finish_tmp_897114:
}
}
void genfunc_tmp_897239 (void) {
/* ADDL_IMM */
{
word_5 tmp_731901;
word_5 field_rc;
word_5 tmp_731902;
word_5 field_ra;
word_32 tmp_731904;
word_8 field_imm;
tmp_731904 = 4;
field_imm = 4;
/* commit */
tmp_731902 = ref_gpr_reg_for_reading(0 + 4);
tmp_731901 = ref_gpr_reg_for_writing(0 + 4);
field_rc = tmp_731901;
field_ra = tmp_731902;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731901);
unref_gpr_reg(tmp_731902);
/* can fail: NIL   num insns: 1 */
}
done_tmp_897238:
}
reg_t genfunc_tmp_897190 (void) {
reg_t tmp_731906;
/* ADDL_IMM */
{
word_5 tmp_731901;
word_5 field_rc;
word_5 tmp_731902;
word_5 field_ra;
word_32 tmp_731904;
word_8 field_imm;
tmp_731904 = 4;
field_imm = 4;
/* commit */
tmp_731902 = ref_gpr_reg_for_reading(0 + 4);
tmp_731901 = tmp_731906 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731901;
field_ra = tmp_731902;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731902);
/* can fail: NIL   num insns: 1 */
}
done_tmp_897189:
return tmp_731906;
}
reg_t genfunc_tmp_897159 (void) {
reg_t tmp_731898;
/* ADDL_IMM */
{
word_5 tmp_731901;
word_5 field_rc;
word_5 tmp_731902;
word_5 field_ra;
word_32 tmp_731904;
word_8 field_imm;
tmp_731904 = 4;
field_imm = 4;
/* commit */
tmp_731902 = ref_gpr_reg_for_reading(0 + 4);
tmp_731901 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731901;
field_ra = tmp_731902;
emit(COMPOSE_ADDL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731902);
/* can fail: NIL   num insns: 1 */
}
done_tmp_897158:
return tmp_731898;
}
void genfunc_tmp_897112 (void) {
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_894270();
goto next_tmp_897109;
next_tmp_897109:
goto tmp_897108;
tmp_897108:
}
tmp_731381 = ref_gpr_reg_for_writing(0 + rm);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731381);
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_897111:
}
void genfunc_tmp_897055 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_897049();
goto next_tmp_896928;
next_tmp_896928:
goto tmp_896927;
tmp_896927:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_897052;
next_tmp_897052:
goto tmp_897051;
tmp_897051:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_897054:
}
reg_t genfunc_tmp_897049 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_897016 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_897016 >> 8) == 0)
field_imm = tmp_897016;
else goto fail_tmp_897015;
}
/* commit */
{
tmp_731858 = genfunc_tmp_896960();
goto next_tmp_897018;
next_tmp_897018:
goto tmp_897017;
tmp_897017:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_897048;
fail_tmp_897015:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_897040 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_897040))
field_imm = inv_maskmask(8, tmp_897040);
else goto fail_tmp_897039;
}
/* commit */
{
tmp_731075 = genfunc_tmp_896960();
goto next_tmp_897042;
next_tmp_897042:
goto tmp_897041;
tmp_897041:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_897048;
fail_tmp_897039:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_896960();
goto next_tmp_897046;
next_tmp_897046:
goto tmp_897045;
tmp_897045:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_897048:
return tmp_731142;
}
reg_t genfunc_tmp_897013 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_896982 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_896982 >> 8) == 0)
field_imm = tmp_896982;
else goto fail_tmp_896981;
}
/* commit */
{
tmp_731858 = genfunc_tmp_896960();
goto next_tmp_896984;
next_tmp_896984:
goto tmp_896983;
tmp_896983:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_897012;
fail_tmp_896981:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_897004 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_897004))
field_imm = inv_maskmask(8, tmp_897004);
else goto fail_tmp_897003;
}
/* commit */
{
tmp_731075 = genfunc_tmp_896960();
goto next_tmp_897006;
next_tmp_897006:
goto tmp_897005;
tmp_897005:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_897012;
fail_tmp_897003:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_896960();
goto next_tmp_897010;
next_tmp_897010:
goto tmp_897009;
tmp_897009:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_897012:
return tmp_731862;
}
reg_t genfunc_tmp_896960 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_896957;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + 5);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_896959;
fail_tmp_896957:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_896958;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + 5);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_896959;
fail_tmp_896958:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + 5);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_896959:
return tmp_731876;
}
void genfunc_tmp_896922 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_896916();
goto next_tmp_896786;
next_tmp_896786:
goto tmp_896785;
tmp_896785:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_896919;
next_tmp_896919:
goto tmp_896918;
tmp_896918:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_896921:
}
reg_t genfunc_tmp_896916 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_896883 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_896883 >> 8) == 0)
field_imm = tmp_896883;
else goto fail_tmp_896882;
}
/* commit */
{
tmp_731858 = genfunc_tmp_896827();
goto next_tmp_896885;
next_tmp_896885:
goto tmp_896884;
tmp_896884:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_896915;
fail_tmp_896882:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_896907 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_896907))
field_imm = inv_maskmask(8, tmp_896907);
else goto fail_tmp_896906;
}
/* commit */
{
tmp_731075 = genfunc_tmp_896827();
goto next_tmp_896909;
next_tmp_896909:
goto tmp_896908;
tmp_896908:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_896915;
fail_tmp_896906:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_896827();
goto next_tmp_896913;
next_tmp_896913:
goto tmp_896912;
tmp_896912:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_896915:
return tmp_731142;
}
reg_t genfunc_tmp_896880 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_896849 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_896849 >> 8) == 0)
field_imm = tmp_896849;
else goto fail_tmp_896848;
}
/* commit */
{
tmp_731858 = genfunc_tmp_896827();
goto next_tmp_896851;
next_tmp_896851:
goto tmp_896850;
tmp_896850:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_896879;
fail_tmp_896848:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_896871 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_896871))
field_imm = inv_maskmask(8, tmp_896871);
else goto fail_tmp_896870;
}
/* commit */
{
tmp_731075 = genfunc_tmp_896827();
goto next_tmp_896873;
next_tmp_896873:
goto tmp_896872;
tmp_896872:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_896879;
fail_tmp_896870:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_896827();
goto next_tmp_896877;
next_tmp_896877:
goto tmp_896876;
tmp_896876:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_896879:
return tmp_731862;
}
reg_t genfunc_tmp_896827 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_896818;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_895830();
goto next_tmp_896820;
next_tmp_896820:
goto tmp_896819;
tmp_896819:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896826;
fail_tmp_896818:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_896822;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_895830();
goto next_tmp_896824;
next_tmp_896824:
goto tmp_896823;
tmp_896823:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896826;
fail_tmp_896822:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_895830();
goto next_tmp_896802;
next_tmp_896802:
goto tmp_896801;
tmp_896801:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_896826:
return tmp_731876;
}
void genfunc_tmp_896780 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_896774();
goto next_tmp_896644;
next_tmp_896644:
goto tmp_896643;
tmp_896643:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_896777;
next_tmp_896777:
goto tmp_896776;
tmp_896776:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 7 */
}
done_tmp_896779:
}
reg_t genfunc_tmp_896774 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_896741 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_896741 >> 8) == 0)
field_imm = tmp_896741;
else goto fail_tmp_896740;
}
/* commit */
{
tmp_731858 = genfunc_tmp_896685();
goto next_tmp_896743;
next_tmp_896743:
goto tmp_896742;
tmp_896742:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_896773;
fail_tmp_896740:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_896765 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_896765))
field_imm = inv_maskmask(8, tmp_896765);
else goto fail_tmp_896764;
}
/* commit */
{
tmp_731075 = genfunc_tmp_896685();
goto next_tmp_896767;
next_tmp_896767:
goto tmp_896766;
tmp_896766:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_896773;
fail_tmp_896764:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_896685();
goto next_tmp_896771;
next_tmp_896771:
goto tmp_896770;
tmp_896770:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_896773:
return tmp_731142;
}
reg_t genfunc_tmp_896738 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_896707 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_896707 >> 8) == 0)
field_imm = tmp_896707;
else goto fail_tmp_896706;
}
/* commit */
{
tmp_731858 = genfunc_tmp_896685();
goto next_tmp_896709;
next_tmp_896709:
goto tmp_896708;
tmp_896708:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_896737;
fail_tmp_896706:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_896729 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_896729))
field_imm = inv_maskmask(8, tmp_896729);
else goto fail_tmp_896728;
}
/* commit */
{
tmp_731075 = genfunc_tmp_896685();
goto next_tmp_896731;
next_tmp_896731:
goto tmp_896730;
tmp_896730:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_896737;
fail_tmp_896728:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_896685();
goto next_tmp_896735;
next_tmp_896735:
goto tmp_896734;
tmp_896734:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_896737:
return tmp_731862;
}
reg_t genfunc_tmp_896685 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_896676;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_895666();
goto next_tmp_896678;
next_tmp_896678:
goto tmp_896677;
tmp_896677:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_896684;
fail_tmp_896676:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_896680;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_895666();
goto next_tmp_896682;
next_tmp_896682:
goto tmp_896681;
tmp_896681:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_896684;
fail_tmp_896680:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_895666();
goto next_tmp_896660;
next_tmp_896660:
goto tmp_896659;
tmp_896659:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_896684:
return tmp_731876;
}
void genfunc_tmp_896638 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_896632();
goto next_tmp_896511;
next_tmp_896511:
goto tmp_896510;
tmp_896510:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_896635;
next_tmp_896635:
goto tmp_896634;
tmp_896634:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_896637:
}
reg_t genfunc_tmp_896632 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_896599 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_896599 >> 8) == 0)
field_imm = tmp_896599;
else goto fail_tmp_896598;
}
/* commit */
{
tmp_731858 = genfunc_tmp_896543();
goto next_tmp_896601;
next_tmp_896601:
goto tmp_896600;
tmp_896600:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896631;
fail_tmp_896598:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_896623 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_896623))
field_imm = inv_maskmask(8, tmp_896623);
else goto fail_tmp_896622;
}
/* commit */
{
tmp_731075 = genfunc_tmp_896543();
goto next_tmp_896625;
next_tmp_896625:
goto tmp_896624;
tmp_896624:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896631;
fail_tmp_896622:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_896543();
goto next_tmp_896629;
next_tmp_896629:
goto tmp_896628;
tmp_896628:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_896631:
return tmp_731142;
}
reg_t genfunc_tmp_896596 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_896565 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_896565 >> 8) == 0)
field_imm = tmp_896565;
else goto fail_tmp_896564;
}
/* commit */
{
tmp_731858 = genfunc_tmp_896543();
goto next_tmp_896567;
next_tmp_896567:
goto tmp_896566;
tmp_896566:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896595;
fail_tmp_896564:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_896587 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_896587))
field_imm = inv_maskmask(8, tmp_896587);
else goto fail_tmp_896586;
}
/* commit */
{
tmp_731075 = genfunc_tmp_896543();
goto next_tmp_896589;
next_tmp_896589:
goto tmp_896588;
tmp_896588:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896595;
fail_tmp_896586:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_896543();
goto next_tmp_896593;
next_tmp_896593:
goto tmp_896592;
tmp_896592:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_896595:
return tmp_731862;
}
reg_t genfunc_tmp_896543 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_896540;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + base);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_896542;
fail_tmp_896540:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_896541;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + base);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_896542;
fail_tmp_896541:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + base);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_896542:
return tmp_731876;
}
void genfunc_tmp_896505 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_896499();
goto next_tmp_896369;
next_tmp_896369:
goto tmp_896368;
tmp_896368:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_896502;
next_tmp_896502:
goto tmp_896501;
tmp_896501:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_896504:
}
reg_t genfunc_tmp_896499 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_896466 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_896466 >> 8) == 0)
field_imm = tmp_896466;
else goto fail_tmp_896465;
}
/* commit */
{
tmp_731858 = genfunc_tmp_896410();
goto next_tmp_896468;
next_tmp_896468:
goto tmp_896467;
tmp_896467:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_896498;
fail_tmp_896465:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_896490 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_896490))
field_imm = inv_maskmask(8, tmp_896490);
else goto fail_tmp_896489;
}
/* commit */
{
tmp_731075 = genfunc_tmp_896410();
goto next_tmp_896492;
next_tmp_896492:
goto tmp_896491;
tmp_896491:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_896498;
fail_tmp_896489:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_896410();
goto next_tmp_896496;
next_tmp_896496:
goto tmp_896495;
tmp_896495:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_896498:
return tmp_731142;
}
reg_t genfunc_tmp_896463 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_896432 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_896432 >> 8) == 0)
field_imm = tmp_896432;
else goto fail_tmp_896431;
}
/* commit */
{
tmp_731858 = genfunc_tmp_896410();
goto next_tmp_896434;
next_tmp_896434:
goto tmp_896433;
tmp_896433:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_896462;
fail_tmp_896431:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_896454 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_896454))
field_imm = inv_maskmask(8, tmp_896454);
else goto fail_tmp_896453;
}
/* commit */
{
tmp_731075 = genfunc_tmp_896410();
goto next_tmp_896456;
next_tmp_896456:
goto tmp_896455;
tmp_896455:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_896462;
fail_tmp_896453:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_896410();
goto next_tmp_896460;
next_tmp_896460:
goto tmp_896459;
tmp_896459:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_896462:
return tmp_731862;
}
reg_t genfunc_tmp_896410 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_896401;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_894595();
goto next_tmp_896403;
next_tmp_896403:
goto tmp_896402;
tmp_896402:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896409;
fail_tmp_896401:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_896405;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_894595();
goto next_tmp_896407;
next_tmp_896407:
goto tmp_896406;
tmp_896406:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896409;
fail_tmp_896405:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_894595();
goto next_tmp_896385;
next_tmp_896385:
goto tmp_896384;
tmp_896384:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_896409:
return tmp_731876;
}
void genfunc_tmp_896363 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_896357();
goto next_tmp_896227;
next_tmp_896227:
goto tmp_896226;
tmp_896226:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_896360;
next_tmp_896360:
goto tmp_896359;
tmp_896359:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 7 */
}
done_tmp_896362:
}
reg_t genfunc_tmp_896357 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_896324 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_896324 >> 8) == 0)
field_imm = tmp_896324;
else goto fail_tmp_896323;
}
/* commit */
{
tmp_731858 = genfunc_tmp_896268();
goto next_tmp_896326;
next_tmp_896326:
goto tmp_896325;
tmp_896325:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_896356;
fail_tmp_896323:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_896348 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_896348))
field_imm = inv_maskmask(8, tmp_896348);
else goto fail_tmp_896347;
}
/* commit */
{
tmp_731075 = genfunc_tmp_896268();
goto next_tmp_896350;
next_tmp_896350:
goto tmp_896349;
tmp_896349:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_896356;
fail_tmp_896347:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_896268();
goto next_tmp_896354;
next_tmp_896354:
goto tmp_896353;
tmp_896353:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_896356:
return tmp_731142;
}
reg_t genfunc_tmp_896321 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_896290 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_896290 >> 8) == 0)
field_imm = tmp_896290;
else goto fail_tmp_896289;
}
/* commit */
{
tmp_731858 = genfunc_tmp_896268();
goto next_tmp_896292;
next_tmp_896292:
goto tmp_896291;
tmp_896291:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_896320;
fail_tmp_896289:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_896312 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_896312))
field_imm = inv_maskmask(8, tmp_896312);
else goto fail_tmp_896311;
}
/* commit */
{
tmp_731075 = genfunc_tmp_896268();
goto next_tmp_896314;
next_tmp_896314:
goto tmp_896313;
tmp_896313:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_896320;
fail_tmp_896311:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_896268();
goto next_tmp_896318;
next_tmp_896318:
goto tmp_896317;
tmp_896317:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_896320:
return tmp_731862;
}
reg_t genfunc_tmp_896268 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_896259;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_894429();
goto next_tmp_896261;
next_tmp_896261:
goto tmp_896260;
tmp_896260:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_896267;
fail_tmp_896259:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_896263;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_894429();
goto next_tmp_896265;
next_tmp_896265:
goto tmp_896264;
tmp_896264:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_896267;
fail_tmp_896263:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_894429();
goto next_tmp_896243;
next_tmp_896243:
goto tmp_896242;
tmp_896242:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_896267:
return tmp_731876;
}
void genfunc_tmp_896221 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_896215();
goto next_tmp_896089;
next_tmp_896089:
goto tmp_896088;
tmp_896088:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_896218;
next_tmp_896218:
goto tmp_896217;
tmp_896217:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_896220:
}
reg_t genfunc_tmp_896215 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_896182 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_896182 >> 8) == 0)
field_imm = tmp_896182;
else goto fail_tmp_896181;
}
/* commit */
{
tmp_731858 = genfunc_tmp_896126();
goto next_tmp_896184;
next_tmp_896184:
goto tmp_896183;
tmp_896183:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896214;
fail_tmp_896181:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_896206 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_896206))
field_imm = inv_maskmask(8, tmp_896206);
else goto fail_tmp_896205;
}
/* commit */
{
tmp_731075 = genfunc_tmp_896126();
goto next_tmp_896208;
next_tmp_896208:
goto tmp_896207;
tmp_896207:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896214;
fail_tmp_896205:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_896126();
goto next_tmp_896212;
next_tmp_896212:
goto tmp_896211;
tmp_896211:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_896214:
return tmp_731142;
}
reg_t genfunc_tmp_896179 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_896148 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_896148 >> 8) == 0)
field_imm = tmp_896148;
else goto fail_tmp_896147;
}
/* commit */
{
tmp_731858 = genfunc_tmp_896126();
goto next_tmp_896150;
next_tmp_896150:
goto tmp_896149;
tmp_896149:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896178;
fail_tmp_896147:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_896170 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_896170))
field_imm = inv_maskmask(8, tmp_896170);
else goto fail_tmp_896169;
}
/* commit */
{
tmp_731075 = genfunc_tmp_896126();
goto next_tmp_896172;
next_tmp_896172:
goto tmp_896171;
tmp_896171:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896178;
fail_tmp_896169:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_896126();
goto next_tmp_896176;
next_tmp_896176:
goto tmp_896175;
tmp_896175:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_896178:
return tmp_731862;
}
reg_t genfunc_tmp_896126 (void) {
reg_t tmp_731876;
/* ADDQ_IMM */
{
word_5 tmp_731893;
word_5 field_rc;
word_5 tmp_731894;
word_5 field_ra;
word_64 tmp_731896;
word_8 field_imm;
tmp_731896 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_896111 = tmp_731896;
if ((tmp_896111 >> 8) == 0)
field_imm = tmp_896111;
else goto fail_tmp_896110;
}
/* commit */
tmp_731894 = ref_gpr_reg_for_reading(0 + rm);
tmp_731893 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731893;
field_ra = tmp_731894;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731894);
/* can fail: T   num insns: 1 */
}
goto done_tmp_896125;
fail_tmp_896110:
/* LDA */
{
word_5 tmp_731397;
word_5 field_ra;
word_5 tmp_731398;
word_5 field_rb;
word_64 tmp_731400;
word_16 field_memory_disp;
tmp_731400 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_896119 = tmp_731400;
if ((tmp_896119 >> 16) == 0xFFFFFFFFFFFF || (tmp_896119 >> 16) == 0)
field_memory_disp = (tmp_896119 & 0xFFFF);
else goto fail_tmp_896118;
}
/* commit */
tmp_731398 = ref_gpr_reg_for_reading(0 + rm);
tmp_731397 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731397;
field_rb = tmp_731398;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731398);
/* can fail: T   num insns: 1 */
}
goto done_tmp_896125;
fail_tmp_896118:
/* LDAH */
{
word_5 tmp_731393;
word_5 field_ra;
word_5 tmp_731394;
word_5 field_rb;
word_64 tmp_731396;
word_16 field_memory_disp;
tmp_731396 = ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32);
{
word_64 tmp_896123 = tmp_731396;
if ((tmp_896123 & 0xFFFF) == 0)
{
word_64 tmp_896124 = (tmp_896123 >> 16);
if ((tmp_896124 >> 16) == 0xFFFFFFFFFFFF || (tmp_896124 >> 16) == 0)
field_memory_disp = (tmp_896124 & 0xFFFF);
else goto fail_tmp_896122;
}
else goto fail_tmp_896122;
}
/* commit */
tmp_731394 = ref_gpr_reg_for_reading(0 + rm);
tmp_731393 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731393;
field_rb = tmp_731394;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731394);
/* can fail: T   num insns: 1 */
}
goto done_tmp_896125;
fail_tmp_896122:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731900 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731900, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_896125:
return tmp_731876;
}
void genfunc_tmp_896083 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_896077();
goto next_tmp_895956;
next_tmp_895956:
goto tmp_895955;
tmp_895955:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_896080;
next_tmp_896080:
goto tmp_896079;
tmp_896079:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_896082:
}
reg_t genfunc_tmp_896077 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_896044 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_896044 >> 8) == 0)
field_imm = tmp_896044;
else goto fail_tmp_896043;
}
/* commit */
{
tmp_731858 = genfunc_tmp_895988();
goto next_tmp_896046;
next_tmp_896046:
goto tmp_896045;
tmp_896045:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896076;
fail_tmp_896043:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_896068 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_896068))
field_imm = inv_maskmask(8, tmp_896068);
else goto fail_tmp_896067;
}
/* commit */
{
tmp_731075 = genfunc_tmp_895988();
goto next_tmp_896070;
next_tmp_896070:
goto tmp_896069;
tmp_896069:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896076;
fail_tmp_896067:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_895988();
goto next_tmp_896074;
next_tmp_896074:
goto tmp_896073;
tmp_896073:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_896076:
return tmp_731142;
}
reg_t genfunc_tmp_896041 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_896010 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_896010 >> 8) == 0)
field_imm = tmp_896010;
else goto fail_tmp_896009;
}
/* commit */
{
tmp_731858 = genfunc_tmp_895988();
goto next_tmp_896012;
next_tmp_896012:
goto tmp_896011;
tmp_896011:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896040;
fail_tmp_896009:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_896032 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_896032))
field_imm = inv_maskmask(8, tmp_896032);
else goto fail_tmp_896031;
}
/* commit */
{
tmp_731075 = genfunc_tmp_895988();
goto next_tmp_896034;
next_tmp_896034:
goto tmp_896033;
tmp_896033:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_896040;
fail_tmp_896031:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_895988();
goto next_tmp_896038;
next_tmp_896038:
goto tmp_896037;
tmp_896037:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_896040:
return tmp_731862;
}
reg_t genfunc_tmp_895988 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_895985;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + 5);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_895987;
fail_tmp_895985:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_895986;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + 5);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_895987;
fail_tmp_895986:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731900 = ref_gpr_reg_for_reading(0 + 5);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_895987:
return tmp_731876;
}
void genfunc_tmp_895950 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_895944();
goto next_tmp_895792;
next_tmp_895792:
goto tmp_895791;
tmp_895791:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_895947;
next_tmp_895947:
goto tmp_895946;
tmp_895946:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_895949:
}
reg_t genfunc_tmp_895944 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_895911 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_895911 >> 8) == 0)
field_imm = tmp_895911;
else goto fail_tmp_895910;
}
/* commit */
{
tmp_731858 = genfunc_tmp_895855();
goto next_tmp_895913;
next_tmp_895913:
goto tmp_895912;
tmp_895912:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_895943;
fail_tmp_895910:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_895935 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_895935))
field_imm = inv_maskmask(8, tmp_895935);
else goto fail_tmp_895934;
}
/* commit */
{
tmp_731075 = genfunc_tmp_895855();
goto next_tmp_895937;
next_tmp_895937:
goto tmp_895936;
tmp_895936:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_895943;
fail_tmp_895934:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_895855();
goto next_tmp_895941;
next_tmp_895941:
goto tmp_895940;
tmp_895940:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_895943:
return tmp_731142;
}
reg_t genfunc_tmp_895908 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_895877 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_895877 >> 8) == 0)
field_imm = tmp_895877;
else goto fail_tmp_895876;
}
/* commit */
{
tmp_731858 = genfunc_tmp_895855();
goto next_tmp_895879;
next_tmp_895879:
goto tmp_895878;
tmp_895878:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_895907;
fail_tmp_895876:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_895899 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_895899))
field_imm = inv_maskmask(8, tmp_895899);
else goto fail_tmp_895898;
}
/* commit */
{
tmp_731075 = genfunc_tmp_895855();
goto next_tmp_895901;
next_tmp_895901:
goto tmp_895900;
tmp_895900:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_895907;
fail_tmp_895898:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_895855();
goto next_tmp_895905;
next_tmp_895905:
goto tmp_895904;
tmp_895904:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_895907:
return tmp_731862;
}
reg_t genfunc_tmp_895855 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_895846;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_895830();
goto next_tmp_895848;
next_tmp_895848:
goto tmp_895847;
tmp_895847:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_895854;
fail_tmp_895846:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_895850;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_895830();
goto next_tmp_895852;
next_tmp_895852:
goto tmp_895851;
tmp_895851:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_895854;
fail_tmp_895850:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_895830();
goto next_tmp_895808;
next_tmp_895808:
goto tmp_895807;
tmp_895807:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_895854:
return tmp_731876;
}
reg_t genfunc_tmp_895830 (void) {
reg_t tmp_731900;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + 5);
{
tmp_731900 = genfunc_tmp_894578();
goto next_tmp_895813;
next_tmp_895813:
goto tmp_895812;
tmp_895812:
}
tmp_731897 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_895829:
return tmp_731900;
}
void genfunc_tmp_895786 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_895780();
goto next_tmp_895631;
next_tmp_895631:
goto tmp_895630;
tmp_895630:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_895783;
next_tmp_895783:
goto tmp_895782;
tmp_895782:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 7 */
}
done_tmp_895785:
}
reg_t genfunc_tmp_895780 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_895747 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_895747 >> 8) == 0)
field_imm = tmp_895747;
else goto fail_tmp_895746;
}
/* commit */
{
tmp_731858 = genfunc_tmp_895691();
goto next_tmp_895749;
next_tmp_895749:
goto tmp_895748;
tmp_895748:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_895779;
fail_tmp_895746:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_895771 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_895771))
field_imm = inv_maskmask(8, tmp_895771);
else goto fail_tmp_895770;
}
/* commit */
{
tmp_731075 = genfunc_tmp_895691();
goto next_tmp_895773;
next_tmp_895773:
goto tmp_895772;
tmp_895772:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_895779;
fail_tmp_895770:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_895691();
goto next_tmp_895777;
next_tmp_895777:
goto tmp_895776;
tmp_895776:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_895779:
return tmp_731142;
}
reg_t genfunc_tmp_895744 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_895713 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_895713 >> 8) == 0)
field_imm = tmp_895713;
else goto fail_tmp_895712;
}
/* commit */
{
tmp_731858 = genfunc_tmp_895691();
goto next_tmp_895715;
next_tmp_895715:
goto tmp_895714;
tmp_895714:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_895743;
fail_tmp_895712:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_895735 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_895735))
field_imm = inv_maskmask(8, tmp_895735);
else goto fail_tmp_895734;
}
/* commit */
{
tmp_731075 = genfunc_tmp_895691();
goto next_tmp_895737;
next_tmp_895737:
goto tmp_895736;
tmp_895736:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_895743;
fail_tmp_895734:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_895691();
goto next_tmp_895741;
next_tmp_895741:
goto tmp_895740;
tmp_895740:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_895743:
return tmp_731862;
}
reg_t genfunc_tmp_895691 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_895682;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_895666();
goto next_tmp_895684;
next_tmp_895684:
goto tmp_895683;
tmp_895683:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_895690;
fail_tmp_895682:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_895686;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_895666();
goto next_tmp_895688;
next_tmp_895688:
goto tmp_895687;
tmp_895687:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_895690;
fail_tmp_895686:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_895666();
goto next_tmp_895647;
next_tmp_895647:
goto tmp_895646;
tmp_895646:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_895690:
return tmp_731876;
}
reg_t genfunc_tmp_895666 (void) {
reg_t tmp_731900;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + 5);
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_895665:
return tmp_731900;
}
void genfunc_tmp_895625 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_895619();
goto next_tmp_895498;
next_tmp_895498:
goto tmp_895497;
tmp_895497:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_895622;
next_tmp_895622:
goto tmp_895621;
tmp_895621:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_895624:
}
reg_t genfunc_tmp_895619 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_895586 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_895586 >> 8) == 0)
field_imm = tmp_895586;
else goto fail_tmp_895585;
}
/* commit */
{
tmp_731858 = genfunc_tmp_895530();
goto next_tmp_895588;
next_tmp_895588:
goto tmp_895587;
tmp_895587:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_895618;
fail_tmp_895585:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_895610 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_895610))
field_imm = inv_maskmask(8, tmp_895610);
else goto fail_tmp_895609;
}
/* commit */
{
tmp_731075 = genfunc_tmp_895530();
goto next_tmp_895612;
next_tmp_895612:
goto tmp_895611;
tmp_895611:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_895618;
fail_tmp_895609:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_895530();
goto next_tmp_895616;
next_tmp_895616:
goto tmp_895615;
tmp_895615:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_895618:
return tmp_731142;
}
reg_t genfunc_tmp_895583 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_895552 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_895552 >> 8) == 0)
field_imm = tmp_895552;
else goto fail_tmp_895551;
}
/* commit */
{
tmp_731858 = genfunc_tmp_895530();
goto next_tmp_895554;
next_tmp_895554:
goto tmp_895553;
tmp_895553:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_895582;
fail_tmp_895551:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_895574 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_895574))
field_imm = inv_maskmask(8, tmp_895574);
else goto fail_tmp_895573;
}
/* commit */
{
tmp_731075 = genfunc_tmp_895530();
goto next_tmp_895576;
next_tmp_895576:
goto tmp_895575;
tmp_895575:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_895582;
fail_tmp_895573:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_895530();
goto next_tmp_895580;
next_tmp_895580:
goto tmp_895579;
tmp_895579:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_895582:
return tmp_731862;
}
reg_t genfunc_tmp_895530 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_895527;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + base);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_895529;
fail_tmp_895527:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_895528;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + base);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_895529;
fail_tmp_895528:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731900 = ref_gpr_reg_for_reading(0 + base);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_895529:
return tmp_731876;
}
void genfunc_tmp_895492 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_895486();
goto next_tmp_895356;
next_tmp_895356:
goto tmp_895355;
tmp_895355:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_895489;
next_tmp_895489:
goto tmp_895488;
tmp_895488:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 8 */
}
done_tmp_895491:
}
reg_t genfunc_tmp_895486 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_895453 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_895453 >> 8) == 0)
field_imm = tmp_895453;
else goto fail_tmp_895452;
}
/* commit */
{
tmp_731858 = genfunc_tmp_895397();
goto next_tmp_895455;
next_tmp_895455:
goto tmp_895454;
tmp_895454:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_895485;
fail_tmp_895452:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_895477 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_895477))
field_imm = inv_maskmask(8, tmp_895477);
else goto fail_tmp_895476;
}
/* commit */
{
tmp_731075 = genfunc_tmp_895397();
goto next_tmp_895479;
next_tmp_895479:
goto tmp_895478;
tmp_895478:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_895485;
fail_tmp_895476:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_895397();
goto next_tmp_895483;
next_tmp_895483:
goto tmp_895482;
tmp_895482:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_895485:
return tmp_731142;
}
reg_t genfunc_tmp_895450 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_895419 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_895419 >> 8) == 0)
field_imm = tmp_895419;
else goto fail_tmp_895418;
}
/* commit */
{
tmp_731858 = genfunc_tmp_895397();
goto next_tmp_895421;
next_tmp_895421:
goto tmp_895420;
tmp_895420:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 5 */
}
goto done_tmp_895449;
fail_tmp_895418:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_895441 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_895441))
field_imm = inv_maskmask(8, tmp_895441);
else goto fail_tmp_895440;
}
/* commit */
{
tmp_731075 = genfunc_tmp_895397();
goto next_tmp_895443;
next_tmp_895443:
goto tmp_895442;
tmp_895442:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 5 */
}
goto done_tmp_895449;
fail_tmp_895440:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_895397();
goto next_tmp_895447;
next_tmp_895447:
goto tmp_895446;
tmp_895446:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 5 */
}
done_tmp_895449:
return tmp_731862;
}
reg_t genfunc_tmp_895397 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_895388;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_894595();
goto next_tmp_895390;
next_tmp_895390:
goto tmp_895389;
tmp_895389:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 3 */
}
goto done_tmp_895396;
fail_tmp_895388:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_895392;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_894595();
goto next_tmp_895394;
next_tmp_895394:
goto tmp_895393;
tmp_895393:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 3 */
}
goto done_tmp_895396;
fail_tmp_895392:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_894595();
goto next_tmp_895372;
next_tmp_895372:
goto tmp_895371;
tmp_895371:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 4 */
}
done_tmp_895396:
return tmp_731876;
}
void genfunc_tmp_895350 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_895344();
goto next_tmp_895214;
next_tmp_895214:
goto tmp_895213;
tmp_895213:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_895347;
next_tmp_895347:
goto tmp_895346;
tmp_895346:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 7 */
}
done_tmp_895349:
}
reg_t genfunc_tmp_895344 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_895311 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_895311 >> 8) == 0)
field_imm = tmp_895311;
else goto fail_tmp_895310;
}
/* commit */
{
tmp_731858 = genfunc_tmp_895255();
goto next_tmp_895313;
next_tmp_895313:
goto tmp_895312;
tmp_895312:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_895343;
fail_tmp_895310:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_895335 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_895335))
field_imm = inv_maskmask(8, tmp_895335);
else goto fail_tmp_895334;
}
/* commit */
{
tmp_731075 = genfunc_tmp_895255();
goto next_tmp_895337;
next_tmp_895337:
goto tmp_895336;
tmp_895336:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_895343;
fail_tmp_895334:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_895255();
goto next_tmp_895341;
next_tmp_895341:
goto tmp_895340;
tmp_895340:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_895343:
return tmp_731142;
}
reg_t genfunc_tmp_895308 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_895277 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_895277 >> 8) == 0)
field_imm = tmp_895277;
else goto fail_tmp_895276;
}
/* commit */
{
tmp_731858 = genfunc_tmp_895255();
goto next_tmp_895279;
next_tmp_895279:
goto tmp_895278;
tmp_895278:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_895307;
fail_tmp_895276:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_895299 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_895299))
field_imm = inv_maskmask(8, tmp_895299);
else goto fail_tmp_895298;
}
/* commit */
{
tmp_731075 = genfunc_tmp_895255();
goto next_tmp_895301;
next_tmp_895301:
goto tmp_895300;
tmp_895300:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_895307;
fail_tmp_895298:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_895255();
goto next_tmp_895305;
next_tmp_895305:
goto tmp_895304;
tmp_895304:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_895307:
return tmp_731862;
}
reg_t genfunc_tmp_895255 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_895246;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_894429();
goto next_tmp_895248;
next_tmp_895248:
goto tmp_895247;
tmp_895247:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_895254;
fail_tmp_895246:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8)) goto fail_tmp_895250;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_894429();
goto next_tmp_895252;
next_tmp_895252:
goto tmp_895251;
tmp_895251:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_895254;
fail_tmp_895250:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
{
tmp_731900 = genfunc_tmp_894429();
goto next_tmp_895230;
next_tmp_895230:
goto tmp_895229;
tmp_895229:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_895254:
return tmp_731876;
}
void genfunc_tmp_895208 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_895202();
goto next_tmp_895076;
next_tmp_895076:
goto tmp_895075;
tmp_895075:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_895205;
next_tmp_895205:
goto tmp_895204;
tmp_895204:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_895207:
}
reg_t genfunc_tmp_895202 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_895169 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_895169 >> 8) == 0)
field_imm = tmp_895169;
else goto fail_tmp_895168;
}
/* commit */
{
tmp_731858 = genfunc_tmp_895113();
goto next_tmp_895171;
next_tmp_895171:
goto tmp_895170;
tmp_895170:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_895201;
fail_tmp_895168:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_895193 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_895193))
field_imm = inv_maskmask(8, tmp_895193);
else goto fail_tmp_895192;
}
/* commit */
{
tmp_731075 = genfunc_tmp_895113();
goto next_tmp_895195;
next_tmp_895195:
goto tmp_895194;
tmp_895194:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_895201;
fail_tmp_895192:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_895113();
goto next_tmp_895199;
next_tmp_895199:
goto tmp_895198;
tmp_895198:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_895201:
return tmp_731142;
}
reg_t genfunc_tmp_895166 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_895135 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_895135 >> 8) == 0)
field_imm = tmp_895135;
else goto fail_tmp_895134;
}
/* commit */
{
tmp_731858 = genfunc_tmp_895113();
goto next_tmp_895137;
next_tmp_895137:
goto tmp_895136;
tmp_895136:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_895165;
fail_tmp_895134:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_895157 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_895157))
field_imm = inv_maskmask(8, tmp_895157);
else goto fail_tmp_895156;
}
/* commit */
{
tmp_731075 = genfunc_tmp_895113();
goto next_tmp_895159;
next_tmp_895159:
goto tmp_895158;
tmp_895158:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_895165;
fail_tmp_895156:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_895113();
goto next_tmp_895163;
next_tmp_895163:
goto tmp_895162;
tmp_895162:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_895165:
return tmp_731862;
}
reg_t genfunc_tmp_895113 (void) {
reg_t tmp_731876;
/* ADDQ_IMM */
{
word_5 tmp_731893;
word_5 field_rc;
word_5 tmp_731894;
word_5 field_ra;
word_64 tmp_731896;
word_8 field_imm;
tmp_731896 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_895098 = tmp_731896;
if ((tmp_895098 >> 8) == 0)
field_imm = tmp_895098;
else goto fail_tmp_895097;
}
/* commit */
tmp_731894 = ref_gpr_reg_for_reading(0 + rm);
tmp_731893 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731893;
field_ra = tmp_731894;
emit(COMPOSE_ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731894);
/* can fail: T   num insns: 1 */
}
goto done_tmp_895112;
fail_tmp_895097:
/* LDA */
{
word_5 tmp_731397;
word_5 field_ra;
word_5 tmp_731398;
word_5 field_rb;
word_64 tmp_731400;
word_16 field_memory_disp;
tmp_731400 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_895106 = tmp_731400;
if ((tmp_895106 >> 16) == 0xFFFFFFFFFFFF || (tmp_895106 >> 16) == 0)
field_memory_disp = (tmp_895106 & 0xFFFF);
else goto fail_tmp_895105;
}
/* commit */
tmp_731398 = ref_gpr_reg_for_reading(0 + rm);
tmp_731397 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731397;
field_rb = tmp_731398;
emit(COMPOSE_LDA(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731398);
/* can fail: T   num insns: 1 */
}
goto done_tmp_895112;
fail_tmp_895105:
/* LDAH */
{
word_5 tmp_731393;
word_5 field_ra;
word_5 tmp_731394;
word_5 field_rb;
word_64 tmp_731396;
word_16 field_memory_disp;
tmp_731396 = ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8);
{
word_64 tmp_895110 = tmp_731396;
if ((tmp_895110 & 0xFFFF) == 0)
{
word_64 tmp_895111 = (tmp_895110 >> 16);
if ((tmp_895111 >> 16) == 0xFFFFFFFFFFFF || (tmp_895111 >> 16) == 0)
field_memory_disp = (tmp_895111 & 0xFFFF);
else goto fail_tmp_895109;
}
else goto fail_tmp_895109;
}
/* commit */
tmp_731394 = ref_gpr_reg_for_reading(0 + rm);
tmp_731393 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731393;
field_rb = tmp_731394;
emit(COMPOSE_LDAH(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731394);
/* can fail: T   num insns: 1 */
}
goto done_tmp_895112;
fail_tmp_895109:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + rm);
tmp_731900 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731900, ((disp8 & 0x80) ? ((word_64)disp8 | 0xFFFFFFFFFFFFFF00) : (word_64)disp8));
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_895112:
return tmp_731876;
}
void genfunc_tmp_895067 (void) {
/* STL */
{
word_5 field_rb;
word_64 tmp_731143;
word_16 field_memory_disp;
word_5 tmp_731145;
word_5 field_ra;
tmp_731143 = ((word_64)disp32);
field_rb = 31;
{
word_64 tmp_895062 = tmp_731143;
if ((tmp_895062 >> 16) == 0xFFFFFFFFFFFF || (tmp_895062 >> 16) == 0)
field_memory_disp = (tmp_895062 & 0xFFFF);
else goto fail_tmp_895061;
}
/* commit */
{
tmp_731145 = genfunc_tmp_894390();
goto next_tmp_895064;
next_tmp_895064:
goto tmp_895063;
tmp_895063:
}
field_ra = tmp_731145;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731145);
/* can fail: T   num insns: 3 */
}
goto done_tmp_895066;
fail_tmp_895061:
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
tmp_731142 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731142, ((word_64)disp32));
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_895059;
next_tmp_895059:
goto tmp_895058;
tmp_895058:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_895066:
}
void genfunc_tmp_895053 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_895047();
goto next_tmp_894917;
next_tmp_894917:
goto tmp_894916;
tmp_894916:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_895050;
next_tmp_895050:
goto tmp_895049;
tmp_895049:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 7 */
}
done_tmp_895052:
}
reg_t genfunc_tmp_895047 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_895014 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_895014 >> 8) == 0)
field_imm = tmp_895014;
else goto fail_tmp_895013;
}
/* commit */
{
tmp_731858 = genfunc_tmp_894958();
goto next_tmp_895016;
next_tmp_895016:
goto tmp_895015;
tmp_895015:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_895046;
fail_tmp_895013:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_895038 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_895038))
field_imm = inv_maskmask(8, tmp_895038);
else goto fail_tmp_895037;
}
/* commit */
{
tmp_731075 = genfunc_tmp_894958();
goto next_tmp_895040;
next_tmp_895040:
goto tmp_895039;
tmp_895039:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_895046;
fail_tmp_895037:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_894958();
goto next_tmp_895044;
next_tmp_895044:
goto tmp_895043;
tmp_895043:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_895046:
return tmp_731142;
}
reg_t genfunc_tmp_895011 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_894980 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_894980 >> 8) == 0)
field_imm = tmp_894980;
else goto fail_tmp_894979;
}
/* commit */
{
tmp_731858 = genfunc_tmp_894958();
goto next_tmp_894982;
next_tmp_894982:
goto tmp_894981;
tmp_894981:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 4 */
}
goto done_tmp_895010;
fail_tmp_894979:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_895002 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_895002))
field_imm = inv_maskmask(8, tmp_895002);
else goto fail_tmp_895001;
}
/* commit */
{
tmp_731075 = genfunc_tmp_894958();
goto next_tmp_895004;
next_tmp_895004:
goto tmp_895003;
tmp_895003:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 4 */
}
goto done_tmp_895010;
fail_tmp_895001:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_894958();
goto next_tmp_895008;
next_tmp_895008:
goto tmp_895007;
tmp_895007:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 4 */
}
done_tmp_895010:
return tmp_731862;
}
reg_t genfunc_tmp_894958 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_894949;
field_ra = 31;
/* commit */
{
tmp_731242 = genfunc_tmp_894578();
goto next_tmp_894951;
next_tmp_894951:
goto tmp_894950;
tmp_894950:
}
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 2 */
}
goto done_tmp_894957;
fail_tmp_894949:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_894953;
field_ra = 31;
/* commit */
{
tmp_731210 = genfunc_tmp_894578();
goto next_tmp_894955;
next_tmp_894955:
goto tmp_894954;
tmp_894954:
}
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 2 */
}
goto done_tmp_894957;
fail_tmp_894953:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
{
tmp_731900 = genfunc_tmp_894578();
goto next_tmp_894933;
next_tmp_894933:
goto tmp_894932;
tmp_894932:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 3 */
}
done_tmp_894957:
return tmp_731876;
}
void genfunc_tmp_894911 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_894905();
goto next_tmp_894784;
next_tmp_894784:
goto tmp_894783;
tmp_894783:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_894908;
next_tmp_894908:
goto tmp_894907;
tmp_894907:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_894910:
}
reg_t genfunc_tmp_894905 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_894872 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_894872 >> 8) == 0)
field_imm = tmp_894872;
else goto fail_tmp_894871;
}
/* commit */
{
tmp_731858 = genfunc_tmp_894816();
goto next_tmp_894874;
next_tmp_894874:
goto tmp_894873;
tmp_894873:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_894904;
fail_tmp_894871:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_894896 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_894896))
field_imm = inv_maskmask(8, tmp_894896);
else goto fail_tmp_894895;
}
/* commit */
{
tmp_731075 = genfunc_tmp_894816();
goto next_tmp_894898;
next_tmp_894898:
goto tmp_894897;
tmp_894897:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_894904;
fail_tmp_894895:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_894816();
goto next_tmp_894902;
next_tmp_894902:
goto tmp_894901;
tmp_894901:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_894904:
return tmp_731142;
}
reg_t genfunc_tmp_894869 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_894838 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_894838 >> 8) == 0)
field_imm = tmp_894838;
else goto fail_tmp_894837;
}
/* commit */
{
tmp_731858 = genfunc_tmp_894816();
goto next_tmp_894840;
next_tmp_894840:
goto tmp_894839;
tmp_894839:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_894868;
fail_tmp_894837:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_894860 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_894860))
field_imm = inv_maskmask(8, tmp_894860);
else goto fail_tmp_894859;
}
/* commit */
{
tmp_731075 = genfunc_tmp_894816();
goto next_tmp_894862;
next_tmp_894862:
goto tmp_894861;
tmp_894861:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_894868;
fail_tmp_894859:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_894816();
goto next_tmp_894866;
next_tmp_894866:
goto tmp_894865;
tmp_894865:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_894868:
return tmp_731862;
}
reg_t genfunc_tmp_894816 (void) {
reg_t tmp_731876;
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731242;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_894813;
field_ra = 31;
/* commit */
tmp_731242 = ref_gpr_reg_for_reading(0 + index);
tmp_731240 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_rb = tmp_731242;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731242);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894815;
fail_tmp_894813:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 field_ra;
word_5 tmp_731210;
word_5 field_rb;
if (2 != ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32)) goto fail_tmp_894814;
field_ra = 31;
/* commit */
tmp_731210 = ref_gpr_reg_for_reading(0 + index);
tmp_731208 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_rb = tmp_731210;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731210);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894815;
fail_tmp_894814:
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_writing(-1);
emit_load_integer_64(tmp_731898, ((disp32 & 0x80000000) ? ((word_64)disp32 | 0xFFFFFFFF00000000) : (word_64)disp32));
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_894815:
return tmp_731876;
}
void genfunc_tmp_894778 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_894772();
goto next_tmp_894696;
next_tmp_894696:
goto tmp_894695;
tmp_894695:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_894775;
next_tmp_894775:
goto tmp_894774;
tmp_894774:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_894777:
}
reg_t genfunc_tmp_894772 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_894748 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_894748 >> 8) == 0)
field_imm = tmp_894748;
else goto fail_tmp_894747;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + base);
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894771;
fail_tmp_894747:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_894769 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_894769))
field_imm = inv_maskmask(8, tmp_894769);
else goto fail_tmp_894768;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + base);
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894771;
fail_tmp_894768:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + base);
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_894771:
return tmp_731142;
}
reg_t genfunc_tmp_894745 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_894723 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_894723 >> 8) == 0)
field_imm = tmp_894723;
else goto fail_tmp_894722;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + base);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894744;
fail_tmp_894722:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_894742 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_894742))
field_imm = inv_maskmask(8, tmp_894742);
else goto fail_tmp_894741;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + base);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894744;
fail_tmp_894741:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + base);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_894744:
return tmp_731862;
}
void genfunc_tmp_894690 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_894684();
goto next_tmp_894530;
next_tmp_894530:
goto tmp_894529;
tmp_894529:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_894687;
next_tmp_894687:
goto tmp_894686;
tmp_894686:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 6 */
}
done_tmp_894689:
}
reg_t genfunc_tmp_894684 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_894651 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_894651 >> 8) == 0)
field_imm = tmp_894651;
else goto fail_tmp_894650;
}
/* commit */
{
tmp_731858 = genfunc_tmp_894595();
goto next_tmp_894653;
next_tmp_894653:
goto tmp_894652;
tmp_894652:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_894683;
fail_tmp_894650:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_894675 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_894675))
field_imm = inv_maskmask(8, tmp_894675);
else goto fail_tmp_894674;
}
/* commit */
{
tmp_731075 = genfunc_tmp_894595();
goto next_tmp_894677;
next_tmp_894677:
goto tmp_894676;
tmp_894676:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_894683;
fail_tmp_894674:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_894595();
goto next_tmp_894681;
next_tmp_894681:
goto tmp_894680;
tmp_894680:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_894683:
return tmp_731142;
}
reg_t genfunc_tmp_894648 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_894617 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_894617 >> 8) == 0)
field_imm = tmp_894617;
else goto fail_tmp_894616;
}
/* commit */
{
tmp_731858 = genfunc_tmp_894595();
goto next_tmp_894619;
next_tmp_894619:
goto tmp_894618;
tmp_894618:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_894647;
fail_tmp_894616:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_894639 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_894639))
field_imm = inv_maskmask(8, tmp_894639);
else goto fail_tmp_894638;
}
/* commit */
{
tmp_731075 = genfunc_tmp_894595();
goto next_tmp_894641;
next_tmp_894641:
goto tmp_894640;
tmp_894640:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_894647;
fail_tmp_894638:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_894595();
goto next_tmp_894645;
next_tmp_894645:
goto tmp_894644;
tmp_894644:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_894647:
return tmp_731862;
}
reg_t genfunc_tmp_894595 (void) {
reg_t tmp_731876;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + base);
{
tmp_731900 = genfunc_tmp_894578();
goto next_tmp_894546;
next_tmp_894546:
goto tmp_894545;
tmp_894545:
}
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 2 */
}
done_tmp_894594:
return tmp_731876;
}
reg_t genfunc_tmp_894578 (void) {
reg_t tmp_731900;
/* EXTQH */
{
word_5 tmp_731618;
word_5 field_rc;
word_5 tmp_731619;
word_5 field_ra;
word_5 field_rb;
if (64 != ((word_64)scale)) goto fail_tmp_894559;
field_rb = 31;
/* commit */
tmp_731619 = ref_gpr_reg_for_reading(0 + index);
tmp_731618 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731618;
field_ra = tmp_731619;
emit(COMPOSE_EXTQH(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731619);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894577;
fail_tmp_894559:
/* EXTQH_IMM */
{
word_5 tmp_731614;
word_5 field_rc;
word_5 tmp_731615;
word_5 field_ra;
word_64 tmp_731617;
word_8 field_imm;
tmp_731617 = ((word_64)scale);
{
word_64 tmp_894561 = ((64 - tmp_731617) & 0xFFFFFFFFFFFFFFFF);
if (tmp_894561 % 8 == 0)
{
word_64 tmp_894562 = (tmp_894561 / 8);
if ((tmp_894562 & 7) == tmp_894562)
{
word_64 tmp_894563 = tmp_894562;
if ((tmp_894563 >> 8) == 0)
field_imm = tmp_894563;
else goto fail_tmp_894560;
}
else goto fail_tmp_894560;
}
else goto fail_tmp_894560;
}
/* commit */
tmp_731615 = ref_gpr_reg_for_reading(0 + index);
tmp_731614 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731614;
field_ra = tmp_731615;
emit(COMPOSE_EXTQH_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731615);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894577;
fail_tmp_894560:
/* S4ADDQ */
{
word_5 tmp_731240;
word_5 field_rc;
word_5 tmp_731241;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_894569;
field_rb = 31;
/* commit */
tmp_731241 = ref_gpr_reg_for_reading(0 + index);
tmp_731240 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731240;
field_ra = tmp_731241;
emit(COMPOSE_S4ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731241);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894577;
fail_tmp_894569:
/* S4ADDQ_IMM */
{
word_5 tmp_731236;
word_5 field_rc;
word_5 tmp_731237;
word_5 field_ra;
word_64 tmp_731239;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_894570;
tmp_731239 = 0;
field_imm = 0;
/* commit */
tmp_731237 = ref_gpr_reg_for_reading(0 + index);
tmp_731236 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731236;
field_ra = tmp_731237;
emit(COMPOSE_S4ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731237);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894577;
fail_tmp_894570:
/* S8ADDQ */
{
word_5 tmp_731208;
word_5 field_rc;
word_5 tmp_731209;
word_5 field_ra;
word_5 field_rb;
if (2 != ((word_64)scale)) goto fail_tmp_894572;
field_rb = 31;
/* commit */
tmp_731209 = ref_gpr_reg_for_reading(0 + index);
tmp_731208 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731208;
field_ra = tmp_731209;
emit(COMPOSE_S8ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731209);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894577;
fail_tmp_894572:
/* S8ADDQ_IMM */
{
word_5 tmp_731204;
word_5 field_rc;
word_5 tmp_731205;
word_5 field_ra;
word_64 tmp_731207;
word_8 field_imm;
if (2 != ((word_64)scale)) goto fail_tmp_894573;
tmp_731207 = 0;
field_imm = 0;
/* commit */
tmp_731205 = ref_gpr_reg_for_reading(0 + index);
tmp_731204 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731204;
field_ra = tmp_731205;
emit(COMPOSE_S8ADDQ_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731205);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894577;
fail_tmp_894573:
/* SLL */
{
word_5 tmp_731176;
word_5 field_rc;
word_5 tmp_731177;
word_5 field_ra;
word_5 field_rb;
if (0 != ((word_64)scale)) goto fail_tmp_894574;
field_rb = 31;
/* commit */
tmp_731177 = ref_gpr_reg_for_reading(0 + index);
tmp_731176 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731176;
field_ra = tmp_731177;
emit(COMPOSE_SLL(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731177);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894577;
fail_tmp_894574:
/* SLL_IMM */
{
word_5 tmp_731172;
word_5 field_rc;
word_5 tmp_731173;
word_5 field_ra;
word_64 tmp_731175;
word_8 field_imm;
tmp_731175 = ((word_64)scale);
field_imm = tmp_731175;
/* commit */
tmp_731173 = ref_gpr_reg_for_reading(0 + index);
tmp_731172 = tmp_731900 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731172;
field_ra = tmp_731173;
emit(COMPOSE_SLL_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731173);
/* can fail: NIL   num insns: 1 */
}
done_tmp_894577:
return tmp_731900;
}
void genfunc_tmp_894524 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_894518();
goto next_tmp_894399;
next_tmp_894399:
goto tmp_894398;
tmp_894398:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_894521;
next_tmp_894521:
goto tmp_894520;
tmp_894520:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 5 */
}
done_tmp_894523:
}
reg_t genfunc_tmp_894518 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_894485 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_894485 >> 8) == 0)
field_imm = tmp_894485;
else goto fail_tmp_894484;
}
/* commit */
{
tmp_731858 = genfunc_tmp_894429();
goto next_tmp_894487;
next_tmp_894487:
goto tmp_894486;
tmp_894486:
}
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_894517;
fail_tmp_894484:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_894509 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_894509))
field_imm = inv_maskmask(8, tmp_894509);
else goto fail_tmp_894508;
}
/* commit */
{
tmp_731075 = genfunc_tmp_894429();
goto next_tmp_894511;
next_tmp_894511:
goto tmp_894510;
tmp_894510:
}
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_894517;
fail_tmp_894508:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_894429();
goto next_tmp_894515;
next_tmp_894515:
goto tmp_894514;
tmp_894514:
}
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_894517:
return tmp_731142;
}
reg_t genfunc_tmp_894482 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_894451 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_894451 >> 8) == 0)
field_imm = tmp_894451;
else goto fail_tmp_894450;
}
/* commit */
{
tmp_731858 = genfunc_tmp_894429();
goto next_tmp_894453;
next_tmp_894453:
goto tmp_894452;
tmp_894452:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 2 */
}
goto done_tmp_894481;
fail_tmp_894450:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_894473 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_894473))
field_imm = inv_maskmask(8, tmp_894473);
else goto fail_tmp_894472;
}
/* commit */
{
tmp_731075 = genfunc_tmp_894429();
goto next_tmp_894475;
next_tmp_894475:
goto tmp_894474;
tmp_894474:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 2 */
}
goto done_tmp_894481;
fail_tmp_894472:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_894429();
goto next_tmp_894479;
next_tmp_894479:
goto tmp_894478;
tmp_894478:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 2 */
}
done_tmp_894481:
return tmp_731862;
}
reg_t genfunc_tmp_894429 (void) {
reg_t tmp_731876;
/* ADDQ */
{
word_5 tmp_731897;
word_5 field_rc;
word_5 tmp_731898;
word_5 field_ra;
word_5 tmp_731900;
word_5 field_rb;
/* commit */
tmp_731898 = ref_gpr_reg_for_reading(0 + base);
tmp_731900 = ref_gpr_reg_for_reading(0 + index);
tmp_731897 = tmp_731876 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731897;
field_ra = tmp_731898;
field_rb = tmp_731900;
emit(COMPOSE_ADDQ(field_ra, field_rb, field_rc));
unref_gpr_reg(tmp_731900);
unref_gpr_reg(tmp_731898);
/* can fail: NIL   num insns: 1 */
}
done_tmp_894428:
return tmp_731876;
}
void genfunc_tmp_894393 (void) {
/* STL */
{
word_5 tmp_731142;
word_5 field_rb;
word_64 tmp_731144;
word_16 field_memory_disp;
word_5 tmp_731146;
word_5 field_ra;
tmp_731144 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731142 = genfunc_tmp_894153();
goto next_tmp_894077;
next_tmp_894077:
goto tmp_894076;
tmp_894076:
}
{
tmp_731146 = genfunc_tmp_894390();
goto next_tmp_894156;
next_tmp_894156:
goto tmp_894155;
tmp_894155:
}
field_rb = tmp_731142;
field_ra = tmp_731146;
emit(COMPOSE_STL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731146);
unref_gpr_reg(tmp_731142);
/* can fail: NIL   num insns: 4 */
}
done_tmp_894392:
}
reg_t genfunc_tmp_894390 (void) {
reg_t tmp_731146;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_894270();
goto next_tmp_894367;
next_tmp_894367:
goto tmp_894366;
tmp_894366:
}
tmp_731381 = tmp_731146 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_894389:
return tmp_731146;
}
reg_t genfunc_tmp_894342 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_894311 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_894311 >> 8) == 0)
field_imm = tmp_894311;
else goto fail_tmp_894310;
}
/* commit */
{
tmp_731858 = genfunc_tmp_894273();
goto next_tmp_894313;
next_tmp_894313:
goto tmp_894312;
tmp_894312:
}
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 3 */
}
goto done_tmp_894341;
fail_tmp_894310:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_894333 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_894333))
field_imm = inv_maskmask(8, tmp_894333);
else goto fail_tmp_894332;
}
/* commit */
{
tmp_731075 = genfunc_tmp_894273();
goto next_tmp_894335;
next_tmp_894335:
goto tmp_894334;
tmp_894334:
}
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 3 */
}
goto done_tmp_894341;
fail_tmp_894332:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
{
tmp_731067 = genfunc_tmp_894273();
goto next_tmp_894339;
next_tmp_894339:
goto tmp_894338;
tmp_894338:
}
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 3 */
}
done_tmp_894341:
return tmp_731862;
}
reg_t genfunc_tmp_894273 (void) {
reg_t tmp_731898;
/* LDL */
{
word_5 tmp_731381;
word_5 field_ra;
word_5 tmp_731382;
word_5 field_rb;
word_64 tmp_731384;
word_16 field_memory_disp;
tmp_731384 = 0;
field_memory_disp = 0;
/* commit */
{
tmp_731382 = genfunc_tmp_894270();
goto next_tmp_894194;
next_tmp_894194:
goto tmp_894193;
tmp_894193:
}
tmp_731381 = tmp_731898 = ref_gpr_reg_for_writing(-1);
field_ra = tmp_731381;
field_rb = tmp_731382;
emit(COMPOSE_LDL(field_ra, field_memory_disp, field_rb));
unref_gpr_reg(tmp_731382);
/* can fail: NIL   num insns: 2 */
}
done_tmp_894272:
return tmp_731898;
}
reg_t genfunc_tmp_894270 (void) {
reg_t tmp_731382;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_894246 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_894246 >> 8) == 0)
field_imm = tmp_894246;
else goto fail_tmp_894245;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + 4);
tmp_731857 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894269;
fail_tmp_894245:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_894267 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_894267))
field_imm = inv_maskmask(8, tmp_894267);
else goto fail_tmp_894266;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + 4);
tmp_731074 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894269;
fail_tmp_894266:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + 4);
tmp_731066 = tmp_731382 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_894269:
return tmp_731382;
}
reg_t genfunc_tmp_894243 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_894221 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_894221 >> 8) == 0)
field_imm = tmp_894221;
else goto fail_tmp_894220;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + 4);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894242;
fail_tmp_894220:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_894240 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_894240))
field_imm = inv_maskmask(8, tmp_894240);
else goto fail_tmp_894239;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + 4);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894242;
fail_tmp_894239:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + 4);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_894242:
return tmp_731862;
}
reg_t genfunc_tmp_894153 (void) {
reg_t tmp_731142;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_894129 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_894129 >> 8) == 0)
field_imm = tmp_894129;
else goto fail_tmp_894128;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + rm);
tmp_731857 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894152;
fail_tmp_894128:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_894150 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_894150))
field_imm = inv_maskmask(8, tmp_894150);
else goto fail_tmp_894149;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + rm);
tmp_731074 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894152;
fail_tmp_894149:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + rm);
tmp_731066 = tmp_731142 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_894152:
return tmp_731142;
}
reg_t genfunc_tmp_894126 (void) {
reg_t tmp_731862;
/* BIC_IMM */
{
word_5 tmp_731857;
word_5 field_rc;
word_5 tmp_731858;
word_5 field_ra;
word_64 tmp_731860;
word_8 field_imm;
tmp_731860 = 4294967295;
{
word_64 tmp_894104 = (~tmp_731860 & 0xFFFFFFFFFFFFFFFF);
if ((tmp_894104 >> 8) == 0)
field_imm = tmp_894104;
else goto fail_tmp_894103;
}
/* commit */
tmp_731858 = ref_gpr_reg_for_reading(0 + rm);
tmp_731857 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731857;
field_ra = tmp_731858;
emit(COMPOSE_BIC_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731858);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894125;
fail_tmp_894103:
/* ZAP_IMM */
{
word_5 tmp_731074;
word_5 field_rc;
word_5 tmp_731075;
word_5 field_ra;
word_64 tmp_731077;
word_8 field_imm;
tmp_731077 = 4294967295;
{
word_64 tmp_894123 = (~tmp_731077 & 0xFFFFFFFFFFFFFFFF);
if (can_inv_maskmask(8, tmp_894123))
field_imm = inv_maskmask(8, tmp_894123);
else goto fail_tmp_894122;
}
/* commit */
tmp_731075 = ref_gpr_reg_for_reading(0 + rm);
tmp_731074 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731074;
field_ra = tmp_731075;
emit(COMPOSE_ZAP_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731075);
/* can fail: T   num insns: 1 */
}
goto done_tmp_894125;
fail_tmp_894122:
/* ZAPNOT_IMM */
{
word_5 tmp_731066;
word_5 field_rc;
word_5 tmp_731067;
word_5 field_ra;
word_64 tmp_731069;
word_8 field_imm;
tmp_731069 = 4294967295;
field_imm = 15;
/* commit */
tmp_731067 = ref_gpr_reg_for_reading(0 + rm);
tmp_731066 = tmp_731862 = ref_gpr_reg_for_writing(-1);
field_rc = tmp_731066;
field_ra = tmp_731067;
emit(COMPOSE_ZAPNOT_IMM(field_ra, field_imm, field_rc));
unref_gpr_reg(tmp_731067);
/* can fail: NIL   num insns: 1 */
}
done_tmp_894125:
return tmp_731862;
}
