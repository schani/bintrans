void liveness_i386_insn (interpreter_t *intp, word_32 *_live_EFLAGS, word_32 *_killed_EFLAGS) {
word_8 opcode, opcode2;
word_32 pc, next_pc;
int prefix_flags;
word_8 mod, reg, rm, sib_scale, sib_index, sib_base, disp8, opcode_reg, imm8;
word_16 imm16;
word_32 disp32, imm32;
word_32 live_EFLAGS = *_live_EFLAGS, killed_EFLAGS = 0;
i386_decode_opcode(intp, &prefix_flags, &opcode, &opcode2);
switch (opcode) {
case 51 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 50 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (reg) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
}
break;
case 49 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 48 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 53 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 52 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 135 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
live_EFLAGS |= 0;
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 134 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
live_EFLAGS |= 0;
switch (reg) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
live_EFLAGS |= 0;
}
break;
case 144 :
case 145 :
case 146 :
case 147 :
case 148 :
case 149 :
case 150 :
case 151 :
opcode_reg = opcode - 144;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 133 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 132 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 169 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 168 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 43 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
}
break;
case 42 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (reg) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
}
break;
case 41 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
}
break;
case 40 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
}
break;
case 45 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
}
break;
case 44 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
}
break;
case 171 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 170 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 27 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
}
break;
case 26 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (reg) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
}
break;
case 25 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
}
break;
case 24 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
}
break;
case 29 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
}
break;
case 28 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
}
break;
case 209 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
default :
assert(0);
}
}
break;
case 192 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
default :
assert(0);
}
}
break;
case 210 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
default :
assert(0);
}
}
break;
case 208 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
default :
assert(0);
}
}
break;
case 193 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
live_EFLAGS |= 0;
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
live_EFLAGS |= 0;
}
break;
default :
assert(0);
}
}
break;
case 211 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0x1| 0);
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| 0x1);
}
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| 0x1);
}
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
live_EFLAGS |= 0;
}
break;
default :
assert(0);
}
}
break;
case 194 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 195 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 242 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 174 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
/* nop */
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
{
word_32 last_live, save_live = 0;
do {
last_live = save_live;
save_live = live_EFLAGS;
live_EFLAGS |= (0 | (0 | 0x40| 0)| 0);
live_EFLAGS |= 0;
live_EFLAGS |= 0;
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
live_EFLAGS |= save_live;
} while (last_live != live_EFLAGS);
}
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= 0;
}
break;
default :
switch (reg) {
default :
assert(0);
}
}
break;
case 243 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 171 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
/* nop */
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
{
word_32 last_live, save_live = 0;
do {
last_live = save_live;
save_live = live_EFLAGS;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= save_live;
} while (last_live != live_EFLAGS);
}
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= 0;
}
break;
case 170 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
/* nop */
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
{
word_32 last_live, save_live = 0;
do {
last_live = save_live;
save_live = live_EFLAGS;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= save_live;
} while (last_live != live_EFLAGS);
}
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= 0;
}
break;
case 165 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
/* nop */
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
{
word_32 last_live, save_live = 0;
do {
last_live = save_live;
save_live = live_EFLAGS;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= save_live;
} while (last_live != live_EFLAGS);
}
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= 0;
}
break;
case 164 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
/* nop */
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
{
word_32 last_live, save_live = 0;
do {
last_live = save_live;
save_live = live_EFLAGS;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= save_live;
} while (last_live != live_EFLAGS);
}
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= 0;
}
break;
case 166 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
/* nop */
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
{
word_32 last_live, save_live = 0;
do {
last_live = save_live;
save_live = live_EFLAGS;
live_EFLAGS |= (0 | (0 | 0x40| 0)| 0);
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= save_live;
} while (last_live != live_EFLAGS);
}
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= 0;
}
break;
default :
switch (reg) {
default :
assert(0);
}
}
break;
case 104 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 106 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 80 :
case 81 :
case 82 :
case 83 :
case 84 :
case 85 :
case 86 :
case 87 :
opcode_reg = opcode - 80;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 88 :
case 89 :
case 90 :
case 91 :
case 92 :
case 93 :
case 94 :
case 95 :
opcode_reg = opcode - 88;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 143 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
live_EFLAGS |= 0;
}
break;
default :
assert(0);
}
}
break;
case 11 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 10 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (reg) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
}
break;
case 9 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 8 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 13 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 12 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 199 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
default :
assert(0);
}
}
break;
case 198 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
default :
assert(0);
}
}
break;
case 184 :
case 185 :
case 186 :
case 187 :
case 188 :
case 189 :
case 190 :
case 191 :
opcode_reg = opcode - 184;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 176 :
case 177 :
case 178 :
case 179 :
case 180 :
case 181 :
case 182 :
case 183 :
opcode_reg = opcode - 176;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (opcode_reg) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
}
break;
case 163 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 161 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 139 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 138 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (reg) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
}
break;
case 137 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 136 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 141 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 120 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x80| 0);
}
break;
case 122 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x4| 0);
}
break;
case 121 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x80| 0);
}
break;
case 123 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x4| 0);
}
break;
case 117 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x40| 0);
}
break;
case 233 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 235 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 126 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | (0 | 0x40| 0)| (0 | (0 | 0x80| 0x800)));
}
break;
case 124 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
/* nop */
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x80| 0x800);
}
break;
case 125 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x80| 0x800);
}
break;
case 127 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | (0 | 0x40| 0)| (0 | 0x80| 0x800));
}
break;
case 116 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x40| 0);
}
break;
case 118 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | (0 | 0x1| 0)| (0 | 0x40| 0));
}
break;
case 114 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x1| 0);
}
break;
case 115 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x1| 0);
}
break;
case 119 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | (0 | 0x1| 0)| (0 | 0x40| 0));
}
break;
case 205 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
live_EFLAGS = 4294967295;
}
break;
case 64 :
case 65 :
case 66 :
case 67 :
case 68 :
case 69 :
case 70 :
case 71 :
opcode_reg = opcode - 64;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
}
break;
case 105 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0x1;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0x1;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 221 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 232 :
case 233 :
case 234 :
case 235 :
case 236 :
case 237 :
case 238 :
case 239 :
opcode_reg = opcode2 - 232;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 224 :
case 225 :
case 226 :
case 227 :
case 228 :
case 229 :
case 230 :
case 231 :
opcode_reg = opcode2 - 224;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 216 :
case 217 :
case 218 :
case 219 :
case 220 :
case 221 :
case 222 :
case 223 :
opcode_reg = opcode2 - 216;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 208 :
case 209 :
case 210 :
case 211 :
case 212 :
case 213 :
case 214 :
case 215 :
opcode_reg = opcode2 - 208;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
default :
assert(opcode2 <= 0xbf);
switch (reg) {
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
default :
assert(0);
}
}
break;
case 219 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
assert(opcode2 <= 0xbf);
switch (reg) {
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
default :
assert(0);
}
}
break;
case 223 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 224 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
default :
assert(opcode2 <= 0xbf);
switch (reg) {
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
default :
assert(0);
}
}
break;
case 218 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 233 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
default :
assert(opcode2 <= 0xbf);
switch (reg) {
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
default :
assert(0);
}
}
break;
case 222 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 224 :
case 225 :
case 226 :
case 227 :
case 228 :
case 229 :
case 230 :
case 231 :
opcode_reg = opcode2 - 224;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 240 :
case 241 :
case 242 :
case 243 :
case 244 :
case 245 :
case 246 :
case 247 :
opcode_reg = opcode2 - 240;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 248 :
case 249 :
case 250 :
case 251 :
case 252 :
case 253 :
case 254 :
case 255 :
opcode_reg = opcode2 - 248;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 217 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 192 :
case 193 :
case 194 :
case 195 :
case 196 :
case 197 :
case 198 :
case 199 :
opcode_reg = opcode2 - 192;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
default :
assert(opcode2 <= 0xbf);
switch (reg) {
default :
assert(0);
}
}
break;
case 220 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
default :
assert(opcode2 <= 0xbf);
switch (reg) {
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
default :
assert(0);
}
}
break;
case 216 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 224 :
case 225 :
case 226 :
case 227 :
case 228 :
case 229 :
case 230 :
case 231 :
opcode_reg = opcode2 - 224;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 240 :
case 241 :
case 242 :
case 243 :
case 244 :
case 245 :
case 246 :
case 247 :
opcode_reg = opcode2 - 240;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 216 :
case 217 :
case 218 :
case 219 :
case 220 :
case 221 :
case 222 :
case 223 :
opcode_reg = opcode2 - 216;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 208 :
case 209 :
case 210 :
case 211 :
case 212 :
case 213 :
case 214 :
case 215 :
opcode_reg = opcode2 - 208;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
default :
assert(opcode2 <= 0xbf);
switch (reg) {
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
default :
assert(0);
}
}
break;
case 217 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 241 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
/* not implemented */
}
break;
case 200 :
case 201 :
case 202 :
case 203 :
case 204 :
case 205 :
case 206 :
case 207 :
opcode_reg = opcode2 - 200;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 253 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
/* not implemented */
}
break;
case 252 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
/* not implemented */
}
break;
case 238 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 232 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 192 :
case 193 :
case 194 :
case 195 :
case 196 :
case 197 :
case 198 :
case 199 :
opcode_reg = opcode2 - 192;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 224 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 240 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
/* not implemented */
}
break;
default :
assert(opcode2 <= 0xbf);
switch (reg) {
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
default :
assert(0);
}
}
break;
case 247 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0x1;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if ((16 == 32)) {
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0x1;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
} else {
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0x1;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
} else {
next_pc = pc = intp->pc;
if ((32 == 32)) {
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0x1;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
} else {
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0x1;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
default :
assert(0);
}
}
break;
case 246 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0x1;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0x1;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
default :
assert(0);
}
}
break;
case 72 :
case 73 :
case 74 :
case 75 :
case 76 :
case 77 :
case 78 :
case 79 :
opcode_reg = opcode - 72;
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
}
break;
case 254 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
}
break;
default :
assert(0);
}
}
break;
case 59 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 58 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 57 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 56 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 61 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 60 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 252 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x400) {
killed_EFLAGS |= 0x400;
live_EFLAGS &= ~0x400;
live_EFLAGS |= 0;
}
}
break;
case 153 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= 0;
}
break;
case 152 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 255 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
default :
assert(0);
}
}
break;
case 232 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
live_EFLAGS |= 0;
}
break;
case 15 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
case 172 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (((imm8 & 31) == 0)) {
/* nop */
} else {
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
}
break;
case 173 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
/* nop */
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= 0;
}
break;
case 164 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (((imm8 & 31) == 0)) {
/* nop */
} else {
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
}
break;
case 165 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
/* nop */
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= 0;
}
break;
case 149 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= (0 | (0 | 0x40)| 0);
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 151 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= ((0 | (0 | 0x1| 0)| (0 | 0x40| 0)) | 0 | 0);
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 146 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= (0 | 0x1);
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 158 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= ((0 | (0 | 0x40| 0)| (0 | (0 | 0x80| 0x800))) | 0 | 0);
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 156 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= ((0 | 0x80| 0x800) | 0 | 0);
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 159 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= ((0 | (0 | 0x40| 0)| (0 | 0x80| 0x800)) | 0 | 0);
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 148 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= (0 | 0x40);
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 150 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= ((0 | (0 | 0x1| 0)| (0 | 0x40| 0)) | 0 | 0);
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 183 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 182 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 191 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 190 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
}
break;
case 136 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x80| 0);
}
break;
case 138 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x4| 0);
}
break;
case 137 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x80| 0);
}
break;
case 139 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x4| 0);
}
break;
case 133 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x40| 0);
}
break;
case 142 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | (0 | 0x40| 0)| (0 | (0 | 0x80| 0x800)));
}
break;
case 140 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
/* nop */
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x80| 0x800);
}
break;
case 141 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x80| 0x800);
}
break;
case 143 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | (0 | 0x40| 0)| (0 | 0x80| 0x800));
}
break;
case 132 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x40| 0);
}
break;
case 134 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | (0 | 0x1| 0)| (0 | 0x40| 0));
}
break;
case 130 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x1| 0);
}
break;
case 131 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | 0x1| 0);
}
break;
case 135 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
{
word_32 save_killed_EFLAGS = killed_EFLAGS, tmp_killed_EFLAGS, save_live_EFLAGS = live_EFLAGS, tmp_live_EFLAGS;
killed_EFLAGS = 0;
live_EFLAGS |= 0;
tmp_live_EFLAGS = live_EFLAGS;
live_EFLAGS = save_live_EFLAGS;
tmp_killed_EFLAGS = killed_EFLAGS;
killed_EFLAGS = 0;
/* nop */
live_EFLAGS = live_EFLAGS | tmp_live_EFLAGS;
killed_EFLAGS = save_killed_EFLAGS | killed_EFLAGS | tmp_killed_EFLAGS;
}
live_EFLAGS |= (0 | (0 | 0x1| 0)| (0 | 0x40| 0));
}
break;
case 175 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0x1;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0x1;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 171 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
if ((mod == 3)) {
} else {
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 163 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
}
break;
case 189 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
} else {
next_pc = pc = intp->pc;
live_EFLAGS |= 0;
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
}
break;
default :
switch (reg) {
default :
assert(0);
}
}
break;
case 35 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 34 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (reg) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
}
break;
case 33 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 32 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 37 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 36 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 3 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
}
break;
case 2 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (reg) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
}
break;
case 1 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
}
break;
case 0 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
}
break;
case 5 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
}
break;
case 4 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
}
break;
case 19 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
}
break;
case 18 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
switch (reg) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
}
break;
case 17 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
}
break;
case 16 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
}
break;
case 131 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
}
break;
default :
assert(0);
}
}
break;
case 129 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
}
break;
default :
assert(0);
}
}
break;
case 128 :
i386_decode_modrm(intp, &opcode2, &mod, &reg, &rm);
switch (opcode2) {
default :
switch (reg) {
case 6 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 5 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
}
break;
case 3 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
}
break;
case 1 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 7 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
}
break;
case 4 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
}
break;
case 0 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= 0;
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= 0;
}
}
break;
case 2 :
i386_decode_sib(intp, opcode2, &sib_scale, &sib_index, &sib_base, &disp8, &disp32);
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
switch (mod) {
case 0: case 1: case 2: 
break;
case 3: 
switch (rm) {
case 0: case 1: case 2: case 3: 
break;
case 4: case 5: case 6: case 7: 
break;
}
break;
}
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
}
break;
default :
assert(0);
}
}
break;
case 21 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
imm16 = i386_decode_imm16(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
} else {
imm32 = i386_decode_imm32(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
}
break;
case 20 :
if (prefix_flags & I386_PREFIX_OP_SIZE_OVERRIDE) {
assert(0);
} else {
imm8 = i386_decode_imm8(intp);
next_pc = pc = intp->pc;
if (live_EFLAGS & 0x4) {
killed_EFLAGS |= 0x4;
live_EFLAGS &= ~0x4;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x40) {
killed_EFLAGS |= 0x40;
live_EFLAGS &= ~0x40;
live_EFLAGS |= 0;
}
if (live_EFLAGS & 0x80) {
killed_EFLAGS |= 0x80;
live_EFLAGS &= ~0x80;
live_EFLAGS |= 0;
}
live_EFLAGS |= (0 | 0| (0 | 0x1));
if (live_EFLAGS & 0x1) {
killed_EFLAGS |= 0x1;
live_EFLAGS &= ~0x1;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
if (live_EFLAGS & 0x800) {
killed_EFLAGS |= 0x800;
live_EFLAGS &= ~0x800;
live_EFLAGS |= (0 | 0| (0 | 0| (0 | 0x1)));
}
}
break;
default:
assert(0);
}
*_live_EFLAGS = live_EFLAGS;
*_killed_EFLAGS = killed_EFLAGS;
intp->pc = next_pc;
}
